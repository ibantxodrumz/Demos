# Excel Monitoring System - Functional System Understanding

## Purpose

The Excel Monitoring System is an operational monitoring platform implemented within Excel.

Although technically delivered through Excel and VBA, the workbook should be viewed as a business application rather than a spreadsheet.

The purpose of the system is to:

- Retrieve monitoring alerts from Azure SQL 
- Present alerts to analysts for investigation - different workstreams covered
- Support review using operational context and supporting information - via external sources
- Capture investigation outcomes - 
- Persist analyst decisions to NED - business database
- Support governance and regulatory review activities
- Support long-run monitoring and recurring behaviour analysis

The workbook itself does not generate the monitoring alerts - only retrieves via workstream

The monitoring logic exists upstream.

The workbook acts primarily as:

- Alert retrieval tool
- Investigation workspace
- Case-management platform
- Governance tool
- Persistence mechanism

---

## Application Boundaries

The Activity Log workbook is not responsible for generating monitoring alerts.

### Upstream Responsibilities

The following responsibilities exist outside the workbook:

- Monitoring rule execution
- Alert generation
- Monitoring data storage
- Azure SQL data management

### Workbook Responsibilities

The workbook is responsible for:

- Alert retrieval
- Alert investigation
- Decision capture and classification
- Case management
- Historical record management
- Long-run analysis
- Governance support

### Downstream Responsibilities

The following activities occur outside the workbook:

- STR investigations
- MIR investigations
- Formal regulatory assessment
- External reporting activities


# High-Level Architecture

```
Azure SQL Monitoring Database
                ↓
      Activity Log Workbook
                ↓
          Analyst Review
                ↓
        Decision Capture
                ↓
             Persistence to NED database
                ↓
      Long Run Analysis (triggered by statistics on workstreams)
                ↓
   Governance / STR / MIR (scalation + kpi)
```

---

# System Structure

The workbook contains two primary applications:

## Activity Log APP

Primary operational monitoring application.

Used daily by analysts.

---

## Exception Table APP

Exception management functionality exists within the workbook.

The functionality appears to be used infrequently in the current operating model.

The future role and business importance of this functionality could not be validated during this review and should be confirmed with users before being included in any replacement platform.


---

# Landing Page

The Landing Page acts as the application entry point.

Functions available:

- Activity Log APP
- Exception Table APP
- Check Credentials
- Change Credentials

Deprecated functionality:

- Modify Limits

---

# Activity Log APP

The Activity Log APP is the primary operational tool used by analysts.

The UI consists of a series of menus and controls to support analyst to carry out alert reviews

## Date filtering buttoms for workstream review - applied to all workstreams - retrieve alerts by date

- review start date
- review end date
- TCLC start date (-7 days from review start date)
- TCLC end data (-7 days from review end date)
- Import Constraints start date (From previous week Mond to Sun)
- Import Constraints end date (From previous week Mond to Sun)


## Core Monitoring Workstreams
## (click on button to access workstream functionality to review alerts by set dates)

- UMM MEL -- opens new page with filtered alert by data for this workstream
- Close IOLC -- opens new page with filtered alert by data for this workstream
- Close TCLC -- opens new page with filtered alert by data for this workstream
- IC Trading -- opens new page with filtered alert by data for this workstream
- Import Constraints -- opens new page with filtered alert by data for this workstream 

## Pack Review (extra buttoms to support analyst review)

- All Open Records -- new page opens with all records open
- Selected Open Records -- filter specific open records
- Add Data To Activity Log -- as per tigle
- Complete Data -- click to search historic data by specific date
- Long Run Statistics -- click here to open page where you can run statistics on workstreams

## Supporting Tools (extra buttoms to perfrom processes)

- PN Logs - opens new page check PN from database table by start/ end date
- Price Logs - opens new page to check PN from database table by start/ end date

## Deprecated Functionality

The following functionality exists but is explicitly marked as "Do Not Use":

- Extract By Parameters
- Extract By BMU
- Trading / ENCC Calls Data Entry
- Previous Day / Days Data
- Update Elexon Data
- Multiple Unit Analysis
- Clean Activity Log Status

The future platform should not assume these areas remain required without further validation.

---

# Monitoring Workstreams

Each monitoring workstream retrieves data independently from Azure SQL.

The workbook does to generate alerts itself - no transformations

Instead, alerts are retrieved from existing monitoring datasets 

When clicking the buttom for each workstrea a new page shows with the following:

- retrieved data
- Investigation controls/ support buttoms

## retrieved data - contains the following fiels:

- BMU ID -- from sql 
- PARTY NAME -- from sql
- PARAMETER BREACHED -- from sql
- RAISE DATE(DD-MM-YYYY) -- from sql
- START DATE(DD-MMM-YYYY HH:MM:SS) -- from sql
- END DATE(DD-MMM-YYYY HH:MM:SS) -- from sql
- PERSON RAISING	NOTIFICATION -- assinged by app/ analyst doing review
- SOURCE -- workstream id
- ACTION TAKEN -- range of actions to chose from menu/ to be filled from analyst
- ANALYSIS STATUS -- open or closed
- ANALYST REMARK -- comments to be inputed by analyst 
- REVIEW COMMENTS -- from sql
- SIGNED OFF -- only use for scalation purposes
- BY	REASON FOR STR -- same
- STR NUMBER -- same
- EVIDENCE LINK -- same 
- Key -- same


## Support buttoms for analyst

Each worksteam page has the following support buttoms on the page UI:

- Home -- go back to activity log APP menu
- Add records -- persit finihed alerts in to NED database table
- Autofill raise date (helper buttom if raise data not displayed)
- clean complete data -- cleans data from screen (make sure you have added records before) Filters records so analysts can focus on records that remain open and require discussion.
- Phisical data -- link to webpage: elexon data of that bmu on date of alert for investigation support.
- Elexon remit -- link to webpage: elexon remit data from bmu on those dates for investigation support.
- Nordpool -- link to webpage: remit data might be here instead of elexon for investigation support.
- Sonar -- link to webpage: remit data might be here instead of elexon for investigation support.
- EEX -- link to webpage:remit data might be here instead of elexon for investigation support.
- TCLC dashboard - link to internal PowerBi for investigation support.
- Price dashboard - link to internal PowerBi for investigation support.
- IC dashboard - link to internal PowerBi for investigation support.

---

## UMM MEL -- workstream 1

Purpose:

Review UMM and MEL alerts.

## Close IOLC  --- workstream 2

Purpose:

Review IOLC-related alerts.

## Close TCLC -- workstream 3

Purpose:

Review TCLC-related alerts.

## IC Trading -- workstream 4

Purpose:

Review Interconnector Trading alerts.

## Import Constraints -- workstream 5

Purpose:

Review Import Constraint alerts.

---

# Alert Retrieval Process

The monitoring workflow begins when an analyst selects a workstream.

Workflow:

```
Select monitoring dates
↓
click  Monitoring Workstream 
↓
SQL Query is triggerded with specific dates
↓
Retrieve Alerts From Azure SQL database
↓
Populate alerts page
↓
Begin Investigation

```

The workbook therefore acts as the interface between monitoring data and analyst investigating alerts.

---

# Monitoring Data Layer - page

Dedicated sheets exist for displaying raw monitoring datasets.

Confirmed raw datasets include:

- UMM MEL
- IOLC
- TCLC
- IC Trading
- Import Constraints

Each dataset has its own schema.

The monitoring streams are therefore independent datasets that leave on sql tables.

---

# Activity Log Data Model

As stated before the  investigation UI revolves around a common activity-log structure.

Common fields include:

- BMU ID
- Party Name
- Parameter Breached
- Raise Date
- Start Date
- End Date
- Person Raising
- Notification Source
- Action Taken
- Analysis Status
- Analyst Remark
- Review Comments
- Signed Off By
- Reason For STR
- STR Number
- Evidence Link

This structure acts as the standard review and persistence model for all alert investigations.

---

## Decision Capture & Classification

The workbook supports standardized analyst decision making.

The purpose of the process is to ensure alerts are reviewed consistently and can be used for:

- Alert closure -- historical 
- Ongoing monitoring 
- Long-run analysis
- Escalation identification
- STR review
- MIR review

### Inputs

Analysts use:
- Monitoring alerts
- Power BI context
- BMRS information
- REMIT information
- Operational knowledge
- Monitoring experience

### Outputs

Analysts assign a standardized Action Taken value.

Examples include:
- AutoClose
- Monitor Ongoing
- Resolved With Provider
- Escalated To STR
- Review For Potential STR
- Escalated To MIR

The selected outcome forms part of the historical investigation record and supports future long-run analysis and governance processes.

Repeated occurrences of specific outcomes may support further investigation or escalation activity.


# Analyst Daily Workflow

The workbook supports a daily operational investigation workflow.

## Step 1

Select datae & monitoring workstream.

Examples:

- UMM MEL
- IOLC
- TCLC
- IC Trading
- Import Constraints

---

## Step 2

 SQL  query is exectued and  monitoring alerts retrieved.

---

## Step 3

Aler review using support buttoms (VBA applied to buttoms so info is provided on filtered dates)

Each monitoring workstream has supporting Power BI content used during investigations.

Power BI provides additional operational context for decision

Review supporting information from Elexon BMRS and other websites if needed

BMRS is used as an external validation and investigation source.

---

## Step 4

Apply analyst judgement and classify the alert outcome

- Analysts use available evidence to classify alerts using standardized Action Taken values.
- These classifications are stored and later support long-run analysis, governance review, and escalation activities.

---

## Step 5

Assign investigation results.

Analysts populate fields such as:

- Action Taken (menu opens to assing option)
- Analysis Status (open or closed)
- Analyst remark (analyst adds comments for clarity)

---

## Step 7

Persist records.

The workbook executes a write-back query that persists investigation outcomes to a table in NED database

---

### Step 8

Review open cases.

Cases left open are reviewed during weekly team discussions.

The purpose of the review is to:
- Discuss unresolved alerts
- Determine whether further information is required
- Assign follow-up actions with market participants where necessary
- Reach a final investigation outcome

---

## Step 9

Regulatory review.

Long-run patterns and investigation outcomes may lead to:

- Further monitoring
- Regulatory review
- STR discussion
- MIR escalation

---

# Add Data To Activity Log

The workbook supports manual activity log creation.

Functions available include:

- new Records
- Physical Data
- REMIT

This allows analysts to create records that do not originate directly from monitoring datasets.

---

# Complete Data

Complete Data represents the historical activity log repository viewed through the workbook.

The sheet contains reviewed records together with investigation outcomes.

Purpose:

- Historical audit trail
- Investigation history
- Governance support
- Long-run analysis support

---

# Long Run Statistics

The workbook contains dedicated long-run statistics functionality.

Users can select:

- Source
- Start Date
- End Date

and retrieve long-run records.

---

# Long Run Analysis

Dedicated long-run analysis exists for:

- TCLC
- IOLC

Observed measures include:

- Count AutoClose
- Count Monitor Ongoing

grouped by party.

---

# Purpose Of Long Run Analysis

Current purpose:

Identify market participants that repeatedly generate monitoring alerts.

When alert volumes reach sufficient levels, analysts may initiate additional investigation activity.

Examples include:

- Long-run reviews
- Repeat behaviour investigations
- Escalation discussions

Future purpose:

In addition to investigations, long-run analysis is expected to form part of the KPI and accountability layer of a future monitoring platform.

---

# AutoClose

AutoClose exists as an investigation outcome.

AutoClose is not primarily a hidden VBA rule.

The decision is made by analysts.

Meaning:

```text
This alert does not require ongoing monitoring.
```

Once assigned, VBA processes the selected outcome as part of the workflow.

AutoClosed records continue to contribute to historical analysis and long-run statistics.

---

# Extra Supporting Investigation Sources

As stated Analysts do not rely solely on the workbook.

Supporting information regularly comes from:

## Power BI

Primary analytical investigation tool.

Each monitoring workstream has its own supporting Power BI dashboard.


---

## Elexon BMRS

Used to validate operational events and investigation context.

---

## Analyst Expertise

Domain knowledge and analyst judgement are core components of the review process.

---

# Technical Explanations

The workbook contains a Technical Explanations repository.

Fields include:

- Unit
- Company
- Parameter
- Start Date
- End Date
- Technical Explanation
- Notes

The repository contains historical contextual information.

However, analyst investigations today rely primarily on:

- Power BI
- BMRS
- External operational information
- Analyst judgement

The importance of the Technical Explanations repository appears to have reduced over time.

Its future role should be reviewed during platform design.

---

# Exception Table APP

The Exception Table APP supports exception management.

Functions include:

## Add Data

Users can create exception records.

Observed fields are the same as above

---

## View Complete Data

Allows users to review exception records.

Although not heavily used today, exception management functionality
remains available within the workbook. The future business importance
of this capability should be validated with users.

---

# Reference Data Layer 

The workbook contains reference data used throughout investigations when an analysts has to make a decision about the alerts

Examples include:

## Parameters

Examples:

- DYN_MEL
- DYN_MIL
- DYN_MNZT
- FPN_MEL
- FPN_MIL
- NOT_OK_BID_PRICE
- NOT_OK_OFFER_PRICE

---

## Actions

Examples:

- Monitor Ongoing
- Escalated To STR
- Review For Potential STR
- Escalated To MIR
- Resolved With Provider
- AutoClose

---

## Analysis Status

Examples:

- Open  --- to be reviewd on weekly meeting 
- Close --- becomes historical 
- Open: For Further Team Review --- not used much

---



# Governance And Regulatory Support

The workbook supports governance and regulatory review activities.

Capabilities include:

- Open case tracking
- Weekly case discussions
- Long-run investigations
- STR support 
- MIR support
- Audit trail maintenance

The workbook does not manage STR or MIR investigations directly.

Instead, it supports governance processes by:
- Identifying cases requiring escalation
- Recording escalation metadata
- Storing supporting references and evidence
- Providing historical investigation records

In the future this should be move to PowerBi to be viewed as the KPI layer

---

# Business Critical Dependencies

The current operating model depends on:

## Azure SQL

Primary alert source.

---

## Power BI

Primary investigation tool.

---

## BMRS

Primary external validation tool.

---

## NED

Persistence layer for investigation outcomes.

---

## Analyst Judgement

Core decision-making component of the workflow.

---

# End-To-End Workflow

```

Select monitoring dates
↓
Workstream Selection
↓
SQL Query Execution
↓
Alert Retrieval
↓
Power BI Review
↓
BMRS Review
↓
Analyst Assessment
↓
Action Taken - add comments 
↓
Analysis Status - open/ closed 
↓
Persist To NED
↓
Weekly pack review - review open cases
↓
Long Run Analysis --- periodical checks if further investigation needed
↓
Governance / STR / MIR Review if applicable
```

---

# Key Conclusion/ summary

The Excel Monitoring System is an operational investigation and governance platform.

Its primary purpose is not alert generation.

Its primary purpose is:

- Alert retrieval
- Alert review
- Decision capture
- Case management
- Governance support
- Long-run monitoring
- Persistence of analyst outcomes

The workbook should therefore be treated as a business application whose workflows and business capabilities need to be understood before deciding how they should be simplified, redesigned or replaced within a future monitoring platform.
``