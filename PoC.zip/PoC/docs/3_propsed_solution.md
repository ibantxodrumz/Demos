## Proposed Solution — Market Monitoring System Redesign

### 1. Executive Summary

We propose a full redesign of the current Excel-based monitoring system into a scalable monitoring platform.

This is not a like-for-like replacement.

It introduces:

- Azure SQL as the central operational data platform
- Backend services for data access, persistence, aggregation and integrations
- Dash as the unified operational application and analytical support layer
- Power BI for governance and reporting

The proposed solution is not intended to recreate Excel.

It is intended to provide a cleaner implementation of the existing monitoring, investigation, decision-capture and governance capabilities while removing technical limitations associated with Excel and NED.

---

### 2. Core Transformation

FROM:

Excel-based system with:

- embedded logic
- NED persistence
- fragmented workflow
- multiple investigation tools

TO:

Structured platform:

- Azure SQL as the system of record
- Backend services for data access, persistence and aggregation
- Dash for workflow, investigation and operational intelligence delivery
- Power BI for governance and reporting

---

### 3. Design Principles

#### Separation of Concerns

Clear system responsibilities:

- Data → Azure SQL
- Data access, persistence and aggregation → Backend
- Workflow → Dash
- Investigation intelligence → Dash
- Governance → Power BI

---

#### System of Record

- Azure SQL replaces NED as the operational persistence layer
- Monitoring alerts, investigation outcomes and operational monitoring data are stored centrally

---

#### Unified Application Experience

- Dash becomes the primary operational application
- Analysts investigate, review and manage alerts in one place
- Investigation intelligence is surfaced through the application

---

#### Human-In-The-Loop Design

The monitoring process remains analyst-driven.

The platform supports:

- investigation
- review
- decision capture
- escalation

while preserving analyst judgement as the core decision-making mechanism.

---

#### Incremental Transformation

The system is migrated in phases, beginning with persistence layer replacement before replacing the operational interface.

---

### 4. Architecture

Power BI (Governance)
↑

Azure SQL (System of Record)
↑

Backend Services (Data Access + Persistence + Aggregation)
↑

Dash Application (Workflow + Investigation Intelligence)
↑

Analyst

---

### 5. Core Components

#### Data Layer (Azure SQL)

Stores:

- monitoring alerts
- investigations
- decisions
- actions
- statuses
- reference data
- long-run investigation information

This becomes the system of record replacing NED.

---

#### Backend Layer

Responsible for:

- data access
- persistence
- validation
- aggregation
- audit services
- integration with supporting systems

The backend prepares operational and analytical data for Dash and prevents heavy processing from being embedded directly in the user interface.

---

#### Application Layer (Dash)

Single operational application responsible for:

- workstream selection
- alert queue
- investigation workflow
- filtering
- decision capture
- comments and evidence
- case management
- investigation intelligence
- contextual navigation

Dash becomes the primary analyst workspace.

---

#### Governance Layer (Power BI)

Responsible for:

- KPIs
- accountability reporting
- workload monitoring
- alert trends
- long-term monitoring trends
- governance reporting

Power BI is focused on governance rather than day-to-day operational workflow.

---

### 6. Business Capability Mapping

The current workbook contains a number of business capabilities.

The objective is not to recreate Excel feature-for-feature.

The objective is to ensure existing capabilities are consciously retained, simplified, redesigned or removed.

| Current Capability | Future Direction |
|----------|----------|
| UMM MEL Monitoring | Dash Workstream Module |
| IOLC Monitoring | Dash Workstream Module |
| TCLC Monitoring | Dash Workstream Module |
| IC Trading Monitoring | Dash Workstream Module |
| Import Constraints Monitoring | Dash Workstream Module |
| Activity Log | Azure SQL + Dash |
| Analyst Investigation Workflow | Dash |
| Decision Capture | Dash |
| Open Case Review | Dash |
| Long Run Statistics | Dash + Azure SQL |
| Long Run Investigation Triggers | Power BI + Dash |
| Reference Data | Azure SQL Configuration Tables |
| Exception Management | Simplified Platform Capability |
| Regulatory Review Support | Dash + Power BI |
| Investigation Intelligence | Dash |

These capabilities should be assessed individually during platform design before deciding whether they should be:

- retained
- simplified
- redesigned
- removed

---

### 7. Investigation Intelligence Strategy

Dash is not only the workflow application.

Dash is also the primary operational intelligence delivery layer used during investigations.

The objective is to provide analysts with the information required to investigate an alert without manually navigating multiple disconnected systems.

Investigation context should be surfaced directly from the alert being reviewed.

Examples include:

- workstream-specific operational analytics
- relevant historical investigation information
- supporting reference material
- operational context
- direct access to BMRS using alert-specific timestamps and metadata

Example:

Alert Selected
↓
Analytics Tab
↓
Relevant workstream dashboard displayed

Alert Selected
↓
BMRS Tab
↓
Relevant BMRS information displayed or opened using alert context

The objective is to reduce context switching and support faster, more consistent analyst decision making.

Operational long-run analysis remains part of the Dash application and is used to support alert investigations and escalation decisions.

Examples include:

- historical alerts by BMU
- historical investigation outcomes
- alert count thresholds
- repeat behaviour investigations

Power BI supports broader trend analysis, governance reporting, KPI monitoring and long-term monitoring views.

Examples include:

- alert trends over time
- workstream trends
- governance reporting
- KPI reporting
- management information

Power BI remains the governance and KPI layer, while operational intelligence should be delivered through Dash wherever practical.

---

### 8. Critical Migration Principle

The transformation must begin with persistence layer replacement.

#### Phase 1 — Remove NED

- Azure SQL becomes the operational persistence layer
- Excel stops writing to NED
- Existing workflows can continue temporarily

This establishes Azure SQL as the system of record before further migration takes place.

All later phases depend on this foundation.

---

### 9. Benefits

#### Operational Benefits

- unified analyst workflow
- reduced context switching
- improved investigation experience
- centralised decision capture
- simplified onboarding of new monitoring streams

#### Technical Benefits

- removal of Excel dependency
- removal of NED dependency
- clearer backend responsibility
- improved maintainability
- improved scalability
- improved supportability

#### Governance Benefits

- stronger auditability
- structured investigation history
- improved reporting
- clearer accountability
- enhanced long-run analysis capabilities

---

### 10. Final Outcome

A monitoring platform where:

- alerts are retrieved and managed centrally
- investigations occur within Dash
- intelligence is surfaced directly through the application
- decisions are stored in Azure SQL
- governance is handled through Power BI
- new monitoring streams can be added without increasing application complexity

The result is a platform that separates:

- data
- data access and persistence
- workflow
- governance

while providing analysts with a single operational experience.

---

### One-Line Summary

Build an Azure SQL-backed monitoring platform that unifies workflow, investigation and operational intelligence delivery within Dash, replaces NED as the persistence layer, and uses Power BI for governance and accountability.