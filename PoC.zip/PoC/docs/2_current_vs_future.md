### Market Monitoring Platform — Current vs Future State

#### Context

Market Monitoring currently relies on an Excel macro-based application that acts as the operational investigation and decision-capture platform for analysts.

The workbook does not generate monitoring alerts itself. Monitoring alerts are generated upstream and retrieved from Azure SQL database.

The workbook is currently used to:

- retrieve alerts
- support investigations
- capture analyst decisions
- persist outcomes to at table in an internal database - > not azure sql 
- support governance and regulatory review activities
- support long-run investigations

Analysts currently work across multiple tools:

- Excel
- Power BI
- Elexon BMRS
- SharePoint reference material (list of bmus, other excel files with info)

The current setup works operationally, but it is not structured as a scalable application.

It mixes:

- workflow
- analysis
- reporting
- persistence
- reference support

into a single Excel-based solution.

#### Problem Statement

The current workflow is:

- fragmented across Excel, Power BI, Elexon, and SharePoint
- hard to maintain because logic is embedded in macros, and workbook structure, as well as using VBA.
- tightly coupled to an internal business database (NED) that currently acts as the persistence layer
- operational monitoring data and investigation outcomes should be consolidated within Azure SQL
- manually intensive for analysts
- difficult to scale as new monitoring needs will emerge
- weak/ needs improvement in terms of governance, auditability, and system clarity

The core issue is that Excel is being used as a full application layer.

#### End-to-End Current System Flow

MONITORING ALERT DATA (Azure SQL)
↓
ACTIVITY LOG APPLICATION (Excel/VBA)
↓
ANALYST INVESTIGATION
(Power BI + BMRS + Analyst Judgement)
↓
DECISION CAPTURE
↓
PERSISTENCE (internal database)
↓
LONG-RUN INVESTIGATIONS
↓
GOVERNANCE & REGULATORY REVIEW

---

### Future State (To-Be)

#### Core Design Principle

The future platform must:

- separate concerns at the system level
- provide a unified experience at the user level

##### Platform Principles

The future platform should be:
- maintainable
- auditable
- scalable
- secure
- easy to extend with additional monitoring workstreams
- transparent in terms of decision traceability


#### Target System Model

Azure SQL (system of record)
↑
Backend (data access, persistence and aggregation)
↑
Dash (operational application + analystics support)
↑
Analyst

Power BI (governance layer)

#### Key Changes

- Excel is no longer the application layer
- Internal database is fully removed as a persistence layer
- Dash becomes the single operational application for:
  - alert retrieval and review
  - investigation workflow and operational intelligence
  - decision capture
  - case management (open / closed)
- Power BI becomes the governance and KPI layer
- Azure SQL becomes the system of record for monitoring alerts, investigation outcomes and operational monitoring data
- Backend services provide data access, persistence, integrations, aggregation and audit capabilities
- Dash consumes prepared operational and analytical data and remains focused on the investigation experience

#### Investigation Intelligence Strategy

Dash is not only the workflow application.

Dash is the primary operational intelligence layer used during investigations.

Only intelligence required to support analyst decision making should be presented within Dash.

Governance reporting, KPI monitoring and broader analytical reporting remain the responsibility of Power BI.

Operational long-run analysis remains part of the Dash application and is used to support alert investigations and escalation decisions.

Examples include:
- historical alerts by BMU
- historical investigation outcomes
- alert count thresholds
- repeat behaviour investigations

Power BI remains responsible for broader trend analysis, governance reporting, KPI monitoring and long-term monitoring views.

Examples include:
- alert trends over time
- workstream trends
- governance reporting
- KPI reporting
- management information

The objective is to provide analysts with a unified UI where they can both do the operational and the analytical without navigating multiple disconnected systems (also add links to external websites).

Investigation context should be surfaced directly from the alert being reviewed

Examples include:

- workstream-specific dash pages with dashboards etc that consume data from the backend filtered by dates of the review
- contextual operational information filter for specific bmu/ fuel type
- relevant historical investigation information -- dash page for historical analysis
- supporting reference material --- links to sharepoint buttom
- direct access to BMRS using alert-specific context --- links to external wesbiste (buttom on page)

Example:

Main page -> select dates

select workstream

↓
Retrive alerts
↓
Relevant workstream dashboard displayed/ access to it via buttom

↓
access to BMRS link via bottom 
↓
Relevant BMRS information displayed or opened using alert timestamps and metadata


The objective is to reduce context switching and support faster, more consistent analyst decision making.

Power BI remains the governance and KPI layer and keep some legacy well working dashboards but analytical intelligence should be delivered through Dash wherever practical.

#### Future Analyst Workflow

Open Dash app
↓
Select monitoring workstream
↓
View alert queue
↓
Select alert
↓
Review alert details
↓
Access supporting investigation context -- it should open other dash pages via buttoms per workstream
↓
Assign Action Taken
↓
Assign Analysis Status
↓
Record comments and evidence
↓
Save decision -- open/ close 
↓
if close Persist decision to azure SQL tab;e 
↓
if open Review open cases in weekely meeting pack ---> decision: close or follow up provider
↓
Support governance and long-run investigations --- page where this can be looked at + powerbi bi


##### Audit And Traceability

The future platform must maintain a complete audit trail of analyst activity.

Minimum requirements include:
- analyst identity
- decision timestamp
- Action Taken history
- Analysis Status history
- analyst comments
- governance-related metadata
- investigation evidence references

The platform should support the traceability of monitoring investigations from alert creation through to final outcome.

#### Current Business Capabilities

The current workbook provides much more capabilites that the core describe above

These capabilities should be understood and assessed during future platform design before deciding whether they should be:

- retained
- simplified
- redesigned
- removed

Capabilities currently include:

- multi-workstream monitoring
- alert retrieval from SQL
- analyst investigation workflow
- decision capture
- status management
- action management
- evidence recording
- open case review
- long-run investigations
- governance support
- regulatory escalation support
- exception management
- reference data management

The objective is not to recreate Excel feature-for-feature.

The objective is to understand existing business capabilities and then determine the most appropriate implementation within the future platform.

#### Why This Future State Is Better

- single application experience
- reduced context switching
- workflow and analysis available through a unified interface
- investigation intelligence available directly from the application
- clear separation of concerns

System responsibilities become:

- Azure SQL = operational monitoring data and investigation outcomes
- Backend = data access, persistence, aggregation and integrations
- Dash = operational application and intelligence delivery layer
- Power BI = governance and reporting

Additional benefits:

- removal of NED dependency
- SQL becomes the system of record
- improved scalability
- improved maintainability
- improved auditability
- structured decision storage and traceability
- simpler onboarding for future workstreams

---

### PoC Direction

The initial proof of concept will use the Import Constraints workstream.

#### Phase 1 — Replace NED (mandatory first step)

- remove NED/ internal database persistence 
- store decisions in azure SQL
- keep existing workflow temporarily if needed

##### Phase 1 Success Criteria

The phase is considered successful if:

- investigation outcomes can be persisted to Azure SQL
- investigation outcomes can be retrieved from Azure SQL
- historical investigation records remain accessible
- no dependency on NED exists for the selected workflow


#### Phase 2 — Dash PoC (Import Constraints)

- build alertqueu UI in Dash
- implement decision capture
- integrate analytical -- dash page with dashboards + other info
- provide unified workflow and investigation support


##### Phase 2 Success Criteria

The phase is considered successful if:

- monitoring alerts can be retrieved from Azure SQL
- analysts can review alerts through Dash
- analysts can capture Action Taken and Analysis Status
- investigation outcomes can be persisted to Azure SQL
- historical investigation information can be retrieved
- investigation context can be accessed from within the application
- the selected workstream can operate without Excel

---

### Concept Summary

The future platform:

- replaces Excel as application layer
- replaces NED as persistence layer
- centralises operational data in SQL
- provides a unified Dash-based operational application
- delivers investigation intelligence through the application
- uses Power BI for governance, accountability and KPI reporting
- reduces analyst context switching through direct access to investigation context

---

### One-Line Summary

Replace Excel and NED with a SQL-backed platform that provides a unified Dash application for investigation,
decision capture and intelligence delivery, supported by backend services and Power BI governance.
 
 