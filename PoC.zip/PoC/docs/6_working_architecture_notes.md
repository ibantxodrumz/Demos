# Market Monitoring Platform — Working Architecture Notes

## Purpose

This document captures working architecture notes for the Market Monitoring Platform PoC.

It combines:

- lessons learned from Filipos' Dashboard
- Market Monitoring platform requirements
- Dash + Azure architecture thinking
- uv adoption
- Pydantic adoption
- SQL-first design
- future team ownership considerations

This document is intentionally a working engineering note.

It is not yet an approved architecture standard.

---

## Executive Summary

This is not:

- an Excel replacement
- a dashboard

This is:

- a Market Monitoring Platform

The platform supports:

Alert
↓
Investigation
↓
Decision
↓
Persistence
↓
Governance

for multiple Market Monitoring workstreams.

---

## Success Criteria

Phase 1 success:

Import Constraints
↓
Entire workflow completed
↓
No Excel required
↓
No NED required

If analysts can perform the full Import Constraints workflow without Excel or NED, then the architecture is proven.

Additional workstreams then become migration exercises rather than complete redesign exercises.

---

## Mental Model 1 — Analyst Workspace

The future application is not a dashboard.

The application is an analyst workspace.

It contains:

- operations
- investigation intelligence
- analytical support
- governance access

The analyst should be able to complete the operational investigation workflow without relying on Excel as the application layer.

---

## Mental Model 2 — Alert Lifecycle

Alert
↓
Assigned Analyst
↓
Investigation
↓
Comments
↓
Decision
↓
Persist

Either:

Close
↓
Historical Record

Or:

Open For Discussion
↓
Weekly Review
↓
Additional Comment
↓
Final Decision
↓
Persist
↓
Close
↓
Historical Record

This lifecycle reflects the current operating model but should be validated further during detailed design.

---

## Mental Model 3 — Core Platform Concepts

The following are core business concepts in the future platform:

1. Alerts
2. Cases
3. Investigations
4. Comments
5. Decisions
6. Historical Records
7. Escalations
8. Investigation Intelligence
9. Analytical Support
10. Governance

These are business concepts, not necessarily technical layers.

The technical design should represent these concepts clearly without creating unnecessary architectural complexity.

---

## Mental Model 4 — System Architecture

ETL Pipelines
↓
Azure SQL
↓
Repositories
↓
Services
↓
Dash
↓
Analysts

Power BI
↑
Azure SQL

Everything operational writes to Azure SQL.

Power BI reads from Azure SQL for governance, KPI reporting and long-term monitoring views.

---

## What We Reuse From Filipos' Dashboard

### Keep

#### Multi-Page Structure

Examples:

- Import Constraints
- UMM
- TCLC
- IOLC
- IC Trading

Domain-based navigation is useful and should be preserved.

#### Azure Deployment Pattern

Useful existing patterns:

- Docker
- Azure Web Apps
- AAD authentication

This provides a proven deployment direction.

#### Reusable Components

Useful ideas:

- navigation
- filters
- tables
- common UI components

Avoid unnecessary duplication across pages.

#### Prepared Data Thinking

Preferred pattern:

Pipeline
↓
SQL
↓
Application

The application should consume prepared data where practical rather than performing heavy processing in the UI.

#### Analyst-Centric UX

Users think:

"I need Import Constraints"

not:

"Which table stores Import Constraints?"

This user-first navigation model is worth preserving.

---

## What We Deliberately Improve

### Eliminate Business Logic From Pages

Observed pattern to avoid:

Page
↓
Everything

Preferred pattern:

Page
↓
Service
↓
Repository
↓
Azure SQL

Pages should focus on layout, callbacks and display.

They should not directly own SQL access, persistence rules or heavy processing.

---

### Avoid Giant Files

Large page modules become difficult to maintain.

The future platform should favour:

- small modules
- single responsibility
- shared components
- reusable services
- testable functions

---

### Use Lightweight Domain Models Where Helpful

Existing analytical code may rely heavily on DataFrame-to-DataFrame transformations.

That is fine for analysis, but the application should introduce lightweight domain concepts where they improve clarity.

Examples:

- Alert
- Case
- Comment
- Decision
- Escalation

These should remain lightweight.

Avoid unnecessary inheritance, deep object hierarchies or enterprise-style domain modelling unless there is clear business value.

---

### Improve Dependency Management

Use:

- uv
- pyproject.toml
- uv.lock

from day one.

Avoid manual requirements management where possible.

---

## Technology Stack

### Core Stack

- Dash
- Azure SQL
- Docker
- AAD
- Azure Web Apps
- uv
- pytest
- black
- logging

### PoC Stack Boundary

For Phase 1, avoid introducing additional platform components unless required.

Do not introduce by default:

- FastAPI
- microservices
- message queues
- orchestration engines
- separate API hosting
- complex workflow engines

These can be reconsidered later if a real requirement emerges.

---

## Pydantic Strategy

### Principle

Use Pydantic at system boundaries.

Do not use Pydantic everywhere by default.

### Appropriate Uses

#### Configuration

Example:

    class Settings(BaseSettings):
        sql_server: str
        sql_database: str

#### Domain Models

Example:

    class Alert(BaseModel):
        alert_id: int
        workstream: str

#### Database Inputs

Example:

    class CreateCommentRequest(BaseModel):
        case_id: int
        comment: str

#### User Inputs

Examples:

- case updates
- comments
- status changes
- action changes

---

## FastAPI Decision

Current recommendation:

Do not introduce FastAPI in v1.

Reason:

The current PoC architecture only requires:

Dash
↓
Services
↓
Repositories
↓
Azure SQL

There are no current requirements for:

- multiple front-end clients
- mobile applications
- external API consumers
- microservices
- independent backend deployment

### Preferred Phase 1 Architecture

Dash
↓
Pydantic Models
↓
Services
↓
Repositories
↓
Azure SQL

This is simple, maintainable and sufficient for Phase 1.

FastAPI can be reconsidered later if there is a clear requirement for multiple consumers or stronger deployment separation.

---

## Azure SQL As System Of Record

Azure SQL is the operational system of record.

Operational data belongs in Azure SQL, including:

- alerts
- cases
- comments
- decisions
- escalations
- reference data
- historical records

There should be no operational dependency on:

- Excel
- NED

Power BI should consume persisted data from Azure SQL for governance, KPI reporting and long-term trend analysis.

---

## Core SQL Model

This is an illustrative logical model only.

Final schema design should be validated during PoC implementation.

### ALERTS

Purpose:

Incoming monitoring alert.

Possible fields:

- AlertID
- Workstream
- BMU
- Party
- Parameter
- RaiseDate
- StartDate
- EndDate
- AssignedAnalyst

---

### CASES

Purpose:

Operational investigation case.

Possible fields:

- CaseID
- AlertID
- AssignedAnalyst
- CurrentStatus
- ActionTaken
- AnalysisStatus
- CreatedDate
- UpdatedDate
- ClosedDate

---

### COMMENTS

Purpose:

Append-only investigation comments.

Possible fields:

- CommentID
- CaseID
- Author
- Comment
- CreatedDate

Important rule:

Comments should be immutable where possible.

Do not edit comments in place.

Append new comments to preserve auditability.

---

### DECISIONS

Purpose:

Structured decision history.

Possible fields:

- DecisionID
- CaseID
- Decision
- DecisionReason
- CreatedDate
- CreatedBy

Examples:

- Close
- Open For Discussion
- Monitor Ongoing
- Long-Term Review
- Escalated

---

### ESCALATIONS

Purpose:

Capture governance or regulatory escalation metadata.

Possible fields:

- EscalationID
- CaseID
- EscalationType
- ReferenceNumber
- Reason
- CreatedDate
- CreatedBy

Examples:

- STR
- MIR
- Reported To Ofgem

---

### REFERENCE DATA

Purpose:

Configurable controlled values.

Examples:

- Action Taken
- Analysis Status
- Notification Source
- Workstream
- Analysts
- Escalation Types

Principle:

Everything configurable should be stored as reference data.

Avoid hardcoding values that analysts or governance processes may need to change.

---

## Operational Rules

### Ownership

Working assumption:

An alert or case is assigned to an analyst during review.

Ownership may remain with that analyst until closure.

This assumption requires validation with users during detailed design.

---

### Weekly Review

Open alerts are discussed using an Open Alerts page.

Workflow:

Open Alerts
↓
Discussion
↓
Comment
↓
Decision
↓
Persist

The system should support weekly discussion without forcing the weekly review process to become overly formal.

---

### Updates

Working assumption:

Updates occur one alert or case at a time.

No bulk update requirement has been identified for Phase 1.

This should be validated during PoC implementation.

---

### Closed Alerts

Current assumption:

Closed alerts are considered complete and become historical records.

Re-opening requirements have not yet been validated.

Re-opening should not be designed into Phase 1 unless users confirm it is required.

---

## Dash Analytics Boundary

Dash owns operational, alert-centric analytical support.

Dash should support:

- alert-centric analytics
- decision-support analytics
- investigation analytics
- historical alerts by BMU
- historical investigation outcomes
- alert count thresholds
- repeat behaviour checks
- operational long-run analysis required during investigation

Power BI owns broader governance and portfolio-level analytics.

Power BI should support:

- KPI reporting
- governance reporting
- workload reporting
- long-term trends
- workstream trends
- management information
- accountability reporting

This boundary prevents Dash becoming a full Power BI replacement while still allowing Dash to provide the analytical support analysts need during investigations.

---

## Intelligence Layer

Purpose:

Support analyst decisions.

Not:

Replace analyst judgement.

The analyst remains responsible for the final decision.

### Intelligence Features

Dash may provide:

- workstream analytics
- alert-specific analytical support
- Power BI links
- BMRS links
- reference information
- operational context
- historical investigation information

### Explicitly Out Of Scope

The Phase 1 platform should not introduce:

- expert systems
- decision engines
- automated recommendations
- automated regulatory conclusions
- technical explanation libraries unless separately justified

---

## Power BI Strategy

Power BI remains part of the platform.

However:

Power BI = governance layer

not:

Power BI = operational workflow layer

### Dash Owns

- queues
- investigations
- comments
- open cases
- decisions
- alert-centric analytical support

### Power BI Owns

- KPIs
- team reporting
- governance
- accountability reporting
- long-term trends

---

## Security And Access Assumptions

Security requirements should be validated during detailed design.

Working assumptions for Phase 1:

- users authenticate through AAD
- the application identifies the signed-in analyst
- analyst identity is persisted with investigation activity
- access should be limited to authorised Market Monitoring users
- database access should avoid hardcoded credentials where possible
- audit fields should be captured for key user actions

Minimum audit fields should include:

- created by
- created datetime
- updated by
- updated datetime
- decision author
- decision timestamp
- comment author
- comment timestamp

---

## Configuration Strategy

Application configuration should be separated from application code.

Configuration examples:

- SQL server
- SQL database
- environment name
- logging level
- feature flags
- external link templates
- Power BI link configuration
- BMRS link configuration

Configuration should be handled through environment-specific settings rather than hardcoded values.

---

## Environment Strategy

At minimum, the platform should distinguish:

- local development
- test / development deployment
- production deployment

Phase 1 should not overcomplicate environment management, but it should avoid patterns that prevent safe promotion between environments later.

---

## Testing Strategy

Testing should focus on business-critical behaviour first.

Priority test areas:

- validation logic
- SQL repository functions
- decision persistence
- comment persistence
- action/status update logic
- historical record retrieval
- link generation utilities
- service-layer functions

Use pytest for functions.

Avoid over-investing in UI tests during Phase 1 unless a specific risk requires it.

---

## Observability And Logging

The application should include basic logging from the start.

Minimum logging areas:

- application startup
- database connection failures
- failed persistence attempts
- validation failures
- unexpected callback errors
- decision save events
- comment save events

Logs should support troubleshooting without exposing sensitive investigation content unnecessarily.

---

## Repository Structure

Suggested structure:

    src/
    ├── app.py
    │
    ├── config/
    │
    ├── pages/
    │
    ├── components/
    │
    ├── services/
    │
    ├── repositories/
    │
    ├── models/
    │
    ├── charts/
    └── utils/

---

## Layer Responsibilities

### Pages

Responsible for:

- layout
- callbacks
- display
- user interaction

Not responsible for:

- SQL access
- persistence
- heavy processing
- complex business logic

---

### Services

Responsible for:

- data preparation
- validation
- aggregation
- case lifecycle management
- decision persistence coordination
- audit support

Services should stay practical and thin.

Do not introduce a complex service layer without a clear requirement.

---

### Repositories

Responsible for:

- reads
- writes
- database calls
- query execution
- mapping SQL outputs into useful structures

Repositories should isolate SQL access from Dash pages.

---

### Models

Responsible for lightweight representations of:

- Alert
- Case
- Comment
- Decision
- Escalation

using Pydantic where useful.

Models should improve clarity and validation.

They should not introduce unnecessary complexity.

---

## Documentation Strategy

Create from day one:

    docs/
    ├── architecture/
    ├── schemas/
    ├── workflows/
    └── decisions/

Documentation should capture:

- architecture decisions
- schema decisions
- workflow assumptions
- validation findings
- known limitations

---

## ADRs To Create Immediately

### ADR-001

Use uv

### ADR-002

Azure SQL As System Of Record

### ADR-003

Dash Is Analyst Workspace

### ADR-004

Power BI Is Governance Layer

### ADR-005

Shared Lightweight Domain Model Across Workstreams

### ADR-006

Pydantic Used At System Boundaries

### ADR-007

No FastAPI In Phase 1

### ADR-008

Dash Provides Analytical Support But Does Not Replace Power BI

### ADR-009

Comments Are Append-Only Where Practical

---

## Phase 1 Scope

Only prove:

Import Constraints end-to-end.

Workflow:

Retrieve Alert
↓
Investigate
↓
Comment
↓
Persist
↓
Open For Discussion
↓
Review
↓
Close
↓
Historical Record

Using:

- Dash
- Azure SQL
- AAD
- Docker
- uv
- Pydantic
- pytest
- black

And:

- no Excel
- no NED

---

## Open Validation Questions

These are not blockers for starting the PoC, but should be validated during implementation.

1. Does ownership remain with the original analyst after weekly review?
2. Is alert reopening required after closure?
3. Are bulk updates required for any workstream?
4. Which reference data values need to be user-configurable?
5. What is the minimum audit history required for governance review?
6. Which Power BI links need to be embedded, opened or merely referenced?
7. Which BMRS / external source links can be generated from alert metadata?
8. Does Import Constraints require any workflow behaviour not shared by other workstreams?
9. What historical data must be migrated or made visible in Phase 1?
10. What level of role-based access is required beyond basic authorised access?

---

## Final Vision

Market Monitoring Platform

    ├── Workstream Queues
    ├── Investigations
    ├── Comments
    ├── Decisions
    ├── Open Alert Management
    ├── Historical Records
    ├── Escalations
    ├── Investigation Intelligence
    ├── Analytical Support
    ├── Governance Links
    └── SQL Persistence

Built using:

- Dash
- Azure SQL
- Docker
- AAD
- Azure Web Apps
- uv
- Pydantic
- pytest
- black

while deliberately:

- reusing the good ideas from Filipos' Dashboard
- avoiding architectural pain points that would become difficult to maintain as the platform grows
- keeping the Phase 1 architecture simple, practical and testable