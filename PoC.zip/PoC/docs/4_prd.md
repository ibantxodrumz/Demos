# Product Requirements Document (PRD) — Market Monitoring Platform

## 1. Objective

Design a scalable Market Monitoring platform that replaces the current Excel-based operational application and removes NED as the persistence layer.

The platform must provide a cleaner, more maintainable implementation of the existing monitoring, investigation, decision-capture and governance capabilities.

The platform should:

- replace Excel as the application layer
- remove NED as the persistence layer
- centralise operational monitoring data in Azure SQL
- provide a unified Dash-based operational application
- support analyst investigation and decision capture
- deliver operational investigation intelligence through Dash
- support governance, KPIs and accountability through Power BI
- enable incremental migration of monitoring workstreams

The objective is not to recreate Excel feature-for-feature.

The objective is to understand the current business capabilities and implement them in a simpler, more scalable and more maintainable platform.

---

## 2. Product Vision

The future platform will consist of:

- Azure SQL as the system of record for operational monitoring data, investigations, decisions and reference data
- Backend services for data access, persistence, validation, aggregation, audit support and integrations
- Dash as the unified operational application for analysts
- Power BI as the governance, KPI and accountability layer

The platform should allow analysts to:

- select a monitoring workstream
- retrieve and review alerts
- access relevant investigation intelligence
- assign actions and statuses
- record comments and evidence
- persist decisions to Azure SQL
- review open cases
- support operational long-run investigations
- support governance and regulatory review

---

## 3. Core Design Principles

### Separation of Concerns

System responsibilities should be clearly separated:

- Azure SQL = operational data and persistence
- Backend = data access, persistence, validation, aggregation, audit support and integrations
- Dash = operational workflow and operational investigation intelligence
- Power BI = governance, KPI reporting, trend analysis and accountability

---

### System of Record

Azure SQL should replace NED as the operational persistence layer.

Operational records should be stored centrally, including:

- alerts
- investigations
- decisions
- actions
- statuses
- comments
- evidence references
- reference data
- long-run investigation outputs

---

### Unified Operational Application

Dash should become the primary operational interface for analysts.

Analysts should not need to use Excel as the application layer.

Dash should support:

- alert review
- investigation workflow
- decision capture
- case management
- operational investigation intelligence
- contextual access to supporting sources

---

### Investigation Intelligence Delivery

Dash should provide access to the intelligence needed to make investigation decisions.

This may include:

- workstream-specific operational analytics
- contextual BMRS access
- historical investigation information
- alert count thresholds
- recurring BMU / party information
- supporting reference information

The objective is to reduce manual context switching and make investigation context available from the alert being reviewed.

Broader trend analysis, governance reporting, KPI monitoring and long-term monitoring views remain the responsibility of Power BI.

---

### Human-In-The-Loop Decisions

The monitoring process remains analyst-led.

The platform should support analyst judgement rather than replace it.

The platform should help analysts make better and more consistent decisions by providing:

- structured alert information
- relevant operational context
- configurable actions and statuses
- historical context
- governance visibility

---

### Incremental Migration

The platform should be delivered incrementally.

The first migration priority is to remove NED as the persistence layer.

Further workstreams and platform capabilities can then be migrated in phases.

---

## 4. Core Business Capabilities

The platform must support the current business capabilities before deciding whether each capability should be retained, simplified, redesigned or removed.

The current workbook provides the following business capabilities:

- multi-workstream monitoring
- alert retrieval from Azure SQL
- analyst investigation workflow
- alert review and decision capture
- action management
- status management
- comment capture
- evidence recording
- open case review
- operational long-run investigations
- governance support
- regulatory escalation support
- exception management
- reference data management
- investigation intelligence access

These capabilities should be assessed during platform design.

The target platform should simplify the experience where possible, but capability removal should be a conscious design decision rather than an accidental migration gap.

---

## 5. Core Workflow

The target operational workflow should support the following analyst journey:

Open Dash
↓
Select monitoring workstream
↓
View alert queue
↓
Select alert
↓
Review alert details
↓
Access supporting investigation intelligence
↓
Assign Action Taken
↓
Assign Analysis Status
↓
Record comments and evidence
↓
Save decision
↓
Persist decision to Azure SQL
↓
Review open cases
↓
Support operational long-run investigations and governance

---

## 6. Functional Requirements

### 6.1 Dash Application Requirements

Dash must support:

- monitoring workstream selection
- alert queue
- alert filtering
- alert detail view
- investigation workflow
- decision capture
- action assignment
- status assignment
- comments
- evidence references
- open case review
- investigation history
- contextual intelligence access
- multiple monitoring streams

Dash should become the primary analyst workspace.

---

### 6.2 Workstream Requirements

The platform must support multiple monitoring workstreams.

Initial and known workstreams include:

- UMM MEL
- IOLC
- TCLC
- IC Trading
- Import Constraints

Each workstream may have:

- different raw data fields
- different investigation context
- different analytical views
- different operational considerations

The platform should support workstream-specific behaviour without requiring each workstream to become a separate application.

---

### 6.3 Alert Review Requirements

The platform must allow analysts to:

- view retrieved alerts
- review alert-level details
- filter alerts by relevant criteria
- select alerts for investigation
- understand the source workstream
- identify affected BMUs, parties, parameters and time periods where available

---

### 6.4 Case Management Requirements

The platform must support case-management functionality currently represented through the activity log.

The platform must support structured capture of:

- BMU ID
- Party Name
- Parameter Breached
- Raise Date
- Start Date
- End Date
- Person Raising
- Notification Source
- Action Taken
- Analysis Status
- Analyst Remark
- Review Comments
- Signed Off By
- Reason For STR
- STR Number
- Evidence Link

The exact future data model may be simplified, but these current information elements should be considered during design.

---

### 6.5 Decision Capture Requirements

The platform must allow analysts to record investigation outcomes.

Decision capture must include:

- action taken
- analysis status
- analyst comments
- review comments
- evidence references where relevant
- regulatory information where relevant

The platform should support analyst-led outcomes such as:

- close
- monitor ongoing
- open for further team review
- AutoClose
- regulatory escalation outcomes

---

### 6.6 AutoClose Requirements

The platform must support AutoClose as an analyst outcome.

AutoClose means the alert does not require active analyst monitoring.

The platform should treat AutoClose as a structured decision outcome that can be persisted and included in historical and long-run reporting.

The platform does not need to replicate existing VBA behaviour exactly.

---

### 6.7 Investigation Intelligence Requirements

The platform must deliver operational investigation intelligence through Dash wherever practical.

Dash should provide contextual access to:

- relevant operational analytics
- relevant BMRS information
- workstream-specific analytical context
- historical investigation context
- alert count thresholds
- repeat behaviour information
- supporting reference material

Example target behaviour:

Alert Selected
↓
Analytics Button
↓
Relevant workstream dashboard or analytics view appears

Alert Selected
↓
BMRS Button
↓
Relevant BMRS page or context opens using alert metadata such as timestamps

The objective is to reduce analyst effort and improve investigation consistency.

---

### 6.8 SQL Layer Requirements

Azure SQL must act as the system of record.

Azure SQL must support storage of:

- retrieved alerts
- investigation records
- analyst decisions
- actions
- statuses
- comments
- evidence references
- reference data
- exception records
- operational long-run investigation data

Azure SQL replaces NED as the persistence layer.

---

### 6.9 Backend Requirements

Backend services must support:

- data retrieval
- persistence workflows
- validation
- aggregation
- audit services
- integration with Azure SQL
- integration with supporting external sources where required
- reusable data-access and processing patterns

The backend should prepare operational and analytical data for Dash and avoid embedding heavy processing directly in the Dash interface.

---

### 6.10 Reference Data Requirements

The platform must support configurable reference data.

Reference data includes:

- monitoring parameters
- person / analyst values
- notification sources
- action values
- analysis statuses
- regulatory categories
- STR / MIR reasons
- BMU and party reference data where required

Reference data should not be hardcoded into the application where configurability is required.

---

### 6.11 Exception Management Requirements

The current workbook includes exception management functionality.

This functionality is not heavily used today and may be simplified in the future platform.

The platform should support, at minimum:

- storing exception records
- reviewing exception records
- retaining sufficient exception information for governance and operational context

The future design should determine whether exception handling should be retained, simplified, redesigned or removed.

---

### 6.12 Open Case Review Requirements

The platform must support review of open cases.

Open cases are those requiring further discussion, monitoring or escalation.

The platform should support:

- identifying open cases
- reviewing open case details
- supporting weekly review discussions
- updating case outcomes after review

---

### 6.13 Long-Run Investigation Requirements

The platform must support operational long-run investigation capability within Dash.

Current long-run analysis is used to identify repeated alert behaviour and to support further investigation when alert volumes exceed relevant thresholds.

Dash should support operational long-run analysis required during investigations, including:

- recurring party identification
- recurring BMU identification
- historical alerts by BMU
- historical investigation outcomes
- alert count thresholds
- repeat behaviour investigations
- investigation trigger identification
- monitoring outcome analysis

Power BI should support broader long-term monitoring views, including:

- alert trends over time
- workstream trends
- KPI reporting
- governance reporting
- management information
- accountability reporting

---

### 6.14 Governance And Reporting Requirements

Power BI must support governance and reporting.

Power BI should provide:

- KPI tracking
- workload reporting
- alert trends
- workstream trends
- accountability metrics
- long-term monitoring views
- governance reporting
- management information

Power BI should not be the primary operational workflow tool.

---

### 6.15 Regulatory Review Support

The platform must support regulatory review activity.

The platform should support capture and reporting of:

- STR-related information
- MIR-related information
- regulatory categories
- escalation decisions
- investigation history
- supporting evidence references

The platform should support regulatory review workflows without attempting to automate analyst judgement.

---

### 6.16 Audit And Traceability Requirements

The platform must support auditability and traceability of analyst decisions.

The platform should record:

- analyst identity
- decision timestamp
- action taken
- analysis status
- analyst comments
- evidence references
- changes to key investigation fields
- regulatory metadata where relevant

The platform should allow historical investigation records to remain accessible and traceable after decisions are persisted.

---

## 7. Phased Delivery

### Phase 1 — Replace NED

Objective:

Remove NED as the persistence layer.

Scope:

- move decision persistence to Azure SQL
- maintain the current workflow temporarily if required
- ensure analyst decisions can be saved without NED
- prove Azure SQL can act as the system of record

Outcome:

NED dependency removed.

---

### Phase 2 — Dash PoC Using Import Constraints

Objective:

Prove the operational workflow can run through Dash for one workstream.

Scope:

- implement Import Constraints alert queue
- implement workstream selection where needed
- implement alert detail view
- implement decision capture
- integrate investigation intelligence where practical
- persist decisions to Azure SQL

Outcome:

Excel is no longer required for the selected workstream.

---

### Phase 3 — Expand Workstream Coverage

Objective:

Extend the approach to additional monitoring workstreams.

Scope:

- add further workstreams
- standardise common workflows
- preserve workstream-specific investigation context
- reuse shared platform components

Outcome:

Core monitoring workflows move progressively from Excel to the platform.

---

### Phase 4 — Governance And Long-Run Investigations

Objective:

Strengthen governance, KPI, accountability and long-run investigation capability.

Scope:

- enhance Power BI reporting
- formalise operational long-run investigation support in Dash
- improve accountability metrics
- improve governance visibility
- support regulatory review reporting

Outcome:

The platform supports both daily operations and governance oversight.

---

## 8. PoC Scope

The initial PoC should focus on Import Constraints.

Import Constraints is suitable for the PoC because:

- it is a contained workstream
- it is operationally manageable
- existing Python analytical work can be reused where relevant
- it can prove the target architecture without migrating all workstreams at once

The PoC should prove:

- Azure SQL can replace NED
- Dash can replace Excel for one operational workflow
- analysts can review alerts, access intelligence, record decisions and save outcomes
- historical investigation records can be retrieved
- analyst decisions can be audited and traced
- Power BI can reflect persisted outcomes for governance purposes

---

## 9. Success Criteria

The platform will be successful if:

- NED is removed as the persistence layer
- Excel is removed as the operational application layer
- Azure SQL becomes the system of record
- Dash becomes the operational analyst application
- analysts can complete investigations without Excel
- decisions are persisted without NED
- investigation context is accessible from Dash
- open case reviews can be supported within the platform
- operational long-run investigations are supported in Dash
- governance and KPI reporting are supported through Power BI
- monitoring workstreams can be migrated incrementally
- analyst context switching is reduced
- auditability and traceability are improved
- analyst decisions can be audited and traced
- historical investigation records remain accessible

---

## 10. Risks

Key risks include:

- replicating Excel complexity rather than simplifying the process
- overbuilding early stages
- unclear decision model
- losing existing business capabilities during migration
- migrating operational workflows before persistence is stabilised
- coupling governance and operations too tightly
- underestimating workstream-specific differences
- leaving investigation intelligence fragmented across too many tools
- insufficient reference data design
- unclear ownership of future configuration and governance processes
- unclear audit and traceability requirements
- treating Dash as a replacement for Power BI rather than as the operational application

---

## 11. Non-Goals

The platform is not intended to:

- recreate Excel feature-for-feature
- preserve deprecated workbook functionality by default
- automate analyst judgement
- replace Power BI as the governance reporting layer
- replace all external investigation sources immediately
- migrate every workstream in the first phase
- introduce a complex backend architecture without a clear requirement

---

## 12. Summary

The Market Monitoring Platform will replace Excel as the operational application layer and remove NED as the persistence layer.

The future platform will provide:

- Azure SQL-backed persistence
- backend-supported data access, validation, aggregation, audit and integration services
- Dash-based operational workflow and investigation intelligence
- Power BI-based governance and accountability reporting

The platform should preserve the important business capabilities of the current workbook while simplifying the implementation and reducing technical debt.

---

## One-Line Summary

Build an Azure SQL-backed Market Monitoring platform where Dash supports alert review, investigation intelligence and decision capture, replacing Excel and NED while Power BI provides governance, KPI and accountability reporting.