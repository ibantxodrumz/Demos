# Proof of Concept (PoC) - Market Monitoring Platform

## Objective

Prove that the Market Monitoring workflow can operate without:

- Excel as the operational application layer
- NED as the persistence layer

Using:

- Azure SQL as the system of record
- Dash as the unified operational application, investigation intelligence layer and analytical support layer
- Backend services for data access, persistence, validation, aggregation, audit support and integrations
- Power BI as the governance and KPI layer

The objective of the PoC is not to prove every platform capability.

The objective is to prove the highest-risk assumptions before broader platform delivery begins.

---

## Target Architecture (PoC)

Power BI (Governance + KPI Reporting)
↑

Azure SQL (System of Record)
↑

Backend Services (Data Access + Persistence + Aggregation + Audit Support)
↑

Dash Application (Workflow + Investigation Intelligence + Analytical Support)
↑

Analyst

---

## Core Assumptions Being Tested

The PoC is designed to validate the following assumptions:

### Assumption 1

NED can be removed as the persistence layer.

### Assumption 2

Excel is not required as the operational application layer.

### Assumption 3

Investigation workflow, investigation intelligence, analytical support and decision capture can operate within a single Dash application.

If these assumptions are proven, the target architecture becomes viable for wider rollout.

---

## Core Design Principles

### Single Operational Application

Dash becomes the operational application used by analysts.

Dash should support:

- workstream selection
- alert review
- investigation workflow
- investigation intelligence
- analytical support
- action assignment
- status assignment
- comments and evidence
- decision capture

The analyst should not require Excel to complete the selected workstream workflow.

---

### System of Record

Azure SQL replaces NED as the operational persistence layer.

Persisted operational records are stored centrally.

The PoC should prove:

- analyst decisions can be stored in Azure SQL
- analyst decisions can be retrieved from Azure SQL
- Azure SQL can serve as the operational system of record
- NED is no longer required for the selected workflow

---

### Investigation Intelligence And Analytical Support Delivered Through The Application

The PoC is not only proving workflow.

The PoC must also demonstrate that investigation intelligence and analytical support can be delivered through Dash.

Examples include:

- workstream-specific operational analytics
- contextual BMRS access
- contextual Power BI links where useful
- historical investigation information
- alert count thresholds
- repeat behaviour analysis
- supporting investigation information

The objective is to reduce analyst context switching while maintaining access to the information required to make decisions.

Dash should support alert-centric and investigation-centric analysis.

Power BI remains responsible for governance, KPI reporting, broader trend analysis and management information.

---

### Reuse Existing Logic

Existing analytical work should be reused where appropriate.

The objective is not to rebuild working analytical logic unnecessarily.

Reusable logic should be transferred into the future platform in a cleaner structure where possible.

---

## Role Of Existing Streamlit Work

The existing Streamlit application:

- provides validated analytical logic
- acts as a reference implementation
- provides insight into analytical requirements

The Streamlit application is:

- not part of the final platform architecture
- not the target operational application

Instead it should be used to:

- understand analytical requirements
- accelerate development
- transfer proven logic into the Dash application where appropriate

---

## PoC Strategy

### Phase 1 - Replace NED

Objective:

Remove NED as the persistence layer.

Activities:

- move decision persistence from NED to Azure SQL
- retain existing operational workflow temporarily if required
- validate Azure SQL persistence
- validate retrieval of persisted decisions
- validate historical investigation records remain accessible

This proves:

- Azure SQL can store investigation outcomes
- Azure SQL can retrieve investigation outcomes
- Azure SQL can replace NED as the operational persistence layer
- NED can be removed safely

Outcome:

NED dependency successfully removed for the selected workflow.

---

### Phase 2 - Dash PoC Using Import Constraints

Objective:

Prove that workflow, investigation intelligence, analytical support and decision capture can operate within Dash.

Activities:

- implement Import Constraints workstream
- implement workstream selection
- implement alert queue
- implement alert detail view
- implement investigation workflow
- implement investigation intelligence
- implement analytical support
- implement action assignment
- implement status assignment
- implement comments and evidence capture
- persist decisions directly to Azure SQL
- retrieve historical investigation records from Azure SQL
- provide governance-ready outputs for Power BI

This proves:

- Excel is no longer required for the selected workstream
- workflow, investigation and analytical support can coexist in one application
- operational intelligence can be surfaced within the application
- analysts can operate end-to-end within Dash
- persisted outcomes can be used by Power BI for governance reporting

Outcome:

Import Constraints becomes operational without Excel.

---

## Why Import Constraints

Import Constraints is selected because:

- it is a contained workstream
- operational complexity is manageable
- existing analytical work already exists in Python
- it provides a realistic operational workflow
- it can validate the target architecture without requiring full platform migration

The objective is to prove the architecture using one representative workstream before scaling further.

---

## What The PoC Must Demonstrate

### 1. System-Level Proof

The PoC must demonstrate:

- NED can be removed
- Azure SQL can act as the operational system of record
- persistence can operate independently of Excel
- decisions can be stored and retrieved from Azure SQL

---

### 2. Application Proof

The PoC must demonstrate that Dash can support:

- workstream selection
- alert review
- investigation workflow
- investigation intelligence
- analytical support
- action assignment
- status assignment
- comments and evidence
- decision capture
- open case visibility where required

---

### 3. Intelligence And Analytical Support Proof

The PoC must demonstrate that investigation intelligence and analytical support can be surfaced through Dash.

Examples include:

- contextual analytics
- workstream-specific intelligence
- contextual BMRS access
- contextual Power BI links where useful
- supporting investigation resources
- historical investigation records
- alert count thresholds
- repeat behaviour analysis

The analyst should not need to manually navigate multiple disconnected systems to gather core investigation context.

---

### 4. Workflow Proof

The analyst should be able to perform the full selected workflow within Dash:

Select Workstream
↓
Review Alert
↓
Access Investigation Intelligence And Analytical Support
↓
Make Decision
↓
Record Outcome
↓
Save To Azure SQL
↓
Retrieve Historical Record

without using Excel or NED.

---

### 5. Architecture Proof

The PoC must demonstrate:

- no Excel dependency for the selected workstream
- no NED dependency for the selected workflow
- no unnecessary duplicated logic
- clear separation between data, backend services, workflow and governance
- Dash remains focused on the analyst experience
- Dash provides investigation intelligence and analytical support
- Power BI remains focused on governance and KPI reporting

---

## Success Criteria

The PoC will be considered successful if:

- NED is removed from the selected workflow
- Azure SQL becomes the operational persistence layer for the selected workflow
- Dash becomes the operational interface for the selected workstream
- analysts can complete investigations without Excel
- analysts can select workstreams and review alerts
- analysts can access investigation intelligence from within Dash
- analysts can access analytical support from within Dash
- analysts can assign actions and statuses
- analysts can record comments and supporting information
- analysts can persist outcomes directly to Azure SQL
- persisted outcomes can be retrieved from Azure SQL
- historical investigation records remain accessible
- analyst decisions can be audited and traced
- Power BI can consume persisted outcomes for governance reporting
- workflow, investigation intelligence and analytical support can coexist within the same application

---

## Out Of Scope

The PoC is not intended to prove every future platform capability.

The following areas are intentionally excluded:

- full exception-management redesign
- long-run investigation redesign
- regulatory workflow redesign
- full reference-data administration
- migration of every monitoring workstream
- full Power BI governance model redesign
- complex backend architecture beyond the needs of the PoC
- replacement of all external investigation sources

These areas should be addressed in later platform phases.

---

## Final System Model

Azure SQL
↑

Backend Services
↑

Dash (Workflow + Investigation Intelligence + Analytical Support)
↑

Analyst

Power BI (Governance + KPI Reporting)
↑

Azure SQL

---

## Key Outcome

The PoC does not simply prove that Excel can be replaced.

It proves that:

- NED can be removed
- Azure SQL can become the operational persistence layer
- workflow can be delivered through Dash
- investigation intelligence can be delivered through Dash
- analytical support can be delivered through Dash
- existing analytical logic can be reused where appropriate
- analyst workflow can operate end-to-end without Excel
- persisted outcomes can support Power BI governance reporting
- a clean and scalable platform architecture is viable

---

## One-Line Summary

Prove that an Azure SQL-backed Dash application can replace Excel and NED by supporting alert review, investigation intelligence, analytical support and decision capture within a single workflow, while Power BI provides governance and accountability reporting.