from typing import Any, Dict, List
from dash import dash_table

ALERT_TABLE_COLUMNS = [
    {"name": "BMU ID", "id": "BMU_ID"},
    {"name": "Party Name", "id": "COUNTERPARTY"},
    {"name": "Fuel Type", "id": "FUEL_TYPE"},
    {"name": "Parameter Breached", "id": "PARAMETER_BREACHED"},
    {"name": "Start Time (Local)", "id": "START_LOCAL"},
    {"name": "End Time (Local)", "id": "END_LOCAL"},
    {"name": "Duration (min)", "id": "DURATION_MIN"},
    {"name": "SPs", "id": "COUNT_SP"},
    {"name": "Review Status", "id": "DISPLAY_STATUS"},
    {"name": "Action Taken", "id": "ACTION_TAKEN"},
    {"name": "Review Comments", "id": "REVIEW_COMMENTS"},
]


def create_alert_table(alert_data: List[Dict[str, Any]]) -> dash_table.DataTable:
    return dash_table.DataTable(
        id="alert-review-table",
        columns=ALERT_TABLE_COLUMNS,
        data=alert_data,
        row_selectable="multi",
        selected_rows=[],
        style_table={"overflowX": "auto", "borderRadius": "8px", "border": "1px solid #e2e8f0"},
        style_header={
            "backgroundColor": "#edf1f7",
            "color": "#4e0038",
            "fontWeight": "700",
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "borderBottom": "2px solid #cbd5e1",
        },
        style_cell={
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "fontFamily": "Inter, Segoe UI, sans-serif",
            "whiteSpace": "normal",
            "height": "auto",
            "color": "#1e293b",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_data_conditional=[
            {
                "if": {"row_index": "odd"},
                "backgroundColor": "#f8fafc",
            },
            {
                "if": {"state": "selected"},
                "backgroundColor": "#fdf4fa",
                "border": "1px solid #4e0038",
            },
            {
                "if": {
                    "column_id": "DISPLAY_STATUS",
                    "filter_query": '{DISPLAY_STATUS} = "Unreviewed"',
                },
                "color": "#d97706",
                "fontWeight": "700",
            },
            {
                "if": {
                    "column_id": "DISPLAY_STATUS",
                    "filter_query": '{DISPLAY_STATUS} = "Open"',
                },
                "color": "#2563eb",
                "fontWeight": "700",
            },
            {
                "if": {
                    "column_id": "DISPLAY_STATUS",
                    "filter_query": '{DISPLAY_STATUS} = "Closed"',
                },
                "color": "#16a34a",
                "fontWeight": "700",
            },
        ],
        page_size=15,
        style_as_list_view=False,
        css=[
            {
                "selector": ".dash-select-cell, .dash-select-header",
                "rule": "width: 55px !important; min-width: 55px !important; max-width: 55px !important; text-align: center !important; padding: 8px 4px !important;",
            },
            {
                "selector": ".dash-select-cell input, .dash-select-header input",
                "rule": "cursor: pointer; width: 16px !important; height: 16px !important; vertical-align: middle;",
            },
        ],
    )
