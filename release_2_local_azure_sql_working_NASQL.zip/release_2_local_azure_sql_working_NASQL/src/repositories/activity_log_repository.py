from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.config.constants import SQL_TABLE_ACTIVITY_LOG
from src.repositories.connection import get_db


def ensure_activity_log_table_exists(db_path: Optional[Union[Path, str]] = None) -> None:
    """Ensures the ACTIVITY_LOG table exists.

    Uses SQLite-compatible DDL when running against a SQLite connection (tests /
    local mode) and T-SQL DDL when running against Azure SQL.
    """
    import sqlite3 as _sqlite3

    sqlite_ddl = f"""
    CREATE TABLE IF NOT EXISTS {SQL_TABLE_ACTIVITY_LOG} (
        ACTIVITY_LOG_ID    TEXT NOT NULL PRIMARY KEY,
        ALERT_UNIQUE_ID    TEXT NOT NULL UNIQUE,
        BMU_ID             TEXT,
        PARTY_NAME         TEXT,
        PARAMETER_BREACHED TEXT,
        RAISE_DATE         TEXT,
        START_DATE         TEXT,
        END_DATE           TEXT,
        PERSON_RAISING     TEXT,
        NOTIFICATION_SOURCE TEXT,
        ACTION_TAKEN       TEXT,
        ANALYSIS_STATUS    TEXT,
        INFO_FOR_ANALYST   TEXT,
        REVIEW_COMMENTS    TEXT,
        CREATED_DATETIME   TEXT,
        UPDATED_DATETIME   TEXT
    )
    """

    azure_ddl = f"""
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'{SQL_TABLE_ACTIVITY_LOG}') AND type in (N'U'))
    BEGIN
        CREATE TABLE {SQL_TABLE_ACTIVITY_LOG} (
            [ACTIVITY_LOG_ID]    VARCHAR(255) NOT NULL PRIMARY KEY,
            [ALERT_UNIQUE_ID]    VARCHAR(255) NOT NULL,
            [BMU_ID]             VARCHAR(100) NULL,
            [PARTY_NAME]         VARCHAR(255) NULL,
            [PARAMETER_BREACHED] VARCHAR(255) NULL,
            [RAISE_DATE]         VARCHAR(50) NULL,
            [START_DATE]         VARCHAR(50) NULL,
            [END_DATE]           VARCHAR(50) NULL,
            [PERSON_RAISING]     VARCHAR(255) NULL,
            [NOTIFICATION_SOURCE] VARCHAR(255) NULL,
            [ACTION_TAKEN]       VARCHAR(255) NULL,
            [ANALYSIS_STATUS]    VARCHAR(50) NULL,
            [INFO_FOR_ANALYST]   NVARCHAR(MAX) NULL,
            [REVIEW_COMMENTS]    NVARCHAR(MAX) NULL,
            [CREATED_DATETIME]   VARCHAR(50) NULL,
            [UPDATED_DATETIME]   VARCHAR(50) NULL,
            CONSTRAINT [UQ_ACTIVITY_LOG_ALERT_UNIQUE_ID] UNIQUE ([ALERT_UNIQUE_ID])
        );

        CREATE INDEX [IX_ACTIVITY_LOG_ANALYSIS_STATUS] ON {SQL_TABLE_ACTIVITY_LOG} ([ANALYSIS_STATUS]);
        CREATE INDEX [IX_ACTIVITY_LOG_PARTY_NAME] ON {SQL_TABLE_ACTIVITY_LOG} ([PARTY_NAME]);
    END
    """

    try:
        with get_db(db_path) as conn:
            if isinstance(conn, _sqlite3.Connection):
                conn.execute(sqlite_ddl)
            else:
                conn.execute(azure_ddl)
    except Exception:
        raise


def get_activity_log_by_alert_id(
    alert_unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    query = f"SELECT * FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :alert_unique_id"
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query, {"alert_unique_id": alert_unique_id})
            row = cursor.fetchone()
            return dict(row) if row else None
    except Exception:
        return None


def save_activity_log(
    record: Dict[str, Any],
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Inserts a new ACTIVITY_LOG record or updates an existing record linked to ALERT_UNIQUE_ID.
    Preserves CREATED_DATETIME on update, updates UPDATED_DATETIME.
    Uses transaction management via get_db context manager.
    """
    ensure_activity_log_table_exists(db_path)
    alert_unique_id = record["ALERT_UNIQUE_ID"]

    with get_db(db_path) as conn:
        cursor = conn.execute(
            f"SELECT ACTIVITY_LOG_ID, CREATED_DATETIME FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :id",
            {"id": alert_unique_id},
        )
        existing = cursor.fetchone()

        if existing:
            # Update existing record
            activity_log_id = existing["ACTIVITY_LOG_ID"]
            update_query = f"""
            UPDATE {SQL_TABLE_ACTIVITY_LOG}
            SET PARTY_NAME = :PARTY_NAME,
                PARAMETER_BREACHED = :PARAMETER_BREACHED,
                RAISE_DATE = :RAISE_DATE,
                START_DATE = :START_DATE,
                END_DATE = :END_DATE,
                PERSON_RAISING = :PERSON_RAISING,
                NOTIFICATION_SOURCE = :NOTIFICATION_SOURCE,
                ACTION_TAKEN = :ACTION_TAKEN,
                ANALYSIS_STATUS = :ANALYSIS_STATUS,
                INFO_FOR_ANALYST = :INFO_FOR_ANALYST,
                REVIEW_COMMENTS = :REVIEW_COMMENTS,
                UPDATED_DATETIME = :UPDATED_DATETIME
            WHERE ALERT_UNIQUE_ID = :ALERT_UNIQUE_ID
            """
            params = {
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": record["RAISE_DATE"],
                "START_DATE": record["START_DATE"],
                "END_DATE": record["END_DATE"],
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "UPDATED_DATETIME": record["UPDATED_DATETIME"],
                "ALERT_UNIQUE_ID": alert_unique_id,
            }
            conn.execute(update_query, params)
            record["ACTIVITY_LOG_ID"] = activity_log_id
            record["CREATED_DATETIME"] = existing["CREATED_DATETIME"]
        else:
            # Insert new record.
            # ACTIVITY_LOG_ID is generated by Azure SQL using DEFAULT NEWID().
            insert_query = f"""
            INSERT INTO {SQL_TABLE_ACTIVITY_LOG} (
                ALERT_UNIQUE_ID,
                BMU_ID,
                PARTY_NAME,
                PARAMETER_BREACHED,
                RAISE_DATE,
                START_DATE,
                END_DATE,
                PERSON_RAISING,
                NOTIFICATION_SOURCE,
                ACTION_TAKEN,
                ANALYSIS_STATUS,
                INFO_FOR_ANALYST,
                REVIEW_COMMENTS,
                CREATED_DATETIME,
                UPDATED_DATETIME
            )
            OUTPUT INSERTED.ACTIVITY_LOG_ID
            VALUES (
                :ALERT_UNIQUE_ID,
                :BMU_ID,
                :PARTY_NAME,
                :PARAMETER_BREACHED,
                :RAISE_DATE,
                :START_DATE,
                :END_DATE,
                :PERSON_RAISING,
                :NOTIFICATION_SOURCE,
                :ACTION_TAKEN,
                :ANALYSIS_STATUS,
                :INFO_FOR_ANALYST,
                :REVIEW_COMMENTS,
                :CREATED_DATETIME,
                :UPDATED_DATETIME
            )
            """

            params = {
                "ALERT_UNIQUE_ID": record["ALERT_UNIQUE_ID"],
                "BMU_ID": record["BMU_ID"],
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": record["RAISE_DATE"],
                "START_DATE": record["START_DATE"],
                "END_DATE": record["END_DATE"],
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "CREATED_DATETIME": record["CREATED_DATETIME"],
                "UPDATED_DATETIME": record.get("UPDATED_DATETIME"),
            }
            cursor = conn.execute(insert_query, params)
            inserted = cursor.fetchone()
            record["ACTIVITY_LOG_ID"] = str(inserted[0])

    return record


def get_all_saved_reviews(
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    query = f"""
    SELECT *
    FROM {SQL_TABLE_ACTIVITY_LOG}
    ORDER BY START_DATE DESC, BMU_ID ASC
    """
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query)
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except Exception:
        return []


def get_closed_reviews(
    start_date: str,
    end_date: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Returns persisted closed reviews from ACTIVITY_LOG.

    IMPORT_ALERTS is used only to retrieve supplementary display fields.
    """
    query = f"""
    SELECT
        al.ALERT_UNIQUE_ID AS UNIQUE_ID,
        al.BMU_ID,
        al.PARTY_NAME AS COUNTERPARTY,
        al.ACTION_TAKEN,
        al.ANALYSIS_STATUS,
        al.PERSON_RAISING,
        al.REVIEW_COMMENTS,
        al.CREATED_DATETIME,
        al.UPDATED_DATETIME,
        alert_data.FUEL_TYPE,
        alert_data.START_GMT,
        alert_data.END_GMT,
        COALESCE(alert_data.START_LOCAL, al.START_DATE) AS START_LOCAL,
        COALESCE(alert_data.END_LOCAL, al.END_DATE) AS END_LOCAL,
        alert_data.DURATION_MIN,
        alert_data.COUNT_SP
    FROM {SQL_TABLE_ACTIVITY_LOG} AS al
    OUTER APPLY (
        SELECT TOP 1
            ia.FUEL_TYPE,
            ia.START_GMT,
            ia.END_GMT,
            ia.START_LOCAL,
            ia.END_LOCAL,
            ia.DURATION_MIN,
            ia.COUNT_SP
        FROM dbo.IMPORT_ALERTS AS ia
        WHERE ia.UNIQUE_ID = al.ALERT_UNIQUE_ID
        ORDER BY ia.START_LOCAL ASC
    ) AS alert_data
    WHERE al.ANALYSIS_STATUS = 'Closed'
      AND al.START_DATE >= :start_date
      AND al.START_DATE < DATEADD(DAY, 1, CAST(:end_date AS DATE))
    ORDER BY al.START_DATE DESC, al.BMU_ID ASC
    """

    with get_db(db_path) as conn:
        cursor = conn.execute(
            query,
            {
                "start_date": start_date,
                "end_date": end_date,
            },
        )
        return [dict(row) for row in cursor.fetchall()]
