ACCOUNT_URL = "https://dlaaencmmdsffuks01.blob.core.windows.net/"
CONTAINER_NAME = "datalake"
PROJECT_NAME = "pn-accuracy-2025"
