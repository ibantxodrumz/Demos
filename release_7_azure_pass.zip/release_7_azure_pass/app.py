import base64
import calendar
from datetime import datetime, date, timedelta
import os
import sys
import time

import duckdb  # type: ignore
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from azure_blob_helper import AzureBlobStorage
from constants import (
    ACCOUNT_URL,
    AVAILABLE_YEARS,
    CONTAINER_NAME,
    DEFAULT_YEAR,
    PROJECT_BASE_NAME,
    PROJECT_NAME,
    VERSION,
)

# --- Pure Analytical & Helper Functions (Exposed for Testing and CLI) ---


def force_light_chart(fig):
    """Force high-contrast light background and clear typography on Plotly charts."""
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#111827", family="Poppins, sans-serif"),
        xaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#000000",
            tickfont=dict(color="#111827", size=11),
            title_font=dict(color="#000000", size=12, family="Poppins, sans-serif"),
        ),
        yaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#000000",
            tickfont=dict(color="#111827", size=11),
            title_font=dict(color="#000000", size=12, family="Poppins, sans-serif"),
        ),
        title_font=dict(color="#400732", size=14, family="Poppins, sans-serif"),
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig


def render_chart(fig):
    """Convenience helper to style and render a chart in Streamlit."""
    styled = force_light_chart(fig)
    st.plotly_chart(styled, use_container_width=True)


def categorize_error(x):
    """Categorize error percentage into predefined operational bands."""
    if x <= 1:
        return "0-1%"
    elif x <= 2:
        return "1-2%"
    elif x <= 4:
        return "2-4%"
    elif x <= 10:
        return "4-10%"
    else:
        return ">10%"


def get_reason(row):
    """Generate detailed reason string for BMUs exceeding operational thresholds.

    Wind/Solar: Net outside [-3%, +3%] OR ABS >= 9.4%
    Other fuels: Net outside [-1%, +1%] OR ABS >= 2.6%
    """
    reasons = []
    fuel_upper = str(row.get("Fuel", "")).upper()

    # Universal column resolution across schema variants
    net_err = row.get(
        "A_Net_Error%", row.get("A_Net_error%", row.get("A_NetError%", 0.0))
    )
    abs_err = row.get(
        "A_ABS_Error%", row.get("A_ABS_error%", row.get("A_ABS_NetError%", 0.0))
    )

    if fuel_upper in ["WIND", "SOLAR"]:
        if abs(net_err) > 3.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±3%)")
        if abs_err >= 9.4:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 9.4%)")
    else:
        if abs(net_err) > 1.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±1%)")
        if abs_err >= 2.6:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 2.6%)")
    return "; ".join(reasons) if reasons else "Within Tolerances"


def find_local_input_file(filename: str):
    """Robust local file resolver across test runners and Streamlit execution."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(script_dir, "inputs", filename),
        os.path.join(os.getcwd(), "inputs", filename),
        os.path.join(script_dir, "..", "inputs", filename),
        os.path.join(script_dir, "..", "release_7_azure", "inputs", filename),
        os.path.join(os.getcwd(), "release_7_azure", "inputs", filename),
        (
            os.path.join(
                script_dir, "..", "release_6_prompt", "sample_sp_january_2025_FOMO.csv"
            )
            if "sp_summary" in filename
            else None
        ),
        (
            os.path.join(
                os.getcwd(), "release_6_prompt", "sample_sp_january_2025_FOMO.csv"
            )
            if "sp_summary" in filename
            else None
        ),
        os.path.join("inputs", filename),
        os.path.join(script_dir, filename),
        os.path.join(os.getcwd(), filename),
    ]
    for path in candidates:
        if path and os.path.exists(path):
            return os.path.abspath(path)
    return None


def query_sp_data(
    sp_source: str,
    bmu: str,
    start_date: str,
    end_date: str,
    is_azure: bool = False,
    azure_token: str = None,
) -> pd.DataFrame:
    """Query Settlement Period data directly using DuckDB.

    Azure Settlement Period data is queried from Parquet.
    Local Settlement Period data continues to use CSV.

    DuckDB's Azure credential chain supports the configured Azure identity.
    """
    del azure_token  # Retained temporarily for caller compatibility.

    if not sp_source:
        return pd.DataFrame()

    con = duckdb.connect()

    try:
        if is_azure:
            account_name = (
                ACCOUNT_URL.replace("https://", "").replace("http://", "").split(".")[0]
            )

            con.execute("INSTALL azure;")
            con.execute("LOAD azure;")

            con.execute(f"""
                CREATE OR REPLACE SECRET azure_storage_secret (
                    TYPE AZURE,
                    PROVIDER CREDENTIAL_CHAIN,
                    ACCOUNT_NAME '{account_name}'
                );
                """)

            query_target = sp_source

        else:
            if not os.path.exists(sp_source):
                raise FileNotFoundError(
                    f"Settlement Period file not found: {sp_source}"
                )

            query_target = sp_source.replace("\\", "/")

        escaped_target = query_target.replace("'", "''")

        if is_azure:
            query = f"""
                SELECT *
                FROM read_parquet('{escaped_target}')
                WHERE nationalGridBmUnit = ?
                  AND CAST(settlementDate AS DATE) >= CAST(? AS DATE)
                  AND CAST(settlementDate AS DATE) <= CAST(? AS DATE)
                ORDER BY timeFrom
            """
        else:
            query = f"""
                SELECT *
                FROM read_csv_auto(
                    '{escaped_target}',
                    header = true
                )
                WHERE nationalGridBmUnit = ?
                  AND CAST(settlementDate AS DATE) >= CAST(? AS DATE)
                  AND CAST(settlementDate AS DATE) <= CAST(? AS DATE)
                ORDER BY timeFrom
            """

        df = con.execute(
            query,
            [bmu, str(start_date), str(end_date)],
        ).df()

    except Exception as exc:
        source_type = "Azure Blob Storage Parquet" if is_azure else "local CSV"

        raise RuntimeError(
            "DuckDB Settlement Period query failed. "
            f"Source type: {source_type}. "
            f"Source: {sp_source}. "
            f"Error: {exc}"
        ) from exc

    finally:
        con.close()

    if df.empty:
        return df

    # Analytical deduplication contract.
    df = df.drop_duplicates(
        subset=[
            "nationalGridBmUnit",
            "settlementDate",
            "settlementPeriod",
        ],
        keep="first",
    ).reset_index(drop=True)

    if "duration_min" in df.columns:
        duration = pd.to_numeric(
            df["duration_min"],
            errors="coerce",
        ).fillna(30.0)
    else:
        duration = pd.Series(
            30.0,
            index=df.index,
        )

    mw_factor = np.where(
        duration > 0,
        60.0 / duration,
        2.0,
    )

    for col in [
        "PNLevel",
        "MELLevel",
        "MILLevel",
        "Metered",
        "ExpectOT",
    ]:
        if col in df.columns:
            df[f"{col}_MW"] = (
                pd.to_numeric(
                    df[col],
                    errors="coerce",
                )
                * mw_factor
            )
        else:
            df[f"{col}_MW"] = 0.0

    absvd_col = None

    if "ABSVD_MWh" in df.columns:
        absvd_col = "ABSVD_MWh"
    elif "ABSVD" in df.columns:
        absvd_col = "ABSVD"

    if absvd_col:
        df["ABSVD_MW"] = (
            pd.to_numeric(
                df[absvd_col],
                errors="coerce",
            )
            * mw_factor
        )
    else:
        df["ABSVD_MW"] = 0.0

    if "BidVolume" in df.columns:
        df["BidVolume_abs"] = (
            pd.to_numeric(
                df["BidVolume"],
                errors="coerce",
            )
            .abs()
            .fillna(0.0)
            * mw_factor
        )

    if "OfferVolume" in df.columns:
        df["OfferVolume_abs"] = (
            pd.to_numeric(
                df["OfferVolume"],
                errors="coerce",
            )
            .abs()
            .fillna(0.0)
            * mw_factor
        )

    if "NetError%" in df.columns:
        df["NetError%"] = pd.to_numeric(
            df["NetError%"],
            errors="coerce",
        ).fillna(0.0)

    elif "NetError" in df.columns:
        df["NetError%"] = pd.to_numeric(
            df["NetError"],
            errors="coerce",
        ).fillna(0.0)

    return df


@st.cache_data
def process_data(df_annual_raw, df_monthly_raw, year: int = 2025):
    """Clean, coerce, and normalize Annual and Monthly datasets.

    Provides universal dual-mapping for all error column conventions:
    A_Net_Error% <-> A_Net_error% <-> A_NetError%
    A_ABS_Error% <-> A_ABS_error% <-> A_ABS_NetError%
    """
    # 1. Process Annual
    try:
        df_annual = df_annual_raw.copy()

        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)
        df_annual["Year"] = int(year)
        df_annual["Grain"] = "annual"

        numeric_cols_annual = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_annual:
            if col in df_annual.columns:
                df_annual[col] = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )

        # Standardize Annual Net Error
        net_err_series = None
        for col in ["A_Net_Error%", "A_Net_error%", "A_NetError%"]:
            if col in df_annual.columns:
                net_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )
                break
        if net_err_series is None:
            net_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_Net_Error%"] = net_err_series
        df_annual["A_Net_error%"] = net_err_series
        df_annual["A_NetError%"] = net_err_series

        # Standardize Annual ABS Error
        abs_err_series = None
        for col in ["A_ABS_Error%", "A_ABS_error%", "A_ABS_NetError%"]:
            if col in df_annual.columns:
                abs_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )
                break
        if abs_err_series is None:
            abs_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_ABS_Error%"] = abs_err_series
        df_annual["A_ABS_error%"] = abs_err_series
        df_annual["A_ABS_NetError%"] = abs_err_series

        # Standardize Max Monthly Error
        max_m_series = None
        for col in ["max_M_ABS_Error%", "max_M_ABS_NetError%"]:
            if col in df_annual.columns:
                max_m_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
                break
        if max_m_series is None:
            max_m_series = pd.Series(0.0, index=df_annual.index)
        df_annual["max_M_ABS_Error%"] = max_m_series
        df_annual["max_M_ABS_NetError%"] = max_m_series

        df_annual["SizeBasis"] = pd.to_numeric(
            df_annual.get("installedCapacity_mwh", 0), errors="coerce"
        ).fillna(0)

    except Exception as e:
        return None, None, f"Error processing Annual data: {str(e)}"

    # 2. Process Monthly
    try:
        df_monthly = df_monthly_raw.copy()

        def parse_date(x):
            try:
                parts = str(x).split("-")
                if len(parts) == 2:
                    return datetime(int(parts[0]), int(parts[1]), 1)
                return pd.NaT
            except Exception:
                return pd.NaT

        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_date)
        df_monthly["Year"] = df_monthly["YearMonthObj"].dt.year
        df_monthly["Month"] = df_monthly["YearMonthObj"].dt.month
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        df_monthly["YearMonth"] = df_monthly["YearMonthObj"].dt.strftime("%Y-%m")

        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)
        df_monthly["Grain"] = "monthly"

        numeric_cols_monthly = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_monthly:
            if col in df_monthly.columns:
                df_monthly[col] = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)

        # Standardize Monthly Net Error
        m_net_err_series = None
        for col in ["M_Net_Error%", "M_Net_error%", "M_NetError%"]:
            if col in df_monthly.columns:
                m_net_err_series = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)
                break
        if m_net_err_series is None:
            m_net_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_Net_Error%"] = m_net_err_series
        df_monthly["M_Net_error%"] = m_net_err_series
        df_monthly["M_NetError%"] = m_net_err_series

        # Standardize Monthly ABS Error
        m_abs_err_series = None
        for col in ["M_ABS_Error%", "M_ABS_error%", "M_ABS_NetError%"]:
            if col in df_monthly.columns:
                m_abs_err_series = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)
                break
        if m_abs_err_series is None:
            m_abs_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_ABS_Error%"] = m_abs_err_series
        df_monthly["M_ABS_error%"] = m_abs_err_series
        df_monthly["M_ABS_NetError%"] = m_abs_err_series

    except Exception as e:
        return None, None, f"Error processing Monthly data: {str(e)}"

    # 3. P90 Calculation retired
    df_annual["P90_monthly_error"] = 0.0

    # 4. Logic: Needs Attention (Fuel-specific thresholds)
    is_wind_solar = df_annual["Fuel"].astype(str).str.upper().isin(["WIND", "SOLAR"])
    cond_wind_solar = is_wind_solar & (
        (df_annual["A_NetError%"].abs() > 3.0) | (df_annual["A_ABS_Error%"] >= 9.4)
    )
    cond_other_fuels = (~is_wind_solar) & (
        (df_annual["A_NetError%"].abs() > 1.0) | (df_annual["A_ABS_Error%"] >= 2.6)
    )
    df_annual["NeedsAttention"] = cond_wind_solar | cond_other_fuels

    # 5. Logic: Error Band Classification
    df_annual["ErrorBand"] = df_annual["A_ABS_Error%"].apply(categorize_error)
    df_annual["ErrorBand"] = pd.Categorical(
        df_annual["ErrorBand"],
        categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"],
        ordered=True,
    )

    return df_annual, df_monthly, None


def apply_filters(df_a, df_m, fuels, bmus=None, attention_only=False):
    """Filter annual and monthly datasets based on active sidebar selections."""
    res_a = df_a[df_a["Fuel"].isin(fuels)]
    if bmus is not None:
        res_a = res_a[res_a["BMU"].isin(bmus)]
    if attention_only:
        res_a = res_a[res_a["NeedsAttention"] == True]

    filtered_bmus = res_a["BMU"].unique()
    res_m = df_m[df_m["BMU"].isin(filtered_bmus)]
    res_m = res_m[res_m["Fuel"].isin(fuels)]

    return res_a, res_m


# --- Streamlit Application Lifecycle (Executed Only Under `streamlit run`) ---


def run_streamlit_app():
    st.set_page_config(
        page_title="PN Accuracy Dashboard",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Assets & Styling with Poppins Font, Light Pink Tabs, and Black Borders
    script_dir = os.path.dirname(os.path.abspath(__file__))
    logo_path = os.path.join(script_dir, "assets", "neso_logo.jpg")
    logo_b64 = None
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as img_f:
            logo_b64 = base64.b64encode(img_f.read()).decode("utf-8")

    st.markdown(
        """
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap');

            .stApp {
                background-color: #fcfcfd;
                color: #111827;
                font-family: 'Poppins', sans-serif !important;
            }
            * {
                font-family: 'Poppins', sans-serif;
            }
            section[data-testid="stSidebar"] {
                background-color: #ffffff !important;
                border-right: 1px solid #000000;
            }
            .neso-sidebar-header {
                padding: 10px 0 16px 0;
                margin-bottom: 12px;
                border-bottom: 2px solid #000000;
                text-align: center;
            }
            .neso-sidebar-logo {
                max-width: 130px;
                height: auto;
                margin-bottom: 8px;
            }
            .neso-sidebar-title {
                color: #400732;
                font-weight: 800;
                font-size: 1.05rem;
                letter-spacing: -0.01em;
                margin: 0;
            }
            .neso-sidebar-subtitle {
                color: #000000;
                font-size: 0.8rem;
                font-weight: 600;
                margin-top: 2px;
            }
            .neso-active-window-card {
                background: #fdf2f8;
                border: 1px solid #000000;
                border-left: 5px solid #400732;
                border-radius: 6px;
                padding: 8px 14px;
                margin-bottom: 16px;
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 0.88rem;
                color: #000000;
                font-weight: 600;
            }
            .neso-aw-badge {
                background: #fce7f3;
                color: #000000;
                font-weight: 700;
                padding: 2px 8px;
                border-radius: 4px;
                border: 1px solid #000000;
                font-size: 0.8rem;
            }
            div[data-testid="stMetric"] {
                background-color: #ffffff;
                border: 1px solid #000000;
                border-radius: 8px;
                padding: 12px 16px;
                box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.08);
            }
            div[data-testid="stMetricLabel"] {
                color: #000000 !important;
                font-size: 0.85rem !important;
                font-weight: 700 !important;
            }
            div[data-testid="stMetricValue"] {
                color: #400732 !important;
                font-weight: 800 !important;
                font-size: 1.65rem !important;
            }

            /* --- Custom Tab Styling: Light Pink, Black Borders, Bold Black Poppins Font --- */
            div[data-baseweb="tab-list"] {
                border-bottom: 2px solid #000000 !important;
                gap: 6px;
                padding-bottom: 2px;
                display: flex !important;
                flex-wrap: wrap !important;
                overflow-x: auto !important;
            }
            button[data-baseweb="tab"] {
                background-color: #fdf2f8 !important;
                border: 1px solid #000000 !important;
                border-radius: 6px 6px 0 0 !important;
                padding: 8px 14px !important;
                color: #000000 !important;
                font-weight: 700 !important;
                font-size: 0.88rem !important;
                white-space: nowrap !important;
                flex-shrink: 0 !important;
                transition: all 0.15s ease-in-out;
            }
            button[data-baseweb="tab"]:hover {
                background-color: #fce7f3 !important;
                border-color: #000000 !important;
                color: #000000 !important;
            }
            button[data-baseweb="tab"][aria-selected="true"] {
                background-color: #fbcfe8 !important;
                border: 2px solid #000000 !important;
                border-bottom: 2px solid #fbcfe8 !important;
                color: #000000 !important;
                font-weight: 800 !important;
            }
            button[data-baseweb="tab"] div {
                color: #000000 !important;
                font-weight: 700 !important;
            }
            button[data-baseweb="tab"][aria-selected="true"] div {
                color: #000000 !important;
                font-weight: 800 !important;
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Sidebar: Branding
    if logo_b64:
        st.sidebar.markdown(
            f"""
            <div class="neso-sidebar-header">
                <img src="data:image/jpeg;base64,{logo_b64}" class="neso-sidebar-logo" alt="NESO Logo" />
                <div class="neso-sidebar-title">Market Monitoring</div>
                <div class="neso-sidebar-subtitle">PN Accuracy Dashboard</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.sidebar.subheader("Data Selection")

    # Calendar Year Selection
    default_year_idx = (
        AVAILABLE_YEARS.index(DEFAULT_YEAR) if DEFAULT_YEAR in AVAILABLE_YEARS else 0
    )
    selected_year = st.sidebar.selectbox(
        "Calendar Year",
        AVAILABLE_YEARS,
        index=default_year_idx,
        key="selected_year_selectbox",
    )

    annual_filename = f"annual_summary_{selected_year}.csv"
    monthly_filename = f"monthly_summary_{selected_year}.csv"

    # Settlement Period sources
    sp_local_filename = f"sp_summary_{selected_year}.csv"
    sp_azure_filename = f"sp_summary_{selected_year}.parquet"

    default_annual_path = find_local_input_file(annual_filename)
    default_monthly_path = find_local_input_file(monthly_filename)

    default_sp_path = (
        find_local_input_file(sp_local_filename)
        or find_local_input_file("sp_summary_test.csv")
        or find_local_input_file("sp_summary.csv")
    )

    has_local_inputs = bool(default_annual_path and default_monthly_path)

    # Data Source Toggle
    if "data_source_selection" not in st.session_state:
        st.session_state["data_source_selection"] = "Azure Blob Storage"

    data_source_options = [
        "Azure Blob Storage",
        "Local (inputs/ folder)",
        "Manual Upload (CSV)",
    ]

    current_index = 0
    if st.session_state["data_source_selection"] in data_source_options:
        current_index = data_source_options.index(
            st.session_state["data_source_selection"]
        )

    data_source = st.sidebar.radio(
        "Data Source",
        data_source_options,
        index=current_index,
        key="data_source_radio",
    )
    st.session_state["data_source_selection"] = data_source

    annual_raw, monthly_raw = None, None
    sp_target_path = None
    sp_is_azure = False
    sp_source_label = None
    sp_azure_token = None

    if data_source == "Azure Blob Storage":
        try:
            project_folder = f"{PROJECT_BASE_NAME}-{selected_year}"
            azure_blob = AzureBlobStorage(
                ACCOUNT_URL,
                CONTAINER_NAME,
                project_folder,
            )

            with st.sidebar.status(
                f"Fetching {selected_year} data from Azure...",
                expanded=False,
            ):
                st.write(
                    f"Connecting to container '{CONTAINER_NAME}' "
                    f"({project_folder})..."
                )
                annual_raw = azure_blob.read_annual_summary()
                st.write(f"Fetched Annual Summary ({annual_filename}).")
                monthly_raw = azure_blob.read_monthly_summary()
                st.write(f"Fetched Monthly Summary ({monthly_filename}).")

            st.sidebar.success(f"Azure {selected_year} Data Loaded Successfully")

            # DuckDB authenticates independently through CREDENTIAL_CHAIN.
            sp_azure_token = None

            if azure_blob.sp_blob_exists(selected_year):
                sp_target_path = azure_blob.get_sp_azure_url(selected_year)
                sp_is_azure = True
                sp_source_label = (
                    f"Azure Cloud Blob "
                    f"({CONTAINER_NAME}/{project_folder}/internal/"
                    f"{sp_azure_filename})"
                )
            else:
                sp_target_path = None
                sp_is_azure = False
                sp_source_label = (
                    f"Azure Blob Storage "
                    f"(Not Available in "
                    f"{CONTAINER_NAME}/{project_folder}/internal/"
                    f"{sp_azure_filename})"
                )

        except Exception as e:
            error_details = str(e)
            st.sidebar.error(f"Azure Connection Notice: {error_details}")
            st.error(
                f"**Unable to connect to Azure Blob Storage**\n\n"
                f"Connection details: `{error_details}`\n\n"
                f"Please ensure Azure authentication is available.\n\n"
                f"To operate offline, switch **Data Source** to "
                f"**Local (inputs/ folder)**."
            )
            st.stop()

    elif data_source == "Local (inputs/ folder)":
        if has_local_inputs:
            annual_raw = pd.read_csv(default_annual_path)
            monthly_raw = pd.read_csv(default_monthly_path)
            st.sidebar.success(f"Local {selected_year} inputs loaded from 'inputs/'")

            # Look strictly in Local inputs when Local mode is selected
            if default_sp_path:
                sp_target_path = default_sp_path
                sp_is_azure = False
                base_name = os.path.basename(default_sp_path)
                sp_source_label = (
                    f"Local Test Dataset ({base_name})"
                    if "test" in base_name.lower()
                    else f"Local Inputs ({base_name})"
                )
            else:
                sp_target_path = None
                sp_is_azure = False
                sp_source_label = f"Local Inputs (Not Found in inputs/{sp_local_filename} or inputs/sp_summary_test.csv)"
        else:
            st.sidebar.error(
                f"Could not find `{annual_filename}` or `{monthly_filename}` in 'inputs/' folder."
            )
            st.info(
                f"Local files for {selected_year} are not present in `inputs/`. Please choose another year or use Manual Upload."
            )
            st.stop()

    else:
        # Manual CSV Upload
        st.sidebar.markdown("### Upload Custom Data")
        uploaded_annual = st.sidebar.file_uploader(
            f"Upload Annual Summary ({selected_year})", type=["csv"]
        )
        uploaded_monthly = st.sidebar.file_uploader(
            f"Upload Monthly Summary ({selected_year})", type=["csv"]
        )
        if uploaded_annual and uploaded_monthly:
            annual_raw = pd.read_csv(uploaded_annual)
            monthly_raw = pd.read_csv(uploaded_monthly)
            st.sidebar.success("Custom CSV datasets loaded successfully.")
        else:
            st.sidebar.info(
                f"Please upload both Annual and Monthly CSV files for {selected_year}."
            )
            st.stop()

    # Process Datasets
    df_annual_raw, df_monthly_raw, error_msg = process_data(
        annual_raw, monthly_raw, year=selected_year
    )
    if error_msg:
        st.error(error_msg)
        st.stop()

    st.sidebar.markdown("---")
    st.sidebar.subheader("Filters")

    all_fuels = sorted(df_annual_raw["Fuel"].unique().tolist())
    selected_fuels = st.sidebar.multiselect(
        "Select Fuel(s)", all_fuels, default=all_fuels
    )

    needs_attention_only = st.sidebar.checkbox("Needs Attention only", value=False)

    df_annual, df_monthly = apply_filters(
        df_annual_raw, df_monthly_raw, selected_fuels, None, needs_attention_only
    )
    available_bmus = sorted(df_annual["BMU"].unique().tolist())

    if df_annual.empty:
        st.warning("No BMUs match the current filters.")
        st.stop()

    # Main Page Header
    st.markdown(
        """
        <div style="margin-bottom: 1rem;">
            <h1 style="color: #400732; font-size: 2.05rem; font-weight: 800; margin: 0; letter-spacing: -0.02em;">
                Market Monitoring: PN Accuracy Dashboard
            </h1>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # 8 Clean Tabs (No Icons, Light Pink with Black Borders)
    tab1, tab1_m, tab1_gwh, tab3, tab4, tab_graph, tab5, tab6 = st.tabs(
        [
            "Executive Summary",
            "Median Error",
            "Total GWh Error",
            "By Technology",
            "BMU Explorer",
            "BMU Units Physical Profile",
            "Require Attention",
            "Exports",
        ]
    )

    # --- TAB 1: Executive Summary ---
    with tab1:
        st.markdown(
            f"""
            <div style="margin-bottom: 6px;">
                <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 14px; letter-spacing: -0.015em;">Executive Summary</h2>
            </div>
            <div class="neso-active-window-card">
                <span>Active Review Window:</span>
                <span class="neso-aw-badge">Dataset: <strong>{selected_year} Calendar Year</strong></span>
                <span style="color: #6b7280; font-weight: 700;">|</span>
                <span class="neso-aw-badge">Status: <strong>Fleet Baseline (Active)</strong></span>
                <span style="color: #000000; font-size: 0.85rem; font-weight: 600;">({len(df_annual):,} BMUs Evaluated • {len(df_monthly):,} Monthly Records)</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

        kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
        fleet_median_error = df_annual["A_ABS_Error%"].median()

        max_err_idx = df_annual["A_ABS_Error%"].idxmax()
        max_err_row = df_annual.loc[max_err_idx]
        fleet_max_error = max_err_row["A_ABS_Error%"]
        max_bmu_info = f"{max_err_row['BMU']} ({max_err_row['Fuel']})"

        bmu_count = df_annual["BMU"].nunique()
        fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
        fleet_net_gwh = df_annual["NetError"].sum() / 1000

        kpi1.metric("Fleet Median Error %", f"{fleet_median_error:.2f}%")
        kpi2.metric(
            "Max Individual Error %",
            f"{fleet_max_error:.2f}%",
            delta=max_bmu_info,
            delta_color="off",
        )
        kpi3.metric("BMU Count", f"{bmu_count}")
        kpi4.metric("Total ABS Error (GWh)", f"{fleet_abs_gwh:,.2f}")
        kpi5.metric("Net Bias (GWh)", f"{fleet_net_gwh:,.2f}")

        fuel_summary = (
            df_annual.groupby("Fuel")
            .agg(
                Median_Error_Pct=("A_ABS_Error%", "median"),
                Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
                BMU_Count=("BMU", "nunique"),
            )
            .reset_index()
            .sort_values("Total_ABS_GWh", ascending=False)
        )

        st.markdown("---")

        # 1. Fuel Performance Summary (Moved above Fleet Error Distribution as requested)
        st.subheader("Fuel Performance Summary")
        st.caption(
            "Detailed volume and error performance ranked by aggregate ABS GWh volume impact across all fuel types."
        )
        st.dataframe(
            fuel_summary.style.format(
                {
                    "Median_Error_Pct": "{:.2f}%",
                    "Total_ABS_GWh": "{:,.2f}",
                    "Net_Bias_GWh": "{:,.2f}",
                    "BMU_Count": "{:,d}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

        csv_fuel = fuel_summary.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Fuel Summary (CSV)",
            data=csv_fuel,
            file_name=f"fuel_performance_summary_{selected_year}.csv",
            mime="text/csv",
        )

        st.markdown("---")

        # 2. Fleet Error Distribution (Colorized by Operational Risk Band)
        st.subheader("Fleet Error Distribution by Operational Risk Band")
        st.caption(
            "Distribution of BMU annual absolute error percentages categorized by operational risk level: "
            "0–1% (Green), 1–2% (Light Green), 2–4% (Amber), 4–10% (Orange), >10% (Red)."
        )

        band_order = ["0-1%", "1-2%", "2-4%", "4-10%", ">10%"]
        band_palette = {
            "0-1%": "#10b981",  # Green
            "1-2%": "#84cc16",  # Light Green
            "2-4%": "#eab308",  # Amber
            "4-10%": "#f97316",  # Orange
            ">10%": "#ef4444",  # Red
        }

        band_df = (
            df_annual["ErrorBand"]
            .value_counts()
            .reindex(band_order)
            .fillna(0)
            .reset_index()
        )
        band_df.columns = ["ErrorBand", "Count"]
        band_df["Count"] = band_df["Count"].astype(int)
        band_df["Percentage"] = (band_df["Count"] / len(df_annual) * 100).round(1)

        fig_hist = px.bar(
            band_df,
            x="ErrorBand",
            y="Count",
            color="ErrorBand",
            color_discrete_map=band_palette,
            category_orders={"ErrorBand": band_order},
            text=band_df.apply(lambda r: f"{r['Count']} ({r['Percentage']}%)", axis=1),
            title=f"Fleet Error Distribution by Operational Risk Band ({selected_year})",
            template="plotly_white",
        )
        fig_hist.update_traces(textposition="outside")
        fig_hist.update_layout(
            xaxis=dict(title="Annual Error Band (Operational Risk Level)"),
            yaxis=dict(title="Count of BMUs"),
            showlegend=False,
            height=380,
        )
        render_chart(fig_hist)

    # --- TAB 2: Median Error ---
    with tab1_m:
        st.header("Median Error by Fuel")
        st.caption("Distribution of Median Absolute Net Error % across fuel types.")

        fuel_median = (
            df_annual.groupby("Fuel")["A_ABS_Error%"]
            .median()
            .reset_index()
            .sort_values("A_ABS_Error%", ascending=True)
        )
        fig_hm1 = px.bar(
            fuel_median,
            x="Fuel",
            y="A_ABS_Error%",
            title="Median Error % by Fuel",
            color="A_ABS_Error%",
            color_continuous_scale=["#fcf4fa", "#cf3e9e", "#8a156e", "#400732"],
            template="plotly_white",
        )
        render_chart(fig_hm1)

        # Context Table directly underneath chart as requested
        st.subheader("Fuel Median Performance & Sample Context")
        st.caption(
            "Contextual breakdown linking median error percentage with fleet sample size (BMU count)."
        )
        fuel_median_context = (
            df_annual.groupby("Fuel")
            .agg(
                Median_Error_Pct=("A_ABS_Error%", "median"),
                BMU_Count=("BMU", "nunique"),
            )
            .reset_index()
            .sort_values("Median_Error_Pct", ascending=False)
        )
        fuel_median_context.columns = ["Fuel", "Median Error %", "BMU Count"]
        st.dataframe(
            fuel_median_context.style.format(
                {"Median Error %": "{:.2f}%", "BMU Count": "{:,d}"}
            ),
            use_container_width=True,
            hide_index=True,
        )

        st.subheader("Annual Error Band Breakdown by Fuel")
        band_pivot = (
            pd.crosstab(
                df_annual["Fuel"],
                df_annual["ErrorBand"],
                normalize="index",
            )
            * 100
        )
        st.dataframe(
            band_pivot.style.format("{:.1f}%"),
            use_container_width=True,
        )

        band_export = df_annual[
            ["BMU", "Fuel", "ErrorBand", "A_ABS_Error%"]
        ].sort_values(["ErrorBand", "A_ABS_Error%"])
        csv_band = band_export.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Error Band Composition (CSV)",
            data=csv_band,
            file_name=f"error_band_composition_{selected_year}.csv",
            mime="text/csv",
        )

    # --- TAB 3: Total GWh Error ---
    with tab1_gwh:
        st.header("Total Volume (GWh) Error by Fuel")
        st.caption(
            "Aggregate volume impact: Total Absolute Error vs Net Directional Bias."
        )

        total_fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
        gwh_summary = (
            df_annual.groupby("Fuel")
            .agg(
                Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
            )
            .reset_index()
            .sort_values("Total_ABS_GWh", ascending=False)
        )
        gwh_summary["Pct_Fleet_Contribution"] = (
            (gwh_summary["Total_ABS_GWh"] / total_fleet_abs_gwh * 100)
            if total_fleet_abs_gwh > 0
            else 0.0
        )

        fig_gwh = px.bar(
            gwh_summary,
            x="Fuel",
            y=["Total_ABS_GWh", "Net_Bias_GWh"],
            barmode="group",
            title="Total Absolute Error vs Net Directional Bias (GWh)",
            color_discrete_sequence=["#400732", "#cf3e9e"],
            template="plotly_white",
        )
        render_chart(fig_gwh)

        st.subheader("Fuel Volume Impact & Fleet Contribution")
        st.caption(
            "Total absolute error, directional net bias, and percentage contribution to overall fleet volume error."
        )
        gwh_display = gwh_summary.rename(
            columns={
                "Total_ABS_GWh": "ABS Error GWh",
                "Net_Bias_GWh": "Net Bias GWh",
                "Pct_Fleet_Contribution": "% Fleet Contribution",
            }
        )
        st.dataframe(
            gwh_display.style.format(
                {
                    "ABS Error GWh": "{:,.2f}",
                    "Net Bias GWh": "{:,.2f}",
                    "% Fleet Contribution": "{:.1f}%",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    # --- TAB 4: By Technology ---
    with tab3:
        st.header("Technology Deep Dive")
        selected_tech = st.selectbox(
            "Select Technology / Fuel Type", all_fuels, key="tech_selector"
        )

        tech_df = df_annual[df_annual["Fuel"] == selected_tech]
        tech_monthly = df_monthly[df_monthly["Fuel"] == selected_tech]

        if tech_df.empty:
            st.info(f"No units available for technology '{selected_tech}'.")
        else:
            tc1, tc2, tc3 = st.columns(3)
            tc1.metric("BMU Count", len(tech_df))
            tc2.metric("Median ABS Error %", f"{tech_df['A_ABS_Error%'].median():.2f}%")
            worst_unit = tech_df.loc[tech_df["A_ABS_Error%"].idxmax()]
            tc3.metric(
                "Worst BMU Error %",
                f"{worst_unit['A_ABS_Error%']:.2f}%",
                delta=worst_unit["BMU"],
                delta_color="off",
            )

            col_t1, col_t2 = st.columns(2)
            with col_t1:
                fig_tdist = px.histogram(
                    tech_df,
                    x="A_ABS_Error%",
                    title=f"Error Distribution — {selected_tech}",
                    color_discrete_sequence=["#400732"],
                    template="plotly_white",
                )
                render_chart(fig_tdist)

            with col_t2:
                if not tech_monthly.empty:
                    trend = (
                        tech_monthly.groupby("YearMonth")["M_ABS_Error%"]
                        .median()
                        .reset_index(name="Monthly_Median")
                    )
                    fig_ttrend = px.line(
                        trend,
                        x="YearMonth",
                        y="Monthly_Median",
                        markers=True,
                        title=f"Monthly Median Error Trend — {selected_tech}",
                        color_discrete_sequence=["#cf3e9e"],
                        template="plotly_white",
                    )
                    render_chart(fig_ttrend)

            col_bench1, col_bench2 = st.columns(2)
            with col_bench1:
                st.subheader(f"Top Performing BMUs — {selected_tech}")
                st.caption(
                    "Top 10 units with the lowest annual absolute error (best performers)."
                )
                top_best = tech_df.nsmallest(10, "A_ABS_Error%")[
                    ["BMU", "A_ABS_Error%", "A_Net_Error%"]
                ]
                top_best = top_best.rename(
                    columns={
                        "A_ABS_Error%": "Annual ABS Error %",
                        "A_Net_Error%": "Annual Net Error %",
                    }
                )
                st.dataframe(
                    top_best.style.format(
                        {
                            "Annual ABS Error %": "{:.2f}%",
                            "Annual Net Error %": "{:+.2f}%",
                        }
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

            with col_bench2:
                st.subheader(f"Bottom BMUs — {selected_tech}")
                st.caption(
                    "Top 10 units with the highest annual absolute error (investigation targets)."
                )
                bottom_worst = tech_df.nlargest(10, "A_ABS_Error%")[
                    ["BMU", "A_ABS_Error%", "A_Net_Error%"]
                ]
                bottom_worst = bottom_worst.rename(
                    columns={
                        "A_ABS_Error%": "Annual ABS Error %",
                        "A_Net_Error%": "Annual Net Error %",
                    }
                )
                st.dataframe(
                    bottom_worst.style.format(
                        {
                            "Annual ABS Error %": "{:.2f}%",
                            "Annual Net Error %": "{:+.2f}%",
                        }
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

    # --- TAB 5: BMU Explorer (Annual & Monthly Summaries) ---
    with tab4:
        st.header("BMU Explorer")
        st.caption(
            "Detailed historical performance profile for an individual Balancing Mechanism Unit."
        )

        col_search1, col_search2 = st.columns([3, 1])
        with col_search1:
            search_query = (
                st.text_input(
                    "Search BMU by name",
                    value="",
                    placeholder="e.g. ABERU-1",
                    key="bmu_exp_search",
                )
                .strip()
                .upper()
            )
        with col_search2:
            st.write("")
            st.write("")
            reset_search = st.button("Reset Search", key="btn_reset_bmu_exp")

        if reset_search or not search_query:
            bmu_options = available_bmus
        else:
            bmu_options = [b for b in available_bmus if search_query in b]

        if not bmu_options:
            st.warning(f"No BMUs found matching '{search_query}'.")
            bmu_pick = available_bmus[0] if available_bmus else None
        else:
            bmu_pick = st.selectbox("Select BMU", bmu_options, key="bmu_exp_select")

        if bmu_pick:
            bmu_annual = df_annual_raw[df_annual_raw["BMU"] == bmu_pick].iloc[0]
            bmu_monthly = df_monthly_raw[df_monthly_raw["BMU"] == bmu_pick].sort_values(
                "YearMonth"
            )

            st.subheader(f"Profile: {bmu_pick}")
            bc1, bc2, bc3 = st.columns(3)

            with bc1:
                st.markdown("### Annual Metrics")
                st.write(f"**Fuel:** {bmu_annual['Fuel']}")
                st.write(f"**Annual Net Error %:** {bmu_annual['A_Net_Error%']:.2f}%")
                st.write(f"**Annual ABS Error %:** {bmu_annual['A_ABS_Error%']:.2f}%")
                st.write(
                    f"**Total ABS Error (GWh):** {bmu_annual['ABSError']/1000:,.2f}"
                )
                st.write(f"**Net Error (GWh):** {bmu_annual['NetError']/1000:,.2f}")
                if bmu_annual["NeedsAttention"]:
                    st.error("Flagged: Needs Attention")
                else:
                    st.success("Status: OK")

            with bc2:
                st.markdown("### Monthly Trend")
                if not bmu_monthly.empty:
                    fig_spark = px.line(
                        bmu_monthly,
                        x="YearMonth",
                        y="M_ABS_Error%",
                        markers=True,
                        title="Monthly Absolute Error %",
                        color_discrete_sequence=["#400732"],
                        template="plotly_white",
                    )
                    render_chart(fig_spark)
                else:
                    st.info("No monthly data available.")

            with bc3:
                st.markdown("### Monthly Data Table")
                st.dataframe(
                    bmu_monthly[["YearMonth", "M_Net_Error%", "M_ABS_Error%"]],
                    use_container_width=True,
                    hide_index=True,
                )

                csv_bmu = bmu_monthly.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label=f"Download {bmu_pick} Data (CSV)",
                    data=csv_bmu,
                    file_name=f"{bmu_pick}_monthly_data_{selected_year}.csv",
                    mime="text/csv",
                )

    # --- TAB 6: BMU Units Physical Profile ---
    with tab_graph:
        st.header("BMU Units Physical Profile")
        st.caption(
            "Granular half-hourly physical generation profile and settlement data."
        )

        # Check availability of SP dataset based on active source
        if not sp_target_path:
            if data_source == "Azure Blob Storage":
                st.warning(
                    f"Settlement Period dataset (`{sp_azure_filename}`) "
                    f"was not found in Azure Blob Storage "
                    f"(`{CONTAINER_NAME}/"
                    f"{PROJECT_BASE_NAME}-{selected_year}/internal/`). "
                    f"Granular half-hourly investigation is available "
                    f"for years with an SP Parquet file. "
                    f"All other dashboard tabs remain fully operational."
                )
            else:
                st.warning(
                    f"Settlement Period dataset (`{sp_local_filename}`) "
                    f"is not currently present in `inputs/`. "
                    f"Granular half-hourly investigation is available "
                    f"for years with an SP file. "
                    f"All other dashboard tabs remain fully operational."
                )
        else:
            if "test" in (sp_source_label or "").lower():
                st.info("Notice: Using sp_summary_test.csv - no sp_summary available")

            # Section 1: Investigation Controls
            # Identify units present in the SP dataset to ensure sample units (e.g. FOMO-1) are selectable
            sp_sample_bmus = []
            if sp_target_path and not sp_is_azure and os.path.exists(sp_target_path):
                try:
                    con_peek = duckdb.connect()
                    peek_target = sp_target_path.replace("\\", "/")
                    sample_rows = con_peek.execute(
                        f"SELECT DISTINCT nationalGridBmUnit FROM read_csv_auto('{peek_target}', header=True) LIMIT 20"
                    ).fetchall()
                    sp_sample_bmus = [r[0] for r in sample_rows if r[0]]
                    con_peek.close()
                except Exception:
                    pass

            investigation_bmus = sorted(
                list(set(available_bmus).union(set(sp_sample_bmus)))
            )
            if not investigation_bmus:
                investigation_bmus = available_bmus

            # BMU Search by Name and Selection
            col_search1, col_search2 = st.columns([3, 1])
            with col_search1:
                sp_search_query = (
                    st.text_input(
                        "Search BMU by name",
                        value="",
                        placeholder="e.g. FOMO-1",
                        key="sp_bmu_search",
                    )
                    .strip()
                    .upper()
                )
            with col_search2:
                st.write("")
                st.write("")
                sp_reset_search = st.button("Reset Search", key="btn_reset_sp_bmu")

            if sp_reset_search or not sp_search_query:
                filtered_sp_bmus = investigation_bmus
            else:
                filtered_sp_bmus = [
                    b for b in investigation_bmus if sp_search_query in b
                ]

            if not filtered_sp_bmus:
                st.warning(f"No BMUs found matching '{sp_search_query}'.")
                graph_bmu_pick = investigation_bmus[0] if investigation_bmus else None
            else:
                default_bmu_idx = 0
                if "FOMO-1" in filtered_sp_bmus:
                    default_bmu_idx = filtered_sp_bmus.index("FOMO-1")
                elif "FOMO2" in filtered_sp_bmus:
                    default_bmu_idx = filtered_sp_bmus.index("FOMO2")

                graph_bmu_pick = st.selectbox(
                    "Select BMU",
                    filtered_sp_bmus,
                    index=default_bmu_idx,
                    key="graph_bmu_select",
                )

            # Date Selection Controls: Day, Week, Month, Custom Range
            is_test_dataset = "test" in (sp_source_label or "").lower()
            active_year = int(selected_year) if not is_test_dataset else 2025

            c_date_mode, c_date_pick = st.columns([1.5, 2.5])
            with c_date_mode:
                date_selection_mode = st.radio(
                    "Date Selection",
                    [
                        "Specific Day",
                        "Specific Week",
                        "Specific Month",
                        "Custom Date Range",
                    ],
                    index=0,
                    key="sp_date_selection_mode",
                )

            with c_date_pick:
                if date_selection_mode == "Specific Day":
                    if is_test_dataset:
                        day_min = date(2025, 1, 1)
                        day_max = date(2025, 1, 31)
                        day_default = date(2025, 1, 1)
                    else:
                        day_min = date(active_year, 1, 1)
                        day_max = date(active_year, 12, 31)
                        day_default = date(active_year, 1, 1)

                    picked_day = st.date_input(
                        "Select Day",
                        value=day_default,
                        min_value=day_min,
                        max_value=day_max,
                        key="sp_single_day_picker",
                    )
                    sp_start_date = picked_day
                    sp_end_date = picked_day

                elif date_selection_mode == "Specific Week":
                    if is_test_dataset:
                        week_options = {
                            "Week 1 (01 Jan - 07 Jan 2025)": (
                                date(2025, 1, 1),
                                date(2025, 1, 7),
                            ),
                            "Week 2 (08 Jan - 14 Jan 2025)": (
                                date(2025, 1, 8),
                                date(2025, 1, 14),
                            ),
                            "Week 3 (15 Jan - 21 Jan 2025)": (
                                date(2025, 1, 15),
                                date(2025, 1, 21),
                            ),
                            "Week 4 (22 Jan - 28 Jan 2025)": (
                                date(2025, 1, 22),
                                date(2025, 1, 28),
                            ),
                            "Week 5 (29 Jan - 31 Jan 2025)": (
                                date(2025, 1, 29),
                                date(2025, 1, 31),
                            ),
                        }
                    else:
                        week_options = {}
                        cur_start = date(active_year, 1, 1)
                        for w in range(1, 53):
                            cur_end = min(
                                cur_start + timedelta(days=6), date(active_year, 12, 31)
                            )
                            week_label = f"Week {w} ({cur_start.strftime('%d %b')} - {cur_end.strftime('%d %b %Y')})"
                            week_options[week_label] = (cur_start, cur_end)
                            cur_start = cur_end + timedelta(days=1)
                            if cur_start.year > active_year:
                                break

                    chosen_week = st.selectbox(
                        "Select Week", list(week_options.keys()), key="sp_week_picker"
                    )
                    sp_start_date, sp_end_date = week_options[chosen_week]

                elif date_selection_mode == "Specific Month":
                    month_names = [
                        "January",
                        "February",
                        "March",
                        "April",
                        "May",
                        "June",
                        "July",
                        "August",
                        "September",
                        "October",
                        "November",
                        "December",
                    ]
                    if is_test_dataset:
                        st.selectbox(
                            "Select Month", ["January"], index=0, key="sp_month_picker"
                        )
                        sp_start_date = date(2025, 1, 1)
                        sp_end_date = date(2025, 1, 31)
                    else:
                        chosen_month = st.selectbox(
                            "Select Month", month_names, index=0, key="sp_month_picker"
                        )
                        m_idx = month_names.index(chosen_month) + 1
                        sp_start_date = date(active_year, m_idx, 1)
                        last_day = calendar.monthrange(active_year, m_idx)[1]
                        sp_end_date = date(active_year, m_idx, last_day)

                else:
                    c_range1, c_range2 = st.columns(2)
                    if is_test_dataset:
                        min_sp_bound = date(2025, 1, 1)
                        max_sp_bound = date(2025, 1, 31)
                        default_sp_start = date(2025, 1, 1)
                        default_sp_end = date(2025, 1, 31)
                    else:
                        min_sp_bound = date(active_year, 1, 1)
                        max_sp_bound = date(active_year, 12, 31)
                        default_sp_start = date(active_year, 1, 1)
                        default_sp_end = date(active_year, 1, 31)

                    with c_range1:
                        sp_start_date = st.date_input(
                            "Start Date",
                            value=default_sp_start,
                            min_value=min_sp_bound,
                            max_value=max_sp_bound,
                            key="sp_start_picker",
                        )
                    with c_range2:
                        sp_end_date = st.date_input(
                            "End Date",
                            value=default_sp_end,
                            min_value=min_sp_bound,
                            max_value=max_sp_bound,
                            key="sp_end_picker",
                        )

            load_profile = st.button(
                "Load Physical Profile",
                type="primary",
                key="load_physical_profile",
            )

            st.markdown("---")

            query_key = (
                sp_target_path,
                graph_bmu_pick,
                str(sp_start_date),
                str(sp_end_date),
                sp_is_azure,
            )

            if load_profile:
                if graph_bmu_pick is None:
                    st.error("Please select a BMU.")
                elif sp_start_date > sp_end_date:
                    st.error("Start Date must be before or equal to End Date.")
                else:
                    try:
                        with st.spinner(
                            f"Loading Settlement Period data for "
                            f"{graph_bmu_pick}..."
                        ):
                            query_start = time.perf_counter()

                            queried_sp_df = query_sp_data(
                                sp_target_path,
                                graph_bmu_pick,
                                str(sp_start_date),
                                str(sp_end_date),
                                is_azure=sp_is_azure,
                                azure_token=sp_azure_token,
                            )

                            query_duration = time.perf_counter() - query_start

                        st.session_state["sp_query_result"] = queried_sp_df
                        st.session_state["sp_query_key"] = query_key
                        st.session_state["sp_query_duration"] = query_duration
                        st.session_state["sp_query_error"] = None

                    except Exception as query_exc:
                        st.session_state.pop("sp_query_result", None)
                        st.session_state.pop("sp_query_key", None)
                        st.session_state["sp_query_error"] = str(query_exc)

            stored_query_key = st.session_state.get("sp_query_key")
            stored_query_error = st.session_state.get("sp_query_error")
            stored_query_duration = st.session_state.get("sp_query_duration")

            if stored_query_error:
                st.error(f"Settlement Period query failed: {stored_query_error}")

            if stored_query_key == query_key:
                sp_df = st.session_state.get(
                    "sp_query_result",
                    pd.DataFrame(),
                )
                query_has_run = True
            else:
                sp_df = pd.DataFrame()
                query_has_run = False
                if not stored_query_error:
                    st.info(
                        "Select a BMU and date range, then click "
                        "**Load Physical Profile**."
                    )

            if query_has_run:
                bmu_unfiltered_rows = len(sp_df)
                query_diag_error = None

                if (
                    sp_df.empty
                    and sp_target_path
                    and not sp_is_azure
                    and os.path.exists(sp_target_path)
                ):
                    try:
                        con_diag = duckdb.connect()
                        diag_query_target = sp_target_path.replace("\\", "/")
                        bmu_unfiltered_rows = con_diag.execute(
                            f"SELECT count(*) FROM read_csv_auto('{diag_query_target}', header=True) WHERE nationalGridBmUnit = ?",
                            [graph_bmu_pick],
                        ).fetchone()[0]
                        con_diag.close()
                    except Exception as diag_err:
                        query_diag_error = str(diag_err)

                # Diagnostics Expander (Zero Icons)
                with st.expander("Settlement Period Query Diagnostics", expanded=False):
                    diag_c1, diag_c2 = st.columns(2)
                    with diag_c1:
                        st.markdown(f"**Data Source Mode**: `{sp_source_label}`")
                        st.markdown(f"**Resolved SP Target**: `{sp_target_path}`")
                        st.markdown(f"**Selected BMU**: `{graph_bmu_pick}`")
                        st.markdown(
                            f"**Selected Date Range**: `{sp_start_date}` to `{sp_end_date}`"
                        )
                    with diag_c2:
                        st.markdown(f"**BMU Rows (In Date Range)**: `{len(sp_df):,}`")
                        st.markdown(
                            f"**BMU Total Rows in Source**: `{bmu_unfiltered_rows:,}`"
                            if isinstance(bmu_unfiltered_rows, int)
                            else f"`{bmu_unfiltered_rows}`"
                        )
                        if query_diag_error:
                            st.markdown(
                                f"**Query Status**: `Query Notice: {query_diag_error}`"
                            )
                        else:
                            st.markdown(
                                f"**Query Status**: `{'Success' if not sp_df.empty else ('BMU Not in Dataset' if bmu_unfiltered_rows == 0 else 'Zero Rows in Date Range')}`"
                            )
                        if stored_query_duration is not None:
                            st.markdown(
                                f"**Query Duration**: "
                                f"`{stored_query_duration:.2f} seconds`"
                            )
                if sp_df.empty:
                    if bmu_unfiltered_rows == 0:
                        bmu_sample_str = (
                            ", ".join(sp_sample_bmus[:10])
                            if sp_sample_bmus
                            else "None detected"
                        )
                        st.info(
                            f"BMU **{graph_bmu_pick}** has no records in this Settlement Period dataset (`{sp_source_label}`).\n\n"
                            f"Sample units present in this dataset: **{bmu_sample_str}**"
                        )
                    else:
                        st.info(
                            f"BMU **{graph_bmu_pick}** has {bmu_unfiltered_rows:,} records in this dataset, but none between {sp_start_date} and {sp_end_date}. "
                            f"Please adjust the investigation date range."
                        )
                else:
                    # Prepare datetime and clean date formatting for all charts
                    sp_plot_df = sp_df.copy()
                    sp_plot_df["timeFrom"] = pd.to_datetime(sp_plot_df["timeFrom"])

                    num_days = (
                        (sp_end_date - sp_start_date).days + 1
                        if hasattr(sp_end_date, "day") and hasattr(sp_start_date, "day")
                        else 1
                    )

                    if num_days == 1:
                        x_tick_format = "%H:%M"
                        x_hover_format = "%H:%M"
                        x_tick_angle = 0
                    elif num_days <= 7:
                        x_tick_format = "%d %b %H:%M"
                        x_hover_format = "%d %b %Y %H:%M"
                        x_tick_angle = -30
                    elif num_days <= 31:
                        x_tick_format = "%d %b"
                        x_hover_format = "%d %b %Y %H:%M"
                        x_tick_angle = -45
                    else:
                        x_tick_format = "%d %b %Y"
                        x_hover_format = "%d %b %Y %H:%M"
                        x_tick_angle = -45

                    # CHART 1: Primary Physical Profile (PN, Metered Output, MEL, MIL, ABSVD)
                    st.subheader(f"{graph_bmu_pick} Physical Profile")
                    st.caption(
                        "Physical Notification (PN), Settlement Metered Output, Maximum Export Limit (MEL), Stable Minimum Limit (MIL), and ABSVD in MW."
                    )

                    fig_primary = go.Figure()

                    if "PNLevel_MW" in sp_plot_df.columns:
                        fig_primary.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["PNLevel_MW"],
                                mode="lines",
                                name="PN",
                                line=dict(color="#0284c7", width=2.2),
                                hovertemplate="PN: %{y:.2f} MW<extra></extra>",
                            )
                        )

                    if "Metered_MW" in sp_plot_df.columns:
                        fig_primary.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["Metered_MW"],
                                mode="lines",
                                name="Metered Output",
                                line=dict(color="#cf3e9e", width=2.2),
                                hovertemplate="Metered Output: %{y:.2f} MW<extra></extra>",
                            )
                        )

                    if "MELLevel_MW" in sp_plot_df.columns:
                        fig_primary.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["MELLevel_MW"],
                                mode="lines",
                                name="MEL",
                                line=dict(color="#400732", width=2.2, shape="hv"),
                                hovertemplate="MEL: %{y:.2f} MW<extra></extra>",
                            )
                        )

                    if "MILLevel_MW" in sp_plot_df.columns:
                        fig_primary.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["MILLevel_MW"],
                                mode="lines",
                                name="MIL",
                                line=dict(
                                    color="#6b7280", width=1.8, shape="hv", dash="dot"
                                ),
                                hovertemplate="MIL: %{y:.2f} MW<extra></extra>",
                            )
                        )

                    if "ABSVD_MW" in sp_plot_df.columns:
                        fig_primary.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["ABSVD_MW"],
                                mode="lines",
                                name="ABSVD",
                                line=dict(color="#d97706", width=2.0),
                                hovertemplate="ABSVD: %{y:.2f} MW<extra></extra>",
                            )
                        )

                    fig_primary.update_layout(
                        title=f"{graph_bmu_pick} Physical Profile",
                        hovermode="x unified",
                        yaxis_title="MW",
                        legend=dict(
                            orientation="h",
                            yanchor="bottom",
                            y=1.02,
                            xanchor="right",
                            x=1,
                        ),
                    )
                    fig_primary.update_xaxes(
                        title=None,
                        tickformat=x_tick_format,
                        hoverformat=x_hover_format,
                        tickangle=x_tick_angle,
                        showgrid=True,
                        gridcolor="#f1f5f9",
                    )
                    fig_primary.update_yaxes(
                        zeroline=True, zerolinewidth=1.5, zerolinecolor="#000000"
                    )
                    render_chart(fig_primary)

                    col_g1, col_g2 = st.columns(2)

                    # CHART 2: Expected Output vs Metered
                    with col_g1:
                        st.subheader("Expected Output vs Metered")
                        st.caption(
                            "Comparison of expected delivered output, including ABSVD volume, "
                            "against actual metered generation."
                        )

                        fig_expected_vs_metered = go.Figure()

                        if "ExpectOT_MW" in sp_plot_df.columns:
                            fig_expected_vs_metered.add_trace(
                                go.Scatter(
                                    x=sp_plot_df["timeFrom"],
                                    y=sp_plot_df["ExpectOT_MW"],
                                    mode="lines",
                                    name="Expected Output",
                                    line=dict(
                                        color="#0284c7",
                                        width=2.0,
                                    ),
                                    hovertemplate=(
                                        "Expected Output: %{y:.2f} MW" "<extra></extra>"
                                    ),
                                )
                            )

                        if "Metered_MW" in sp_plot_df.columns:
                            fig_expected_vs_metered.add_trace(
                                go.Scatter(
                                    x=sp_plot_df["timeFrom"],
                                    y=sp_plot_df["Metered_MW"],
                                    mode="lines",
                                    name="Metered",
                                    line=dict(
                                        color="#cf3e9e",
                                        width=2.0,
                                    ),
                                    hovertemplate=(
                                        "Metered: %{y:.2f} MW" "<extra></extra>"
                                    ),
                                )
                            )

                        fig_expected_vs_metered.update_layout(
                            title=(
                                f"Expected Output vs Metered — " f"{graph_bmu_pick}"
                            ),
                            yaxis_title="MW",
                            hovermode="x unified",
                        )

                        fig_expected_vs_metered.update_xaxes(
                            title=None,
                            tickformat=x_tick_format,
                            hoverformat=x_hover_format,
                            tickangle=x_tick_angle,
                            showgrid=True,
                            gridcolor="#f1f5f9",
                        )

                        fig_expected_vs_metered.update_yaxes(
                            zeroline=True,
                            zerolinewidth=1.2,
                            zerolinecolor="#000000",
                        )

                        render_chart(fig_expected_vs_metered)

                    # CHART 3: Net Error Profile (in % with positive/negative colors)
                    with col_g2:
                        st.subheader("Net Error Profile")
                        st.caption(
                            "Directional bias (Net Error %) centered around zero reference line."
                        )
                        fig_neterr = go.Figure()
                        if "NetError%" in sp_plot_df.columns:
                            err_colors = [
                                "#0284c7" if val >= 0 else "#d97706"
                                for val in sp_plot_df["NetError%"]
                            ]
                            fig_neterr.add_trace(
                                go.Bar(
                                    x=sp_plot_df["timeFrom"],
                                    y=sp_plot_df["NetError%"],
                                    name="Net Error (%)",
                                    marker_color=err_colors,
                                    hovertemplate="Net Error: %{y:.2f}%<extra></extra>",
                                )
                            )
                        fig_neterr.add_hline(
                            y=0,
                            line_dash="solid",
                            line_color="#000000",
                            line_width=1.5,
                        )
                        fig_neterr.update_layout(
                            title=f"Net Error Profile — {graph_bmu_pick}",
                            yaxis_title="Net Error (%)",
                            hovermode="x unified",
                        )
                        fig_neterr.update_xaxes(
                            title=None,
                            tickformat=x_tick_format,
                            hoverformat=x_hover_format,
                            tickangle=x_tick_angle,
                            showgrid=True,
                            gridcolor="#f1f5f9",
                        )
                        render_chart(fig_neterr)

                    # CHART 4: MEL / MIL vs PN
                    st.subheader("MEL / MIL vs PN")
                    st.caption(
                        "Physical Notification compared against Maximum Export Limits (MEL) and Minimum Import/Export Limits (MIL)."
                    )
                    fig_envelope = go.Figure()

                    if "MELLevel_MW" in sp_plot_df.columns:
                        fig_envelope.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["MELLevel_MW"],
                                mode="lines",
                                name="MEL",
                                line=dict(color="#400732", width=2.0, shape="hv"),
                                hovertemplate="MEL: %{y:.2f} MW<extra></extra>",
                            )
                        )
                    if "MILLevel_MW" in sp_plot_df.columns:
                        fig_envelope.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["MILLevel_MW"],
                                mode="lines",
                                name="MIL",
                                line=dict(
                                    color="#6b7280", width=1.8, shape="hv", dash="dot"
                                ),
                                hovertemplate="MIL: %{y:.2f} MW<extra></extra>",
                            )
                        )
                    if "PNLevel_MW" in sp_plot_df.columns:
                        fig_envelope.add_trace(
                            go.Scatter(
                                x=sp_plot_df["timeFrom"],
                                y=sp_plot_df["PNLevel_MW"],
                                mode="lines",
                                name="PN",
                                line=dict(color="#0284c7", width=2.2),
                                hovertemplate="PN: %{y:.2f} MW<extra></extra>",
                            )
                        )
                    fig_envelope.update_layout(
                        title=f"MEL / MIL vs PN — {graph_bmu_pick}",
                        yaxis_title="MW",
                        hovermode="x unified",
                    )
                    fig_envelope.update_xaxes(
                        title=None,
                        tickformat=x_tick_format,
                        hoverformat=x_hover_format,
                        tickangle=x_tick_angle,
                        showgrid=True,
                        gridcolor="#f1f5f9",
                    )
                    fig_envelope.update_yaxes(
                        zeroline=True, zerolinewidth=1.2, zerolinecolor="#000000"
                    )
                    render_chart(fig_envelope)

                    # Export Queried SP Records
                    csv_sp = sp_df.to_csv(index=False).encode("utf-8")
                    st.download_button(
                        label=f"Download Settlement Period Data ({graph_bmu_pick})",
                        data=csv_sp,
                        file_name=f"{graph_bmu_pick}_sp_data_{sp_start_date}_to_{sp_end_date}.csv",
                        mime="text/csv",
                    )

    # --- TAB 7: Require Attention (Interactive Fuel Type Selector) ---
    with tab5:
        st.markdown(
            """
            <div style="margin-bottom: 12px;">
                <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 4px;">Require Attention: Units Exceeding Thresholds</h2>
                <p style="color: #000000; font-size: 0.92rem; font-weight: 500; margin-top: 0; margin-bottom: 14px;">
                    Balancing Mechanism Units exceeding operational error tolerances (Wind/Solar: Net Error outside ±3% or ABS Error ≥ 9.4%; Other Fuels: Net Error outside ±1% or ABS Error ≥ 2.6%).
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()

        if attention_df.empty:
            st.success(
                "No BMUs require attention! All units within operational tolerances."
            )
        else:
            attention_df["Reason"] = attention_df.apply(get_reason, axis=1)

            st.markdown(
                f"**{len(attention_df)}** BMUs triggered attention thresholds across the fleet:<br>"
                "• **Wind & Solar**: Net Error outside ±3.0% OR Absolute Error ≥ 9.4%<br>"
                "• **All Other Fuels**: Net Error outside ±1.0% OR Absolute Error ≥ 2.6%",
                unsafe_allow_html=True,
            )

            # Compact Fuel Selector preventing vertical bloat
            available_att_fuels = sorted(attention_df["Fuel"].unique().tolist())
            fuel_counts = attention_df["Fuel"].value_counts().to_dict()
            fuel_options = [f"All Fuels ({len(attention_df)} units)"] + [
                f"{f} ({fuel_counts[f]} units)" for f in available_att_fuels
            ]

            selected_att_option = st.selectbox(
                "Filter Attention Units by Fuel Type",
                fuel_options,
                index=0,
                key="att_fuel_selector",
            )

            if selected_att_option.startswith("All Fuels"):
                subset = attention_df.sort_values("A_ABS_Error%", ascending=False)
                active_fuel_label = "All Fuels"
                total_fuel_bmus = df_annual_raw["BMU"].nunique()
            else:
                fuel_name = selected_att_option.split(" (")[0]
                subset = attention_df[attention_df["Fuel"] == fuel_name].sort_values(
                    "A_ABS_Error%", ascending=False
                )
                active_fuel_label = fuel_name
                total_fuel_bmus = df_annual_raw[df_annual_raw["Fuel"] == fuel_name][
                    "BMU"
                ].nunique()

            pct_fleet_flagged = (
                (len(subset) / total_fuel_bmus * 100) if total_fuel_bmus > 0 else 0.0
            )

            # 5 Key metrics for selected fuel group (added % Fuel Fleet Flagged)
            k1, k2, k3, k4, k5 = st.columns(5)
            k1.metric("Flagged BMUs", len(subset))
            k2.metric(
                "% Fuel Fleet Flagged",
                f"{pct_fleet_flagged:.1f}%",
                delta=f"{len(subset)} / {total_fuel_bmus} units",
                delta_color="off",
            )
            k3.metric("Median ABS Error %", f"{subset['A_ABS_Error%'].median():.2f}%")
            k4.metric("Max ABS Error %", f"{subset['A_ABS_Error%'].max():.2f}%")
            k5.metric(
                "Total ABS Volume Error", f"{subset['ABSError'].sum()/1000:,.2f} GWh"
            )

            st.markdown(f"### {active_fuel_label} — List of Units")
            display_cols = ["BMU", "Fuel", "Reason", "A_Net_Error%", "A_ABS_Error%"]
            if "installedCapacity_mwh" in subset.columns:
                display_cols.append("installedCapacity_mwh")

            st.dataframe(
                subset[display_cols].style.format(
                    {
                        "A_Net_Error%": "{:+.2f}%",
                        "A_ABS_Error%": "{:.2f}%",
                        "installedCapacity_mwh": "{:,.1f}",
                    }
                ),
                use_container_width=True,
                hide_index=True,
            )

            csv_att = subset.to_csv(index=False).encode("utf-8")
            st.download_button(
                label=f"Download {active_fuel_label} Attention Units (CSV)",
                data=csv_att,
                file_name=f"bmus_requiring_attention_{active_fuel_label.lower().replace(' ', '_')}_{selected_year}.csv",
                mime="text/csv",
            )

    # --- TAB 8: Exports (Central Export Hub) ---
    with tab6:
        st.header("Central Export Hub")
        st.caption(
            f"Consolidated download center for all fleet, monthly, fuel, and unit datasets ({selected_year})."
        )
        st.markdown("---")

        ex_col1, ex_col2, ex_col3 = st.columns(3)
        with ex_col1:
            st.subheader("1. Annual Summary")
            st.caption("Fleet-wide performance evaluation and metrics per BMU.")
            csv_annual = df_annual.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Annual Summary (CSV)",
                data=csv_annual,
                file_name=f"annual_summary_{selected_year}_filtered.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with ex_col2:
            st.subheader("2. Monthly Summary")
            st.caption("Granular monthly records per BMU across the calendar year.")
            csv_monthly = df_monthly.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Monthly Summary (CSV)",
                data=csv_monthly,
                file_name=f"monthly_summary_{selected_year}_filtered.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with ex_col3:
            st.subheader("3. Require Attention Dataset")
            st.caption("BMUs exceeding operational error tolerances.")
            if not attention_df.empty:
                csv_attn = attention_df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label="Download Attention Dataset (CSV)",
                    data=csv_attn,
                    file_name=f"needs_attention_list_{selected_year}.csv",
                    mime="text/csv",
                    use_container_width=True,
                )
            else:
                st.info("No attention units to download.")

        st.markdown("---")

        ex_col4, ex_col5, ex_col6 = st.columns(3)
        with ex_col4:
            st.subheader("4. Fuel Performance Summary")
            st.caption("Aggregate volume, net bias, and median error per fuel.")
            csv_fuel = fuel_summary.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Fuel Summary (CSV)",
                data=csv_fuel,
                file_name=f"fuel_performance_summary_{selected_year}.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with ex_col5:
            st.subheader("5. Error Band Composition")
            st.caption("Distribution of units across the 5 operational error bands.")
            band_export = df_annual[
                ["BMU", "Fuel", "ErrorBand", "A_ABS_Error%"]
            ].sort_values(["ErrorBand", "A_ABS_Error%"])
            csv_band = band_export.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Error Bands (CSV)",
                data=csv_band,
                file_name=f"error_band_composition_{selected_year}.csv",
                mime="text/csv",
                use_container_width=True,
            )

        with ex_col6:
            st.subheader("6. Technology Summary")
            st.caption("Comprehensive technology deep dive and metrics per fuel type.")
            tech_summary = (
                df_annual.groupby("Fuel")
                .agg(
                    BMU_Count=("BMU", "nunique"),
                    Median_ABS_Error=("A_ABS_Error%", "median"),
                    Worst_ABS_Error=("A_ABS_Error%", "max"),
                    Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                    Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
                )
                .reset_index()
                .sort_values("Total_ABS_GWh", ascending=False)
            )
            csv_tech = tech_summary.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Technology Summary (CSV)",
                data=csv_tech,
                file_name=f"technology_summary_{selected_year}.csv",
                mime="text/csv",
                use_container_width=True,
            )


# Protect module-level execution so that unit tests can import functions cleanly
if st.runtime.exists():
    run_streamlit_app()
