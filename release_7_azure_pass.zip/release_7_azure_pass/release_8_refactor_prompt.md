# Release 8 - PN Accuracy Dashboard Structural Refactor

## Role

You are my colleague senior Python engineer performing a controlled structural refactor of the PN Accuracy Streamlit dashboard.

Release 7 is now the verified functional baseline. Release 8 is a STRUCTURAL REFACTOR ONLY.

The objective is to reduce the size and responsibility of `app.py`, establish clear application layers, improve maintainability and debugging, and create clean boundaries for later performance optimisation.

Do not redesign the application and do not change established analytical behaviour.

## 1. Context: What Has Been Completed Before Release 8

### Release 7 Azure integration

The dashboard supports two principal storage modes:

1. Azure Blob Storage
2. Local files from the `inputs/` directory

Annual and monthly summary datasets remain CSV:

```text
annual_summary_<year>.csv
monthly_summary_<year>.csv
```

Settlement Period data now differs by source:

```text
Azure: sp_summary_<year>.parquet
Local: sp_summary_<year>.csv
```

The intention is that the storage source is an implementation detail. Once data is returned, downstream analytical and visualisation logic should operate against the same DataFrame contract.

### Settlement Period CSV + Parquet twin

The upstrema pipeline ha been updated to retain the legacy Settlement Period CSV and additionally generate a Parquet twin from the same final `combined_df`.

The pipeline therefore produces:

```text
sp_summary_<year>.csv
sp_summary_<year>.parquet
```

No separate Parquet calculations exist. Both outputs originate from the same final Settlement Period DataFrame after the existing report-level capping logic.

The pipeline storage class now includes a dedicated Parquet aggregate writer using pandas/PyArrow with Snappy compression for normal pipeline generation.

Historical 2025 Parquet was generated separately from the already-completed 2025 CSV using DuckDB `COPY ... FORMAT PARQUET, COMPRESSION SNAPPY`, avoiding a rerun of the frozen 2025 analytical pipeline.

### Parquet availability

Settlement Period Parquet data is now available for both:

```text
2025
2026
```

Release 7 can consume these Azure Parquet datasets.

### Azure Settlement Period querying

The Release 7 dashboard no longer queries the Azure Settlement Period CSV.

Azure Settlement Period queries use DuckDB:

```sql
read_parquet(...)
```

Local Settlement Period queries continue to use:

```sql
read_csv_auto(...)
```

DuckDB authenticates to Azure through:

```text
PROVIDER CREDENTIAL_CHAIN
```

The previous manually retrieved access-token path is no longer required by the DuckDB query. Some compatibility plumbing such as the `azure_token` function argument remains temporarily and may be cleaned up during Release 8 if doing so is behaviour-preserving.

### User-triggered Settlement Period query

A key Release 7 change was preventing the expensive Settlement Period query from executing automatically during Streamlit reruns.

The BMU Units Physical Profile now requires the user to explicitly click:

```text
Load Physical Profile
```

The query result and its query key are retained in `st.session_state`.

The query key identifies the current source, BMU and selected date range so results are only displayed against the corresponding request.

This behaviour MUST be preserved.

### Query diagnostics

Release 7 now exposes Settlement Period diagnostics including:

- data source mode
- resolved SP target
- selected BMU
- selected date range
- rows returned
- query status
- query duration

A recorded Release 7 Azure Parquet benchmark is:

```text
Dataset: sp_summary_2025.parquet
BMU: fjdkfdkfjkdjfkdj
Date range: 2025-01-14 to 2025-01-16
Rows returned after dashboard deduplication: 144
Query status: Success
Query duration: 17.66 seconds --> this is key for the future releases after 8 --> we need to make this feel almost instant
```

This is an important pre-refactor regression benchmark.

A separate observed monthly Azure Parquet query completed in approximately 5-10 seconds.

Do not interpret these timings as performance targets to optimise during the refactor. They are baseline observations for regression comparison.

### Physical Profile analytical correction

The secondary comparison chart was corrected from:

```text
PN vs Metered
```

to:

```text
Expected Output vs Metered
```

The chart now uses:

```text
ExpectOT_MW
Metered_MW
```

This reflects the established requirement that Expected Output (`ExpectOT`) represents expected delivery including ABSVD volume, rather than comparing Metered solely against the original PN.

The dashboard must NOT recompute `ExpectOT`. The pipeline-generated `ExpectOT` column remains the source of truth.

The main Physical Profile chart still shows the existing physical series, including PN, Metered, MEL, MIL and ABSVD.

### Azure/local filename distinction

Release 7 now distinguishes:

```python
sp_local_filename = f"sp_summary_{selected_year}.csv"
sp_azure_filename = f"sp_summary_{selected_year}.parquet"
```

This distinction must remain clear after the refactor.

Azure diagnostics and availability messages must describe Parquet.

Local diagnostics and availability messages must describe CSV.

Do not collapse these back into a misleading generic filename.

## 2. Critical Release 8 Constraint

Release 7 is the behavioural baseline.

Release 8 must change STRUCTURE, not application behaviour.

Prefer moving existing working code over rewriting it.

Do NOT:

- change analytical calculations
- change methodology
- change thresholds
- change column mappings
- change the meaning of ExpectOT
- recompute ExpectOT in the dashboard
- change Settlement Period deduplication
- change MW conversion logic
- change charts unless required solely to move them into modules
- change chart colours
- change labels
- change Streamlit layout
- change tabs
- change filters
- change BMU selection behaviour
- change date-selection behaviour
- change exports
- change Azure folder structure
- change local folder structure
- remove the local fallback
- revert Azure Settlement Period querying to CSV
- change the pipeline
- regenerate Parquet
- add query caching
- add manual refresh behaviour
- tune DuckDB performance
- partition Parquet
- alter Parquet row groups
- add new dependencies
- introduce dependency injection
- introduce abstract base classes
- create generic repository frameworks
- optimise code without evidence
- blindly replace Python `for` loops merely because they are loops

Correctness and behavioural parity are more important than elegance.

## 3. Important Performance Guidance

Do not assume existing `for` loops are performance problems.

Several loops in Release 7 iterate over a small number of known columns, for example numeric coercion and MW derivation. The operations performed inside those loops are already vectorised pandas Series operations.

Examples include loops over columns such as:

```text
PNLevel
MELLevel
MILLevel
Metered
ExpectOT
```

These should not be rewritten merely to remove the `for` statement.

Potential row-wise operations such as `DataFrame.apply(..., axis=1)` may be noted as future optimisation candidates, but Release 8 must not change them unless required for correctness.

Performance optimisation should happen after the structural refactor, using measurements.

## 4. Required Target Structure

Refactor toward this structure:

```text
app.py
constants.py

data/
    __init__.py
    azure_blob_helper.py
    data_loader.py
    sp_repository.py

services/
    __init__.py
    data_processing.py

utils/
    __init__.py
    chart_utils.py

views/
    __init__.py
    executive_summary.py
    median_error.py
    total_gwh_error.py
    technology.py
    bmu_explorer.py
    physical_profile.py
    require_attention.py
    exports.py
```

Do not create additional layers without a concrete need.

## 5. app.py Responsibility

`app.py` must become primarily the orchestration layer.

It should be responsible for:

- Streamlit page configuration
- top-level application lifecycle
- branding/styling where appropriate
- calendar year selection
- source selection
- obtaining data through the data layer
- application-level filters
- tab construction/navigation
- calling view render functions

It should NOT contain:

- DuckDB SQL
- Azure authentication implementation
- large data-processing functions
- Settlement Period transformation logic
- large Plotly chart definitions
- detailed tab implementations

Do not force `app.py` to become artificially tiny. It should remain readable orchestration code.

## 6. data/azure_blob_helper.py

Move/preserve the existing Azure helper here.

Responsibilities:

- Azure Blob client creation
- Azure CLI credential handling currently used by the dashboard helper
- annual summary path resolution
- monthly summary path resolution
- Settlement Period Parquet path resolution
- annual CSV retrieval
- monthly CSV retrieval
- SP Parquet existence check
- SP `azure://` URL construction

Preserve the current distinction:

```text
annual/monthly Azure -> CSV
Settlement Period Azure -> Parquet
```

The existing full CSV `read_sp_summary()` method may be retained for compatibility if removal is not clearly safe. If it is unused, identify it as cleanup/technical debt rather than removing it without evidence.

## 7. data/data_loader.py

Create a small data-loading boundary for application source selection.

Responsibilities should include only what is genuinely useful, such as:

- resolving local input files
- loading annual/monthly Azure summaries
- loading annual/monthly local summaries
- resolving local Settlement Period source
- resolving Azure Settlement Period source metadata

Do not duplicate analytical processing between Azure and local modes.

The output contract should make downstream logic independent of whether annual/monthly data came from Azure or local files.

Prefer an explicit and simple return structure rather than a framework.

## 8. data/sp_repository.py

This is the most important Release 8 boundary.

Move the current `query_sp_data(...)` implementation here.

Responsibilities:

- DuckDB connection lifecycle
- Azure extension setup
- Azure `CREDENTIAL_CHAIN` secret setup
- Azure Parquet querying with `read_parquet()`
- local CSV querying with `read_csv_auto()`
- BMU filtering
- settlement-date filtering
- query ordering
- query error context
- first-record deduplication
- SP MW-derived fields
- existing Bid/Offer absolute volume fields
- `NetError%` normalisation

The public repository function must return the same DataFrame contract currently returned by Release 7.

Do not modify query semantics during the move.

### Preserve SP deduplication exactly

```python
df.drop_duplicates(
    subset=[
        "nationalGridBmUnit",
        "settlementDate",
        "settlementPeriod",
    ],
    keep="first",
)
```

The original SP source can contain more than one source row per Settlement Period. This existing dashboard deduplication is intentional and must not be removed or altered during the refactor.

### Preserve MW conversion exactly

```text
MW = MWh * 60 / duration_min
```

with the current 30-minute fallback and factor-2 fallback behaviour.

Preserve creation of:

```text
PNLevel_MW
MELLevel_MW
MILLevel_MW
Metered_MW
ExpectOT_MW
ABSVD_MW
BidVolume_abs
OfferVolume_abs
NetError%
```

### Leave performance tuning for later -> release 9 etc.

The current query uses `SELECT *`.

Do not change that during the structural refactor even though explicit column projection may later improve remote Parquet performance.

After Release 8 is verified, future profiling should be able to separately measure:

- DuckDB connection creation
- Azure extension install/load
- credential/secret setup
- remote Parquet scan
- DataFrame materialisation
- SP post-processing

Release 8 should make that profiling easier, not perform the optimisation itself.

## 9. services/data_processing.py

Move the current analytical functions here:

```text
process_data
apply_filters
categorize_error
get_reason
```

Preserve logic exactly.

Do not change:

- error thresholds
- annual/monthly schema compatibility mappings
- NeedsAttention logic
- error-band definitions
- numeric coercion behaviour
- existing zero/fallback handling

Current row-wise `.apply()` calls may be documented as potential future optimisation candidates but should remain unchanged during Release 8 unless a verified bug requires otherwise.

## 10. utils/chart_utils.py

Move:

```text
force_light_chart
render_chart
```

Preserve styling exactly.

Do not redesign Plotly themes or colours.

## 11. Views

Move each major Streamlit tab into its own view module.

Use simple render functions such as:

```python
render_executive_summary(...)
render_median_error(...)
render_total_gwh_error(...)
render_technology(...)
render_bmu_explorer(...)
render_physical_profile(...)
render_require_attention(...)
render_exports(...)
```

Function signatures should contain only the inputs the view genuinely requires.

Do not introduce classes solely for views.

Move existing working view code rather than recreating it.

The visual output must remain materially equivalent to Release 7.

## 12. views/physical_profile.py

This view requires the strongest parity protection.

Preserve:

- BMU search
- BMU selector
- Specific Day
- Specific Week
- Specific Month
- Custom Date Range
- `Load Physical Profile` button
- loading spinner
- query key
- `st.session_state` query result persistence
- `st.session_state` query error handling
- query duration persistence
- Settlement Period Query Diagnostics
- main Physical Profile chart
- Expected Output vs Metered chart
- Net Error Profile
- MEL / MIL vs PN chart
- Settlement Period CSV download

The view should call `data/sp_repository.py` for SP retrieval.

It must NOT contain:

- DuckDB SQL
- Azure secret creation
- Azure extension setup
- repository-level transformation code

Conceptually:

```text
physical_profile.py
        |
        v
sp_repository.py
        |
        +---- Azure Parquet
        |
        +---- Local CSV
```

## 13. Expected Output vs Metered Contract

Preserve the corrected Release 7 comparison.

The secondary comparison chart must be:

```text
Expected Output vs Metered
```

using:

```text
ExpectOT_MW
Metered_MW
```

Do not regress this to PN vs Metered.

Chart description should continue to communicate that Expected Output includes the established expected-delivery adjustment represented by pipeline `ExpectOT`.

Do not independently reconstruct ExpectOT from PN and ABSVD in the dashboard.

## 14. Data-Source Contract

Release 8 must maintain this behaviour:

```text
Azure
  annual  -> CSV
  monthly -> CSV
  SP      -> Parquet through DuckDB

Local
  annual  -> CSV
  monthly -> CSV
  SP      -> CSV through DuckDB
```

The rest of the application should operate on DataFrames without needing storage-specific logic.

Keep source-specific filenames explicit where user diagnostics require them:

```python
sp_local_filename = f"sp_summary_{selected_year}.csv"
sp_azure_filename = f"sp_summary_{selected_year}.parquet"
```

## 15. Error Handling

Do not restore silent operational failure patterns such as:

```python
except Exception:
    return pd.DataFrame()
```

when the exception represents a genuine retrieval/query failure.

Errors should retain enough context to distinguish:

- Azure connection/access errors
- missing Azure Parquet
- missing local CSV
- DuckDB query errors
- processing errors

Do not expose access tokens, credentials or secrets.

A legitimate query returning zero rows is not the same as a query failure.

## 16. Dependencies

Do not add dependencies.

Current relevant runtime technologies include:

- Python
- Streamlit
- pandas
- NumPy
- Plotly
- DuckDB
- Azure Storage SDK
- Azure Identity
- PyArrow in the pipeline environment

Release 8 is an application refactor and must not introduce package changes silently.

A formal reproducible project dependency definition is recognised as future technical debt, create this for release 8 in the form of toml file

## 17. Tests

Use `pytest` for functions.

Do not add unit tests for classes unless explicitly required.

Preserve existing tests wherever possible.

When functions move modules, update imports rather than rewriting test intent.

Add only focused tests necessary to establish behavioural parity at the new module boundaries.

Useful test boundaries include:

- analytical processing functions
- local file resolution
- SP post-processing
- query parameter construction/behaviour where practical
- mocked Azure/DuckDB boundaries where integration access is unavailable

Do not pretend an Azure integration test has run if it has not.

## 18. Mandatory Release 7 -> Release 8 Regression Checks

Before Release 8 is accepted, verify as much of the following as the available environment allows via testing

### Application

- application imports successfully
- application starts under Streamlit
- all 8 tabs still exist
- filters still work
- year selection still works
- source selection still works

### Annual/monthly

- Azure annual loads
- Azure monthly loads
- local annual loads
- local monthly loads
- analytical outputs remain equivalent

### Settlement Period

- Azure detects `sp_summary_2025.parquet`
- Azure detects `sp_summary_2026.parquet`
- Azure query uses Parquet
- local query continues to use CSV
- `Load Physical Profile` remains mandatory
- unrelated widget reruns do not automatically trigger a new SP query
- query result persistence remains correct
- changing BMU/date/source does not display a stale mismatched result



## 20. Out of Scope for Release 8

Explicitly out of scope:

- changing the PN Accuracy pipeline
- changing CSV/Parquet generation
- changing Parquet compression
- changing Parquet row-group layout
- partitioning Parquet
- removing the legacy CSV
- replacing DuckDB
- changing Azure infrastructure
- introducing a database for SP querying
- adding Streamlit query caching
- adding manual cache refresh
- optimising `INSTALL azure` / `LOAD azure`
- caching DuckDB connections
- changing `SELECT *` to column projection
- vectorising code purely for style
- UI redesign
- chart redesign
- methodology changes
- new thresholds
- new metrics

These can be assessed after Release 8 when the architecture makes them easy to profile independently.

## 21. Technical Debt to Preserve or Document, Not Silently Change

The refactor should explicitly identify but not automatically solve:

- obsolete `azure_token` compatibility plumbing
- possible unused `read_sp_summary()` full-CSV helper
- repeated DuckDB Azure extension/secret setup per query
- use of `SELECT *` for remote Parquet scans
- potential future query-result caching
- row-wise `.apply()` operations in non-SP analytical sections
- absence of a formal project dependency definition

Any cleanup of these items must be clearly justified as behaviour-neutral. Otherwise leave them for a later release.

## 22. Implementation Order

Work conservatively and incrementally.

First inspect the entire Release 7 codebase and existing tests.

Then proceed in this order:

1. Capture the current project tree and baseline test status.
2. Move chart utilities.
3. Move pure analytical/data-processing functions.
4. Move Azure storage helper into the data layer without behavioural changes.
5. Create the simple annual/monthly/local data-loader boundary.
6. Move Settlement Period querying into `sp_repository.py`.
7. Verify SP function parity before touching the Physical Profile view.
8. Move each simple view one at a time.
9. Move the Physical Profile view last because it carries the most state/query behaviour.
10. Reduce `app.py` to orchestration.
11. Run tests and import/syntax checks.
12. Perform local functional verification.
13. Perform Azure verification if the environment permits it.
14. Compare the known Release 7 SP benchmark where possible.

At each step, favour `git diff`-friendly code movement over rewrites.

## 23. Definition of Done

Release 8 is complete only when:

1. Release 7 behaviour is preserved.
2. `app.py` primarily orchestrates the application.
3. Azure/local loading concerns are isolated from UI code.
4. Settlement Period DuckDB querying is isolated in `data/sp_repository.py`.
5. Analytical processing is isolated in `services/data_processing.py`.
6. Shared Plotly rendering utilities are isolated in `utils/chart_utils.py`.
7. Each major Streamlit tab has an appropriate view module.
8. Azure annual/monthly CSV behaviour remains intact.
9. Azure SP Parquet behaviour remains intact for 2025 and 2026.
10. Local CSV fallback remains intact.
11. Explicit `Load Physical Profile` behaviour remains intact.
12. Session-state query persistence remains intact.
13. Query diagnostics, including duration, remain intact.
14. Expected Output vs Metered remains intact using pipeline `ExpectOT`.
15. Existing analytical thresholds and calculations remain unchanged.
16. No new dependencies are introduced.
17. No performance tuning is mixed into the structural refactor.
18. Applicable tests pass.
19. Syntax/import validation passes.
20. Any verification that could not be performed is explicitly reported rather than assumed.

## 24. Required Final Report

At completion, provide a concise engineering report containing:

### Final project tree

Show the resulting module/file structure.

### Files created

List each created file and its responsibility.

### Files changed

List each changed existing file and why.

### Behavioural parity

State exactly what was verified against Release 7.

### Tests

List tests/checks executed and their results.

### Azure verification

State whether Azure behaviour was actually exercised or only structurally inspected.

### Performance baseline

Report the Release 8 result for the known ZEN02A benchmark if it was actually run. Otherwise explicitly state that it was not run.

### Deferred technical debt

List relevant items deliberately left for post-refactor optimisation.

### Scope statement

Explicitly confirm whether any analytical logic, thresholds, methodology, data-source semantics or UI behaviour changed.

If anything changed beyond structural refactoring, identify it clearly rather than presenting Release 8 as fully behaviour-preserving.

## 25. Working Principles

- Read the existing code before changing it.
- Read existing tests before changing imports or structure.
- Do not invent behaviour.
- Do not infer undocumented methodology.
- Do not rewrite working code unnecessarily.
- Prefer movement over reinvention.
- Keep diffs reviewable.
- Keep functions explicit and readable.
- Use short docstrings.
- Avoid clever abstractions.
- Do not add dependencies silently.
- Use `black` formatting.
- Use `pytest` for function tests.
- Preserve observability and error visibility.
- Correctness first.
- Behavioural parity second.
- Maintainability third.
- Performance optimisation comes after Release 8.
