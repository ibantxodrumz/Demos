import os
import unittest
import pandas as pd
from tests import get_app_module, APP_DIR
import sys
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)
import constants
from azure_blob_helper import AzureBlobStorage

app = get_app_module()
query_sp_data = app.query_sp_data
find_local_input_file = app.find_local_input_file


class TestSPDuckDB(unittest.TestCase):
    """Guards Settlement Period data ingestion, DuckDB direct querying, and deduplication."""

    @classmethod
    def setUpClass(cls):
        cls.sp_path = (
            find_local_input_file("sp_summary_test.csv")
            or find_local_input_file("sp_summary_2025.csv")
        )
        if not cls.sp_path:
            # Fallback to prompt sample file if testing outside release folder
            alt_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "release_6_prompt", "sample_sp_january_2025_FOMO.csv")
            if os.path.exists(alt_path):
                cls.sp_path = os.path.abspath(alt_path)

    def test_sp_file_located(self):
        self.assertIsNotNone(self.sp_path, "sp_summary_test.csv or sp_summary_2025.csv must be located")
        self.assertTrue(os.path.exists(self.sp_path))

    def test_query_sp_data_successful_slice(self):
        df = query_sp_data(self.sp_path, "FOMO-1", "2025-01-01", "2025-01-05")
        self.assertFalse(df.empty)
        # 5 days * 48 half-hours = 240 settlement periods
        self.assertEqual(len(df), 240)
        self.assertIn("nationalGridBmUnit", df.columns)
        self.assertIn("settlementDate", df.columns)
        self.assertIn("settlementPeriod", df.columns)
        self.assertIn("timeFrom", df.columns)
        self.assertIn("PNLevel", df.columns)
        self.assertIn("MELLevel", df.columns)
        self.assertIn("Metered", df.columns)
        self.assertIn("NetError", df.columns)

    def test_query_sp_data_bid_offer_abs_magnitudes(self):
        df = query_sp_data(self.sp_path, "FOMO-1", "2025-01-01", "2025-01-02")
        self.assertIn("BidVolume_abs", df.columns)
        self.assertIn("OfferVolume_abs", df.columns)
        self.assertTrue((df["BidVolume_abs"] >= 0).all())
        self.assertTrue((df["OfferVolume_abs"] >= 0).all())

    def test_query_sp_data_deduplication(self):
        df = query_sp_data(self.sp_path, "FOMO-1", "2025-01-01", "2025-01-10")
        duplicates = df.duplicated(subset=["nationalGridBmUnit", "settlementDate", "settlementPeriod"]).sum()
        self.assertEqual(duplicates, 0, "Query result must contain zero duplicate settlement periods")

    def test_query_sp_missing_file_returns_empty_df(self):
        df = query_sp_data("non_existent_file_99999.csv", "FOMO-1", "2025-01-01", "2025-01-05")
        self.assertIsInstance(df, pd.DataFrame)
        self.assertTrue(df.empty)

    def test_query_sp_unknown_bmu_returns_empty_df(self):
        df = query_sp_data(self.sp_path, "UNKNOWN_BMU_XYZ", "2025-01-01", "2025-01-05")
        self.assertIsInstance(df, pd.DataFrame)
        self.assertTrue(df.empty)

    def test_azure_sp_blob_path_resolution(self):
        storage = AzureBlobStorage(
            account_url=constants.ACCOUNT_URL,
            container_name=constants.CONTAINER_NAME,
            project_name=constants.PROJECT_BASE_NAME,
        )
        recorded_paths = []
        storage._read_csv = lambda path: recorded_paths.append(path)

        storage.read_sp_summary(2025)
        storage.read_sp_summary(2026)

        expected = [
            "pn-accuracy-2025/internal/sp_summary_2025.csv",
            "pn-accuracy-2026/internal/sp_summary_2026.csv",
        ]
        self.assertEqual(recorded_paths, expected)

    def test_azure_get_sp_azure_url(self):
        storage = AzureBlobStorage(
            account_url=constants.ACCOUNT_URL,
            container_name=constants.CONTAINER_NAME,
            project_name=constants.PROJECT_BASE_NAME,
        )
        url_2025 = storage.get_sp_azure_url(2025)
        self.assertEqual(
            url_2025,
            f"azure://dlaaencmmdsffuks01.blob.core.windows.net/{constants.CONTAINER_NAME}/pn-accuracy-2025/internal/sp_summary_2025.csv",
        )
        url_2026 = storage.get_sp_azure_url(2026)
        self.assertEqual(
            url_2026,
            f"azure://dlaaencmmdsffuks01.blob.core.windows.net/{constants.CONTAINER_NAME}/pn-accuracy-2026/internal/sp_summary_2026.csv",
        )

    def test_sp_blob_exists_mock(self):
        storage = AzureBlobStorage(
            account_url=constants.ACCOUNT_URL,
            container_name=constants.CONTAINER_NAME,
            project_name=constants.PROJECT_BASE_NAME,
        )

        class MockBlobClient:
            def __init__(self, exists_flag):
                self._exists_flag = exists_flag

            def exists(self):
                return self._exists_flag

        class MockContainerClient:
            def get_blob_client(self, path):
                if "2025" in path:
                    return MockBlobClient(True)
                return MockBlobClient(False)

        storage.container_client = MockContainerClient()
        self.assertTrue(storage.sp_blob_exists(2025))
        self.assertFalse(storage.sp_blob_exists(2026))

    def test_sp_test_file_located(self):
        test_path = find_local_input_file("sp_summary_test.csv")
        self.assertIsNotNone(test_path, "sp_summary_test.csv must be located")
        self.assertTrue(os.path.exists(test_path))
        df = query_sp_data(test_path, "FOMO-1", "2025-01-01", "2025-01-02")
        self.assertFalse(df.empty)
        self.assertEqual(len(df), 96)

    def test_query_sp_data_mw_conversions(self):
        df = query_sp_data(self.sp_path, "FOMO-1", "2025-01-01", "2025-01-01")
        self.assertFalse(df.empty)
        self.assertIn("PNLevel_MW", df.columns)
        self.assertIn("MELLevel_MW", df.columns)
        self.assertIn("MILLevel_MW", df.columns)
        self.assertIn("Metered_MW", df.columns)
        self.assertIn("ABSVD_MW", df.columns)
        # Check first row conversion: MWh * 2 == MW (duration_min = 30)
        row0 = df.iloc[0]
        self.assertAlmostEqual(row0["PNLevel_MW"], row0["PNLevel"] * 2, places=2)
        self.assertAlmostEqual(row0["MELLevel_MW"], row0["MELLevel"] * 2, places=2)
        self.assertAlmostEqual(row0["Metered_MW"], row0["Metered"] * 2, places=2)
        # NetError% should remain in percentage as-is
        self.assertIn("NetError%", df.columns)
        self.assertAlmostEqual(row0["NetError%"], 1.26, places=1)


if __name__ == "__main__":
    unittest.main()

