# Import Constraints Intelligence Layer Dashboard (Release 1)

This folder contains a fully self-contained, interactive MVP (Minimum Viable Product) of the `Import Constraints Dashboard`, built using Streamlit. 

## Included Files

- `app.py`: The core Streamlit application script containing the dashboard logic, metrics, and Plotly visualizations.
- `requirements.txt`: All necessary Python dependencies to run the app.
- `inputs/`: The data directory containing the canonical dataset (`alerts_data.csv`).
- `.streamlit/`: Streamlit configuration settings (e.g., custom themes).

## How to Run Locally

1. **Prerequisites:** Ensure you have Python installed (preferably version 3.9+). 
2. **Open Terminal** and navigate into `IC_dashboard`dashboard` folder.
3. **Set up a Virtual Environment (Highly Recommended):**
4. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
5. **Run the Dashboard:**
   ```bash
   streamlit run app.py
   ```

## Features
- **BMU Deep Dive:** Inspect daily condition occurrence rates and chronological spread pricing for specific BMUs.
- **Ensemble Breakdowns:** Detailed, dynamic reporting on the occurrence of combinations of constraints (C1, C2, C3).
- **Spread Analysis:** Interactive density curves and heatmaps charting pricing distributions across Fuel Types, Weekdays, and Hours. 

---
