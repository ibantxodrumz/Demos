import urllib.parse
from datetime import timedelta
from typing import Optional

import pandas as pd


def get_bmrs_bmu_url(
    bmu_id: str,
    start_gmt: Optional[str] = None,
) -> str:
    """
    Generates an Elexon BMRS link for a specific BMU.

    When an alert start time is provided, BMRS opens on the complete UTC
    day containing the alert start: 00:00 UTC to 00:00 UTC the next day.
    """
    if not bmu_id or not str(bmu_id).strip():
        return "https://bmrs.elexon.co.uk/"

    normalized_bmu_id = str(bmu_id).strip()

    if not normalized_bmu_id.startswith("T_"):
        normalized_bmu_id = f"T_{normalized_bmu_id}"

    query_params = {
        "bmuId": normalized_bmu_id,
        "activeTab": "Physical",
    }

    if start_gmt:
        alert_start = pd.to_datetime(start_gmt, errors="coerce", utc=True)

        if not pd.isna(alert_start):
            start_of_day = alert_start.normalize()
            end_of_day = start_of_day + timedelta(days=1)

            query_params["startDate"] = start_of_day.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            query_params["endDate"] = end_of_day.strftime("%Y-%m-%dT%H:%M:%S.000Z")

    encoded_query = urllib.parse.urlencode(query_params)

    return "https://bmrs.elexon.co.uk/balancing-mechanism-bmu-view" f"?{encoded_query}"


def get_bmrs_remit_url(bmu_id: str) -> str:
    """
    Generates external link to Elexon REMIT portal for a specific BMU.
    """
    if not bmu_id or str(bmu_id).strip() == "":
        return "https://www.elexonportal.co.uk/news/latest"
    encoded_bmu = urllib.parse.quote(str(bmu_id).strip())
    return f"https://bmrs.elexon.co.uk/remit?bmu={encoded_bmu}"
