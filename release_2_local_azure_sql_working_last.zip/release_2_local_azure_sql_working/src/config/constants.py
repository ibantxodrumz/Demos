# src/config/constants.py
import os

# SQL Azure Configuration
# Defaults mirror the SQL Dashboard configuration (SQL_DS) while allowing environment overrides
SQL_SERVER = os.getenv("AZURE_SQL_SERVER", "placehold for server")
SQL_DATABASE = os.getenv("AZURE_SQL_DATABASE", "placeholder for database")

# Table Definitions (Compatible with both Azure SQL Database default schema and unit test SQLite runner)
SQL_TABLE_ALERTS = os.getenv("AZURE_SQL_TABLE_ALERTS", "IMPORT_ALERTS")
SQL_TABLE_ALERTS_DATA = os.getenv("AZURE_SQL_TABLE_ALERTS_DATA", "IMPORT_ALERTS_DATA")
SQL_TABLE_ACTIVITY_LOG = os.getenv("AZURE_SQL_TABLE_ACTIVITY_LOG", "ACTIVITY_LOG")

# Azure ODBC Connection String Options
ODBC_DRIVER_PREFERENCE = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
]
