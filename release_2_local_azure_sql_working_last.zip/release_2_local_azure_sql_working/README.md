# Import Constraints Local Prototype

## Overview

This project is a Dash application for the Import Constraints Local Prototype reading from SQL database

## Prerequisites

- Python
- Conda

## Setup

### Option 1: Create a new conda environment

```bash
conda create -n dashboard python=3.12
conda activate dashboard
```

### Option 2: Use an existing conda environment

```bash
conda activate <your_environment_name>
```

## Install Dependencies

From the project root directory:

```bash
pip install -r requirements.txt
```

## Run the Application

From the project root directory:

```bash
python -m src.app
```
## Notes

- Ensure the conda environment is activated before installing dependencies or running the application.
- Run all commands from the project root directory.
- Any application configuration or local database dependencies should be available before launching the app.