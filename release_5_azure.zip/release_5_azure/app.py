import base64
from datetime import datetime
import os
import sys

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from azure_blob_helper import AzureBlobStorage
from constants import (
    ACCOUNT_URL,
    AVAILABLE_YEARS,
    CONTAINER_NAME,
    DEFAULT_YEAR,
    PROJECT_BASE_NAME,
    PROJECT_NAME,
    VERSION,
)

# --- Pure Analytical & Helper Functions (Exposed for Testing and CLI) ---


def force_light_chart(fig):
    """Force high-contrast light background and clear typography on Plotly charts."""
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#1f2937", family="sans-serif"),
        xaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#e5e7eb",
            tickfont=dict(color="#374151"),
            title_font=dict(color="#111827", size=13),
        ),
        yaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#e5e7eb",
            tickfont=dict(color="#374151"),
            title_font=dict(color="#111827", size=13),
        ),
        title_font=dict(color="#400732", size=15),
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig


def render_chart(fig):
    """Convenience helper to style and render a chart in Streamlit."""
    styled = force_light_chart(fig)
    st.plotly_chart(styled, use_container_width=True)


def categorize_error(x):
    """Categorize error percentage into predefined operational bands."""
    if x <= 1:
        return "0-1%"
    elif x <= 2:
        return "1-2%"
    elif x <= 4:
        return "2-4%"
    elif x <= 10:
        return "4-10%"
    else:
        return ">10%"


def get_reason(row):
    """Generate detailed reason string for BMUs exceeding operational thresholds.

    Wind/Solar: Net outside [-3%, +3%] OR ABS >= 9.4%
    Other fuels: Net outside [-1%, +1%] OR ABS >= 2.6%
    """
    reasons = []
    fuel_upper = str(row.get("Fuel", "")).upper()

    # Universal column resolution across schema variants
    net_err = row.get("A_Net_Error%", row.get("A_Net_error%", row.get("A_NetError%", 0.0)))
    abs_err = row.get("A_ABS_Error%", row.get("A_ABS_error%", row.get("A_ABS_NetError%", 0.0)))

    if fuel_upper in ["WIND", "SOLAR"]:
        if abs(net_err) > 3.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±3%)")
        if abs_err >= 9.4:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 9.4%)")
    else:
        if abs(net_err) > 1.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±1%)")
        if abs_err >= 2.6:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 2.6%)")
    return "; ".join(reasons) if reasons else "Within Tolerances"


def find_local_input_file(filename: str):
    """Robust local file resolver across test runners and Streamlit execution."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(script_dir, "inputs", filename),
        os.path.join(os.getcwd(), "inputs", filename),
        os.path.join(script_dir, "..", "inputs", filename),
        os.path.join("inputs", filename),
        os.path.join(script_dir, filename),
        os.path.join(os.getcwd(), filename),
    ]
    for path in candidates:
        if os.path.exists(path):
            return os.path.abspath(path)
    return None


@st.cache_data
def process_data(df_annual_raw, df_monthly_raw, year: int = 2025):
    """Clean, coerce, and normalize Annual and Monthly datasets.

    Provides universal dual-mapping for all error column conventions:
    A_Net_Error% <-> A_Net_error% <-> A_NetError%
    A_ABS_Error% <-> A_ABS_error% <-> A_ABS_NetError%
    """
    # 1. Process Annual
    try:
        df_annual = df_annual_raw.copy()

        # Standardize identifiers
        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)
        df_annual["Year"] = int(year)
        df_annual["Grain"] = "annual"

        # Coerce numerics safely for any available volumetric/power columns
        numeric_cols_annual = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_annual:
            if col in df_annual.columns:
                df_annual[col] = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)

        # Standardize Annual Net Error (supporting all naming conventions)
        net_err_series = None
        for col in ["A_Net_Error%", "A_Net_error%", "A_NetError%"]:
            if col in df_annual.columns:
                net_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
                break
        if net_err_series is None:
            net_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_Net_Error%"] = net_err_series
        df_annual["A_Net_error%"] = net_err_series
        df_annual["A_NetError%"] = net_err_series

        # Standardize Annual ABS Error (supporting all naming conventions)
        abs_err_series = None
        for col in ["A_ABS_Error%", "A_ABS_error%", "A_ABS_NetError%"]:
            if col in df_annual.columns:
                abs_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
                break
        if abs_err_series is None:
            abs_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_ABS_Error%"] = abs_err_series
        df_annual["A_ABS_error%"] = abs_err_series
        df_annual["A_ABS_NetError%"] = abs_err_series

        # Standardize Max Monthly Error
        max_m_series = None
        for col in ["max_M_ABS_Error%", "max_M_ABS_NetError%"]:
            if col in df_annual.columns:
                max_m_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
                break
        if max_m_series is None:
            max_m_series = pd.Series(0.0, index=df_annual.index)
        df_annual["max_M_ABS_Error%"] = max_m_series
        df_annual["max_M_ABS_NetError%"] = max_m_series

        # Define SizeBasis for charts based on capacity
        df_annual["SizeBasis"] = pd.to_numeric(
            df_annual.get("installedCapacity_mwh", 0), errors="coerce"
        ).fillna(0)

    except Exception as e:
        return None, None, f"Error processing Annual data: {str(e)}"

    # 2. Process Monthly
    try:
        df_monthly = df_monthly_raw.copy()

        # Date Parsing
        def parse_date(x):
            try:
                parts = str(x).split("-")
                if len(parts) == 2:
                    return datetime(int(parts[0]), int(parts[1]), 1)
                return pd.NaT
            except Exception:
                return pd.NaT

        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_date)
        df_monthly["Year"] = df_monthly["YearMonthObj"].dt.year
        df_monthly["Month"] = df_monthly["YearMonthObj"].dt.month
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        df_monthly["YearMonth"] = df_monthly["YearMonthObj"].dt.strftime("%Y-%m")

        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)
        df_monthly["Grain"] = "monthly"

        numeric_cols_monthly = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_monthly:
            if col in df_monthly.columns:
                df_monthly[col] = pd.to_numeric(df_monthly[col], errors="coerce").fillna(0)

        # Standardize Monthly Net Error
        m_net_err_series = None
        for col in ["M_Net_Error%", "M_Net_error%", "M_NetError%"]:
            if col in df_monthly.columns:
                m_net_err_series = pd.to_numeric(df_monthly[col], errors="coerce").fillna(0)
                break
        if m_net_err_series is None:
            m_net_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_Net_Error%"] = m_net_err_series
        df_monthly["M_Net_error%"] = m_net_err_series
        df_monthly["M_NetError%"] = m_net_err_series

        # Standardize Monthly ABS Error
        m_abs_err_series = None
        for col in ["M_ABS_Error%", "M_ABS_error%", "M_ABS_NetError%"]:
            if col in df_monthly.columns:
                m_abs_err_series = pd.to_numeric(df_monthly[col], errors="coerce").fillna(0)
                break
        if m_abs_err_series is None:
            m_abs_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_ABS_Error%"] = m_abs_err_series
        df_monthly["M_ABS_error%"] = m_abs_err_series
        df_monthly["M_ABS_NetError%"] = m_abs_err_series

    except Exception as e:
        return None, None, f"Error processing Monthly data: {str(e)}"

    # 3. P90 Calculation retired
    df_annual["P90_monthly_error"] = 0.0

    # 4. Logic: Needs Attention (Fuel-specific thresholds)
    is_wind_solar = df_annual["Fuel"].astype(str).str.upper().isin(["WIND", "SOLAR"])
    cond_wind_solar = is_wind_solar & (
        (df_annual["A_NetError%"].abs() > 3.0) | (df_annual["A_ABS_Error%"] >= 9.4)
    )
    cond_other_fuels = (~is_wind_solar) & (
        (df_annual["A_NetError%"].abs() > 1.0) | (df_annual["A_ABS_Error%"] >= 2.6)
    )
    df_annual["NeedsAttention"] = cond_wind_solar | cond_other_fuels

    # 5. Logic: Error Band Classification
    df_annual["ErrorBand"] = df_annual["A_ABS_Error%"].apply(categorize_error)
    df_annual["ErrorBand"] = pd.Categorical(
        df_annual["ErrorBand"],
        categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"],
        ordered=True,
    )

    return df_annual, df_monthly, None


def apply_filters(df_a, df_m, fuels, bmus, attention_only):
    """Filter annual and monthly datasets based on active sidebar selections."""
    # Annual
    res_a = df_a[df_a["Fuel"].isin(fuels)]
    res_a = res_a[res_a["BMU"].isin(bmus)]
    if attention_only:
        res_a = res_a[res_a["NeedsAttention"] == True]

    # Monthly
    filtered_bmus = res_a["BMU"].unique()
    res_m = df_m[df_m["BMU"].isin(filtered_bmus)]
    res_m = res_m[res_m["Fuel"].isin(fuels)]

    return res_a, res_m


# --- Streamlit Application Lifecycle (Executed Only Under `streamlit run`) ---


def run_streamlit_app():
    st.set_page_config(
        page_title="PN Accuracy Dashboard",
        page_icon="⚡",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Assets & Styling
    script_dir = os.path.dirname(os.path.abspath(__file__))
    logo_path = os.path.join(script_dir, "assets", "neso_logo.jpg")
    logo_b64 = None
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as img_f:
            logo_b64 = base64.b64encode(img_f.read()).decode("utf-8")

    st.markdown(
        """
        <style>
            .stApp {
                background-color: #fcfcfd;
                color: #111827;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            }
            section[data-testid="stSidebar"] {
                background-color: #ffffff !important;
                border-right: 1px solid #e5e7eb;
            }
            .neso-sidebar-header {
                padding: 10px 0 16px 0;
                margin-bottom: 12px;
                border-bottom: 2px solid #400732;
                text-align: center;
            }
            .neso-sidebar-logo {
                max-width: 130px;
                height: auto;
                margin-bottom: 8px;
            }
            .neso-sidebar-title {
                color: #400732;
                font-weight: 800;
                font-size: 1.05rem;
                letter-spacing: -0.01em;
                margin: 0;
            }
            .neso-sidebar-subtitle {
                color: #6b7280;
                font-size: 0.8rem;
                margin-top: 2px;
            }
            .neso-active-window-card {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-left: 4px solid #400732;
                border-radius: 6px;
                padding: 8px 14px;
                margin-bottom: 16px;
                display: flex;
                align-items: center;
                gap: 10px;
                font-size: 0.88rem;
                color: #374151;
            }
            .neso-aw-badge {
                background: #fdf2f8;
                color: #831843;
                font-weight: 600;
                padding: 2px 8px;
                border-radius: 4px;
                border: 1px solid #fbcfe8;
                font-size: 0.8rem;
            }
            div[data-testid="stMetric"] {
                background-color: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                padding: 12px 16px;
                box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            }
            div[data-testid="stMetricLabel"] {
                color: #4b5563 !important;
                font-size: 0.85rem !important;
                font-weight: 600 !important;
            }
            div[data-testid="stMetricValue"] {
                color: #400732 !important;
                font-weight: 800 !important;
                font-size: 1.65rem !important;
            }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Sidebar: Branding
    if logo_b64:
        st.sidebar.markdown(
            f"""
            <div class="neso-sidebar-header">
                <img src="data:image/jpeg;base64,{logo_b64}" class="neso-sidebar-logo" alt="NESO Logo" />
                <div class="neso-sidebar-title">Market Monitoring</div>
                <div class="neso-sidebar-subtitle">PN Accuracy Dashboard</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.sidebar.subheader("Data Selection")

    # Calendar Year Selection
    default_year_idx = AVAILABLE_YEARS.index(DEFAULT_YEAR) if DEFAULT_YEAR in AVAILABLE_YEARS else 0
    selected_year = st.sidebar.selectbox(
        "Calendar Year",
        AVAILABLE_YEARS,
        index=default_year_idx,
        key="selected_year_selectbox",
    )

    annual_filename = f"annual_summary_{selected_year}.csv"
    monthly_filename = f"monthly_summary_{selected_year}.csv"
    default_annual_path = find_local_input_file(annual_filename)
    default_monthly_path = find_local_input_file(monthly_filename)
    has_local_inputs = bool(default_annual_path and default_monthly_path)

    # Data Source Toggle
    if "data_source_selection" not in st.session_state:
        st.session_state["data_source_selection"] = "Azure Blob Storage"

    data_source_options = [
        "Azure Blob Storage",
        "Local (inputs/ folder)",
        "Manual Upload (CSV)",
    ]

    current_index = 0
    if st.session_state["data_source_selection"] in data_source_options:
        current_index = data_source_options.index(st.session_state["data_source_selection"])

    data_source = st.sidebar.radio(
        "Data Source",
        data_source_options,
        index=current_index,
        key="data_source_radio",
    )
    st.session_state["data_source_selection"] = data_source

    auto_fallback = st.sidebar.checkbox(
        "Auto-fallback to local inputs if Azure fails",
        value=True,
        help="When enabled, if Azure connection fails (e.g. laptop not configured with az login), the dashboard automatically loads local files from 'inputs/'.",
    )

    annual_raw, monthly_raw = None, None
    data_source_mode_notice = None

    if data_source == "Azure Blob Storage":
        try:
            project_folder = f"{PROJECT_BASE_NAME}-{selected_year}"
            azure_blob = AzureBlobStorage(ACCOUNT_URL, CONTAINER_NAME, project_folder)
            with st.sidebar.status(f"Fetching {selected_year} data from Azure...", expanded=False):
                st.write(f"Connecting to container '{CONTAINER_NAME}' ({project_folder})...")
                annual_raw = azure_blob.read_annual_summary()
                st.write(f"Fetched Annual Summary ({annual_filename}).")
                monthly_raw = azure_blob.read_monthly_summary()
                st.write(f"Fetched Monthly Summary ({monthly_filename}).")
            st.sidebar.success(f"✅ Azure {selected_year} Data Loaded Successfully")
        except Exception as e:
            error_details = str(e)
            st.sidebar.error(f"❌ Azure Connection Failed: {error_details}")

            if has_local_inputs and auto_fallback:
                st.sidebar.warning(f"⚠️ Laptop is not configured for Azure. Loaded local files for {selected_year} from 'inputs/' folder.")
                data_source_mode_notice = (
                    f"⚠️ **Azure Blob Storage is unavailable on this machine** (credentials or Azure CLI not active).\n\n"
                    f"The dashboard has automatically fallen back to the **local baseline** using `{annual_filename}` and `{monthly_filename}` from the `inputs/` folder."
                )
                annual_raw = pd.read_csv(default_annual_path)
                monthly_raw = pd.read_csv(default_monthly_path)
            else:
                st.sidebar.info("Tip: Switch Data Source to 'Local (inputs/ folder)' or 'Manual Upload (CSV)' to operate offline.")
                st.stop()

    elif data_source == "Local (inputs/ folder)":
        if has_local_inputs:
            annual_raw = pd.read_csv(default_annual_path)
            monthly_raw = pd.read_csv(default_monthly_path)
            st.sidebar.success(f"✅ Local {selected_year} inputs loaded from 'inputs/'")
        else:
            st.sidebar.error(f"❌ Could not find `{annual_filename}` or `{monthly_filename}` in 'inputs/' folder.")
            st.info(f"Local files for {selected_year} are not present in `inputs/`. Please choose another year or use Manual Upload.")
            st.stop()

    else:
        # Manual CSV Upload
        st.sidebar.markdown("### Upload Custom Data")
        uploaded_annual = st.sidebar.file_uploader(f"Upload Annual Summary ({selected_year})", type=["csv"])
        uploaded_monthly = st.sidebar.file_uploader(f"Upload Monthly Summary ({selected_year})", type=["csv"])
        if uploaded_annual and uploaded_monthly:
            annual_raw = pd.read_csv(uploaded_annual)
            monthly_raw = pd.read_csv(uploaded_monthly)
            st.sidebar.success("✅ Custom CSV datasets loaded successfully.")
        else:
            st.sidebar.info(f"Please upload both Annual and Monthly CSV files for {selected_year}.")
            st.stop()

    # Process Datasets
    df_annual_raw, df_monthly_raw, error_msg = process_data(annual_raw, monthly_raw, year=selected_year)
    if error_msg:
        st.error(error_msg)
        st.stop()

    st.sidebar.markdown("---")
    st.sidebar.subheader("Filters")

    # Filters
    all_fuels = sorted(df_annual_raw["Fuel"].unique().tolist())
    selected_fuels = st.sidebar.multiselect("Select Fuel(s)", all_fuels, default=all_fuels)

    # BMU Search / Select
    available_bmus = sorted(df_annual_raw[df_annual_raw["Fuel"].isin(selected_fuels)]["BMU"].unique().tolist())
    selected_bmus = st.sidebar.multiselect("Select BMU(s)", available_bmus, default=available_bmus)

    needs_attention_only = st.sidebar.checkbox("🚩 'Needs Attention' only", value=False)

    df_annual, df_monthly = apply_filters(
        df_annual_raw, df_monthly_raw, selected_fuels, selected_bmus, needs_attention_only
    )

    if df_annual.empty:
        st.warning("No BMUs match the current filters.")
        st.stop()

    if data_source_mode_notice:
        st.info(data_source_mode_notice, icon="ℹ️")

    # Main Page Header
    st.markdown(
        """
        <div style="margin-bottom: 1rem;">
            <h1 style="color: #400732; font-size: 2.05rem; font-weight: 800; margin: 0; letter-spacing: -0.02em;">
                Market Monitoring: PN Accuracy Dashboard
            </h1>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # 8 Clean Tabs
    tab1, tab1_m, tab1_gwh, tab2_cap, tab3, tab4, tab5, tab6 = st.tabs(
        [
            "Executive Summary",
            "Median Error",
            "Total GWh Error",
            "Fleet: Capacity",
            "By Technology",
            "BMU Explorer",
            "Require Attention",
            "Exports",
        ]
    )

    # --- TAB 1: Executive Summary ---
    with tab1:
        st.markdown(
            f"""
            <div style="margin-bottom: 6px;">
                <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 14px; letter-spacing: -0.015em;">Executive Summary</h2>
            </div>
            <div class="neso-active-window-card">
                <span>Active Review Window:</span>
                <span class="neso-aw-badge">Dataset: <strong>{selected_year} Calendar Year</strong></span>
                <span>➔</span>
                <span class="neso-aw-badge">Status: <strong>Fleet Baseline (Active)</strong></span>
                <span style="color: #6b7280; font-size: 0.85rem;">({len(df_annual):,} BMUs Evaluated • {len(df_monthly):,} Monthly Records)</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

        kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
        fleet_median_error = df_annual["A_ABS_Error%"].median()

        max_err_idx = df_annual["A_ABS_Error%"].idxmax()
        max_err_row = df_annual.loc[max_err_idx]
        fleet_max_error = max_err_row["A_ABS_Error%"]
        max_bmu_info = f"{max_err_row['BMU']} ({max_err_row['Fuel']})"

        bmu_count = df_annual["BMU"].nunique()
        fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
        fleet_net_gwh = df_annual["NetError"].sum() / 1000

        kpi1.metric("Fleet Median Error %", f"{fleet_median_error:.2f}%")
        kpi2.metric(
            "Max Individual Error %",
            f"{fleet_max_error:.2f}%",
            delta=max_bmu_info,
            delta_color="off",
        )
        kpi3.metric("BMU Count", f"{bmu_count}")
        kpi4.metric("Total ABS Error (GWh)", f"{fleet_abs_gwh:,.2f}")
        kpi5.metric("Net Bias (GWh)", f"{fleet_net_gwh:,.2f}")

        fuel_summary = (
            df_annual.groupby("Fuel")
            .agg(
                Median_Error_Pct=("A_ABS_Error%", "median"),
                Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
                BMU_Count=("BMU", "nunique"),
            )
            .reset_index()
            .sort_values("Total_ABS_GWh", ascending=False)
        )

        st.markdown("---")

        col_main1, col_main2 = st.columns(2)

        with col_main1:
            st.subheader("Fleet Error Distribution")
            fig_hist = px.histogram(
                df_annual,
                x="A_ABS_Error%",
                title="Distribution of Annual Error % (0-100% Range)",
                color_discrete_sequence=["#400732"],
                template="plotly_white",
                range_x=[0, 100],
            )
            fig_hist.update_traces(xbins=dict(start=0, end=100, size=2.5))
            fig_hist.update_layout(
                xaxis=dict(tickmode="linear", tick0=0, dtick=5, title="Annual Error %"),
                yaxis=dict(title="Count of BMUs"),
                bargap=0.1,
            )
            render_chart(fig_hist)

        with col_main2:
            st.subheader("Fuel Performance Summary")
            st.caption("Detailed breakdown across all fuel types.")
            st.dataframe(
                fuel_summary.style.format(
                    {
                        "Median_Error_Pct": "{:.2f}%",
                        "Total_ABS_GWh": "{:,.2f}",
                        "Net_Bias_GWh": "{:,.2f}",
                    }
                ),
                use_container_width=True,
                height=400,
                hide_index=True,
            )

            csv_fuel = fuel_summary.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Download Fuel Summary (CSV)",
                data=csv_fuel,
                file_name=f"fuel_performance_summary_{selected_year}.csv",
                mime="text/csv",
            )

    # --- TAB 2: Median Error ---
    with tab1_m:
        st.header("Median Error by Fuel")
        st.caption("Distribution of Median Absolute Net Error % across fuel types.")

        fuel_median = (
            df_annual.groupby("Fuel")["A_ABS_Error%"]
            .median()
            .reset_index()
            .sort_values("A_ABS_Error%", ascending=True)
        )
        fig_hm1 = px.bar(
            fuel_median,
            x="Fuel",
            y="A_ABS_Error%",
            title="Median Error % by Fuel",
            color="A_ABS_Error%",
            color_continuous_scale=["#fcf4fa", "#cf3e9e", "#8a156e", "#400732"],
            template="plotly_white",
        )
        render_chart(fig_hm1)

        st.subheader("Annual Error Band Breakdown by Fuel")
        band_pivot = pd.crosstab(
            df_annual["Fuel"],
            df_annual["ErrorBand"],
            normalize="index",
        ) * 100
        st.dataframe(
            band_pivot.style.format("{:.1f}%"),
            use_container_width=True,
        )

        band_export = df_annual[
            ["BMU", "Fuel", "ErrorBand", "A_ABS_Error%"]
        ].sort_values(["ErrorBand", "A_ABS_Error%"])
        csv_band = band_export.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Error Band Composition (CSV)",
            data=csv_band,
            file_name=f"error_band_composition_{selected_year}.csv",
            mime="text/csv",
        )

    # --- TAB 3: Total GWh Error ---
    with tab1_gwh:
        st.header("Total Volume (GWh) Error by Fuel")
        st.caption("Aggregate volume impact: Total Absolute Error vs Net Directional Bias.")

        gwh_summary = (
            df_annual.groupby("Fuel")
            .agg(
                Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
            )
            .reset_index()
            .sort_values("Total_ABS_GWh", ascending=False)
        )

        fig_gwh = px.bar(
            gwh_summary,
            x="Fuel",
            y=["Total_ABS_GWh", "Net_Bias_GWh"],
            barmode="group",
            title="Total Absolute Error vs Net Directional Bias (GWh)",
            color_discrete_sequence=["#400732", "#cf3e9e"],
            template="plotly_white",
        )
        render_chart(fig_gwh)

        st.dataframe(
            gwh_summary.style.format(
                {
                    "Total_ABS_GWh": "{:,.2f}",
                    "Net_Bias_GWh": "{:,.2f}",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    # --- TAB 4: Fleet: Capacity ---
    with tab2_cap:
        st.header("Fleet Overview: Capacity vs Error %")
        st.caption("Bubble chart showing asset size (MW) vs Absolute Error %.")

        fig_cap = px.scatter(
            df_annual,
            x="installedCapacity_mwh",
            y="A_ABS_Error%",
            size="SizeBasis",
            color="Fuel",
            hover_name="BMU",
            title="Installed Capacity vs Absolute Error %",
            template="plotly_white",
            labels={
                "installedCapacity_mwh": "Installed Capacity (MWh)",
                "A_ABS_Error%": "Absolute Error %",
            },
        )
        render_chart(fig_cap)

    # --- TAB 5: By Technology ---
    with tab3:
        st.header("Technology Deep Dive")
        selected_tech = st.selectbox("Select Technology / Fuel Type", all_fuels, key="tech_selector")

        tech_df = df_annual[df_annual["Fuel"] == selected_tech]
        tech_monthly = df_monthly[df_monthly["Fuel"] == selected_tech]

        if tech_df.empty:
            st.info(f"No units available for technology '{selected_tech}'.")
        else:
            tc1, tc2, tc3 = st.columns(3)
            tc1.metric("BMU Count", len(tech_df))
            tc2.metric("Median ABS Error %", f"{tech_df['A_ABS_Error%'].median():.2f}%")
            worst_unit = tech_df.loc[tech_df["A_ABS_Error%"].idxmax()]
            tc3.metric("Worst BMU Error %", f"{worst_unit['A_ABS_Error%']:.2f}%", delta=worst_unit["BMU"], delta_color="off")

            col_t1, col_t2 = st.columns(2)
            with col_t1:
                fig_tdist = px.histogram(
                    tech_df,
                    x="A_ABS_Error%",
                    title=f"Error Distribution — {selected_tech}",
                    color_discrete_sequence=["#400732"],
                    template="plotly_white",
                )
                render_chart(fig_tdist)

            with col_t2:
                if not tech_monthly.empty:
                    trend = (
                        tech_monthly.groupby("YearMonth")["M_ABS_Error%"]
                        .median()
                        .reset_index(name="Monthly_Median")
                    )
                    fig_ttrend = px.line(
                        trend,
                        x="YearMonth",
                        y="Monthly_Median",
                        markers=True,
                        title=f"Monthly Median Error Trend — {selected_tech}",
                        color_discrete_sequence=["#cf3e9e"],
                        template="plotly_white",
                    )
                    render_chart(fig_ttrend)

            st.subheader(f"Top BMUs — {selected_tech}")
            top_best = tech_df.nsmallest(10, "A_ABS_Error%")[["BMU", "A_ABS_Error%", "A_Net_Error%", "NeedsAttention"]]
            st.dataframe(top_best, use_container_width=True, hide_index=True)

    # --- TAB 6: BMU Explorer ---
    with tab4:
        st.header("BMU Explorer")
        st.caption("Detailed historical performance profile for an individual Balancing Mechanism Unit.")

        col_search1, col_search2 = st.columns([3, 1])
        with col_search1:
            search_query = st.text_input("Search BMU by name", value="", placeholder="e.g. ABERU-1").strip().upper()
        with col_search2:
            st.write("")
            st.write("")
            reset_search = st.button("Reset Search")

        if reset_search or not search_query:
            bmu_options = available_bmus
        else:
            bmu_options = [b for b in available_bmus if search_query in b]

        if not bmu_options:
            st.warning(f"No BMUs found matching '{search_query}'.")
            bmu_pick = available_bmus[0] if available_bmus else None
        else:
            bmu_pick = st.selectbox("Select BMU", bmu_options)

        if bmu_pick:
            bmu_annual = df_annual_raw[df_annual_raw["BMU"] == bmu_pick].iloc[0]
            bmu_monthly = df_monthly_raw[df_monthly_raw["BMU"] == bmu_pick].sort_values("YearMonth")

            st.subheader(f"Profile: {bmu_pick}")
            bc1, bc2, bc3 = st.columns(3)

            with bc1:
                st.markdown("### Annual Metrics")
                st.write(f"**Fuel:** {bmu_annual['Fuel']}")
                st.write(f"**Annual Net Error %:** {bmu_annual['A_Net_Error%']:.2f}%")
                st.write(f"**Annual ABS Error %:** {bmu_annual['A_ABS_Error%']:.2f}%")
                st.write(f"**Total ABS Error (GWh):** {bmu_annual['ABSError']/1000:,.2f}")
                st.write(f"**Net Error (GWh):** {bmu_annual['NetError']/1000:,.2f}")
                if bmu_annual["NeedsAttention"]:
                    st.error("⚠️ Flagged: Needs Attention")
                else:
                    st.success("✅ Status: OK")

            with bc2:
                st.markdown("### Monthly Trend")
                if not bmu_monthly.empty:
                    fig_spark = px.line(
                        bmu_monthly,
                        x="YearMonth",
                        y="M_ABS_Error%",
                        markers=True,
                        title="Monthly Absolute Error %",
                        color_discrete_sequence=["#400732"],
                        template="plotly_white",
                    )
                    render_chart(fig_spark)
                else:
                    st.info("No monthly data available.")

            with bc3:
                st.markdown("### Monthly Data Table")
                st.dataframe(
                    bmu_monthly[["YearMonth", "M_Net_Error%", "M_ABS_Error%"]],
                    use_container_width=True,
                    hide_index=True,
                )

                csv_bmu = bmu_monthly.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label=f"📥 Download {bmu_pick} Data (CSV)",
                    data=csv_bmu,
                    file_name=f"{bmu_pick}_monthly_data_{selected_year}.csv",
                    mime="text/csv",
                )

    # --- TAB 7: Require Attention ---
    with tab5:
        st.markdown(
            """
            <div style="margin-bottom: 12px;">
                <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 4px;">Require Attention: Units Exceeding Thresholds</h2>
                <p style="color: #6b7280; font-size: 0.92rem; margin-top: 0; margin-bottom: 14px;">
                    Balancing Mechanism Units exceeding operational error tolerances (Wind/Solar: Net Error outside ±3% or ABS Error ≥ 9.4%; Other Fuels: Net Error outside ±1% or ABS Error ≥ 2.6%).
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()

        if attention_df.empty:
            st.success("🎉 No BMUs require attention! All units within operational tolerances.")
        else:
            attention_df["Reason"] = attention_df.apply(get_reason, axis=1)

            st.markdown(
                f"**{len(attention_df)}** BMUs triggered attention thresholds across the fleet:<br>"
                "• **Wind & Solar**: Net Error outside ±3.0% OR Absolute Error ≥ 9.4%<br>"
                "• **All Other Fuels**: Net Error outside ±1.0% OR Absolute Error ≥ 2.6%",
                unsafe_allow_html=True,
            )

            csv_att = attention_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Download Attention Needed Units (CSV)",
                data=csv_att,
                file_name=f"bmus_requiring_attention_{selected_year}.csv",
                mime="text/csv",
            )

            for fuel_grp in sorted(attention_df["Fuel"].unique()):
                subset = attention_df[attention_df["Fuel"] == fuel_grp].sort_values(
                    "A_ABS_Error%", ascending=False
                )
                with st.expander(f"Fuel: {fuel_grp} ({len(subset)} units)", expanded=True):
                    display_cols = ["BMU", "Reason", "A_Net_Error%", "A_ABS_Error%"]
                    if "installedCapacity_mwh" in subset.columns:
                        display_cols.append("installedCapacity_mwh")

                    st.dataframe(
                        subset[display_cols].style.format(
                            {
                                "A_Net_Error%": "{:+.2f}%",
                                "A_ABS_Error%": "{:.2f}%",
                                "installedCapacity_mwh": "{:,.1f}",
                            }
                        ),
                        use_container_width=True,
                        hide_index=True,
                    )

    # --- TAB 8: Exports ---
    with tab6:
        st.header("Data Exports")
        st.markdown(
            f"""
            ### Available Datasets ({selected_year})
            * **Annual Summary**: Fleet-wide evaluation per BMU.
            * **Monthly Summary**: Granular monthly records per BMU.
            * **Needs Attention List**: Non-compliant units exceeding tolerances.
            """
        )
        st.markdown("---")

        ec1, ec2, ec3 = st.columns(3)
        with ec1:
            st.subheader("Annual Summary")
            csv_annual = df_annual.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Download Annual Summary",
                data=csv_annual,
                file_name=f"annual_summary_{selected_year}_filtered.csv",
                mime="text/csv",
            )
        with ec2:
            st.subheader("Monthly Summary")
            csv_monthly = df_monthly.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Download Monthly Summary",
                data=csv_monthly,
                file_name=f"monthly_summary_{selected_year}_filtered.csv",
                mime="text/csv",
            )
        with ec3:
            st.subheader("Needs Attention List")
            if not attention_df.empty:
                csv_attn = attention_df.to_csv(index=False).encode("utf-8")
                st.download_button(
                    label="📥 Download Attention List",
                    data=csv_attn,
                    file_name=f"needs_attention_list_{selected_year}.csv",
                    mime="text/csv",
                )
            else:
                st.write("No attention units to download.")


# Protect module-level execution so that unit tests can import functions cleanly
if st.runtime.exists():
    run_streamlit_app()
