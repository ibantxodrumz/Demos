"""Release 5 Azure Package initialization."""
