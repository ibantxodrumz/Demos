# Physical Notification (PN) Accuracy Dashboard — Release 5

## 🎯 Overview
This enterprise analytical dashboard monitors and assesses the Physical Notification (PN) accuracy of Balancing Mechanism Units (BMUs) across the GB power generation fleet. It evaluates volume risk, directional bias, and compliance tolerances across multiple calendar years (2025, 2026+).

---

## 🌟 What's New in Release 5
- **Verified Azure Endpoint & Connection**: Configured for the active enterprise Azure Blob Storage container (`https://dlaaencmmdsffuks01.blob.core.windows.net/`) utilizing seamless corporate authentication via `AzureCliCredential`.
- **Universal Schema Normalizer**: Permanently eliminates variable naming mismatches. Automatically harmonizes and dual-maps all error conventions (`A_Net_Error%`, `A_Net_error%`, `A_NetError%`, `A_ABS_Error%`, `A_ABS_NetError%`, `M_Net_Error%`, `M_ABS_Error%`, etc.) so that live Azure datasets, local CSVs, and custom uploads execute without `KeyError` or schema friction.
- **Calendar Year Selection (2025 / 2026)**: Dynamic multi-year routing from the sidebar selector. Azure automatically queries `pn-accuracy-{year}/internal/` while local mode automatically picks up corresponding files from `inputs/`.
- **Hybrid Data Sourcing & Graceful Offline Fallback**: Switch smoothly between **Azure Blob Storage**, **Local `inputs/` folder**, and **Manual CSV Upload**. When Azure CLI credentials or network connectivity are absent, the app never crashes; it displays an informative notice and falls back automatically to local inputs.
- **Corporate NESO Visual Design**: Aligned with modern corporate brand guidelines (NESO Plum `#400732`, Magenta `#cf3e9e`, active review window badge, styled KPI metrics, and light Plotly figures).
- **BMU Explorer Filter & Search**: Quick BMU search with interactive reset and sparkline trend visualization.
- **Fuel-Specific "Require Attention" Rules**: Automated flagging for Wind/Solar (Net Error outside $\pm3\%$ or ABS $\ge 9.4\%$) and Other Fuels (Net Error outside $\pm1\%$ or ABS $\ge 2.6\%$). P90 metric retired.
- **Guardian Regression Test Suite**: 31 self-contained guardian unit tests guarding analytical baselines, business rules, multi-year resolution, and schema resilience.

---

## 💻 Windows 11 Setup Guide (VS Code + Conda)

This package is verified and self-contained to run on **Windows 11** using **Conda** and **Visual Studio Code**.

### 1. Prerequisites on Windows 11
* **Miniconda or Anaconda**: [Install Miniconda for Windows](https://docs.conda.io/en/latest/miniconda.html)
* **Visual Studio Code**: [Install VS Code](https://code.visualstudio.com/)
* **Azure CLI (Required for live Azure mode)**: [Install Azure CLI for Windows](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows)

---

### 2. Environment Setup (Terminal in VS Code)
Open VS Code, press ``Ctrl + ` `` to open the integrated terminal (PowerShell or Command Prompt), and run:

```powershell
# 1. Create a clean Conda environment with Python 3.11
conda create -n dashboard python=3.11 -y

# 2. Activate the environment
conda activate dashboard

# 3. Navigate into the release directory
cd release_5_azure

# 4. Install dependencies
pip install -r requirements.txt
```

---

### 3. Corporate Azure Authentication (`az login`)
To connect to live corporate Azure Blob Storage, authenticate once via the Azure CLI:

```powershell
az login
```
*(A browser window will open for corporate Single Sign-On / MFA. Once authenticated, the terminal will confirm your subscription).*

---

### 4. Verification: Run Guardian Test Suite
Before launching the application, verify that your environment passes all analytical and schema invariants:

```powershell
python tests/run_tests.py
```
*(All 31 guardian tests will execute and report `✅ ALL TEST SUITES PASSED` in < 1 second).*

---

### 5. Running the Dashboard

#### Option A: Live Azure Mode (Default)
With Azure CLI authenticated, launch the application:
```powershell
streamlit run app.py
```
* The sidebar will display `Azure Blob Storage` as the selected data source.
* You can switch between **2025** and **2026** directly from the **Calendar Year** dropdown.

#### Option B: Offline / Local Mode (Zero Cloud Credentials Required)
If operating on an unconfigured machine or without network access:
```powershell
streamlit run app.py
```
* If Azure credentials are not found, the app **automatically falls back** to bundled local inputs (`inputs/annual_summary_2025.csv` and `monthly_summary_2025.csv`).
* Alternatively, select **Local (inputs/ folder)** or **Manual Upload (CSV)** directly in the sidebar.

---

## 📂 Project Structure
```
release_5_azure/
├── app.py                   # Sole application entry point
├── constants.py             # Configuration endpoints & multi-year list
├── azure_blob_helper.py     # Azure Blob Storage connector (AzureCliCredential)
├── requirements.txt         # Pinned production dependencies
├── README.md                # Windows 11 & VS Code execution guide
├── assets/
│   ├── neso_logo.jpg        # Embedded corporate logo
│   └── dashboard_reference.png
├── documentation/
│   └── How_to.docx          # Stakeholder and operational user guide
├── inputs/                  # Local fallback datasets
│   ├── annual_summary_2025.csv
│   ├── monthly_summary_2025.csv
│   └── clean.ipynb
└── tests/                   # Guardian regression test suite
    ├── run_tests.py         # Single-command test runner (exit 0 on pass)
    ├── test_business_rules.py
    ├── test_data_processing.py
    ├── test_azure_and_fallback.py
    └── test_baseline_invariants.py
```

---

## 🛡️ Guardian Test Architecture

The regression test suite is split across 4 focused modules:
1. `test_business_rules.py` (13 tests): Wind/Solar thresholds ($\pm3\%$ net, $9.4\%$ ABS), other fuel thresholds ($\pm1\%$ net, $2.6\%$ ABS), reason string formatting, and 5 operational error bands.
2. `test_data_processing.py` (5 tests): Multi-year stamping, schema coercion, NaN handling, monthly date parsing, and attention flagging.
3. `test_azure_and_fallback.py` (6 tests): Dynamic multi-year blob path resolution (`pn-accuracy-{year}`), constants verification, and local fallback locator.
4. `test_baseline_invariants.py` (7 tests): Regression audit against canonical baseline datasets ensuring fleet counts, monthly records, and flagged attention units remain invariant.
