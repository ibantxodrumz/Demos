from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from src.config.constants import SQL_TABLE_ALERTS_DATA
from src.repositories.connection import get_db


def get_sp_data_for_period(
    start_date: str,
    end_date: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    """Retrieve settlement period rows from SQL_TABLE_ALERTS_DATA for [start_date, end_date]."""
    end_date_str = str(end_date)[:10]
    end_exclusive = (datetime.strptime(end_date_str, "%Y-%m-%d") + timedelta(days=1)).strftime(
        "%Y-%m-%d"
    )

    query = f"""
    SELECT *
    FROM {SQL_TABLE_ALERTS_DATA}
    WHERE LOCAL_DATETIME >= :start_date AND LOCAL_DATETIME < :end_exclusive
    ORDER BY LOCAL_DATETIME ASC, BMU_ID ASC
    """
    with get_db(db_path) as conn:
        cursor = conn.execute(query, {"start_date": start_date, "end_exclusive": end_exclusive})
        rows = cursor.fetchall()

        seen_uids = set()
        seen_sp_keys = set()
        deduped = []

        for r in rows:
            row_dict = dict(r)
            uid = row_dict.get("UNIQUE_ID")
            bmu = row_dict.get("BMU_ID")
            dt = str(row_dict.get("LOCAL_DATETIME") or row_dict.get("GMT_FROM") or "")
            sp = str(row_dict.get("SETTLEMENT_PERIOD") or "")

            sp_key = (bmu, dt, sp)

            if uid and uid in seen_uids:
                continue
            if sp_key in seen_sp_keys and bmu and dt:
                continue

            if uid:
                seen_uids.add(uid)
            if bmu and dt:
                seen_sp_keys.add(sp_key)
            deduped.append(row_dict)

        return deduped


def get_database_date_bounds(
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, str]:
    """Retrieve minimum start date and maximum end date of alerts present in the database."""
    query = f"SELECT MIN(LOCAL_DATETIME), MAX(LOCAL_DATETIME) FROM {SQL_TABLE_ALERTS_DATA}"
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query)
            row = cursor.fetchone()
            if row and row[0] and row[1]:
                min_d = str(row[0])[:10]
                max_d = str(row[1])[:10]
                return {"start": min_d, "end": max_d}
    except Exception:
        pass
    from src.utils.date_utils import generate_available_time_options
    opts = generate_available_time_options()
    return {"start": opts["min_date"], "end": opts["max_date"]}
