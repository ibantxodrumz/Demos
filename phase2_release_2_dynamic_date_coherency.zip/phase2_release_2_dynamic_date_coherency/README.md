# Market Monitoring Platform — Phase 2 Release 2

## Release Overview

**Release Identifier**: `phase2_release_2_dynamic_date_coherency`  
**Target Environments**: Windows 11 (VS Code Local Execution) & macOS  
**Database Backend**: Azure SQL Database (`DATABASE_MODE=azure`) with SQLite local fallback (`DATABASE_MODE=sqlite`)

This release resolves the date bounds incoherency reported in Release 1 by dynamically binding all date selection controls across all pages—including single day pickers, start date pickers, end date pickers, week presets, and month presets—to the dynamic range **August 2022 (`2022-08-01`) through Current Date + 1 Month Forward Margin**.

---

## What's Fixed & Implemented in Phase 2 Release 2

1. **Platform-Wide Date Picker Coherency**:
   - Fixed **Alert Review Page** (`src/pages/alert_review.py`) and **Import Constraints Intelligence Workspace** (`src/pages/import_constraints.py`):
     - `Select Specific Day` (`picker-specific-day` / `ic-picker-specific-day`), `Start Date`, and `End Date` controls now dynamically accept dates back to **August 2022** up to current date + forward margin (October buffer).
     - Hardcoded `2026-01-01` to `2026-06-30` bounds have been removed across all DatePickerSingle instances.
   - Added `Select Specific Day` picker control and callback handling to **Alert Review Page** for complete multi-page control parity.
   - Fixed fallback bounds in `sp_analytics_repository.get_database_date_bounds()` and full period reset buttons across `closed_reviews.py` and `long_run_analytics.py`.

2. **Verified Azure SQL Persistence (`dbo.MM_ACTIVITY_LOG`)**:
   - Maintains full operational persistence to `dbo.MM_ACTIVITY_LOG` with `WORKSTREAM_NAME = 'IMPORT_CONSTRAINTS'`.
   - Technical Primary Key: `ACTIVITY_LOG_ID` (`UNIQUEIDENTIFIER` / Python UUID).
   - Composite Uniqueness: `UNIQUE (WORKSTREAM_NAME, ALERT_UNIQUE_ID)`.
   - Phase 1 `dbo.ACTIVITY_LOG` remains unmodified and protected.

---

## Instructions for Colleagues Testing on Windows 11 (VS Code)

### Step 1: Environment Setup
Open the folder `releases/phase2_release_2_dynamic_date_coherency` in VS Code and install dependencies:

```powershell
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables
Set your environment variables in your terminal or `.env` file:

```powershell
$env:DATABASE_MODE="azure"
$env:AZURE_SQL_SERVER="your_server.database.windows.net"
$env:AZURE_SQL_DATABASE="your_db_name"
$env:AZURE_SQL_USER="your_username"
$env:AZURE_SQL_PASSWORD="your_password"
```

*(To run locally in SQLite test mode without Azure SQL credentials, set `$env:DATABASE_MODE="sqlite"`)*

### Step 3: Run the Application
Launch the Market Monitoring Platform Dash application:

```powershell
python src/app.py
```

Access the application in your browser at `http://127.0.0.1:8050`.

---

## Coherency & Functionality Verification Checklist

- [ ] **Alert Review Page**: Verify that `Select Specific Day`, `Start Date`, and `End Date` allow selecting single days and custom date ranges back to **August 2022** and up to **October** (current date + 1 month buffer).
- [ ] **Import Constraints Workspace**: Verify that `Select Specific Day`, `Start Date`, and `End Date` allow selecting single days and custom date ranges back to **August 2022** and up to **October**.
- [ ] **Open Reviews, Closed Reviews, Long Run Analytics**: Confirm date pickers continue to allow full historical range back to August 2022 and forward margin buffer.
- [ ] **Azure SQL Review Persistence**: Save/update reviews on Alert Review page and verify records persist to `dbo.MM_ACTIVITY_LOG`.

---

## Technical Verification Evidence

- **Unit & Integration Suite**: `51 / 51 tests passed` (100% pass rate in 2.75s).
- **Execution Command**: `uv run python -m pytest tests/` inside release directory.
