import dash
from dash import dcc, html, Input, Output, State, callback

dash.register_page(
    __name__,
    path="/",
    title="Market Monitoring Platform",
)

ANALYST_OPTIONS = [
    {"label": "Analyst 1", "value": "Analyst 1"},
    {"label": "Analyst 2", "value": "Analyst 2"},
    {"label": "Analyst 3", "value": "Analyst 3"},
]

_PANEL_STYLE = {
    "position": "relative",
    "backgroundColor": "#D4BDD8",
    "border": "3px solid #4E0038",
    "borderRadius": "24px",
    "padding": "32px",
    "boxShadow": "0 8px 16px rgba(0,0,0,0.15)",
    "marginTop": "16px",
}

_PANEL_TITLE_STYLE = {
    "position": "absolute",
    "top": "-20px",
    "left": "50%",
    "transform": "translateX(-50%)",
    "backgroundColor": "#E2E8F0",
    "border": "2px solid #4E0038",
    "borderRadius": "8px",
    "padding": "4px 16px",
    "color": "#4E0038",
    "fontSize": "20px",
    "fontWeight": "800",
    "whiteSpace": "nowrap",
}


def _build_panel(title, buttons, extra_style=None):
    """Builds a landing-page panel (titled badge + stacked buttons) matching the existing panels."""
    return html.Div(
        style={**_PANEL_STYLE, **(extra_style or {})},
        children=[
            html.Div(title, style=_PANEL_TITLE_STYLE),
            html.Div(
                style={"display": "flex", "flexDirection": "column", "gap": "16px"},
                children=buttons,
            ),
        ],
    )


def _build_action_button(label, component_id):
    """Platform button with standard styling, wired for gated callback navigation."""
    return html.Button(
        label,
        id=component_id,
        n_clicks=0,
        style={
            "backgroundColor": "#4E0038",
            "color": "#ffffff",
            "border": "none",
            "padding": "16px",
            "borderRadius": "8px",
            "fontSize": "16px",
            "fontWeight": "700",
            "cursor": "pointer",
            "boxShadow": "0 4px 8px rgba(0,0,0,0.2)",
            "transition": "all 0.2s ease",
            "textAlign": "center",
        },
    )


def _build_planned_button(label, component_id):
    """Disabled placeholder button for capabilities that are not operational yet."""
    return html.Button(
        label,
        id=component_id,
        disabled=True,
        className="btn-ws-disabled",
        style={
            "backgroundColor": "#3B002A",
            "color": "rgba(255, 255, 255, 0.5)",
            "border": "none",
            "padding": "16px",
            "borderRadius": "8px",
            "fontSize": "16px",
            "fontWeight": "600",
            "cursor": "not-allowed",
            "textAlign": "center",
            "boxShadow": "0 4px 6px rgba(0,0,0,0.1)",
        },
    )


layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "100%",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#F4F4F6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        # 1. Top Header Row (NESO Logo, Title, Analyst Dropdown)
        html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "280px 1fr 320px",
                "gap": "24px",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                # Direct NESO Logo Image (No outer padded box container)
                html.Img(
                    src="/assets/logo.jpg",
                    alt="NESO Logo",
                    style={
                        "height": "76px",
                        "width": "100%",
                        "objectFit": "contain",
                        "borderRadius": "8px",
                    },
                ),
                # Central Title Box
                html.Div(
                    style={
                        "backgroundColor": "#F3E8F6",
                        "border": "2px solid #D4BDD8",
                        "borderRadius": "8px",
                        "padding": "18px 28px",
                        "textAlign": "center",
                    },
                    children=[
                        html.H1(
                            "Market Monitoring Platform",
                            style={
                                "margin": "0",
                                "color": "#5A214B",
                                "fontSize": "26px",
                                "fontWeight": "700",
                                "letterSpacing": "0.5px",
                            },
                        )
                    ],
                ),
                # Right Analyst Dropdown Box
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "border": "1px solid #cbd5e1",
                        "borderRadius": "8px",
                        "padding": "14px 18px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.05)",
                    },
                    children=[
                        html.Label(
                            "Select Analyst Space:",
                            style={
                                "display": "block",
                                "fontSize": "12px",
                                "fontWeight": "700",
                                "color": "#707070",
                                "textTransform": "uppercase",
                                "marginBottom": "6px",
                                "letterSpacing": "0.5px",
                            },
                        ),
                        dcc.Dropdown(
                            id="landing-analyst-select",
                            options=ANALYST_OPTIONS,
                            placeholder="Choose Analyst...",
                            clearable=True,
                            style={"fontSize": "14px"},
                        ),
                    ],
                ),
            ],
        ),
        # 2. Welcome Banner Bar
        html.Div(
            style={
                "backgroundColor": "#5A0047",
                "color": "#ffffff",
                "borderRadius": "8px",
                "padding": "20px 32px",
                "marginBottom": "28px",
                "display": "flex",
                "alignItems": "center",
                "justifyContent": "center",
                "gap": "14px",
                "boxShadow": "0 2px 6px rgba(0,0,0,0.1)",
            },
            children=[
                html.Span(
                    "Welcome :",
                    style={
                        "fontSize": "20px",
                        "fontWeight": "700",
                        "letterSpacing": "0.5px",
                    },
                ),
                html.Div(
                    id="landing-welcome-name-pill",
                    style={
                        "backgroundColor": "#46C18A",
                        "color": "#ffffff",
                        "padding": "8px 24px",
                        "borderRadius": "6px",
                        "fontWeight": "700",
                        "fontSize": "18px",
                        "minWidth": "180px",
                        "textAlign": "center",
                        "letterSpacing": "0.5px",
                        "border": "none",
                    },
                    children="Select Analyst",
                ),
            ],
        ),
        # Guardrail Warning Alert (hidden by default)
        html.Div(
            id="landing-guardrail-warning",
            style={"display": "none", "marginBottom": "20px"},
        ),
        # 3. Main Content Cards (Two Columns: Workstream & Rota)
        html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "1fr 1fr",
                "gap": "28px",
                "alignItems": "start",
            },
            children=[
                # Column 1: Core Tools
                html.Div(
                    style={
                        "gridColumn": "1",
                        "gridRow": "1 / span 2",
                        "position": "relative",
                        "backgroundColor": "#D4BDD8",
                        "border": "3px solid #4E0038",
                        "borderRadius": "24px",
                        "padding": "32px",
                        "boxShadow": "0 8px 16px rgba(0,0,0,0.15)",
                        "marginTop": "16px",
                        "alignSelf": "stretch",
                        "boxSizing": "border-box",
                    },
                    children=[
                        html.Div(
                            "Core Tools",
                            style={
                                "position": "absolute",
                                "top": "-20px",
                                "left": "50%",
                                "transform": "translateX(-50%)",
                                "backgroundColor": "#E2E8F0",
                                "border": "2px solid #4E0038",
                                "borderRadius": "8px",
                                "padding": "4px 16px",
                                "color": "#4E0038",
                                "fontSize": "20px",
                                "fontWeight": "800",
                                "whiteSpace": "nowrap",
                            },
                        ),
                        html.Div(
                            style={
                                "display": "flex",
                                "flexDirection": "column",
                                "justifyContent": "space-between",
                                "height": "100%",
                                "boxSizing": "border-box",
                            },
                            children=[
                                html.Button(
                                    "UMM MEL (Planned)",
                                    id="btn-ws-umm",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#3B002A",
                                        "color": "rgba(255, 255, 255, 0.5)",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                        "textAlign": "center",
                                        "boxShadow": "0 4px 6px rgba(0,0,0,0.1)",
                                    },
                                ),
                                html.Button(
                                    "Close IOLC (Planned)",
                                    id="btn-ws-iolc",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#3B002A",
                                        "color": "rgba(255, 255, 255, 0.5)",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                        "textAlign": "center",
                                        "boxShadow": "0 4px 6px rgba(0,0,0,0.1)",
                                    },
                                ),
                                html.Button(
                                    "Close TCLC (Planned)",
                                    id="btn-ws-tclc",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#3B002A",
                                        "color": "rgba(255, 255, 255, 0.5)",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                        "textAlign": "center",
                                        "boxShadow": "0 4px 6px rgba(0,0,0,0.1)",
                                    },
                                ),
                                html.Button(
                                    "IC Trading (Planned)",
                                    id="btn-ws-ic",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#3B002A",
                                        "color": "rgba(255, 255, 255, 0.5)",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                        "textAlign": "center",
                                        "boxShadow": "0 4px 6px rgba(0,0,0,0.1)",
                                    },
                                ),
                                html.Button(
                                    "Import Constraints",
                                    id="btn-ws-import-constraints",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": "#4E0038",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "700",
                                        "cursor": "pointer",
                                        "boxShadow": "0 4px 8px rgba(0,0,0,0.2)",
                                        "transition": "all 0.2s ease",
                                        "textAlign": "center",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
                # Column 2: Rota & Administration
                html.Div(
                    style={
                        "gridColumn": "2",
                        "gridRow": "1",
                        "position": "relative",
                        "backgroundColor": "#D4BDD8",
                        "border": "3px solid #4E0038",
                        "borderRadius": "24px",
                        "padding": "32px",
                        "boxShadow": "0 8px 16px rgba(0,0,0,0.15)",
                        "marginTop": "16px",
                    },
                    children=[
                        html.Div(
                            "Rota & Administration",
                            style={
                                "position": "absolute",
                                "top": "-20px",
                                "left": "50%",
                                "transform": "translateX(-50%)",
                                "backgroundColor": "#E2E8F0",
                                "border": "2px solid #4E0038",
                                "borderRadius": "8px",
                                "padding": "4px 16px",
                                "color": "#4E0038",
                                "fontSize": "20px",
                                "fontWeight": "800",
                                "whiteSpace": "nowrap",
                            },
                        ),
                        html.Div(
                            style={
                                "display": "flex",
                                "flexDirection": "column",
                                "gap": "20px",
                            },
                            children=[
                                html.Button(
                                    "Rota for this week",
                                    id="btn-rota-this-week",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": "#4E0038",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "700",
                                        "cursor": "pointer",
                                        "boxShadow": "0 4px 8px rgba(0,0,0,0.2)",
                                        "transition": "all 0.2s ease",
                                        "textAlign": "center",
                                    },
                                ),
                                html.Button(
                                    "Admin Page",
                                    id="btn-admin-page",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": "#4E0038",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "8px",
                                        "fontSize": "16px",
                                        "fontWeight": "700",
                                        "cursor": "pointer",
                                        "boxShadow": "0 4px 8px rgba(0,0,0,0.2)",
                                        "transition": "all 0.2s ease",
                                        "textAlign": "center",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
                # Column 2 (second row): Analytical Support
                _build_panel(
                    "Analytical Support",
                    [
                        _build_action_button("Dashboards", "btn-analytical-dashboards"),
                        _build_action_button(
                            "Long Term Statistics",
                            "btn-analytical-long-term-stats",
                        ),
                    ],
                    extra_style={"gridColumn": "2", "gridRow": "2"},
                ),
            ],
        ),
        # 4. Weekly Review (planned: cross-workstream meeting view is still being designed)
        html.Div(
            style={"maxWidth": "560px", "margin": "44px auto 0 auto"},
            children=[
                _build_panel(
                    "Weekly Review",
                    [
                        _build_planned_button("Open Reviews (Planned)", "btn-weekly-open-reviews"),
                        _build_planned_button("TBC (Planned)", "btn-weekly-tbc"),
                    ],
                ),
            ],
        ),
    ],
)


@callback(
    Output("selected-analyst-store", "data", allow_duplicate=True),
    Output("landing-welcome-name-pill", "children"),
    Output("landing-welcome-name-pill", "style"),
    Input("landing-analyst-select", "value"),
    prevent_initial_call="initial_duplicate",
)
def update_welcome_pill(analyst_name):
    if analyst_name:
        style_active = {
            "backgroundColor": "#46C18A",
            "color": "#ffffff",
            "padding": "8px 24px",
            "borderRadius": "6px",
            "fontWeight": "700",
            "fontSize": "18px",
            "minWidth": "180px",
            "textAlign": "center",
            "letterSpacing": "0.5px",
        }
        return analyst_name, analyst_name, style_active

    style_default = {
        "backgroundColor": "#46C18A",
        "color": "#ffffff",
        "padding": "8px 24px",
        "borderRadius": "6px",
        "fontWeight": "700",
        "fontSize": "18px",
        "minWidth": "180px",
        "textAlign": "center",
        "letterSpacing": "0.5px",
        "border": "none",
    }
    return None, "Select Analyst", style_default


@callback(
    Output("landing-analyst-select", "value"),
    Input("selected-analyst-store", "data"),
    State("landing-analyst-select", "value"),
)
def initialize_analyst_from_store(stored_analyst, current_val):
    if stored_analyst and not current_val:
        return stored_analyst
    return dash.no_update


@callback(
    Output("landing-guardrail-warning", "children"),
    Output("landing-guardrail-warning", "style"),
    Output("url", "pathname", allow_duplicate=True),
    Input("btn-ws-import-constraints", "n_clicks"),
    State("landing-analyst-select", "value"),
    State("selected-analyst-store", "data"),
    prevent_initial_call=True,
)
def navigate_to_import_constraints(n_clicks, analyst_dropdown_val, stored_analyst):
    if not n_clicks:
        return dash.no_update, dash.no_update, dash.no_update

    effective_analyst = analyst_dropdown_val or stored_analyst

    if not effective_analyst:
        alert_box = html.Div(
            style={
                "backgroundColor": "#fef2f2",
                "border": "1px solid #fca5a5",
                "borderRadius": "6px",
                "padding": "12px 18px",
                "color": "#991b1b",
                "fontSize": "14px",
                "fontWeight": "600",
                "display": "flex",
                "alignItems": "center",
                "gap": "8px",
            },
            children=[
                html.Span("⚠️ Guardrail Enforced:"),
                html.Span(
                    "Please select an Analyst from the top dropdown before accessing the operational workspace."
                ),
            ],
        )
        return alert_box, {"display": "block", "marginBottom": "20px"}, dash.no_update

    # Analyst is selected -> navigate to operational alert review workspace
    return dash.no_update, {"display": "none"}, "/alert-review"


@callback(
    Output("landing-guardrail-warning", "children", allow_duplicate=True),
    Output("landing-guardrail-warning", "style", allow_duplicate=True),
    Output("url", "pathname", allow_duplicate=True),
    Input("btn-rota-this-week", "n_clicks"),
    Input("btn-admin-page", "n_clicks"),
    State("landing-analyst-select", "value"),
    State("selected-analyst-store", "data"),
    prevent_initial_call=True,
)
def navigate_to_rota_pages(btn_rota, btn_admin, analyst_dropdown_val, stored_analyst):
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update, dash.no_update

    if not btn_rota and not btn_admin:
        return dash.no_update, dash.no_update, dash.no_update

    button_id = ctx.triggered[0]["prop_id"].split(".")[0]
    effective_analyst = analyst_dropdown_val or stored_analyst

    if not effective_analyst:
        alert_box = html.Div(
            style={
                "backgroundColor": "#fef2f2",
                "border": "1px solid #fca5a5",
                "borderRadius": "6px",
                "padding": "12px 18px",
                "color": "#991b1b",
                "fontSize": "14px",
                "fontWeight": "600",
                "display": "flex",
                "alignItems": "center",
                "gap": "8px",
            },
            children=[
                html.Span("⚠️ Guardrail Enforced:"),
                html.Span(
                    "Please select an Analyst from the top dropdown before accessing the operational workspace."
                ),
            ],
        )
        return alert_box, {"display": "block", "marginBottom": "20px"}, dash.no_update

    if button_id == "btn-rota-this-week":
        return dash.no_update, {"display": "none"}, "/rota-weekly"
    elif button_id == "btn-admin-page":
        return dash.no_update, {"display": "none"}, "/rota-admin"

    return dash.no_update, dash.no_update, dash.no_update


@callback(
    Output("landing-guardrail-warning", "children", allow_duplicate=True),
    Output("landing-guardrail-warning", "style", allow_duplicate=True),
    Output("url", "pathname", allow_duplicate=True),
    Input("btn-analytical-dashboards", "n_clicks"),
    Input("btn-analytical-long-term-stats", "n_clicks"),
    State("landing-analyst-select", "value"),
    State("selected-analyst-store", "data"),
    prevent_initial_call=True,
)
def navigate_to_analytical_support(btn_dashboards, btn_stats, analyst_dropdown_val, stored_analyst):
    ctx = dash.callback_context
    if not ctx.triggered:
        return dash.no_update, dash.no_update, dash.no_update

    if not btn_dashboards and not btn_stats:
        return dash.no_update, dash.no_update, dash.no_update

    button_id = ctx.triggered[0]["prop_id"].split(".")[0]
    effective_analyst = analyst_dropdown_val or stored_analyst

    if not effective_analyst:
        alert_box = html.Div(
            style={
                "backgroundColor": "#fef2f2",
                "border": "1px solid #fca5a5",
                "borderRadius": "6px",
                "padding": "12px 18px",
                "color": "#991b1b",
                "fontSize": "14px",
                "fontWeight": "600",
                "display": "flex",
                "alignItems": "center",
                "gap": "8px",
            },
            children=[
                html.Span("⚠️ Guardrail Enforced:"),
                html.Span(
                    "Please select an Analyst from the top dropdown before accessing the operational workspace."
                ),
            ],
        )
        return alert_box, {"display": "block", "marginBottom": "20px"}, dash.no_update

    if button_id == "btn-analytical-dashboards":
        return dash.no_update, {"display": "none"}, "/analytical-support"
    elif button_id == "btn-analytical-long-term-stats":
        return dash.no_update, {"display": "none"}, "/long-run-analytics"

    return dash.no_update, dash.no_update, dash.no_update


@callback(
    Output("landing-guardrail-warning", "style", allow_duplicate=True),
    Input("landing-analyst-select", "value"),
    prevent_initial_call=True,
)
def hide_guardrail_on_analyst_select(analyst_name):
    if analyst_name:
        return {"display": "none"}
    return dash.no_update
