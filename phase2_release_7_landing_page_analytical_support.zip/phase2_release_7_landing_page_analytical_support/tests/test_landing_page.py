from pathlib import Path
import pytest
import dash

PAGES_DIR = str(Path(__file__).resolve().parent.parent / "src" / "pages")
app = dash.Dash(__name__, use_pages=True, pages_folder=PAGES_DIR)
from src.pages import landing_page


def test_landing_page_layout_structure():
    """Verify landing page layout renders essential components."""
    layout = landing_page.layout
    assert layout is not None
    assert hasattr(layout, "children")
    assert len(layout.children) >= 3


def test_update_welcome_pill():
    """Verify welcome pill updates dynamically based on analyst selection."""
    # When analyst is selected
    store_val, text, style = landing_page.update_welcome_pill("Analyst 1")
    assert store_val == "Analyst 1"
    assert text == "Analyst 1"
    assert style["backgroundColor"] == "#46C18A"  # Green pill
    # When no analyst is selected
    store_none, text_none, style_none = landing_page.update_welcome_pill(None)
    assert store_none is None
    assert text_none == "Select Analyst"
    assert style_none["backgroundColor"] == "#46C18A"  # Default green pill


def test_initialize_analyst_from_store():
    """Verify landing page dropdown initializes from stored analyst context."""
    val = landing_page.initialize_analyst_from_store("Analyst 2", None)
    assert val == "Analyst 2"

    val_no_update = landing_page.initialize_analyst_from_store("Analyst 2", "Analyst 1")
    assert val_no_update == dash.no_update


def test_navigate_to_import_constraints_guardrail():
    """Verify guardrail blocks navigation if no analyst is selected."""
    # 1. No clicks
    alert, style, path = landing_page.navigate_to_import_constraints(0, None, None)
    assert alert == dash.no_update

    # 2. Clicked without analyst -> displays guardrail warning
    alert, style, path = landing_page.navigate_to_import_constraints(1, None, None)
    assert style["display"] == "block"
    assert path == dash.no_update

    # 3. Clicked with analyst in dropdown -> navigates to /alert-review
    alert_ok, style_ok, path_ok = landing_page.navigate_to_import_constraints(1, "Analyst 1", None)
    assert style_ok["display"] == "none"
    assert path_ok == "/alert-review"

    # 4. Clicked with analyst in store -> navigates to /alert-review
    alert_stored, style_stored, path_stored = landing_page.navigate_to_import_constraints(1, None, "Analyst 3")
    assert style_stored["display"] == "none"
    assert path_stored == "/alert-review"


def test_analyst_options_match_rota_analyst_names():
    """Landing-page analysts must match the ANALYST_NAME values stored in MM_ROTA (Analyst 1/2/3)."""
    values = [opt["value"] for opt in landing_page.ANALYST_OPTIONS]
    assert values == ["Analyst 1", "Analyst 2", "Analyst 3"]
    assert all(opt["label"] == opt["value"] for opt in landing_page.ANALYST_OPTIONS)


def _collect_components(component, found=None):
    """Recursively collect every Dash component in a layout tree, keyed by id (if any)."""
    if found is None:
        found = {}
    comp_id = getattr(component, "id", None)
    if comp_id:
        found[comp_id] = component
    children = getattr(component, "children", None)
    if isinstance(children, (list, tuple)):
        for child in children:
            _collect_components(child, found)
    elif children is not None and hasattr(children, "children"):
        _collect_components(children, found)
    return found


def _all_text(component):
    """Recursively collect all string content in a layout tree."""
    texts = []
    children = getattr(component, "children", None)
    if isinstance(children, str):
        texts.append(children)
    elif isinstance(children, (list, tuple)):
        for child in children:
            if isinstance(child, str):
                texts.append(child)
            else:
                texts.extend(_all_text(child))
    elif children is not None:
        texts.extend(_all_text(children))
    return texts


def test_analytical_support_buttons_render_properly():
    """Analytical Support buttons are platform action buttons, ready for gated callback navigation."""
    components = _collect_components(landing_page.layout)

    dashboards = components["btn-analytical-dashboards"]
    assert dashboards.n_clicks == 0
    assert dashboards.children == "Dashboards"

    stats = components["btn-analytical-long-term-stats"]
    assert stats.n_clicks == 0
    assert stats.children == "Long Term Statistics"


def test_navigate_to_analytical_support_guardrail(monkeypatch):
    """Verify guardrail blocks navigation to Analytical Support if no analyst is selected."""
    from unittest.mock import MagicMock

    # 1. No triggers / no clicks
    mock_ctx_none = MagicMock()
    mock_ctx_none.triggered = []
    monkeypatch.setattr(dash, "callback_context", mock_ctx_none)

    alert, style, path = landing_page.navigate_to_analytical_support(0, 0, None, None)
    assert alert == dash.no_update
    assert style == dash.no_update
    assert path == dash.no_update

    # 2. Clicked Dashboards without analyst -> displays guardrail warning
    mock_ctx = MagicMock()
    mock_ctx.triggered = [{"prop_id": "btn-analytical-dashboards.n_clicks", "value": 1}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx)

    alert, style, path = landing_page.navigate_to_analytical_support(1, 0, None, None)
    assert style["display"] == "block"
    assert path == dash.no_update

    # 3. Clicked Dashboards with analyst in dropdown -> navigates to /analytical-support
    alert_ok, style_ok, path_ok = landing_page.navigate_to_analytical_support(1, 0, "Analyst 1", None)
    assert style_ok["display"] == "none"
    assert path_ok == "/analytical-support"

    # 4. Clicked Long Term Statistics with analyst in store -> navigates to /long-run-analytics
    mock_ctx_stats = MagicMock()
    mock_ctx_stats.triggered = [{"prop_id": "btn-analytical-long-term-stats.n_clicks", "value": 1}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx_stats)

    alert_stats, style_stats, path_stats = landing_page.navigate_to_analytical_support(0, 1, None, "Analyst 2")
    assert style_stats["display"] == "none"
    assert path_stats == "/long-run-analytics"


def test_navigate_to_rota_pages_guardrail(monkeypatch):
    """Verify guardrail blocks navigation to Rota pages if no analyst is selected."""
    from unittest.mock import MagicMock

    # 1. No triggers / no clicks
    mock_ctx_none = MagicMock()
    mock_ctx_none.triggered = []
    monkeypatch.setattr(dash, "callback_context", mock_ctx_none)

    alert, style, path = landing_page.navigate_to_rota_pages(0, 0, None, None)
    assert alert == dash.no_update

    # 2. Clicked Rota without analyst -> displays guardrail warning
    mock_ctx = MagicMock()
    mock_ctx.triggered = [{"prop_id": "btn-rota-this-week.n_clicks", "value": 1}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx)

    alert, style, path = landing_page.navigate_to_rota_pages(1, 0, None, None)
    assert style["display"] == "block"
    assert path == dash.no_update

    # 3. Clicked with analyst -> navigates to /rota-weekly
    alert_ok, style_ok, path_ok = landing_page.navigate_to_rota_pages(1, 0, "Analyst 1", None)
    assert style_ok["display"] == "none"
    assert path_ok == "/rota-weekly"

    # 4. Clicked admin with stored analyst -> navigates to /rota-admin
    mock_ctx_admin = MagicMock()
    mock_ctx_admin.triggered = [{"prop_id": "btn-admin-page.n_clicks", "value": 1}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx_admin)

    alert_adm, style_adm, path_adm = landing_page.navigate_to_rota_pages(0, 1, None, "Analyst 3")
    assert style_adm["display"] == "none"
    assert path_adm == "/rota-admin"


def test_analytical_support_targets_are_registered_routes():
    """The new link targets must match routes that actually exist in the app."""
    pages_dir = Path(PAGES_DIR)
    registered_paths = "".join(p.read_text() for p in pages_dir.glob("*.py"))
    assert 'path="/analytical-support"' in registered_paths
    assert 'path="/long-run-analytics"' in registered_paths


def test_weekly_review_buttons_are_planned_and_disabled():
    """Weekly Review is shown as planned: buttons are disabled so they cannot open an incomplete view."""
    components = _collect_components(landing_page.layout)

    open_reviews = components["btn-weekly-open-reviews"]
    assert open_reviews.disabled is True
    assert open_reviews.children == "Open Reviews (Planned)"

    tbc = components["btn-weekly-tbc"]
    assert tbc.disabled is True
    assert tbc.children == "TBC (Planned)"


def test_landing_page_panel_titles():
    """Landing page shows all four panels from the stakeholder mock-up."""
    texts = _all_text(landing_page.layout)
    for title in ("Core Tools", "Rota & Administration", "Analytical Support", "Weekly Review"):
        assert title in texts


def test_existing_landing_buttons_unchanged():
    """Existing Import Constraints, Rota and Admin buttons and planned workstream buttons remain present."""
    components = _collect_components(landing_page.layout)
    for comp_id in ("btn-ws-import-constraints", "btn-rota-this-week", "btn-admin-page"):
        assert comp_id in components
    for comp_id in ("btn-ws-umm", "btn-ws-iolc", "btn-ws-tclc", "btn-ws-ic"):
        assert components[comp_id].disabled is True
