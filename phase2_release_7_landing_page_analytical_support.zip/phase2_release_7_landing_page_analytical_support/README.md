# Phase 2 Release 7: Landing Page Analytical Support & Guardrail Gating (Acceptance Testing)

This release contains the overhauled Landing Page for the Market Monitoring Platform, aligning with stakeholder specifications and enforcing analyst guardrail navigation across all active platform entry points.

## What's Included

* **Analytical Support Panel**:
  * Added **Dashboards** button routing to `/analytical-support` (Investigation Intelligence & Analytical Support portal).
  * Added **Long Term Statistics** button routing to `/long-run-analytics` (Long-Run Statistics & Analytics portal).
* **Weekly Review Panel (Planned)**:
  * Added **Open Reviews (Planned)** and **TBC (Planned)** buttons, explicitly disabled as placeholders while cross-workstream meeting workflows are finalized.
* **Analyst Guardrail Gating**:
  * Accessing **Dashboards**, **Long Term Statistics**, **Import Constraints**, **Rota for this week**, or **Admin Page** is strictly gated on selecting an analyst from the top dropdown (`Analyst 1`, `Analyst 2`, `Analyst 3`).
  * Attempting to click any active button without an analyst selection raises a prominent guardrail warning alert and blocks navigation.
* **Standard Analyst Options**:
  * Analyst dropdown options are restored to `Analyst 1`, `Analyst 2`, `Analyst 3` to match the `MM_ROTA` schedule and database records.

---

## Acceptance Testing Instructions (Windows 11)

This release is pre-configured strictly for **Azure SQL mode** (`DATABASE_MODE=azure`). Do not run this package in SQLite mode.

1. Unzip this package and open the folder in **VS Code**.
2. Open a new **PowerShell** terminal in VS Code.
3. Activate your dedicated Conda environment (or create one):
   ```powershell
   conda activate market_monitoring_env
   ```
4. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Ensure your Azure SQL credentials are set in your local Windows environment variables, or export them in your PowerShell session:
   ```powershell
   $env:DATABASE_MODE="azure"
   $env:AZURE_SQL_SERVER="your_server.database.windows.net"
   $env:AZURE_SQL_DATABASE="your_db"
   ```
6. Launch the application (run as module from the root directory):
   ```powershell
   python -m src.app
   ```
   *(Note: Extract this package into a fresh, clean folder to ensure no older files remain in `src/pages/`)*
7. Open your browser and navigate to:
   ```text
   http://127.0.0.1:8050
   ```

---

## Acceptance Test Scenarios

### 1. Guardrail Validation (No Analyst Selected)
- When the page first loads, ensure the top dropdown placeholder reads **"Choose Analyst..."** and the welcome pill displays **"Select Analyst"**.
- Click the **Dashboards** button in the Analytical Support panel:
  - **Expected**: A red warning box appears (`⚠️ Guardrail Enforced: Please select an Analyst from the top dropdown before accessing the operational workspace.`) and the page does not navigate.
- Click the **Long Term Statistics** button:
  - **Expected**: The guardrail warning remains and the page does not navigate.
- Click **Import Constraints** or **Rota for this week**:
  - **Expected**: The guardrail warning blocks navigation.

### 2. Analyst Selection & Dynamic Pill
- In the top right **Select Analyst Space** dropdown, choose **Analyst 1**.
- **Expected**:
  - The welcome banner immediately updates to **"Welcome : Analyst 1"**.
  - Any previously displayed guardrail warning alert disappears.

### 3. Analytical Support Navigation
- With **Analyst 1** selected, click **Dashboards**:
  - **Expected**: Seamlessly navigates to `/analytical-support` ("Investigation Intelligence & Analytical Support").
  - Click the **Main Landing Page** link in the navigation header to return to `/`.
- Click **Long Term Statistics**:
  - **Expected**: Seamlessly navigates to `/long-run-analytics` ("Long-Run Statistics & Analytics").
  - Return to `/`.

### 4. Weekly Review Placeholder Inspection
- Inspect the **Weekly Review** panel at the bottom center of the landing page.
- **Expected**:
  - **Open Reviews (Planned)** is styled in dark disabled plum and is not clickable.
  - **TBC (Planned)** is styled in dark disabled plum and is not clickable.

### 5. Regression Check on Operational Workflows
- Click **Import Constraints** -> Confirm Alert Review loads successfully with Azure SQL data.
- Click **Rota for this week** -> Confirm the weekly matrix view loads for the current week.
- Click **Admin Page** -> Confirm monthly Rota administration loads.

Please report your validation results back to the team!
