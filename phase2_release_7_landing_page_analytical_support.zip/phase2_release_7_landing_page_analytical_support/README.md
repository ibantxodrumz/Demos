# Phase 2 Release 7: Landing Page Analytical Support & Guardrail Gating (Acceptance Testing)

This release updates the Landing Page for the Market Monitoring platform to match stakeholder specifications, introducing the Analytical Support panel, Weekly Review placeholder panel, and analyst guardrail navigation.

## What's Included

* **Analytical Support Panel**: Added **Dashboards** (`/analytical-support`) and **Long Term Statistics** (`/long-run-analytics`) operational entry points.
* **Analyst Guardrail Gating**: All platform entry points (**Dashboards**, **Long Term Statistics**, **Import Constraints**, **Rota for this week**, **Admin Page**) require selecting an analyst from the top dropdown (`Analyst 1`, `Analyst 2`, `Analyst 3`) before navigation is permitted.
* **Weekly Review Panel (Planned)**: Clean placeholders for cross-workstream meeting review workflows.

## Acceptance Testing Instructions (Windows 11)

This release is pre-configured strictly for **Azure SQL mode**. Do not attempt to run this with SQLite.

1. Unzip this package into a **fresh, clean folder** and open the folder in VS Code.
2. Open a new **PowerShell** terminal in VS Code.
3. Activate your dedicated Conda environment (or create one):
   ```powershell
   conda activate market_monitoring_env
   ```
4. Install the required dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Ensure your Azure SQL credentials are set in your local Windows environment variables, or temporarily export them in your PowerShell session:
   ```powershell
   $env:DATABASE_MODE="azure"
   $env:AZURE_SQL_SERVER="your_server.database.windows.net"
   $env:AZURE_SQL_DATABASE="your_db"
   ```
6. Launch the application:
   ```powershell
   python src/app.py
   ```
7. Open your browser and navigate to `http://127.0.0.1:8050`.

### Things to verify during testing:
- **Guardrail Gating**: Without selecting an analyst, verify clicking any active button displays the red warning alert and blocks navigation.
- **Dynamic Welcome**: Select **Analyst 1** from the top dropdown and verify the banner pill updates to `"Welcome : Analyst 1"`.
- **Navigation**: Click **Dashboards** and **Long Term Statistics** to confirm both routes open their respective portals.
- **Regression Check**: Click **Import Constraints** and **Rota for this week** to confirm existing Azure SQL workflows remain fully functional.

Please report back with your findings!
