# P8: Shared Platform Contract

## 1. Purpose
This document defines the strict architectural and operational contract between the **Core Platform** and any individual **Workstream** (e.g., Import Constraints, System Warnings, Imbalance Pricing). 

Any new workstream integrated into the Market Monitoring Platform must adhere to these definitions to ensure seamless routing, shared persistence, and UI coherency.

---

## 2. The Data Contract (`MM_ACTIVITY_LOG`)

The core of the platform is the shared `MM_ACTIVITY_LOG` Azure SQL table. This table tracks the lifecycle of every alert across every workstream.

### Required Fields (Must be provided by the Workstream)
* `WORKSTREAM_NAME` (varchar): Must exactly match a constant defined in `src/config/constants.py` (e.g., `'IMPORT_CONSTRAINTS'`).
* `ALERT_UNIQUE_ID` (varchar): The primary identifier from the workstream's specific alert table.
* `RAISE_DATE` (date): The date the alert triggered.
* `CREATED_DATETIME` (datetime2): System timestamp of creation.
* `UPDATED_DATETIME` (datetime2): System timestamp of last modification.
* `ANALYSIS_STATUS` (varchar): Must strictly adhere to platform-controlled statuses (e.g., `'Open'`, `'Closed'`).

### Optional / Shared Fields (Provide if applicable)
* `BMU_ID`, `PARTY_NAME`, `PARAMETER_BREACHED`: Used for high-level identification.
* `START_DATE`, `END_DATE`: For date-range bound alerts.
* `PERSON_RAISING`: Usually defaulting to system or `LOCAL_ANALYST_NAME`.
* `ACTION_TAKEN`: Must strictly adhere to `CONTROLLED_ACTIONS` defined in `src/config/settings.py`.
* `REVIEW_COMMENTS`: Analyst text block.

---

## 3. UI and Routing Contract

To prevent circular dependencies and maintain an infinitely scalable navigation structure, workstreams must obey the following UI routing rules:

1. **Independent Pages**: Every workstream view must be registered as a standalone Dash page using `dash.register_page(__name__, path="/workstream-route")`.
2. **Landing Page Integration**: 
   * Workstreams do not modify the core `app.py`.
   * To appear on the Landing Page, the workstream's entry route must be added to the grid in `src/pages/landing_page.py` using a standard button layout.
3. **Strict Root Navigation**:
   * All navigation between major modules (e.g., Landing Page -> Workstream, Workstream -> Rota) must use strict root-level HTTP navigation via standard `<a>` tags with `target="_self"`.
   * **Do not use** `dcc.Link` or `dcc.Location` redirects for inter-module traversal, as this triggers Dash's circular callback traps.
4. **Shared Sidebar/Navbar**: All workstream pages must wrap their content below the shared platform Navbar (`src/components/navbar.py`) to maintain persistent "Home" and "Active Analyst" context.

---

## 4. Repository & Database Expectations

Workstreams must safely interact with the Azure SQL environment without disrupting platform connections.

1. **No Classes in Repositories**: All database interaction layers must be composed of **module-level functions** (e.g., `def get_alerts():`). Do not use Classes for repositories.
2. **Connection Management**: All queries must execute within the platform's standard connection context manager:
   ```python
   from src.repositories import connection
   with connection.get_db() as conn:
       cursor = conn.execute(query)
   ```
3. **Cursor Iteration**: Repositories can and should iterate directly over the cursor (`for row in cursor:`). The platform natively handles Azure vs SQLite cursor mapping.
4. **Schema Centralization**: No repository is allowed to hardcode SQL table names. All table names (and their `dbo.` schemas) must be mapped dynamically from `src/config/constants.py` (e.g., `SQL_TABLE_IMPORT_ALERTS`).

---

## 5. Workstream Extension Points (Specific Data)

While the lifecycle is bound to `MM_ACTIVITY_LOG`, workstreams are expected to have their own highly specific telemetry and data.

* **Workstream Alert Tables**: A workstream is permitted (and encouraged) to have its own detailed table (e.g., `IMPORT_ALERTS`) to store data too granular for the activity log (like `DURATION_MIN`, `COUNT_SP`).
* **Workstream Granular Data**: A workstream may have a raw data telemetry table (e.g., `IMPORT_ALERTS_DATA`) for settlement period-level telemetry.
* **Join Rule**: When rendering an analyst review page, the workstream's UI should query its specific repository (to get the technical telemetry) and the `activity_log_repository` (to get the human workflow state), merging them visually for the user.

---

## 6. Error Handling & Validation

* **SQLite Fallback**: Every SQL query written for a workstream must be validated in `sqlite3` first. Do not use proprietary Azure T-SQL functions (like `GETDATE()` or `IDENTITY`) inside Python queries. Use `datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")`.
* **Testing**: No workstream feature can be merged without corresponding test coverage in `tests/` that utilizes the local SQLite mock database.

---

## 7. The Workstream Migration Playbook

Because the Core Platform (Release 6) is completely decoupled from individual workstreams, adding a new workstream is now a structured **migration**, not a rebuild. 

When onboarding a new workstream (e.g., "System Warnings"), developers must strictly follow this layered integration process:

### Step 1: Configuration & Database Schemas
* Add the new workstream's specific Azure table names to `src/config/constants.py` (e.g., `SQL_TABLE_SYSTEM_WARNINGS = "dbo.SYSTEM_WARNINGS"`).
* Append the SQLite equivalent `CREATE TABLE` and `INSERT` mock data into `tests/conftest.py` so local testing works immediately.

### Step 2: The Repository Layer (`src/repositories/`)
* Create a new isolated repository file (e.g., `src/repositories/sys_warnings_repository.py`).
* Define module-level functions (e.g., `def get_warning_details(alert_id):`) that query only the workstream's specific tables.
* **Do not** write queries to `MM_ACTIVITY_LOG` here; that remains strictly the domain of `activity_log_repository.py`.

### Step 3: The Service Layer (`src/services/`)
* Create a new isolated service file (e.g., `src/services/sys_warnings_service.py`).
* This is where the Workstream and Platform merge. The service function will call `sys_warnings_repository` to get the technical data, and call `activity_log_repository` to get the workflow state, returning a unified object to the UI.

### Step 4: The UI Layer (`src/pages/`)
* Create the specific UI dashboards (e.g., `src/pages/sys_warnings_review.py`).
* Register it at the top of the file using `dash.register_page(__name__, path="/sys-warnings")`.
* Import the shared Navbar from `src/components/navbar.py` to maintain visual and contextual coherency.

### Step 5: Platform Integration (The Landing Page)
* Open `src/pages/landing_page.py`.
* Add a new `html.A` button targeting `/sys-warnings` within the "Workstreams" grid section.

### Step 6: Testing Requirements (`tests/`)
* Create `tests/test_sys_warnings_repository.py` to validate SQL reads/writes against the SQLite mock.
* Ensure the project maintains its strict 100% test pass rate before shipping the integration.
