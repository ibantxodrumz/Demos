# Release 5: New Landing Page & Rota Integration

## Overview
This release introduces the fully styled Landing Page, the Rota Weekly list view, and the Rota Administration editor. **Core operational workspaces (Import Constraints, Dashboards) remain 100% functionally identical to Release 4.**

## Acceptance Testing Focus
Because 55 automated tests guarantee that no existing workflows were altered, **colleagues do not need to waste time re-testing Release 4 functionality.** 

Please focus acceptance testing *exclusively* on:
1. **Landing Page:** 
   - Verify the Neso color schemes (Plum/Slate) and general aesthetics.
   - Verify the Analyst dropdown works and hides the red guardrail warning.
2. **Rota for This Week (`/rota-weekly`):** 
   - Verify the list-based view layout correctly formats the dates.
   - Verify the "IC Owner" row is highlighted in light green with a checkmark.
3. **Rota Administration (`/rota-admin`):** 
   - Verify the month selector dropdown populates future months.
   - Verify the table allows assigning an Analyst and toggling the IC Owner status.
   - Verify clicking "Save Changes" successfully updates the Azure SQL Database.
4. **Navigation:**
   - Verify the "Back to Landing Page" buttons properly return you to the root dashboard from both the Weekly and Admin Rota pages.

## Database Note
The Azure SQL live database already contains the `MM_ROTA` table schema and populated data as confirmed by the product owner. No local or Azure migration scripts need to be run prior to testing. Just launch and test.

## Running the Release (Windows 11 / Conda / VS Code)
```powershell
# Navigate to the release directory
cd releases\phase2_release_5_rota_and_landing_page

# Ensure your conda environment with the required dependencies is active
# conda activate <your_environment>

# Ensure Azure Mode is active
$env:DATABASE_MODE="azure"

# Launch the app
python -m src.app
```
