import pytest
from src.repositories.rota_repository import RotaRepository

def test_get_rota_for_week(fresh_db):
    repo = RotaRepository()
    entries = repo.get_rota_for_week("2026-10-01", "2026-10-07")
    assert len(entries) >= 2
    assert entries[0].analyst_name == "Analyst 1"
    assert entries[0].is_weekly_ic_owner is True
    assert entries[1].analyst_name == "Analyst 2"
    assert entries[1].is_weekly_ic_owner is False

def test_get_rota_for_month(fresh_db):
    repo = RotaRepository()
    entries = repo.get_rota_for_month(2026, 10)
    assert len(entries) >= 2
    assert entries[0].analyst_name == "Analyst 1"

def test_update_rota_entry(fresh_db):
    repo = RotaRepository()
    # Assuming ROTA_ID = 1 corresponds to the first seeded row (2026-10-01)
    entries_before = repo.get_rota_for_week("2026-10-01", "2026-10-01")
    assert entries_before[0].analyst_name == "Analyst 1"
    assert entries_before[0].is_weekly_ic_owner is True
    rota_id = entries_before[0].rota_id

    repo.update_rota_entry(rota_id, "Analyst 3", False)

    entries_after = repo.get_rota_for_week("2026-10-01", "2026-10-01")
    assert entries_after[0].analyst_name == "Analyst 3"
    assert entries_after[0].is_weekly_ic_owner is False
    assert entries_after[0].updated_at is not None
