import dash
from dash import dcc, html, Input, Output, State, callback, dash_table
import pandas as pd
from datetime import date
from dateutil.relativedelta import relativedelta
from src.repositories.rota_repository import RotaRepository

dash.register_page(
    __name__,
    path="/rota-admin",
    title="Rota Administration",
)

def get_month_options():
    # Generate next 6 months options
    today = date(2026, 10, 1) # Hardcoded for demo context
    options = []
    for i in range(6):
        month_date = today + relativedelta(months=i)
        label = month_date.strftime("%B %Y")
        value = month_date.strftime("%Y-%m")
        options.append({"label": label, "value": value})
    return options

layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "1200px",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#F4F4F6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        html.Div(
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                html.H1(
                    "Rota Administration",
                    style={"color": "#4E0038", "margin": "0", "fontSize": "28px"},
                ),
                html.A(
                    "← Back to Landing Page",
                    href="/",
                    target="_self",
                    style={
                        "backgroundColor": "#ffffff",
                        "color": "#4E0038",
                        "padding": "8px 16px",
                        "borderRadius": "6px",
                        "textDecoration": "none",
                        "fontWeight": "600",
                        "border": "1px solid #cbd5e1",
                        "display": "inline-block",
                        "cursor": "pointer",
                    },
                ),
            ],
        ),
        
        # Month Selector Bar
        html.Div(
            style={
                "backgroundColor": "#5A0047",
                "color": "#ffffff",
                "borderRadius": "8px",
                "padding": "20px 32px",
                "marginBottom": "28px",
                "display": "flex",
                "alignItems": "center",
                "justifyContent": "center",
                "gap": "16px",
                "boxShadow": "0 2px 6px rgba(0,0,0,0.1)",
            },
            children=[
                html.Label(
                    "Select Month:",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "letterSpacing": "0.5px",
                    },
                ),
                dcc.Dropdown(
                    id="rota-admin-month-select",
                    options=get_month_options(),
                    value=get_month_options()[0]["value"],
                    clearable=False,
                    style={"color": "#1e293b", "minWidth": "250px"}
                ),
                html.Button(
                    "Save Changes",
                    id="btn-rota-admin-save",
                    n_clicks=0,
                    style={
                        "backgroundColor": "#46C18A",
                        "color": "#ffffff",
                        "border": "none",
                        "padding": "10px 24px",
                        "borderRadius": "6px",
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "cursor": "pointer",
                        "boxShadow": "0 2px 4px rgba(0,0,0,0.2)",
                        "marginLeft": "auto",
                    }
                )
            ],
        ),
        
        html.Div(id="rota-admin-save-status", style={"marginBottom": "16px", "fontWeight": "bold"}),

        html.Div(
            id="rota-admin-content",
            style={
                "backgroundColor": "#ffffff",
                "border": "1px solid #cbd5e1",
                "borderRadius": "8px",
                "padding": "24px",
                "boxShadow": "0 2px 4px rgba(0,0,0,0.05)",
            },
        ),
    ]
)

@callback(
    Output("rota-admin-content", "children"),
    Input("rota-admin-month-select", "value")
)
def load_admin_rota(month_val):
    if not month_val:
        return dash.no_update
        
    year, month = map(int, month_val.split("-"))
    repo = RotaRepository()
    entries = repo.get_rota_for_month(year, month)
    
    if not entries:
        return html.Div("No rota entries found for this month.", style={"color": "#64748b"})

    data = []
    for entry in entries:
        data.append({
            "ROTA_ID": entry.rota_id,
            "Review Date": entry.review_date,
            "Data Date": entry.data_date,
            "Analyst": entry.analyst_name,
            "IC Owner": "Yes" if entry.is_weekly_ic_owner else "No"
        })
    df = pd.DataFrame(data)
    
    return dash_table.DataTable(
        id="rota-admin-table",
        data=df.to_dict('records'),
        columns=[
            {"name": "Review Date", "id": "Review Date", "editable": False},
            {"name": "Data Date", "id": "Data Date", "editable": False},
            {"name": "Analyst", "id": "Analyst", "presentation": "dropdown", "editable": True},
            {"name": "IC Owner", "id": "IC Owner", "presentation": "dropdown", "editable": True},
        ],
        editable=True,
        dropdown={
            "Analyst": {
                "options": [{"label": i, "value": i} for i in ["Analyst 1", "Analyst 2", "Analyst 3"]]
            },
            "IC Owner": {
                "options": [{"label": "Yes", "value": "Yes"}, {"label": "No", "value": "No"}]
            }
        },
        style_header={
            "backgroundColor": "#D4BDD8",
            "color": "#4E0038",
            "fontWeight": "bold",
            "textAlign": "left",
            "padding": "12px",
            "border": "none"
        },
        style_cell={
            "padding": "12px",
            "textAlign": "left",
            "borderBottom": "1px solid #e2e8f0",
            "fontFamily": "Segoe UI",
            "color": "#334155"
        },
        style_data_conditional=[
            {
                "if": {"column_id": "Analyst"},
                "backgroundColor": "#f8fafc",
                "cursor": "pointer"
            },
            {
                "if": {"column_id": "IC Owner"},
                "backgroundColor": "#f8fafc",
                "cursor": "pointer"
            }
        ],
        style_as_list_view=True,
    )

@callback(
    Output("rota-admin-save-status", "children"),
    Output("rota-admin-save-status", "style"),
    Input("btn-rota-admin-save", "n_clicks"),
    State("rota-admin-table", "data"),
    prevent_initial_call=True
)
def save_admin_rota(n_clicks, table_data):
    if not n_clicks or not table_data:
        return dash.no_update, dash.no_update
        
    repo = RotaRepository()
    try:
        for row in table_data:
            rota_id = row.get("ROTA_ID")
            analyst = row.get("Analyst")
            ic_owner = True if row.get("IC Owner") == "Yes" else False
            repo.update_rota_entry(rota_id, analyst, ic_owner)
            
        return "Changes saved successfully!", {"color": "#16a34a", "marginBottom": "16px", "fontWeight": "bold"}
    except Exception as e:
        return f"Error saving changes: {str(e)}", {"color": "#dc2626", "marginBottom": "16px", "fontWeight": "bold"}


