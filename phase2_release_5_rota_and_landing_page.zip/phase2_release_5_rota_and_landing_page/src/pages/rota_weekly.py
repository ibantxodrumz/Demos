import dash
from dash import dcc, html, Input, Output, callback, dash_table
import pandas as pd
from datetime import date
from src.repositories.rota_repository import RotaRepository

dash.register_page(
    __name__,
    path="/rota-weekly",
    title="Rota for This Week",
)

def get_current_week_dates():
    # Hardcoded to a week that has data in our dummy dataset for demo purposes
    start = date(2026, 10, 19)
    end = date(2026, 10, 25)
    return start, end

layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "1200px",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#F4F4F6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        html.Div(
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                html.H1(
                    "Rota for This Week",
                    style={"color": "#4E0038", "margin": "0", "fontSize": "28px"},
                ),
                html.A(
                    "← Back to Landing Page",
                    href="/",
                    target="_self",
                    style={
                        "backgroundColor": "#ffffff",
                        "color": "#4E0038",
                        "padding": "8px 16px",
                        "borderRadius": "6px",
                        "textDecoration": "none",
                        "fontWeight": "600",
                        "border": "1px solid #cbd5e1",
                        "display": "inline-block",
                        "cursor": "pointer",
                    },
                ),
            ],
        ),
        html.Div(
            id="rota-weekly-content",
            style={
                "backgroundColor": "#ffffff",
                "border": "1px solid #cbd5e1",
                "borderRadius": "8px",
                "padding": "24px",
                "boxShadow": "0 2px 4px rgba(0,0,0,0.05)",
            },
        ),
        dcc.Interval(id="rota-weekly-interval", interval=60000, n_intervals=0),
    ]
)

@callback(
    Output("rota-weekly-content", "children"),
    Input("rota-weekly-interval", "n_intervals")
)
def update_weekly_rota(n):
    repo = RotaRepository()
    start_date, end_date = get_current_week_dates()
    entries = repo.get_rota_for_week(start_date.isoformat(), end_date.isoformat())
    
    if not entries:
        return html.Div("No rota entries found for this week.", style={"color": "#64748b"})

    from datetime import datetime

    list_items = []
    for entry in entries:
        # Parse dates
        r_date = datetime.strptime(entry.review_date, "%Y-%m-%d")
        d_date = datetime.strptime(entry.data_date, "%Y-%m-%d")
        
        # Format strings
        review_day = r_date.strftime("%A")
        review_fmt = r_date.strftime("%d/%m/%y")
        
        data_day = d_date.strftime("%A")
        data_fmt = f"{d_date.day}/{d_date.month}"
        
        row_text = f"{review_day} {review_fmt}. {entry.analyst_name} {data_day} ({data_fmt})"
        
        # Determine styling
        is_owner = entry.is_weekly_ic_owner
        bg_color = "#f0fdf4" if is_owner else "#ffffff"
        border_color = "#46C18A" if is_owner else "#cbd5e1"
        text_color = "#166534" if is_owner else "#334155"
        
        icon = html.Span("✅ ", style={"marginRight": "8px"}) if is_owner else None
        
        item_div = html.Div(
            style={
                "backgroundColor": bg_color,
                "border": f"1px solid {border_color}",
                "borderRadius": "8px",
                "padding": "16px 20px",
                "marginBottom": "12px",
                "fontSize": "16px",
                "fontWeight": "500",
                "color": text_color,
                "display": "flex",
                "alignItems": "center",
                "boxShadow": "0 1px 2px rgba(0,0,0,0.05)"
            },
            children=[icon, html.Span(row_text)] if icon else [html.Span(row_text)]
        )
        list_items.append(item_div)
        
    return html.Div([
        html.Div(
            f"Week : From {start_date.strftime('%d/%m/%Y')} to {end_date.strftime('%d/%m/%Y')}",
            style={
                "backgroundColor": "#5A0047",
                "color": "#ffffff",
                "padding": "16px",
                "borderRadius": "8px",
                "textAlign": "center",
                "fontWeight": "700",
                "fontSize": "18px",
                "marginBottom": "24px"
            }
        ),
        html.Div(list_items)
    ])


