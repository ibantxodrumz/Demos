import datetime
from typing import List, Optional
from src.config.constants import SQL_TABLE_ROTA
from src.repositories import connection
from src.models.rota import RotaEntry

def get_rota_for_week(start_date: str, end_date: str) -> List[RotaEntry]:
    """Retrieve rota entries for a specific week based on REVIEW_DATE."""
    query = f"""
        SELECT ROTA_ID, REVIEW_DATE, DATA_DATE, ANALYST_NAME, IS_WEEKLY_IC_OWNER, CREATED_AT, UPDATED_AT
        FROM {SQL_TABLE_ROTA}
        WHERE REVIEW_DATE >= ? AND REVIEW_DATE <= ?
        ORDER BY REVIEW_DATE ASC
    """
    entries = []
    with connection.get_db() as conn:
        cursor = conn.execute(query, (start_date, end_date))
        for row in cursor:
            entries.append(
                RotaEntry(
                    rota_id=row["ROTA_ID"],
                    review_date=str(row["REVIEW_DATE"]),
                    data_date=str(row["DATA_DATE"]),
                    analyst_name=row["ANALYST_NAME"],
                    is_weekly_ic_owner=bool(row["IS_WEEKLY_IC_OWNER"]),
                    created_at=str(row["CREATED_AT"]) if row["CREATED_AT"] else None,
                    updated_at=str(row["UPDATED_AT"]) if row["UPDATED_AT"] else None,
                )
            )
    return entries

def get_rota_for_month(year: int, month: int) -> List[RotaEntry]:
    """Retrieve all rota entries for a given month based on REVIEW_DATE."""
    query = f"""
        SELECT ROTA_ID, REVIEW_DATE, DATA_DATE, ANALYST_NAME, IS_WEEKLY_IC_OWNER, CREATED_AT, UPDATED_AT
        FROM {SQL_TABLE_ROTA}
        WHERE REVIEW_DATE LIKE ?
        ORDER BY REVIEW_DATE ASC
    """
    month_str = f"{year}-{month:02d}-%"
    entries = []
    with connection.get_db() as conn:
        cursor = conn.execute(query, (month_str,))
        for row in cursor:
            entries.append(
                RotaEntry(
                    rota_id=row["ROTA_ID"],
                    review_date=str(row["REVIEW_DATE"]),
                    data_date=str(row["DATA_DATE"]),
                    analyst_name=row["ANALYST_NAME"],
                    is_weekly_ic_owner=bool(row["IS_WEEKLY_IC_OWNER"]),
                    created_at=str(row["CREATED_AT"]) if row["CREATED_AT"] else None,
                    updated_at=str(row["UPDATED_AT"]) if row["UPDATED_AT"] else None,
                )
            )
    return entries

def update_rota_entry(rota_id: int, analyst_name: str, is_weekly_ic_owner: bool) -> None:
    """Update analyst and IC owner status for a given rota entry."""
    now_str = datetime.datetime.now().isoformat()
    query = f"""
        UPDATE {SQL_TABLE_ROTA}
        SET ANALYST_NAME = ?,
            IS_WEEKLY_IC_OWNER = ?,
            UPDATED_AT = ?
        WHERE ROTA_ID = ?
    """
    with connection.get_db() as conn:
        conn.execute(query, (analyst_name, int(is_weekly_ic_owner), now_str, rota_id))
