from pathlib import Path
import pytest
import dash

PAGES_DIR = str(Path(__file__).resolve().parent.parent / "src" / "pages")
app = dash.Dash(__name__, use_pages=True, pages_folder=PAGES_DIR)
from src.pages import landing_page


def test_landing_page_layout_structure():
    """Verify landing page layout renders essential components."""
    layout = landing_page.layout
    assert layout is not None
    assert hasattr(layout, "children")
    assert len(layout.children) >= 3


def test_update_welcome_pill():
    """Verify welcome pill updates dynamically based on analyst selection."""
    # When analyst is selected
    store_val, text, style = landing_page.update_welcome_pill("Analyst 1")
    assert store_val == "Analyst 1"
    assert text == "Analyst 1"
    assert style["backgroundColor"] == "#10b981"  # Green pill

    # When no analyst is selected
    store_none, text_none, style_none = landing_page.update_welcome_pill(None)
    assert store_none is None
    assert text_none == "Select Analyst"
    assert style_none["backgroundColor"] == "#0284c7"  # Default blue pill


def test_initialize_analyst_from_store():
    """Verify landing page dropdown initializes from stored analyst context."""
    val = landing_page.initialize_analyst_from_store("Analyst 2", None)
    assert val == "Analyst 2"

    val_no_update = landing_page.initialize_analyst_from_store("Analyst 2", "Analyst 1")
    assert val_no_update == dash.no_update


def test_navigate_to_import_constraints_guardrail():
    """Verify guardrail blocks navigation if no analyst is selected."""
    # 1. No clicks
    alert, style, path = landing_page.navigate_to_import_constraints(0, None, None)
    assert alert == dash.no_update

    # 2. Clicked without analyst -> displays guardrail warning
    alert, style, path = landing_page.navigate_to_import_constraints(1, None, None)
    assert style["display"] == "block"
    assert path == dash.no_update

    # 3. Clicked with analyst in dropdown -> navigates to /alert-review
    alert_ok, style_ok, path_ok = landing_page.navigate_to_import_constraints(1, "Analyst 1", None)
    assert style_ok["display"] == "none"
    assert path_ok == "/alert-review"

    # 4. Clicked with analyst in store -> navigates to /alert-review
    alert_stored, style_stored, path_stored = landing_page.navigate_to_import_constraints(1, None, "Analyst 3")
    assert style_stored["display"] == "none"
    assert path_stored == "/alert-review"
