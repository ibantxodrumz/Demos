from pathlib import Path
import pytest
from src.config.settings import DEMO_WEEK_1
from src.repositories import alert_repository, ic_analytics_repository
from src.services import ic_analytics_service


def test_sp_evidence_retrieval(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    alert = alerts[0]

    sp_records = ic_analytics_repository.get_sp_evidence_for_alert(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=fresh_db,
    )

    assert len(sp_records) == alert["COUNT_SP"]
    start_gmt_norm = str(alert["START_GMT"]).replace(" ", "T")
    end_gmt_norm = str(alert["END_GMT"]).replace(" ", "T")
    for r in sp_records:
        assert r["BMU_ID"] == alert["BMU_ID"]
        assert r["GMT_FROM"] >= start_gmt_norm
        assert r["GMT_FROM"] < end_gmt_norm


def test_get_why_values_for_alert(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    alert = alerts[0]

    why_values = ic_analytics_repository.get_why_values_for_alert(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=fresh_db,
    )

    assert isinstance(why_values, list)
    for val in why_values:
        assert val is not None
        assert val != ""
        assert val.lower() != "nan"


def test_analytics_payload_service(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    alert = alerts[0]

    payload = ic_analytics_service.get_alert_evidence_payload(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=fresh_db,
    )

    assert "sp_records" in payload
    assert "metrics" in payload
    assert "info_for_analyst" in payload
    assert payload["sp_count"] == alert["COUNT_SP"]


def test_get_database_date_bounds(fresh_db):
    from src.repositories import ic_sp_analytics_repository

    bounds = ic_sp_analytics_repository.get_database_date_bounds(db_path=fresh_db)
    assert "start" in bounds
    assert "end" in bounds
    assert bounds["start"] <= bounds["end"]
