# Phase 2 Development Audit Log

This document tracks all task completions, code edits, database schema updates, and verification results as Phase 2 progresses.

---

## Operational Working Pattern & Validation Loop

1. **Active Development Environment**:
   - Implementation and local testing take place inside [`/Users/ivansanz/Desktop/PoC_1/phase2/`](file:///Users/ivansanz/Desktop/PoC_1/phase2/).
   - Local UI/UX prototyping, visual layout checks, page navigation, and automated tests use local SQLite mode (`DATABASE_MODE=sqlite`).
2. **Visual UI Inspection & Verification**:
   - Before shipping any UI/UX changes, the Dash app is run locally in `sqlite` mode to inspect visuals, layouts, tables, navigation, and callbacks (using browser inspection tools).
   - Once visuals, UX, and logic are confirmed and approved locally, the build is prepared for Azure SQL shipping.
3. **Quality & Test Standards**:
   - **100% test pass rate required** prior to shipping any milestone.
   - Comprehensive test coverage must be added alongside all new features, models, services, and repositories.
4. **Colleague Testing & Live Validation Environment**:
   - Completed application packages are shared with colleagues who perform real validation and testing.
   - Colleague testing is conducted **locally in VS Code on Windows 11 machines** connected directly to the **real Azure SQL database** (`DATABASE_MODE=azure`).
5. **Shipping Exemplar & Baseline Standard**:
   - The frozen release baseline at `releases/release_2_local_azure_sql_working_final` serves as the exact blueprint and standard for how completed Phase 2 builds, scripts, configs, and documentation must be packaged and shipped so testing can be conducted seamlessly.
6. **Continuous Delivery Loop**:
   `Visual & Feature Dev in phase2/ (SQLite Mode) -> Local UI & 100% Test Pass -> Human Sign-off -> Package & Ship for Windows 11 / Azure SQL Validation -> Feedback`.

---

## Task Audit Log

### Step 0 — Phase 2 Directory Scaffolding & Documentation Setup
- **Date**: 2026-09-18
- **Action**: Created dedicated `/Users/ivansanz/Desktop/PoC_1/phase2/` working directory.
- **Seeded Content**:
  - Copied source code baseline from `releases/release_2_local_azure_sql_working_final/src/` to `phase2/src/`.
  - Copied test suite from `releases/release_2_local_azure_sql_working_final/tests/` to `phase2/tests/`.
  - Copied discovery documentation to `phase2/docs/`.
  - Created master implementation plan at [`phase2/docs/PHASE2_MASTER_PLAN.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/docs/PHASE2_MASTER_PLAN.md).
  - Created Phase 2 README at [`phase2/README.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/README.md).
- **Status**: **COMPLETE**

---

#### MM_ACTIVITY_LOG table in azure --- you don't have access to it but the app is meant to work on this

The Phase 2 `MM_ACTIVITY_LOG` table has been created successfully in Azure SQL.

The table is independent from the Phase 1 `ACTIVITY_LOG` table and will be used exclusively for Phase 2 review persistence.

The table was validated using:

```sql
SELECT
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'MM_ACTIVITY_LOG'
ORDER BY ORDINAL_POSITION;
```

The query returned:

| Column | Data type |
|---|---|
| `ACTIVITY_LOG_ID` | `uniqueidentifier` |
| `WORKSTREAM_NAME` | `varchar` |
| `ALERT_UNIQUE_ID` | `varchar` |
| `BMU_ID` | `varchar` |
| `PARTY_NAME` | `varchar` |
| `PARAMETER_BREACHED` | `varchar` |
| `RAISE_DATE` | `date` |
| `START_DATE` | `date` |
| `END_DATE` | `date` |
| `PERSON_RAISING` | `varchar` |
| `NOTIFICATION_SOURCE` | `varchar` |
| `ACTION_TAKEN` | `varchar` |
| `ANALYSIS_STATUS` | `varchar` |
| `INFO_FOR_ANALYST` | `nvarchar` |
| `REVIEW_COMMENTS` | `nvarchar` |
| `CREATED_DATETIME` | `datetime2` |
| `UPDATED_DATETIME` | `datetime2` |

Validation confirms:

- `ACTIVITY_LOG_ID` uses the Azure SQL `UNIQUEIDENTIFIER` datatype.
- `WORKSTREAM_NAME` is present.
- Date fields use the Azure SQL `DATE` datatype.
- Created and updated timestamps use `DATETIME2`.
- Analyst information and review comments use `NVARCHAR`.
- The table contains the expected Phase 2 review fields.
- `MM_ACTIVITY_LOG` is ready for Phase 2 repository integration.

Phase separation:

```text
Phase 1
ACTIVITY_LOG
```

```text
Phase 2
MM_ACTIVITY_LOG
```

No Phase 1 review records were copied or backfilled.

All phase 2 code should repoint the Phase 2 activity-log repository, services, queries and tests from `ACTIVITY_LOG` to `MM_ACTIVITY_LOG`.

All applicable Phase 2 reads, inserts, updates and joins must include `WORKSTREAM_NAME`.

---

### Step 1 — Task 2: Dynamic Date Option Generator Refactoring
- **Date**: 2026-09-23
- **Action**: Created [`phase2/src/utils/date_utils.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/utils/date_utils.py) and refactored `get_available_time_options()` in [`phase2/src/services/alert_service.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/services/alert_service.py).
- **Details**:
  - Dynamically generates Month and ISO Week options from historical lower bound (`2022-08-01`) up to current date + forward margin.
  - Retained exact schema contract (`months`, `weeks`, `min_date`, `max_date`) required by Dash callback dropdown components.
- **Verification**: Verified dynamic dropdown generation.

---

### Step 2 — Task 3 & Task 4: MM_ACTIVITY_LOG Repointing & Persistence Integration
- **Date**: 2026-09-23
- **Action**: Repointed Phase 2 activity log persistence layer to `dbo.MM_ACTIVITY_LOG` and added `WORKSTREAM_NAME` partitioning.
- **Modified Components**:
  - [`phase2/src/config/constants.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/config/constants.py): Set `SQL_TABLE_ACTIVITY_LOG = "MM_ACTIVITY_LOG"` and `DEFAULT_WORKSTREAM_NAME = "IMPORT_CONSTRAINTS"`.
  - [`phase2/src/config/create_mm_activity_log.sql`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/config/create_mm_activity_log.sql): Created DDL definition matching live Azure SQL schema.
  - [`phase2/src/models/activity_log.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/models/activity_log.py) & [`phase2/src/models/alert.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/models/alert.py): Added `WORKSTREAM_NAME` fields.
  - [`phase2/src/repositories/activity_log_repository.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/repositories/activity_log_repository.py): Updated DDL (SQLite & Azure SQL), `SELECT`, `INSERT`, `UPDATE`, and `get_closed_reviews` queries to include `WORKSTREAM_NAME = :workstream_name` and composite uniqueness `UNIQUE(WORKSTREAM_NAME, ALERT_UNIQUE_ID)`.
  - [`phase2/src/repositories/alert_repository.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/repositories/alert_repository.py): Updated `LEFT JOIN MM_ACTIVITY_LOG al ON a.UNIQUE_ID = al.ALERT_UNIQUE_ID AND al.WORKSTREAM_NAME = :workstream_name`.
  - [`phase2/src/services/activity_log_service.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/services/activity_log_service.py): Passed `workstream_name` parameter down to repository.
  - [`phase2/tests/conftest.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/tests/conftest.py) & [`phase2/tests/test_database.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/tests/test_database.py): Updated test SQLite schema to `MM_ACTIVITY_LOG`.
  - [`phase2/tests/test_activity_log_repository.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/tests/test_activity_log_repository.py): Added `test_workstream_name_isolation_and_persistence`.
- **Status**: **COMPLETE** (51/51 tests passing cleanly in 1.88s).

---

### Step 3 — Phase 2 Release 2 Packaging (Dynamic Date Coherency Fix)
- **Date**: 2026-09-23
- **Action**: Resolved date picker bounds incoherency across `alert_review.py` and `import_constraints.py`; packaged `releases/phase2_release_2_dynamic_date_coherency`.
- **Modified Components**:
  - [`phase2/src/pages/import_constraints.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/pages/import_constraints.py): Dynamically bound `ic-picker-specific-day`, `ic-picker-start-date`, and `ic-picker-end-date` min/max date bounds to `TIME_OPTIONS["min_date"]` (`2022-08-01`) and `TIME_OPTIONS["max_date"]` (October buffer).
  - [`phase2/src/pages/alert_review.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/pages/alert_review.py): Dynamically bound `picker-start-date` and `picker-end-date` min/max bounds; added `picker-specific-day` control and callback handling for single-day selection parity.
  - [`phase2/src/pages/closed_reviews.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/pages/closed_reviews.py) & [`phase2/src/pages/long_run_analytics.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/pages/long_run_analytics.py): Dynamically bound full-period reset buttons to `time_opts["min_date"]` and `time_opts["max_date"]`.
  - [`phase2/src/repositories/sp_analytics_repository.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/repositories/sp_analytics_repository.py): Updated `get_database_date_bounds()` fallback to use `generate_available_time_options()`.
- **Release Directory**: [`releases/phase2_release_2_dynamic_date_coherency/`](file:///Users/ivansanz/Desktop/PoC_1/releases/phase2_release_2_dynamic_date_coherency/)
- **Documentation**: [`releases/phase2_release_2_dynamic_date_coherency/README.md`](file:///Users/ivansanz/Desktop/PoC_1/releases/phase2_release_2_dynamic_date_coherency/README.md)
- **Status**: **PASSED & SIGNED OFF** (Acceptance testing successful on Windows 11 with live Azure SQL: all functionality, dates back to August 2022, single-day pickers, and persistence to `dbo.MM_ACTIVITY_LOG` verified working as intended).

---

### Step 4 — Task P2: Platform vs Workstream Folder-by-Folder Architectural Review
- **Date**: 2026-09-25
- **Action**: Completed comprehensive folder-by-folder architectural review and codebase inventory for `phase2/src/`.
- **Key Outcomes & Alignment**:
  - Confirmed universal analyst workflow (Alert Review, Open/Closed queues, status derivation) is identical across all workstreams.
  - Confirmed main workstream workspace landing page parity (modeled by Import Constraints).
  - Explicitly classified `src/services/` (`analytics_service.py` & `sp_analytics_service.py`) and `src/pages/` (`import_constraints.py`) to be renamed with explicit `ic_` prefixes.
  - Documented `Dashboards` portal (`/analytical-support`) workstream selection structure.
  - Documented `Long-Run Statistics` (`/long-run-analytics`) as a Platform-Shared Feature Structure present for all workstreams.
- **Execution**:
  - Renamed `analytics_repository.py` $\rightarrow$ `ic_analytics_repository.py`
  - Renamed `sp_analytics_repository.py` $\rightarrow$ `ic_sp_analytics_repository.py`
  - Renamed `analytics_service.py` $\rightarrow$ `ic_analytics_service.py`
  - Renamed `sp_analytics_service.py` $\rightarrow$ `ic_sp_analytics_service.py`
  - Renamed `import_constraints.py` $\rightarrow$ `ic_import_constraints.py`
  - Renamed `analytical_support.py` $\rightarrow$ `ic_analytical_support.py`
  - Updated all internal module imports in `src/` and `tests/`.
- **Verification**: Executed pytest test suite — **51/51 tests passing cleanly (100% pass rate in 2.24s)**.
- **Documentation**: [`phase2/docs/P2_PLATFORM_VS_WORKSTREAM_REVIEW.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/docs/P2_PLATFORM_VS_WORKSTREAM_REVIEW.md)
- **Status**: **COMPLETE & VERIFIED**

---

### Step 5 — Task P3 & Task P4: Platform Landing Page & Temporary Analyst Session Context
- **Date**: 2026-09-25
- **Action**: Designed and implemented the root Platform Landing Page ([`src/pages/landing_page.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/src/pages/landing_page.py)) matching the layout and structure specified in [`landing_page.png`](file:///Users/ivansanz/Desktop/PoC_1/phase2/landing_page.png).
- **Key Features & Guardrails**:
  - **Header & Title**: Displays NESO Logo, central title box **"Market Monitoring Platform"**, and Analyst Selection Dropdown.
  - **Dynamic Welcome Banner**: Displays `"Welcome : [Analyst Name]"` in a vibrant status pill when an analyst is selected.
  - **Guardrail Enforced**: Clicking operational workstreams (e.g. *Import Constraints*) without selecting an analyst blocks navigation and renders an inline warning alert. Once an analyst is selected, navigation to `/import-constraints` is unlocked.
  - **Workstream & Rota Containers**: Renders operational *Import Constraints* button alongside disabled *Planned* workstream cards (UMM, TCLC, IOLC, IC) and Rota/Admin placeholders.
- **Verification & Visual Audit**:
  - Executed automated browser subagent to interactively inspect UI, test dropdowns, verify guardrails, and capture visual evidence screenshots.
  - Added unit test suite in [`tests/test_landing_page.py`](file:///Users/ivansanz/Desktop/PoC_1/phase2/tests/test_landing_page.py).
  - Executed full test suite: **54/54 tests passing 100% cleanly (2.38s)**.
- **Status**: **COMPLETE & VERIFIED**



