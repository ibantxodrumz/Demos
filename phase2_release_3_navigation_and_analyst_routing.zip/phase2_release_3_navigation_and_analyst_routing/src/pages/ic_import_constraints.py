import dash
from dash import dash_table, dcc, html, Input, Output, callback, State
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from datetime import datetime
from src.config.settings import DEMO_WEEK_1, DEMO_WEEK_2
from src.services import alert_service, ic_sp_analytics_service
from src.utils.formatting import format_currency, format_number

dash.register_page(
    __name__,
    path="/import-constraints-workspace",
    title="Import Constraints Workspace - Market Monitoring Platform",
)

TIME_OPTIONS = alert_service.get_available_time_options()
DB_BOUNDS = ic_sp_analytics_service.get_database_date_bounds()
DEFAULT_START_DATE = DEMO_WEEK_1["start"]
DEFAULT_END_DATE = DEMO_WEEK_1["end"]

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Inter, Segoe UI, sans-serif"},
    children=[
        # Top Header
        html.Div(
            style={
                "marginBottom": "20px",
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
            },
            children=[
                html.Div(
                    children=[
                        html.H2(
                            "Import Constraints Intelligence Workspace",
                            className="neso-page-title",
                        ),
                        html.P(
                            "System overview, ensemble diagnostics, temporal window inference, and BMU deep dives.",
                            className="neso-page-subtitle",
                        ),
                    ]
                ),
                html.A(
                    "← Back to Workstreams",
                    href="/analytical-support",
                    className="btn-neso-primary",
                    style={"textDecoration": "none", "fontSize": "13px"},
                ),
            ],
        ),
        # Workspace Tabs Container
        dcc.Tabs(
            id="ic-workspace-tabs",
            value="tab-0",
            children=[
                dcc.Tab(label="Info & Context", value="tab-0"),
                dcc.Tab(label="System Overview", value="tab-1"),
                dcc.Tab(label="Ensemble SP Intelligence", value="tab-2"),
                dcc.Tab(label="Ensemble Windows", value="tab-3"),
                dcc.Tab(label="BMU Deep Dive", value="tab-4"),
                dcc.Tab(label="Spread Analysis", value="tab-5"),
                dcc.Tab(label="Counterparty Intelligence", value="tab-6"),
            ],
            style={"marginBottom": "20px"},
        ),
        # Date Selection Area (Matching Alert Review Design - Hidden for Info & Context, Visible for Tabs 1-6)
        html.Div(
            id="ic-date-selection-card",
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "20px",
                "display": "none",
            },
            children=[
                # Period Controls Grid: Select Specific Day, Start Date, End Date, Select Whole Week, Select Whole Month, Full Period Button
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(160px, 1fr))",
                        "gap": "14px",
                        "alignItems": "flex-end",
                        "marginBottom": "16px",
                    },
                    children=[
                        # 1. Select Specific Day (First visible control)
                        html.Div(
                            children=[
                                html.Label(
                                    "Select Specific Day:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#4e0038",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="ic-picker-specific-day",
                                    placeholder="Select Day...",
                                    display_format="YYYY-MM-DD",
                                    min_date_allowed=TIME_OPTIONS["min_date"],
                                    max_date_allowed=TIME_OPTIONS["max_date"],
                                    style={"width": "100%", "fontSize": "13px"},
                                ),
                            ],
                        ),
                        # 2. Start Date Input
                        html.Div(
                            children=[
                                html.Label(
                                    "Start Date:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#4e0038",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="ic-picker-start-date",
                                    date=DEFAULT_START_DATE,
                                    display_format="YYYY-MM-DD",
                                    min_date_allowed=TIME_OPTIONS["min_date"],
                                    max_date_allowed=TIME_OPTIONS["max_date"],
                                    style={"width": "100%", "fontSize": "13px"},
                                ),
                            ],
                        ),
                        # 3. End Date Input
                        html.Div(
                            children=[
                                html.Label(
                                    "End Date:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#4e0038",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="ic-picker-end-date",
                                    date=DEFAULT_END_DATE,
                                    display_format="YYYY-MM-DD",
                                    min_date_allowed=TIME_OPTIONS["min_date"],
                                    max_date_allowed=TIME_OPTIONS["max_date"],
                                    style={"width": "100%", "fontSize": "13px"},
                                ),
                            ],
                        ),
                        # 4. Select Whole Week Preset Dropdown
                        html.Div(
                            children=[
                                html.Label(
                                    "Select Whole Week:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#64748b",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-dropdown-select-week",
                                    options=[{"label": "Select a Week Preset...", "value": "none"}]
                                    + [
                                        {"label": w["label"], "value": w["value"]}
                                        for w in TIME_OPTIONS["weeks"]
                                    ],
                                    value="none",
                                    clearable=False,
                                ),
                            ],
                        ),
                        # 5. Select Whole Month Preset Dropdown
                        html.Div(
                            children=[
                                html.Label(
                                    "Select Whole Month:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#64748b",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-dropdown-select-month",
                                    options=[{"label": "Select a Month Preset...", "value": "none"}]
                                    + [
                                        {"label": m["label"], "value": m["value"]}
                                        for m in TIME_OPTIONS["months"]
                                    ],
                                    value="none",
                                    clearable=False,
                                ),
                            ],
                        ),
                        # 6. Full Period Preset Button (No label above)
                        html.Div(
                            children=[
                                html.Button(
                                    "Full Period (All Alerts)",
                                    id="btn-ic-full-period",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": "#4e0038",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "borderRadius": "6px",
                                        "padding": "9px 12px",
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "cursor": "pointer",
                                        "width": "100%",
                                        "height": "38px",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
                # Prominent Active Window Summary Banner
                html.Div(id="ic-active-window-badge"),
            ],
        ),
        # Tab Content Area
        html.Div(id="ic-tab-content-area"),
    ],
)


# Callback to Toggle Date Selection Card Visibility (Hidden for Info & Context [tab-0], Visible for Tabs 1-6)
@callback(
    Output("ic-date-selection-card", "style"),
    Input("ic-workspace-tabs", "value"),
)
def toggle_ic_date_selection_visibility(tab_value):
    style = {
        "backgroundColor": "#ffffff",
        "padding": "20px",
        "borderRadius": "8px",
        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
        "marginBottom": "20px",
    }
    if tab_value == "tab-0":
        style["display"] = "none"
    else:
        style["display"] = "block"
    return style


# Callback to Sync Date Controls and Render Active Window Banner
@callback(
    Output("ic-picker-start-date", "date"),
    Output("ic-picker-end-date", "date"),
    Output("ic-active-window-badge", "children"),
    Input("ic-picker-specific-day", "date"),
    Input("ic-picker-start-date", "date"),
    Input("ic-picker-end-date", "date"),
    Input("ic-dropdown-select-week", "value"),
    Input("ic-dropdown-select-month", "value"),
    Input("btn-ic-full-period", "n_clicks"),
)
def sync_ic_date_controls(single_day, start_date, end_date, week_preset, month_preset, full_clicks):
    try:
        ctx = dash.callback_context
        triggered_id = ctx.triggered[0]["prop_id"].split(".")[0] if (ctx and ctx.triggered) else None
    except Exception:
        triggered_id = None

    # Handle Specific Day Selection
    if triggered_id == "ic-picker-specific-day" and single_day:
        start_date, end_date = str(single_day)[:10], str(single_day)[:10]

    # Handle Full Period Button
    elif triggered_id == "btn-ic-full-period":
        start_date, end_date = DEFAULT_START_DATE, DEFAULT_END_DATE

    # Handle Week Preset
    elif triggered_id == "ic-dropdown-select-week" and week_preset and week_preset != "none":
        delim = "|" if "|" in str(week_preset) else ":" if ":" in str(week_preset) else None
        if delim:
            parts = str(week_preset).split(delim)
            if len(parts) >= 2:
                start_date, end_date = parts[0], parts[1]

    # Handle Month Preset
    elif triggered_id == "ic-dropdown-select-month" and month_preset and month_preset != "none":
        delim = "|" if "|" in str(month_preset) else ":" if ":" in str(month_preset) else None
        if delim:
            parts = str(month_preset).split(delim)
            if len(parts) >= 2:
                start_date, end_date = parts[0], parts[1]

    # Ensure fallbacks if dates are empty

    start_date = start_date or DEFAULT_START_DATE
    end_date = end_date or DEFAULT_END_DATE

    # Calculate Days Count
    try:
        d1 = datetime.strptime(start_date, "%Y-%m-%d")
        d2 = datetime.strptime(end_date, "%Y-%m-%d")
        days_count = max((d2 - d1).days + 1, 1)
    except Exception:
        days_count = 1

    active_badge = html.Div(
        style={
            "backgroundColor": "#fdf4fa",
            "border": "1px solid #4e0038",
            "borderRadius": "6px",
            "padding": "10px 16px",
            "display": "flex",
            "alignItems": "center",
            "gap": "16px",
            "flexWrap": "wrap",
        },
        children=[
            html.Span(
                "Active Review Window:",
                style={"fontWeight": "700", "color": "#4e0038", "fontSize": "13px"},
            ),
            html.Div(
                style={"display": "flex", "alignItems": "center", "gap": "10px"},
                children=[
                    html.Span(
                        f"Start Date: {start_date}",
                        style={
                            "backgroundColor": "#ffffff",
                            "border": "1px solid #cbd5e1",
                            "padding": "4px 10px",
                            "borderRadius": "4px",
                            "fontWeight": "600",
                            "fontSize": "12px",
                            "color": "#1e293b",
                        },
                    ),
                    html.Span("──────►", style={"color": "#94a3b8", "fontSize": "12px"}),
                    html.Span(
                        f"End Date: {end_date}",
                        style={
                            "backgroundColor": "#ffffff",
                            "border": "1px solid #cbd5e1",
                            "padding": "4px 10px",
                            "borderRadius": "4px",
                            "fontWeight": "600",
                            "fontSize": "12px",
                            "color": "#1e293b",
                        },
                    ),
                ],
            ),
            html.Span(
                f"({days_count} Days selected)",
                style={"color": "#64748b", "fontSize": "12px", "fontWeight": "500"},
            ),
        ],
    )

    return start_date, end_date, active_badge


# Main Callback for Tab Content
@callback(
    Output("ic-tab-content-area", "children"),
    Input("ic-workspace-tabs", "value"),
    Input("ic-picker-start-date", "date"),
    Input("ic-picker-end-date", "date"),
)
def render_ic_tab_content(tab_value, start_date, end_date):

    # ---------------- TAB 0: Info & Context ----------------
    if tab_value == "tab-0":
        # Generate ISO week calendar reference table
        dts = pd.date_range(start=TIME_OPTIONS["min_date"], end=TIME_OPTIONS["max_date"], freq="D")
        week_start = dts - pd.to_timedelta(dts.weekday, unit="D")
        week_end = week_start + pd.Timedelta(days=6)
        iso_weeks_df = (
            pd.DataFrame(
                {
                    "ISO Week": dts.strftime("%G-W%V"),
                    "Starts On (Monday)": week_start.strftime("%b %d, %Y"),
                    "Ends On (Sunday)": week_end.strftime("%b %d, %Y"),
                }
            )
            .drop_duplicates("ISO Week")
            .sort_values("ISO Week")
            .reset_index(drop=True)
        )

        iso_table = dash_table.DataTable(
            columns=[{"name": i, "id": i} for i in iso_weeks_df.columns],
            data=iso_weeks_df.to_dict("records"),
            page_size=10,
            style_header={"backgroundColor": "#4e0038", "color": "#fff", "fontWeight": "600"},
            style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
        )

        return html.Div(
            style={"backgroundColor": "#ffffff", "padding": "24px", "borderRadius": "8px"},
            children=[
                html.H3(
                    "Import Constraints Monitoring — Context & Definitions",
                    style={"color": "#4e0038"},
                ),
                html.P(
                    "This workspace supports Market Monitoring analysts in understanding and investigating "
                    "the pricing behaviour of Balancing Mechanism Units (BMUs) behind import constraints."
                ),
                html.Hr(),
                html.H4("Key Behavioural Definitions"),
                html.Ul(
                    children=[
                        html.Li(
                            [
                                html.Strong("Constrained – normal behaviour (Baseline): "),
                                "Pricing is similar to typical unconstrained behaviour. No detection conditions fired.",
                            ]
                        ),
                        html.Li(
                            [
                                html.Strong("Constrained – elevated signal (Directional Change): "),
                                "Exactly one detection condition fired (C1, C2, or C3). Partial departure from baseline.",
                            ]
                        ),
                        html.Li(
                            [
                                html.Strong("Constrained – ensemble (Corroborated Signal): "),
                                "Two or more detection conditions fired. Satisfies ensemble rule for deep investigation.",
                            ]
                        ),
                    ]
                ),
                html.Hr(),
                html.H4("Detection Conditions"),
                html.Ul(
                    children=[
                        html.Li(
                            [
                                html.Strong("C1 (Self-comparison): "),
                                "BMU pricing significantly higher than its own historical typical behaviour.",
                            ]
                        ),
                        html.Li(
                            [
                                html.Strong("C2 (Market/Fuel Context): "),
                                "Price extreme relative to market conditions & fuel threshold.",
                            ]
                        ),
                        html.Li(
                            [
                                html.Strong("C3 (Constrained vs Unconstrained): "),
                                "BMU pricing materially higher when constrained than when unconstrained.",
                            ]
                        ),
                    ]
                ),
                html.Hr(),
                html.Details(
                    children=[
                        html.Summary(
                            "Calendar Reference: ISO Week Mapping",
                            style={
                                "fontWeight": "600",
                                "cursor": "pointer",
                                "fontSize": "14px",
                                "color": "#4e0038",
                            },
                        ),
                        html.Div(iso_table, style={"marginTop": "12px"}),
                    ]
                ),
            ],
        )

    # ---------------- TABS 1-6: Data Loading ----------------
    if not start_date or not end_date:
        return html.Div("Please enter valid start and end dates.", style={"color": "#64748b"})

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]
    alerts_df = data["alerts_df"]
    windows_df = data["windows_df"]

    if sp_df.empty:
        return html.Div(
            f"No settlement period data found for date range {start_date} to {end_date}.",
            style={"color": "#94a3b8", "fontStyle": "italic", "padding": "20px"},
        )

    # ---------------- TAB 1: System Overview ----------------
    if tab_value == "tab-1":
        total_sps = len(sp_df)
        normal_c = (sp_df["BEHAVIOUR_CLASS"] == "Constrained - normal behaviour").sum()
        elevated_c = (sp_df["BEHAVIOUR_CLASS"] == "Constrained - elevated signal").sum()
        ensemble_c = (sp_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble").sum()

        # 1. Top-Level Metrics
        metrics_cards = html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(200px, 1fr))",
                "gap": "16px",
                "marginBottom": "20px",
            },
            children=[
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #64748b",
                    },
                    children=[
                        html.Div(
                            "Total Constrained SPs", style={"fontSize": "12px", "color": "#64748b"}
                        ),
                        html.H3(f"{total_sps:,}", style={"margin": "4px 0 0 0"}),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #16a34a",
                    },
                    children=[
                        html.Div(
                            "Normal Behaviour",
                            style={"fontSize": "12px", "color": "#64748b"},
                        ),
                        html.H3(
                            (
                                f"{normal_c:,} ({(normal_c/total_sps):.1%})"
                                if total_sps > 0
                                else "0 (0%)"
                            ),
                            style={"margin": "4px 0 0 0"},
                        ),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #d97706",
                    },
                    children=[
                        html.Div(
                            "Elevated Signal (1 condition fired)",
                            style={"fontSize": "12px", "color": "#64748b"},
                        ),
                        html.H3(
                            (
                                f"{elevated_c:,} ({(elevated_c/total_sps):.1%})"
                                if total_sps > 0
                                else "0 (0%)"
                            ),
                            style={"margin": "4px 0 0 0"},
                        ),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#fee2e2",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #dc2626",
                    },
                    children=[
                        html.Div(
                            "Ensemble Behaviour (2 conditions fire -> flagged)",
                            style={"fontSize": "12px", "color": "#991b1b"},
                        ),
                        html.H3(
                            (
                                f"{ensemble_c:,} ({(ensemble_c/total_sps):.1%})"
                                if total_sps > 0
                                else "0 (0%)"
                            ),
                            style={"margin": "4px 0 0 0", "color": "#991b1b"},
                        ),
                    ],
                ),
            ],
        )

        # 2. Materiality Extension: Extreme Pricing
        high_price_mask = (sp_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble") & (
            sp_df["OFFER_PRICE"] > 200
        )
        high_price_count = high_price_mask.sum()
        max_extreme = sp_df[high_price_mask]["OFFER_PRICE"].max() if high_price_count > 0 else 0
        avg_extreme = sp_df[high_price_mask]["OFFER_PRICE"].mean() if high_price_count > 0 else 0

        ex_bmus = (
            sorted(sp_df[high_price_mask]["BMU_ID"].dropna().unique().tolist())
            if high_price_count > 0
            else []
        )

        extreme_pricing_section = html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "24px",
            },
            children=[
                html.H3(
                    "Materiality Extension: Extreme Pricing",
                    style={"margin": "0 0 16px 0", "color": "#1e293b"},
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(3, 1fr)",
                        "gap": "16px",
                        "marginBottom": "20px",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.Div(
                                    "Ensemble SPs > £200",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(f"{high_price_count:,}", style={"margin": "2px 0"}),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "Max Extreme Price (£)",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(
                                    f"£{max_extreme:,.2f}" if max_extreme > 0 else "N/A",
                                    style={"margin": "2px 0"},
                                ),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "Avg Extreme Price (£)",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(
                                    f"£{avg_extreme:,.2f}" if avg_extreme > 0 else "N/A",
                                    style={"margin": "2px 0"},
                                ),
                            ]
                        ),
                    ],
                ),
                html.H4(
                    "Extreme Pricing Events by BMU",
                    style={"margin": "16px 0 8px 0", "fontSize": "14px", "color": "#1e293b"},
                ),
                html.P(
                    "Select a BMU to view its extreme pricing events:",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "0 0 10px 0"},
                ),
                dcc.Dropdown(
                    id="ic-t1-ex-bmu-select",
                    options=[{"label": b, "value": b} for b in ex_bmus],
                    value=ex_bmus[0] if ex_bmus else None,
                    placeholder="No BMUs with extreme pricing events",
                    style={"marginBottom": "16px"},
                ),
                html.Div(id="ic-t1-ex-bmu-table-container"),
            ],
        )

        # 3. Component Profiles
        ens_df = sp_df[sp_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"].copy()
        if not ens_df.empty and "WHY" in ens_df.columns:
            combos = ens_df["WHY"].apply(
                lambda x: str(x).split("|")[0].strip() if pd.notna(x) else ""
            )
            combo_counts = combos.value_counts()
        else:
            combo_counts = pd.Series(dtype=int)

        c1_c3_cnt = int(combo_counts.get("C1,C3") or combo_counts.get("C3,C1") or 0)
        c2_c3_cnt = int(combo_counts.get("C2,C3") or combo_counts.get("C3,C2") or 0)
        c1_c2_cnt = int(combo_counts.get("C1,C2") or combo_counts.get("C2,C1") or 0)

        # Overlap View Bar Chart
        if not combo_counts.empty:
            df_combo = combo_counts.reset_index()
            df_combo.columns = ["Combination", "Count"]
            fig_overlap = px.bar(
                df_combo,
                x="Combination",
                y="Count",
                title="Overlap View: Why are they flagged?",
                text_auto=True,
                color="Combination",
                template="plotly_white",
                color_discrete_map={
                    "C1,C2,C3": "#6366f1",
                    "C1,C2": "#ef4444",
                    "C2,C3": "#10b981",
                    "C1,C3": "#a855f7",
                },
            )
            fig_overlap.update_traces(textposition="outside", cliponaxis=False)
            fig_overlap.update_layout(margin=dict(t=60))
        else:
            fig_overlap = go.Figure()

        # Distributions for Flagged Combinations (Fuel & Time)
        if not ens_df.empty and "WHY" in ens_df.columns:
            ens_df["FLAGGED_COMB"] = ens_df["WHY"].apply(
                lambda x: str(x).split("|")[0].strip() if pd.notna(x) else "Unknown"
            )

            fuel_dist_comb = (
                ens_df.groupby(["FUEL_TYPE", "FLAGGED_COMB"]).size().reset_index(name="Count")
            )
            fig_fuel_comb = px.bar(
                fuel_dist_comb,
                x="FUEL_TYPE",
                y="Count",
                color="FLAGGED_COMB",
                title="Ensemble Combinations by Fuel Type",
                barmode="group",
                text_auto=True,
                template="plotly_white",
            )
            fig_fuel_comb.update_traces(textposition="outside", cliponaxis=False)

            time_dist_comb = (
                ens_df.groupby([pd.Grouper(key="LOCAL_DATETIME", freq="W"), "FLAGGED_COMB"])
                .size()
                .reset_index(name="Count")
            )
            fig_time_comb = px.area(
                time_dist_comb,
                x="LOCAL_DATETIME",
                y="Count",
                color="FLAGGED_COMB",
                title="Ensemble Combinations over Time",
                template="plotly_white",
            )
        else:
            fig_fuel_comb = go.Figure()
            fig_time_comb = go.Figure()

        # Condition Diagnostics (Individual Counts)
        c1_fired = int(sp_df["COND_1"].sum()) if "COND_1" in sp_df.columns else 0
        c2_fired = int(sp_df["COND_2"].sum()) if "COND_2" in sp_df.columns else 0
        c3_fired = int(sp_df["COND_3"].sum()) if "COND_3" in sp_df.columns else 0

        # Distributions by Behaviour Class
        fuel_dist = sp_df.groupby(["FUEL_TYPE", "BEHAVIOUR_CLASS"]).size().reset_index(name="Count")
        fig_fuel = px.bar(
            fuel_dist,
            x="FUEL_TYPE",
            y="Count",
            color="BEHAVIOUR_CLASS",
            title="Distribution by Fuel Type",
            barmode="group",
            text_auto=True,
            color_discrete_map={
                "Constrained - normal behaviour": "#94a3b8",
                "Constrained - elevated signal": "#f59e0b",
                "Constrained - ensemble": "#ef4444",
            },
            template="plotly_white",
        )
        fig_fuel.update_traces(textposition="outside", cliponaxis=False)

        time_dist = (
            sp_df.groupby([pd.Grouper(key="LOCAL_DATETIME", freq="W"), "BEHAVIOUR_CLASS"])
            .size()
            .reset_index(name="Count")
        )
        fig_time = px.area(
            time_dist,
            x="LOCAL_DATETIME",
            y="Count",
            color="BEHAVIOUR_CLASS",
            title="Distribution over Time",
            color_discrete_map={
                "Constrained - normal behaviour": "#94a3b8",
                "Constrained - elevated signal": "#f59e0b",
                "Constrained - ensemble": "#ef4444",
            },
            template="plotly_white",
        )

        # Constraint Group Concentration (if column present)
        if "CONSTRAINT_GROUP" in sp_df.columns and sp_df["CONSTRAINT_GROUP"].notna().any():
            cg_dist = (
                sp_df.groupby(["CONSTRAINT_GROUP", "BEHAVIOUR_CLASS"])
                .size()
                .reset_index(name="Count")
            )
            fig_cg = px.bar(
                cg_dist,
                x="CONSTRAINT_GROUP",
                y="Count",
                color="BEHAVIOUR_CLASS",
                title="System Concentration by Constraint Group",
                barmode="group",
                text_auto=True,
                color_discrete_map={
                    "Constrained - normal behaviour": "#94a3b8",
                    "Constrained - elevated signal": "#f59e0b",
                    "Constrained - ensemble": "#ef4444",
                },
                template="plotly_white",
            )
            fig_cg.update_traces(textposition="outside", cliponaxis=False)
            cg_container = html.Div(
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "20px",
                    "borderRadius": "8px",
                    "marginBottom": "24px",
                },
                children=[
                    html.H4(
                        "Concentration by Constraint Group:",
                        style={"margin": "0 0 12px 0", "color": "#1e293b"},
                    ),
                    dcc.Graph(figure=fig_cg, responsive=True),
                ],
            )
        else:
            cg_container = html.Div()

        # Component Profiles Container
        component_profiles_section = html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "marginBottom": "24px",
            },
            children=[
                html.H3("Component Profiles", style={"margin": "0 0 16px 0", "color": "#1e293b"}),
                html.H4(
                    "Condition Diagnostics (Flagged Combinations):",
                    style={"margin": "0 0 12px 0", "fontSize": "14px", "color": "#475569"},
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(3, 1fr)",
                        "gap": "16px",
                        "marginBottom": "20px",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.Div(
                                    "C3 + C1 Fired", style={"fontSize": "12px", "color": "#64748b"}
                                ),
                                html.H3(f"{c1_c3_cnt}", style={"margin": "2px 0"}),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "C3 + C2 Fired", style={"fontSize": "12px", "color": "#64748b"}
                                ),
                                html.H3(f"{c2_c3_cnt}", style={"margin": "2px 0"}),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "C1 + C2 Fired", style={"fontSize": "12px", "color": "#64748b"}
                                ),
                                html.H3(f"{c1_c2_cnt}", style={"margin": "2px 0"}),
                            ]
                        ),
                    ],
                ),
                html.Div(
                    dcc.Graph(figure=fig_overlap, responsive=True), style={"marginBottom": "24px"}
                ),
                html.H4(
                    "Distributions for Flagged Combinations:",
                    style={"margin": "0 0 12px 0", "fontSize": "14px", "color": "#475569"},
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(400px, 1fr))",
                        "gap": "20px",
                        "marginBottom": "28px",
                    },
                    children=[
                        html.Div(dcc.Graph(figure=fig_fuel_comb, responsive=True)),
                        html.Div(dcc.Graph(figure=fig_time_comb, responsive=True)),
                    ],
                ),
                html.Hr(style={"margin": "24px 0", "borderTop": "1px solid #e2e8f0"}),
                html.H4(
                    "Condition Diagnostics (Individual Counts):",
                    style={"margin": "0 0 12px 0", "fontSize": "14px", "color": "#475569"},
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(3, 1fr)",
                        "gap": "16px",
                        "marginBottom": "20px",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.Div(
                                    "C1 Fired (Historical Behavior)",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(f"{c1_fired:,}", style={"margin": "2px 0"}),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "C2 Fired (Fuel Threshold)",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(f"{c2_fired:,}", style={"margin": "2px 0"}),
                            ]
                        ),
                        html.Div(
                            children=[
                                html.Div(
                                    "C3 Fired (Constrained vs Uncon)",
                                    style={"fontSize": "12px", "color": "#64748b"},
                                ),
                                html.H3(f"{c3_fired:,}", style={"margin": "2px 0"}),
                            ]
                        ),
                    ],
                ),
                html.H4(
                    "Distributions by Behaviour Class:",
                    style={"margin": "16px 0 12px 0", "fontSize": "14px", "color": "#475569"},
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(400px, 1fr))",
                        "gap": "20px",
                    },
                    children=[
                        html.Div(dcc.Graph(figure=fig_fuel, responsive=True)),
                        html.Div(dcc.Graph(figure=fig_time, responsive=True)),
                    ],
                ),
            ],
        )

        # 4. BMU Summary Profiling
        all_bmus = sorted(sp_df["BMU_ID"].dropna().unique().tolist())
        bmu_summary_section = html.Div(
            style={"backgroundColor": "#ffffff", "padding": "20px", "borderRadius": "8px"},
            children=[
                html.H3("BMU Summary Profiling", style={"margin": "0 0 8px 0", "color": "#1e293b"}),
                html.P(
                    "Select a BMU for Profiling:",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "0 0 10px 0"},
                ),
                dcc.Dropdown(
                    id="ic-t1-bmu-select",
                    options=[{"label": b, "value": b} for b in all_bmus],
                    value=all_bmus[0] if all_bmus else None,
                    style={"marginBottom": "16px"},
                ),
                html.Div(id="ic-t1-bmu-summary-table-container"),
            ],
        )

        return html.Div(
            [
                metrics_cards,
                extreme_pricing_section,
                component_profiles_section,
                cg_container,
                bmu_summary_section,
            ]
        )

    # ---------------- TAB 2: Ensemble SP Intelligence ----------------
    elif tab_value == "tab-2":
        if alerts_df.empty:
            return html.Div(
                "No Ensemble Breaches found in this time range.",
                style={"color": "#64748b", "padding": "20px"},
            )

        raw_alerts = alerts_df.copy()
        if "LOCAL_DATETIME" in raw_alerts.columns:
            raw_alerts = raw_alerts.sort_values(by="LOCAL_DATETIME", ascending=False)

        ORIGINAL_ALERT_COLS = [
            "SETTLEMENT_DATE",
            "SETTLEMENT_PERIOD",
            "GMT_FROM",
            "LOCAL_DATETIME",
            "COUNTERPARTY",
            "BMU_ID",
            "FUEL_TYPE",
            "OFFER_PRICE",
            "OFFER_VOLUME_MWH",
            "SPREAD",
            "COND_1",
            "COND_2",
            "COND_3",
            "N_CONDITIONS_TRUE",
            "ENSEMBLE",
            "WHY",
        ]
        avail_raw_cols = [c for c in ORIGINAL_ALERT_COLS if c in raw_alerts.columns]

        # Format datetimes for raw table
        raw_disp_df = raw_alerts[avail_raw_cols].copy()
        for dt_col in ["SETTLEMENT_DATE", "GMT_FROM", "LOCAL_DATETIME"]:
            if dt_col in raw_disp_df.columns:
                raw_disp_df[dt_col] = pd.to_datetime(raw_disp_df[dt_col]).dt.strftime(
                    "%Y-%m-%d %H:%M:%S"
                )

        raw_alert_table = dash_table.DataTable(
            columns=[{"name": c, "id": c} for c in avail_raw_cols],
            data=raw_disp_df.to_dict("records"),
            page_size=10,
            style_header={"backgroundColor": "#0f172a", "color": "#fff", "fontWeight": "600"},
            style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
            style_table={"overflowX": "auto"},
        )

        top_section = html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "marginBottom": "24px",
            },
            children=[
                html.H3(
                    "Constrained-Ensemble SP Intelligence",
                    style={"margin": "0 0 6px 0", "color": "#1e293b"},
                ),
                html.P(
                    "These are the alerts derived from the canonical dataset that have passed the ENSEMBLE by satisfying at least 2 conditions.",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "0 0 16px 0"},
                ),
                html.Div(
                    style={"marginBottom": "16px"},
                    children=[
                        html.Div(
                            "Total Constrained-Ensemble Alerts (filtered)",
                            style={"fontSize": "12px", "color": "#64748b"},
                        ),
                        html.H2(
                            f"{len(raw_alerts):,}",
                            style={"margin": "4px 0 16px 0", "color": "#0f172a"},
                        ),
                    ],
                ),
                raw_alert_table,
            ],
        )

        # Filters for Analyst Intelligence
        fuels_t2 = (
            sorted(alerts_df["FUEL_TYPE"].dropna().unique().tolist())
            if "FUEL_TYPE" in alerts_df.columns
            else []
        )
        bmus_t2 = (
            sorted(alerts_df["BMU_ID"].dropna().unique().tolist())
            if "BMU_ID" in alerts_df.columns
            else []
        )

        analyst_intelligence_section = html.Div(
            style={"backgroundColor": "#ffffff", "padding": "20px", "borderRadius": "8px"},
            children=[
                html.H3("Analyst Intelligence", style={"margin": "0 0 16px 0", "color": "#1e293b"}),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(300px, 1fr))",
                        "gap": "20px",
                        "marginBottom": "24px",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.Label(
                                    "Filter by Fuel Type:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#475569",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-t2-fuel-filter",
                                    options=[{"label": f, "value": f} for f in fuels_t2],
                                    value=fuels_t2,
                                    multi=True,
                                    placeholder="Select fuels...",
                                ),
                            ],
                        ),
                        html.Div(
                            children=[
                                html.Label(
                                    "Filter by BMU (leave blank for all):",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#475569",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-t2-bmu-filter",
                                    options=[{"label": b, "value": b} for b in bmus_t2],
                                    value=[],
                                    multi=True,
                                    placeholder="Choose options",
                                ),
                            ],
                        ),
                    ],
                ),
                html.Div(id="ic-t2-analyst-intelligence-container"),
            ],
        )

        return html.Div([top_section, analyst_intelligence_section])

    # ---------------- TAB 3: Ensemble Windows ----------------
    elif tab_value == "tab-3":
        if windows_df.empty:
            return html.Div(
                "No continuous window episodes inferred in this date range.",
                style={"color": "#64748b", "padding": "20px"},
            )

        # ---------------- 1. Supporting Views (Overall Summary) ----------------
        dur_counts = (
            windows_df.groupby("DURATION_MIN")
            .size()
            .reset_index(name="Count")
            .sort_values("DURATION_MIN")
        )
        dur_counts["DURATION_MIN_STR"] = dur_counts["DURATION_MIN"].astype(str)
        fig_dur = px.bar(
            dur_counts,
            x="DURATION_MIN_STR",
            y="Count",
            text="Count",
            title="Distribution of Window Durations",
            template="plotly_white",
            labels={"DURATION_MIN_STR": "Duration (min)", "Count": "Count"},
        )
        fig_dur.update_traces(
            marker_color="#00b4d8",
            textposition="outside",
            cliponaxis=False,
        )
        fig_dur.update_layout(
            margin=dict(l=20, r=20, t=40, b=30),
            height=300,
            xaxis_title="Duration (min)",
            yaxis_title="Count",
        )

        bmu_counts = (
            windows_df.groupby("BMU_ID")
            .size()
            .reset_index(name="Window_Count")
            .sort_values("Window_Count", ascending=False)
            .head(10)
        )
        fig_top_bmu = px.bar(
            bmu_counts,
            x="BMU_ID",
            y="Window_Count",
            text="Window_Count",
            title="Top 10 Repeat Windows by BMU",
            template="plotly_white",
            labels={"BMU_ID": "BMU_ID", "Window_Count": "Window_Count"},
        )
        fig_top_bmu.update_traces(
            marker_color="#00b4d8",
            textposition="outside",
            cliponaxis=False,
        )
        fig_top_bmu.update_layout(
            margin=dict(l=20, r=20, t=40, b=30),
            height=300,
            xaxis_tickangle=-45,
            xaxis_title="BMU_ID",
            yaxis_title="Window_Count",
        )

        fuel_counts = (
            windows_df.groupby("FUEL_TYPE")
            .size()
            .reset_index(name="Window_Count")
            .sort_values("Window_Count", ascending=False)
        )
        fig_fuel = px.bar(
            fuel_counts,
            x="FUEL_TYPE",
            y="Window_Count",
            text="Window_Count",
            title="Concentration by Fuel",
            template="plotly_white",
            labels={"FUEL_TYPE": "FUEL_TYPE", "Window_Count": "Window_Count"},
        )
        fig_fuel.update_traces(
            marker_color="#00b4d8",
            textposition="outside",
            cliponaxis=False,
        )
        fig_fuel.update_layout(
            margin=dict(l=20, r=20, t=40, b=30),
            height=300,
            xaxis_title="FUEL_TYPE",
            yaxis_title="Window_Count",
        )

        supporting_views_section = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "Supporting Views (Overall Summary)",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(3, 1fr)",
                        "gap": "16px",
                    },
                    children=[
                        dcc.Graph(figure=fig_dur, config={"displayModeBar": False}),
                        dcc.Graph(figure=fig_top_bmu, config={"displayModeBar": False}),
                        dcc.Graph(figure=fig_fuel, config={"displayModeBar": False}),
                    ],
                ),
            ],
        )

        # ---------------- 2. High-Level Summary ----------------
        total_wins = len(windows_df)
        unique_bmus = windows_df["BMU_ID"].nunique() if "BMU_ID" in windows_df.columns else 0
        tot_impact = (
            windows_df["IMPACT_WINDOW"].sum() if "IMPACT_WINDOW" in windows_df.columns else 0
        )

        kpi_cards = html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(3, 1fr)",
                "gap": "16px",
                "marginBottom": "20px",
            },
            children=[
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #0284c7",
                    },
                    children=[
                        html.Div(
                            "Total Constraint Windows",
                            style={"fontSize": "12px", "color": "#64748b", "fontWeight": "500"},
                        ),
                        html.H2(
                            f"{total_wins:,}", style={"margin": "6px 0 0 0", "color": "#0f172a"}
                        ),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #16a34a",
                    },
                    children=[
                        html.Div(
                            "Unique BMUs Involved",
                            style={"fontSize": "12px", "color": "#64748b", "fontWeight": "500"},
                        ),
                        html.H2(
                            f"{unique_bmus:,}", style={"margin": "6px 0 0 0", "color": "#0f172a"}
                        ),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#f8fafc",
                        "padding": "16px",
                        "borderRadius": "8px",
                        "borderLeft": "4px solid #dc2626",
                    },
                    children=[
                        html.Div(
                            "Total Estimated Impact",
                            style={"fontSize": "12px", "color": "#64748b", "fontWeight": "500"},
                        ),
                        html.H2(
                            f"£{tot_impact:,.0f}", style={"margin": "6px 0 0 0", "color": "#0f172a"}
                        ),
                    ],
                ),
            ],
        )

        bmu_high_level = (
            windows_df.groupby("BMU_ID")
            .agg(
                Window_Count=("DURATION_MIN", "count"),
                Total_Duration=("DURATION_MIN", "sum"),
                Max_Duration=("DURATION_MIN", "max"),
                Aggregated_Impact=("IMPACT_WINDOW", "sum"),
            )
            .reset_index()
            .sort_values("Aggregated_Impact", ascending=False)
        )

        disp_bmu_hl = bmu_high_level.copy()
        disp_bmu_hl["Aggregated Impact (£)"] = disp_bmu_hl["Aggregated_Impact"].apply(
            lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0"
        )
        disp_bmu_hl = disp_bmu_hl.rename(
            columns={
                "Window_Count": "Window Count",
                "Total_Duration": "Total Duration (min)",
                "Max_Duration": "Max Duration (min)",
            }
        )

        bmu_hl_table = dash_table.DataTable(
            columns=[
                {"name": "BMU_ID", "id": "BMU_ID"},
                {"name": "Window Count", "id": "Window Count"},
                {"name": "Total Duration (min)", "id": "Total Duration (min)"},
                {"name": "Max Duration (min)", "id": "Max Duration (min)"},
                {"name": "Aggregated Impact (£)", "id": "Aggregated Impact (£)"},
            ],
            data=disp_bmu_hl.to_dict("records"),
            page_size=10,
            style_header={
                "backgroundColor": "#f8fafc",
                "color": "#475569",
                "fontWeight": "600",
                "borderBottom": "2px solid #e2e8f0",
            },
            style_cell={
                "textAlign": "left",
                "fontSize": "12px",
                "padding": "10px",
                "borderBottom": "1px solid #f1f5f9",
            },
            style_table={
                "overflowX": "auto",
                "borderRadius": "6px",
                "border": "1px solid #e2e8f0",
            },
        )

        high_level_summary_section = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "High-Level Summary",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                kpi_cards,
                bmu_hl_table,
            ],
        )

        # ---------------- 3. Window-Level Metrics & Impact ----------------
        disp_win = windows_df.copy()
        disp_win["Start"] = pd.to_datetime(disp_win["START_LOCAL"]).dt.strftime("%Y-%m-%d %H:%M")
        disp_win["End"] = pd.to_datetime(disp_win["END_LOCAL"]).dt.strftime("%Y-%m-%d %H:%M")
        disp_win["Mean Spread (£)"] = disp_win["AVG_SPREAD"].apply(
            lambda x: f"£{x:,.2f}" if pd.notna(x) else "N/A"
        )
        disp_win["Max Spread (£)"] = disp_win["MAX_SPREAD"].apply(
            lambda x: f"£{x:,.2f}" if pd.notna(x) else "N/A"
        )
        disp_win["IMPACT_WINDOW_DISP"] = disp_win["IMPACT_WINDOW"].apply(
            lambda x: f"{int(round(x)):,}" if pd.notna(x) else "0"
        )

        win_cols = [
            {"name": "BMU_ID", "id": "BMU_ID"},
            {"name": "CONSTRAINT_GROUP", "id": "CONSTRAINT_GROUP"},
            {"name": "Start", "id": "Start"},
            {"name": "End", "id": "End"},
            {"name": "Duration (min)", "id": "DURATION_MIN"},
            {"name": "SP Count", "id": "COUNT_SP"},
            {"name": "Mean Spread (£)", "id": "Mean Spread (£)"},
            {"name": "Max Spread (£)", "id": "Max Spread (£)"},
            {"name": "IMPACT_WINDOW", "id": "IMPACT_WINDOW_DISP"},
        ]

        win_detail_table = dash_table.DataTable(
            columns=win_cols,
            data=disp_win.to_dict("records"),
            page_size=10,
            sort_action="native",
            style_header={
                "backgroundColor": "#f8fafc",
                "color": "#475569",
                "fontWeight": "600",
                "borderBottom": "2px solid #e2e8f0",
            },
            style_cell={
                "textAlign": "left",
                "fontSize": "12px",
                "padding": "10px",
                "borderBottom": "1px solid #f1f5f9",
            },
            style_table={
                "overflowX": "auto",
                "borderRadius": "6px",
                "border": "1px solid #e2e8f0",
            },
        )

        impact_info_accordion = html.Details(
            style={"marginTop": "16px"},
            children=[
                html.Summary(
                    "ℹ️ How is Window Impact Calculated?",
                    style={
                        "fontSize": "13px",
                        "fontWeight": "600",
                        "color": "#475569",
                        "cursor": "pointer",
                        "padding": "10px 14px",
                        "backgroundColor": "#f8fafc",
                        "borderRadius": "6px",
                        "border": "1px solid #e2e8f0",
                    },
                ),
                html.Div(
                    style={
                        "padding": "14px",
                        "backgroundColor": "#ffffff",
                        "border": "1px solid #e2e8f0",
                        "borderTop": "none",
                        "borderRadius": "0 0 6px 6px",
                        "fontSize": "12px",
                        "color": "#475569",
                        "lineHeight": "1.6",
                    },
                    children=[
                        html.P(
                            "Window Impact (£) represents the cumulative estimated financial impact over a continuous constraint window episode. It is calculated by aggregating the product of Bid-Offer Spread (£/MWh) and Constraint Volume (MWh) across all settlement periods (SPs) forming the continuous episode.",
                            style={"margin": "0 0 8px 0"},
                        ),
                        html.P(
                            "Formula: Aggregated Impact = ∑ (Bid-Offer Spread × Volume) across all SPs in the continuous window episode.",
                            style={"margin": "0", "fontWeight": "600", "fontFamily": "monospace"},
                        ),
                    ],
                ),
            ],
        )

        window_metrics_section = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "Window-Level Metrics & Impact",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                win_detail_table,
                impact_info_accordion,
            ],
        )

        # ---------------- 4. Window Priority Quadrant ----------------
        bmu_options = ["All"] + sorted(list(windows_df["BMU_ID"].dropna().unique()))
        quadrant_section = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "Window Priority Quadrant (Persistence vs Significance):",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "12px",
                    },
                ),
                html.Div(
                    style={"marginBottom": "16px", "maxWidth": "400px"},
                    children=[
                        html.Label(
                            "Select BMU to isolate in Quadrant:",
                            style={
                                "fontSize": "12px",
                                "fontWeight": "600",
                                "color": "#475569",
                                "marginBottom": "6px",
                                "display": "block",
                            },
                        ),
                        dcc.Dropdown(
                            id="ic-t3-quadrant-bmu-dropdown",
                            options=[{"label": b, "value": b} for b in bmu_options],
                            value="All",
                            clearable=False,
                            style={"fontSize": "13px"},
                        ),
                    ],
                ),
                dcc.Graph(id="ic-t3-quadrant-graph", config={"displayModeBar": False}),
            ],
        )

        return html.Div(
            style={"backgroundColor": "#ffffff", "padding": "24px", "borderRadius": "8px"},
            children=[
                supporting_views_section,
                high_level_summary_section,
                window_metrics_section,
                quadrant_section,
            ],
        )

    # ---------------- TAB 4: BMU Deep Dive ----------------
    elif tab_value == "tab-4":
        bmu_list = sorted(list(sp_df["BMU_ID"].dropna().unique()))
        return html.Div(
            style={"backgroundColor": "#ffffff", "padding": "20px", "borderRadius": "8px"},
            children=[
                html.Label("Select BMU for Deep Dive:", style={"fontWeight": "600"}),
                dcc.Dropdown(
                    id="ic-bmu-dropdown",
                    options=bmu_list,
                    value=bmu_list[0] if bmu_list else None,
                    style={"marginBottom": "20px"},
                ),
                html.Div(id="ic-bmu-deepdive-container"),
            ],
        )

    # ---------------- TAB 5: Spread Analysis ----------------
    elif tab_value == "tab-5":
        fuels = (
            sorted(list(sp_df["FUEL_TYPE"].dropna().unique()))
            if "FUEL_TYPE" in sp_df.columns
            else []
        )
        default_fuel = fuels[0] if fuels else None
        behaviors = [
            "Constrained - elevated signal",
            "Constrained - ensemble",
            "Constrained - normal behaviour",
        ]

        # Section 1: C3 Spread by Fuel Type
        sec1 = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "C3: Spread by Fuel Type (Constrained vs Unconstrained)",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                html.Div(
                    style={
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "flex-end",
                        "marginBottom": "16px",
                        "gap": "20px",
                    },
                    children=[
                        html.Div(
                            style={"flex": "1", "maxWidth": "500px"},
                            children=[
                                html.Label(
                                    "Filter Fuel Types for this chart:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "color": "#475569",
                                        "marginBottom": "6px",
                                        "display": "block",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-t5-fuel-select",
                                    options=[{"label": f, "value": f} for f in fuels],
                                    value=fuels,
                                    multi=True,
                                    style={"fontSize": "13px"},
                                ),
                            ],
                        ),
                        html.Div(
                            children=[
                                html.Label(
                                    "Display Mode:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "color": "#475569",
                                        "marginBottom": "6px",
                                        "display": "block",
                                    },
                                ),
                                dcc.RadioItems(
                                    id="ic-t5-fuel-mode",
                                    options=[
                                        {"label": " Both (Comparison)", "value": "both"},
                                        {"label": " Constrained Only", "value": "constrained"},
                                        {"label": " Unconstrained Only", "value": "unconstrained"},
                                    ],
                                    value="both",
                                    inline=True,
                                    style={"fontSize": "13px", "display": "flex", "gap": "14px"},
                                ),
                            ],
                        ),
                    ],
                ),
                dcc.Graph(id="ic-t5-fuel-spread-graph", config={"displayModeBar": False}),
            ],
        )

        # Section 2: C3 Individual BMU Drill-down by Fuel
        sec2 = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "C3: Individual BMU Drill-down by Fuel",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                html.Div(
                    style={
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "flex-end",
                        "marginBottom": "16px",
                        "gap": "20px",
                    },
                    children=[
                        html.Div(
                            style={"flex": "1", "maxWidth": "400px"},
                            children=[
                                html.Label(
                                    "Select Fuel Type to see all units:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "color": "#475569",
                                        "marginBottom": "6px",
                                        "display": "block",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="ic-t5-bmu-fuel-select",
                                    options=[{"label": f, "value": f} for f in fuels],
                                    value=default_fuel,
                                    clearable=False,
                                    style={"fontSize": "13px"},
                                ),
                            ],
                        ),
                        html.Div(
                            children=[
                                html.Label(
                                    "Display Mode (Units):",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "color": "#475569",
                                        "marginBottom": "6px",
                                        "display": "block",
                                    },
                                ),
                                dcc.RadioItems(
                                    id="ic-t5-bmu-mode",
                                    options=[
                                        {"label": " Both (Comparison)", "value": "both"},
                                        {"label": " Constrained Only", "value": "constrained"},
                                        {"label": " Unconstrained Only", "value": "unconstrained"},
                                    ],
                                    value="both",
                                    inline=True,
                                    style={"fontSize": "13px", "display": "flex", "gap": "14px"},
                                ),
                            ],
                        ),
                    ],
                ),
                dcc.Graph(id="ic-t5-bmu-drilldown-graph", config={"displayModeBar": False}),
            ],
        )

        # Section 3: Spread Distributions by Fuel Type & Behavior
        fig_dist = px.violin(
            sp_df,
            x="SPREAD",
            y="FUEL_TYPE",
            color="BEHAVIOUR_CLASS",
            orientation="h",
            title="Spread Distribution Segregated by Behavior",
            template="plotly_white",
            color_discrete_map={
                "Constrained - ensemble": "#ef4444",
                "Constrained - elevated signal": "#f59e0b",
                "Constrained - normal behaviour": "#94a3b8",
            },
            labels={
                "SPREAD": "Spread (£/MWh)",
                "FUEL_TYPE": "FUEL_TYPE",
                "BEHAVIOUR_CLASS": "Behavior Class",
            },
        )
        fig_dist.update_layout(margin=dict(l=30, r=30, t=40, b=30), height=380)

        sec3 = html.Div(
            style={"marginBottom": "32px"},
            children=[
                html.H3(
                    "Spread Distributions by Fuel Type & Behavior",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                dcc.Graph(figure=fig_dist, config={"displayModeBar": False}),
            ],
        )

        # Section 4: Median Spread by Weekday x Hour (GMT)
        sec4 = html.Div(
            style={"marginBottom": "16px"},
            children=[
                html.H3(
                    "Median Spread by Weekday × Hour (GMT)",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                html.Div(
                    style={"marginBottom": "16px", "maxWidth": "600px"},
                    children=[
                        html.Label(
                            "Filter by Behavior Class:",
                            style={
                                "fontSize": "12px",
                                "fontWeight": "600",
                                "color": "#475569",
                                "marginBottom": "6px",
                                "display": "block",
                            },
                        ),
                        dcc.Dropdown(
                            id="ic-t5-heatmap-behavior-select",
                            options=[{"label": b, "value": b} for b in behaviors],
                            value=behaviors,
                            multi=True,
                            style={"fontSize": "13px"},
                        ),
                    ],
                ),
                dcc.Graph(id="ic-t5-heatmap-graph", config={"displayModeBar": False}),
            ],
        )

        return html.Div(
            style={"backgroundColor": "#ffffff", "padding": "24px", "borderRadius": "8px"},
            children=[sec1, sec2, sec3, sec4],
        )

    # ---------------- TAB 6: Counterparty Intelligence ----------------
    elif tab_value == "tab-6":
        cps = (
            sorted(list(sp_df["COUNTERPARTY"].dropna().unique()))
            if "COUNTERPARTY" in sp_df.columns
            else []
        )

        return html.Div(
            style={"backgroundColor": "#ffffff", "padding": "24px", "borderRadius": "8px"},
            children=[
                html.H3(
                    "Counterparty Intelligence",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "color": "#0f172a",
                        "marginBottom": "16px",
                    },
                ),
                html.Div(
                    style={"marginBottom": "20px", "maxWidth": "600px"},
                    children=[
                        html.Label(
                            "Select Counterparties to Inspect (leave blank to display all):",
                            style={
                                "fontSize": "12px",
                                "fontWeight": "600",
                                "color": "#475569",
                                "marginBottom": "6px",
                                "display": "block",
                            },
                        ),
                        dcc.Dropdown(
                            id="ic-t6-cp-select",
                            options=[{"label": c, "value": c} for c in cps],
                            value=[],
                            multi=True,
                            placeholder="All Counterparties",
                            style={"fontSize": "13px"},
                        ),
                    ],
                ),
                html.Div(id="ic-t6-container"),
            ],
        )

    return html.Div("Select a tab to view analysis.")


# Callback for BMU Deep Dive Tab
@callback(
    Output("ic-bmu-deepdive-container", "children"),
    Input("ic-bmu-dropdown", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def render_bmu_deep_dive(selected_bmu, start_date, end_date):
    if not selected_bmu or not start_date or not end_date:
        return html.Div("Select a BMU to inspect.", style={"color": "#64748b"})

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]
    windows_df = data["windows_df"]

    bmu_df = sp_df[sp_df["BMU_ID"] == selected_bmu].copy()

    if bmu_df.empty:
        return html.Div(
            f"No data for BMU {selected_bmu}", style={"color": "#64748b", "padding": "20px"}
        )

    # ---------------- 1. Top-Level Metrics & Materiality Extension ----------------
    total_sps = len(bmu_df)
    normal_sps = (bmu_df["BEHAVIOUR_CLASS"] == "Constrained - normal behaviour").sum()
    elevated_sps = (bmu_df["BEHAVIOUR_CLASS"] == "Constrained - elevated signal").sum()
    ens_sps = (bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble").sum()

    normal_pct = (normal_sps / total_sps * 100) if total_sps > 0 else 0
    elevated_pct = (elevated_sps / total_sps * 100) if total_sps > 0 else 0
    ens_pct = (ens_sps / total_sps * 100) if total_sps > 0 else 0

    tot_bmu_impact = (
        bmu_df["IMPACT_SP"].sum()
        if "IMPACT_SP" in bmu_df.columns
        else (bmu_df[bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"]["SPREAD"] * 15).sum()
    )
    avg_ens_impact = (tot_bmu_impact / ens_sps) if ens_sps > 0 else 0

    # Extreme pricing metrics (> £200)
    ens_df = bmu_df[bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"]
    high_price_df = ens_df[ens_df["OFFER_PRICE"] > 200]
    high_price_count = len(high_price_df)
    max_extreme_price = (
        f"£{high_price_df['OFFER_PRICE'].max():,.2f}" if high_price_count > 0 else "N/A"
    )
    avg_extreme_price = (
        f"£{high_price_df['OFFER_PRICE'].mean():,.2f}" if high_price_count > 0 else "N/A"
    )

    top_level_kpis = html.Div(
        style={"marginBottom": "24px"},
        children=[
            html.H3(
                "Top-Level Metrics",
                style={
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                    "marginBottom": "12px",
                },
            ),
            html.Div(
                style={
                    "display": "grid",
                    "gridTemplateColumns": "repeat(5, 1fr)",
                    "gap": "14px",
                    "marginBottom": "12px",
                },
                children=[
                    html.Div(
                        [
                            html.Div(
                                "Total Constrained SPs",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{total_sps:,}", style={"margin": "4px 0 0 0", "color": "#0f172a"}
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Normal Behaviour", style={"fontSize": "12px", "color": "#64748b"}
                            ),
                            html.H3(
                                f"{normal_sps:,} ({normal_pct:.1f}%)",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Elevated Signal (1 condition fired)",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{elevated_sps:,} ({elevated_pct:.1f}%)",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Ensemble Behaviour (2 conditions fire)",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{ens_sps:,} ({ens_pct:.1f}%)",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Total Aggregated Impact (£)",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"£{tot_bmu_impact:,.0f}",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                ],
            ),
            html.P(
                [
                    html.Strong("Impact Intensity: "),
                    f"On average, each flagged ensemble period for this BMU represents an estimated cost of £{avg_ens_impact:,.0f}.",
                ],
                style={"fontSize": "12px", "color": "#475569", "margin": "0 0 20px 0"},
            ),
            html.Hr(style={"border": "none", "borderTop": "1px solid #e2e8f0", "margin": "20px 0"}),
            html.H3(
                "Materiality Extension: Extreme Pricing",
                style={
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                    "marginBottom": "12px",
                },
            ),
            html.Div(
                style={
                    "display": "grid",
                    "gridTemplateColumns": "repeat(3, 1fr)",
                    "gap": "14px",
                    "marginBottom": "24px",
                },
                children=[
                    html.Div(
                        [
                            html.Div(
                                "Ensemble SPs > £200",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{high_price_count:,}",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Max Extreme Price (£)",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{max_extreme_price}",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                    html.Div(
                        [
                            html.Div(
                                "Avg Extreme Price (£)",
                                style={"fontSize": "12px", "color": "#64748b"},
                            ),
                            html.H3(
                                f"{avg_extreme_price}",
                                style={"margin": "4px 0 0 0", "color": "#0f172a"},
                            ),
                        ]
                    ),
                ],
            ),
            html.Hr(style={"border": "none", "borderTop": "1px solid #e2e8f0", "margin": "20px 0"}),
        ],
    )

    # Price & Spread Charts
    fig_price = px.line(
        bmu_df,
        x="LOCAL_DATETIME",
        y=(
            ["OFFER_PRICE", "REFERENCE_PRICE"]
            if "REFERENCE_PRICE" in bmu_df.columns
            else ["OFFER_PRICE"]
        ),
        title=f"{selected_bmu} — Offer Price vs Reference Price (£/MWh)",
        template="plotly_white",
        color_discrete_map={
            "OFFER_PRICE": "#4e0038",
            "REFERENCE_PRICE": "#0284c7",
        },
    )
    fig_price.update_traces(line=dict(width=2))
    fig_price.update_layout(
        margin=dict(l=30, r=30, t=40, b=30),
        height=320,
        xaxis_title="Date & Time",
        yaxis_title="Price (£/MWh)",
    )

    fig_spread = px.line(
        bmu_df,
        x="LOCAL_DATETIME",
        y="SPREAD",
        title=f"{selected_bmu} — Price Spread Over Time (£/MWh)",
        template="plotly_white",
        color_discrete_sequence=["#4e0038"],
    )
    fig_spread.update_traces(line=dict(width=2, color="#4e0038"), name="Spread (£/MWh)")

    ens_points = bmu_df[bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"]
    if not ens_points.empty:
        fig_spread.add_trace(
            go.Scatter(
                x=ens_points["LOCAL_DATETIME"],
                y=ens_points["SPREAD"],
                mode="markers",
                marker=dict(color="#ef4444", size=7, symbol="circle"),
                name="Ensemble Breach",
                hovertemplate="Ensemble Breach<br>Date: %{x}<br>Spread: £%{y:.2f}/MWh<extra></extra>",
            )
        )

    fig_spread.update_layout(
        margin=dict(l=30, r=30, t=40, b=30),
        height=320,
        xaxis_title="Date & Time",
        yaxis_title="Spread (£/MWh)",
    )

    # ---------------- 2. Component Profiles ----------------
    beh_counts = bmu_df.groupby("BEHAVIOUR_CLASS").size().reset_index(name="Count")
    beh_total = beh_counts["Count"].sum()
    beh_counts["Pct"] = (
        (beh_counts["Count"] / beh_total * 100).round(1).astype(str) + "%"
        if beh_total > 0
        else "0%"
    )

    fig_beh = px.bar(
        beh_counts,
        x="BEHAVIOUR_CLASS",
        y="Count",
        text="Pct",
        title=f"Behaviour Mix for {selected_bmu}",
        color="BEHAVIOUR_CLASS",
        color_discrete_map={
            "Constrained - ensemble": "#ff0000",
            "Constrained - elevated signal": "#ffa500",
            "Constrained - normal behaviour": "#94a3b8",
        },
        template="plotly_white",
    )
    fig_beh.update_traces(textposition="outside", cliponaxis=False)
    fig_beh.update_layout(
        margin=dict(l=20, r=20, t=40, b=30),
        height=320,
        xaxis_title="Behaviour",
        yaxis_title="Count",
        showlegend=True,
    )

    if "WHY" in bmu_df.columns:
        parsed_why = bmu_df["WHY"].apply(ic_sp_analytics_service.parse_why)
        bmu_df["WHY_CONDITIONS"] = [p[0] for p in parsed_why]
        bmu_df["WHY_DETAILS"] = [p[1] for p in parsed_why]
    else:
        bmu_df["WHY_CONDITIONS"] = ""
        bmu_df["WHY_DETAILS"] = ""

    ens_bmu_df = bmu_df[bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"]

    tuple_counts = (
        ens_bmu_df.groupby("WHY_CONDITIONS")
        .size()
        .reset_index(name="Count")
        .sort_values("Count", ascending=False)
    )
    t_tot = tuple_counts["Count"].sum()
    tuple_counts["Pct"] = (
        (tuple_counts["Count"] / t_tot * 100).round(1).astype(str) + "%" if t_tot > 0 else "0%"
    )

    fig_tuples = px.bar(
        tuple_counts,
        x="WHY_CONDITIONS",
        y="Count",
        text="Pct",
        title="Flagged Combinations (Tuples)",
        color="WHY_CONDITIONS",
        color_discrete_sequence=["#6366f1", "#ef4444", "#3b82f6", "#10b981"],
        template="plotly_white",
    )
    fig_tuples.update_traces(textposition="outside", cliponaxis=False)
    fig_tuples.update_layout(
        margin=dict(l=20, r=20, t=40, b=30),
        height=300,
        xaxis_title="Combination",
        yaxis_title="Count",
    )

    c1_cnt = int(bmu_df["COND_1"].sum()) if "COND_1" in bmu_df.columns else 0
    c2_cnt = int(bmu_df["COND_2"].sum()) if "COND_2" in bmu_df.columns else 0
    c3_cnt = int(bmu_df["COND_3"].sum()) if "COND_3" in bmu_df.columns else 0
    cond_total = c1_cnt + c2_cnt + c3_cnt

    cond_df = pd.DataFrame(
        [
            {
                "Condition": "C1 (Historical)",
                "Count": c1_cnt,
                "Pct": f"{(c1_cnt / cond_total * 100):.1f}%" if cond_total > 0 else "0%",
            },
            {
                "Condition": "C2 (Threshold)",
                "Count": c2_cnt,
                "Pct": f"{(c2_cnt / cond_total * 100):.1f}%" if cond_total > 0 else "0%",
            },
            {
                "Condition": "C3 (vs Uncon)",
                "Count": c3_cnt,
                "Pct": f"{(c3_cnt / cond_total * 100):.1f}%" if cond_total > 0 else "0%",
            },
        ]
    )

    fig_ind_cond = px.bar(
        cond_df,
        x="Condition",
        y="Count",
        text="Pct",
        title="Individual Condition Firing",
        color="Condition",
        color_discrete_map={
            "C1 (Historical)": "#06b6d4",
            "C2 (Threshold)": "#f59e0b",
            "C3 (vs Uncon)": "#ef4444",
        },
        template="plotly_white",
    )
    fig_ind_cond.update_traces(textposition="outside", cliponaxis=False)
    fig_ind_cond.update_layout(
        margin=dict(l=20, r=20, t=40, b=30),
        height=300,
        xaxis_title="Condition",
        yaxis_title="Count",
    )

    component_profiles_section = html.Div(
        style={"marginBottom": "32px"},
        children=[
            html.H3(
                "Component Profiles",
                style={
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                    "marginBottom": "16px",
                },
            ),
            html.H4(
                "1. Behaviour Mix:",
                style={
                    "fontSize": "14px",
                    "fontWeight": "600",
                    "color": "#334155",
                    "marginBottom": "12px",
                },
            ),
            dcc.Graph(figure=fig_beh, config={"displayModeBar": False}),
            html.Div(style={"height": "20px"}),
            html.H4(
                "2. Condition Firing Mix:",
                style={
                    "fontSize": "14px",
                    "fontWeight": "600",
                    "color": "#334155",
                    "marginBottom": "12px",
                },
            ),
            html.Div(
                style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "16px"},
                children=[
                    dcc.Graph(figure=fig_tuples, config={"displayModeBar": False}),
                    dcc.Graph(figure=fig_ind_cond, config={"displayModeBar": False}),
                ],
            ),
        ],
    )

    alerts_df = data["alerts_df"]
    if not alerts_df.empty and "BMU_ID" in alerts_df.columns:
        ens_bmu_df = alerts_df[alerts_df["BMU_ID"] == selected_bmu].copy()
    else:
        ens_bmu_df = bmu_df[bmu_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"].copy()

    # ---------------- 3. Constrained-Ensemble SP Intelligence ----------------
    disp_ens_sp = ens_bmu_df.copy()
    if not disp_ens_sp.empty:
        disp_ens_sp["LOCAL_DATETIME"] = pd.to_datetime(disp_ens_sp["LOCAL_DATETIME"]).dt.strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        disp_ens_sp["SPREAD"] = disp_ens_sp["SPREAD"].apply(
            lambda x: f"{x:.1f}" if pd.notna(x) else "N/A"
        )
        if "IMPACT_SP" in disp_ens_sp.columns:
            disp_ens_sp["Estimated Impact (£)"] = disp_ens_sp["IMPACT_SP"].apply(
                lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0"
            )
        elif "SPREAD" in disp_ens_sp.columns:
            disp_ens_sp["Estimated Impact (£)"] = (
                pd.to_numeric(disp_ens_sp["SPREAD"], errors="coerce").fillna(0) * 15
            ).apply(lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0")
        else:
            disp_ens_sp["Estimated Impact (£)"] = "£0"

        disp_ens_sp = disp_ens_sp.sort_values(by="LOCAL_DATETIME", ascending=False).reset_index(
            drop=True
        )

    sp_intel_cols = [
        {"name": "LOCAL_DATETIME", "id": "LOCAL_DATETIME"},
        {"name": "OFFER_PRICE", "id": "OFFER_PRICE"},
        {"name": "SPREAD", "id": "SPREAD"},
        {"name": "WHY_CONDITIONS", "id": "WHY_CONDITIONS"},
        {"name": "WHY_DETAILS", "id": "WHY_DETAILS"},
        {"name": "Estimated Impact (£)", "id": "Estimated Impact (£)"},
    ]

    sp_intel_table = dash_table.DataTable(
        columns=sp_intel_cols,
        data=disp_ens_sp.to_dict("records") if not disp_ens_sp.empty else [],
        page_size=10,
        sort_action="native",
        style_header={
            "backgroundColor": "#f8fafc",
            "color": "#475569",
            "fontWeight": "600",
            "borderBottom": "2px solid #e2e8f0",
        },
        style_cell={
            "textAlign": "left",
            "fontSize": "12px",
            "padding": "10px",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_table={
            "overflowX": "auto",
            "borderRadius": "6px",
            "border": "1px solid #e2e8f0",
        },
    )

    sp_impact_accordion = html.Details(
        style={"marginTop": "12px"},
        children=[
            html.Summary(
                "ℹ️ How is Impact Calculated?",
                style={
                    "fontSize": "13px",
                    "fontWeight": "600",
                    "color": "#475569",
                    "cursor": "pointer",
                    "padding": "10px 14px",
                    "backgroundColor": "#f8fafc",
                    "borderRadius": "6px",
                    "border": "1px solid #e2e8f0",
                },
            ),
            html.Div(
                style={
                    "padding": "14px",
                    "backgroundColor": "#ffffff",
                    "border": "1px solid #e2e8f0",
                    "borderTop": "none",
                    "borderRadius": "0 0 6px 6px",
                    "fontSize": "12px",
                    "color": "#475569",
                },
                children=[
                    html.P(
                        "Estimated Impact per SP is calculated as Bid-Offer Spread (£/MWh) × Constraint Volume (MWh)."
                    ),
                ],
            ),
        ],
    )

    sp_intel_section = html.Div(
        style={"marginBottom": "32px"},
        children=[
            html.H3(
                "Constrained-Ensemble SP Intelligence",
                style={
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                    "marginBottom": "16px",
                },
            ),
            sp_intel_table,
            sp_impact_accordion,
        ],
    )

    # ---------------- 4. Constrained-Ensemble Windows ----------------
    bmu_win_df = (
        windows_df[windows_df["BMU_ID"] == selected_bmu].copy()
        if not windows_df.empty
        else pd.DataFrame()
    )

    tot_cum_win_impact = (
        bmu_win_df["IMPACT_WINDOW"].sum()
        if not bmu_win_df.empty and "IMPACT_WINDOW" in bmu_win_df.columns
        else 0
    )

    if not bmu_win_df.empty:
        disp_bmu_win = bmu_win_df.copy()
        disp_bmu_win["START_LOCAL"] = pd.to_datetime(disp_bmu_win["START_LOCAL"]).dt.strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        disp_bmu_win["END_LOCAL"] = pd.to_datetime(disp_bmu_win["END_LOCAL"]).dt.strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        disp_bmu_win["AVG_SPREAD"] = disp_bmu_win["AVG_SPREAD"].apply(
            lambda x: f"{x:.2f}" if pd.notna(x) else "N/A"
        )
        disp_bmu_win["Window Impact (£)"] = disp_bmu_win["IMPACT_WINDOW"].apply(
            lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0"
        )
    else:
        disp_bmu_win = pd.DataFrame()

    win_intel_cols = [
        {"name": "START_LOCAL", "id": "START_LOCAL"},
        {"name": "END_LOCAL", "id": "END_LOCAL"},
        {"name": "DURATION_MIN", "id": "DURATION_MIN"},
        {"name": "COUNT_SP", "id": "COUNT_SP"},
        {"name": "AVG_SPREAD", "id": "AVG_SPREAD"},
        {"name": "Window Impact (£)", "id": "Window Impact (£)"},
    ]

    win_intel_table = dash_table.DataTable(
        columns=win_intel_cols,
        data=disp_bmu_win.to_dict("records") if not disp_bmu_win.empty else [],
        page_size=10,
        sort_action="native",
        style_header={
            "backgroundColor": "#f8fafc",
            "color": "#475569",
            "fontWeight": "600",
            "borderBottom": "2px solid #e2e8f0",
        },
        style_cell={
            "textAlign": "left",
            "fontSize": "12px",
            "padding": "10px",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_table={
            "overflowX": "auto",
            "borderRadius": "6px",
            "border": "1px solid #e2e8f0",
        },
    )

    windows_intel_section = html.Div(
        style={"marginBottom": "32px"},
        children=[
            html.H3(
                "Constrained-Ensemble Windows",
                style={
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                    "marginBottom": "16px",
                },
            ),
            win_intel_table,
            html.Div(
                style={"marginTop": "20px"},
                children=[
                    html.Div(
                        "Total Cumulative Window Impact",
                        style={"fontSize": "13px", "color": "#64748b", "fontWeight": "500"},
                    ),
                    html.H2(
                        f"£{tot_cum_win_impact:,.0f}",
                        style={
                            "fontSize": "28px",
                            "fontWeight": "800",
                            "color": "#0f172a",
                            "margin": "4px 0 0 0",
                        },
                    ),
                ],
            ),
        ],
    )

    return html.Div(
        children=[
            top_level_kpis,
            dcc.Graph(figure=fig_price, responsive=True),
            html.Div(style={"height": "20px"}),
            dcc.Graph(figure=fig_spread, responsive=True),
            html.Div(style={"height": "32px"}),
            component_profiles_section,
            sp_intel_section,
            windows_intel_section,
        ]
    )


# Callback for Extreme Pricing Events Table in Tab 1
@callback(
    Output("ic-t1-ex-bmu-table-container", "children"),
    Input("ic-t1-ex-bmu-select", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def render_t1_ex_bmu_table(selected_bmu, start_date, end_date):
    if not selected_bmu or not start_date or not end_date:
        return html.Div("No BMU selected", style={"color": "#64748b"})

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]

    high_price_mask = (
        (sp_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble")
        & (sp_df["OFFER_PRICE"] > 200)
        & (sp_df["BMU_ID"] == selected_bmu)
    )
    bmu_ex_df = sp_df[high_price_mask].copy()

    if bmu_ex_df.empty:
        return html.Div(
            f"No extreme pricing events > £200 detected for {selected_bmu}.",
            style={"color": "#64748b", "fontSize": "13px"},
        )

    if "WHY" in bmu_ex_df.columns:
        parsed = bmu_ex_df["WHY"].apply(ic_sp_analytics_service.parse_why)
        bmu_ex_df["WHY_CONDITIONS"] = parsed.apply(lambda x: x[0])
        bmu_ex_df["WHY_DETAILS"] = parsed.apply(lambda x: x[1])
    else:
        bmu_ex_df["WHY_CONDITIONS"] = ""
        bmu_ex_df["WHY_DETAILS"] = ""

    disp_df = (
        bmu_ex_df[
            [
                "LOCAL_DATETIME",
                "OFFER_PRICE",
                "SPREAD",
                "WHY_CONDITIONS",
                "WHY_DETAILS",
            ]
        ]
        .sort_values(by="LOCAL_DATETIME", ascending=False)
        .reset_index(drop=True)
    )
    disp_df["LOCAL_DATETIME"] = pd.to_datetime(disp_df["LOCAL_DATETIME"]).dt.strftime(
        "%Y-%m-%d %H:%M"
    )

    cols = [
        {"name": "Date & Time", "id": "LOCAL_DATETIME"},
        {"name": "Offer Price (£)", "id": "OFFER_PRICE"},
        {"name": "Spread (£)", "id": "SPREAD"},
        {"name": "Conditions Fired", "id": "WHY_CONDITIONS"},
        {"name": "Expanded Explanation", "id": "WHY_DETAILS"},
    ]

    return dash_table.DataTable(
        columns=cols,
        data=disp_df.to_dict("records"),
        page_size=8,
        style_header={
            "backgroundColor": "#0f172a",
            "color": "#fff",
            "fontWeight": "600",
        },
        style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
        style_table={"overflowX": "auto"},
    )


# Callback for BMU Summary Profiling Table in Tab 1
@callback(
    Output("ic-t1-bmu-summary-table-container", "children"),
    Input("ic-t1-bmu-select", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def render_t1_bmu_summary_table(selected_bmu, start_date, end_date):
    if not selected_bmu or not start_date or not end_date:
        return html.Div("No BMU selected", style={"color": "#64748b"})

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]
    bmu_t1_df = sp_df[sp_df["BMU_ID"] == selected_bmu]

    if bmu_t1_df.empty:
        return html.Div(f"No data for BMU {selected_bmu}.", style={"color": "#64748b"})

    bmu_total_sps = len(bmu_t1_df)
    bmu_normal = (bmu_t1_df["BEHAVIOUR_CLASS"] == "Constrained - normal behaviour").sum()
    bmu_elevated = (bmu_t1_df["BEHAVIOUR_CLASS"] == "Constrained - elevated signal").sum()
    bmu_ensemble = (bmu_t1_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble").sum()
    bmu_ens_gt_200 = (
        (bmu_t1_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble")
        & (bmu_t1_df["OFFER_PRICE"] > 200)
    ).sum()

    bmu_summary = pd.DataFrame(
        [
            {
                "BMU_ID": selected_bmu,
                "Total_Constrained_SPs": bmu_total_sps,
                "% Normal": (
                    f"{(bmu_normal / bmu_total_sps * 100):.1f}%" if bmu_total_sps > 0 else "0%"
                ),
                "% Elevated": (
                    f"{(bmu_elevated / bmu_total_sps * 100):.1f}%" if bmu_total_sps > 0 else "0%"
                ),
                "% Ensemble": (
                    f"{(bmu_ensemble / bmu_total_sps * 100):.1f}%" if bmu_total_sps > 0 else "0%"
                ),
                "Ensemble_SPs": bmu_ensemble,
                "Ensemble_GT_200": bmu_ens_gt_200,
            }
        ]
    )

    cols = [
        {"name": "BMU ID", "id": "BMU_ID"},
        {"name": "Total Constrained SPs", "id": "Total_Constrained_SPs"},
        {"name": "% Normal", "id": "% Normal"},
        {"name": "% Elevated", "id": "% Elevated"},
        {"name": "% Ensemble", "id": "% Ensemble"},
        {"name": "Ensemble SPs", "id": "Ensemble_SPs"},
        {"name": "Ensemble > £200", "id": "Ensemble_GT_200"},
    ]

    return dash_table.DataTable(
        columns=cols,
        data=bmu_summary.to_dict("records"),
        style_header={
            "backgroundColor": "#4e0038",
            "color": "#fff",
            "fontWeight": "600",
        },
        style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
    )


# Callback for Tab 2 Analyst Intelligence (BMU-Level Aggregation & SP-Level Detail Tables)
@callback(
    Output("ic-t2-analyst-intelligence-container", "children"),
    Input("ic-t2-fuel-filter", "value"),
    Input("ic-t2-bmu-filter", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def render_t2_analyst_intelligence(selected_fuels, selected_bmus, start_date, end_date):
    if not start_date or not end_date:
        return html.Div("No active date range.", style={"color": "#64748b"})

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    alerts_df = data["alerts_df"]

    if alerts_df.empty:
        return html.Div("No ensemble SPs match the current date range.", style={"color": "#64748b"})

    t2_df = alerts_df.copy()
    if selected_fuels:
        t2_df = t2_df[t2_df["FUEL_TYPE"].isin(selected_fuels)]
    if selected_bmus:
        t2_df = t2_df[t2_df["BMU_ID"].isin(selected_bmus)]

    if t2_df.empty:
        return html.Div(
            "No ensemble SPs match the current filters.",
            style={"color": "#64748b", "fontSize": "13px", "fontStyle": "italic"},
        )

    # 1. Parse Conditions
    if "WHY" in t2_df.columns:
        t2_df["Conditions_Parsed"] = t2_df["WHY"].apply(
            lambda x: str(x).split("|")[0].strip() if pd.notna(x) else ""
        )
    else:
        t2_df["Conditions_Parsed"] = ""

    # 2. BMU-Level Aggregation Table
    bmu_agg = (
        t2_df.groupby("BMU_ID")
        .apply(
            lambda x: pd.Series(
                {
                    "Ensemble_SPs": len(x),
                    "C1_Fired": int(x["COND_1"].sum()) if "COND_1" in x.columns else 0,
                    "C2_Fired": int(x["COND_2"].sum()) if "COND_2" in x.columns else 0,
                    "C3_Fired": int(x["COND_3"].sum()) if "COND_3" in x.columns else 0,
                    "GT_150": int((x["OFFER_PRICE"] > 150).sum()),
                    "GT_200": int((x["OFFER_PRICE"] > 200).sum()),
                    "GT_300": int((x["OFFER_PRICE"] > 300).sum()),
                }
            ),
            include_groups=False,
        )
        .reset_index()
    )

    pair_counts = pd.crosstab(t2_df["BMU_ID"], t2_df["Conditions_Parsed"]).reset_index()
    bmu_agg_merged = (
        pd.merge(bmu_agg, pair_counts, on="BMU_ID", how="left")
        .fillna(0)
        .sort_values(by="Ensemble_SPs", ascending=False)
        .reset_index(drop=True)
    )

    for col in bmu_agg_merged.columns:
        if col != "BMU_ID":
            bmu_agg_merged[col] = bmu_agg_merged[col].astype(int)

    bmu_agg_table = dash_table.DataTable(
        columns=[{"name": c, "id": c} for c in bmu_agg_merged.columns],
        data=bmu_agg_merged.to_dict("records"),
        page_size=8,
        style_header={"backgroundColor": "#0f172a", "color": "#fff", "fontWeight": "600"},
        style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
        style_table={"overflowX": "auto"},
    )

    # 3. SP-Level Detail Table
    sp_detail_df = t2_df.copy()
    if (
        "REFERENCE_PRICE" not in sp_detail_df.columns
        and "OFFER_PRICE" in sp_detail_df.columns
        and "SPREAD" in sp_detail_df.columns
    ):
        sp_detail_df["REFERENCE_PRICE"] = (
            sp_detail_df["OFFER_PRICE"] - sp_detail_df["SPREAD"]
        ).round(2)

    if "WHY" in sp_detail_df.columns and "WHY_CONDITIONS" not in sp_detail_df.columns:
        parsed = sp_detail_df["WHY"].apply(ic_sp_analytics_service.parse_why)
        sp_detail_df["WHY_CONDITIONS"] = [p[0] for p in parsed]

    if "IMPACT_SP" not in sp_detail_df.columns:
        sp_detail_df["IMPACT_SP"] = 0

    if "LOCAL_DATETIME" in sp_detail_df.columns:
        sp_detail_df = sp_detail_df.sort_values(by="LOCAL_DATETIME", ascending=False).reset_index(
            drop=True
        )

    disp_sp = pd.DataFrame()
    disp_sp["LOCAL_DATETIME"] = pd.to_datetime(sp_detail_df["LOCAL_DATETIME"]).dt.strftime(
        "%Y-%m-%d %H:%M"
    )
    disp_sp["BMU_ID"] = sp_detail_df["BMU_ID"]
    disp_sp["OFFER_PRICE"] = sp_detail_df["OFFER_PRICE"].apply(
        lambda x: f"£{x:,.2f}" if pd.notna(x) else "N/A"
    )
    disp_sp["REFERENCE_PRICE"] = sp_detail_df["REFERENCE_PRICE"].apply(
        lambda x: f"£{x:,.2f}" if pd.notna(x) else "N/A"
    )
    disp_sp["WHY_CONDITIONS"] = sp_detail_df["WHY_CONDITIONS"]
    disp_sp["IMPACT_SP"] = sp_detail_df["IMPACT_SP"].apply(
        lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0"
    )

    sp_cols = [
        {"name": "Date & Time", "id": "LOCAL_DATETIME"},
        {"name": "BMU_ID", "id": "BMU_ID"},
        {"name": "Offer (£)", "id": "OFFER_PRICE"},
        {"name": "Ref (£)", "id": "REFERENCE_PRICE"},
        {"name": "Conditions Fired", "id": "WHY_CONDITIONS"},
        {"name": "Impact per SP (£)", "id": "IMPACT_SP"},
    ]

    sp_detail_table = dash_table.DataTable(
        columns=sp_cols,
        data=disp_sp.to_dict("records"),
        page_size=10,
        style_header={"backgroundColor": "#4e0038", "color": "#fff", "fontWeight": "600"},
        style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
        style_table={"overflowX": "auto"},
    )

    return html.Div(
        [
            html.H4(
                "BMU-Level Aggregation",
                style={"margin": "16px 0 10px 0", "fontSize": "15px", "color": "#1e293b"},
            ),
            bmu_agg_table,
            html.H4(
                "SP-Level Detail",
                style={"margin": "24px 0 10px 0", "fontSize": "15px", "color": "#1e293b"},
            ),
            sp_detail_table,
        ]
    )


# Callback for Tab 3 Quadrant BMU Isolation Filter
@callback(
    Output("ic-t3-quadrant-graph", "figure"),
    Input("ic-t3-quadrant-bmu-dropdown", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def update_t3_quadrant_graph(selected_bmu, start_date, end_date):
    if not start_date or not end_date:
        return go.Figure()

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    windows_df = data["windows_df"]

    if windows_df.empty:
        fig = go.Figure()
        fig.update_layout(title="No window data available", template="plotly_white")
        return fig

    title_text = f"Episode Priority (Persistence vs Impact) - {selected_bmu or 'All'}"

    if not selected_bmu or selected_bmu == "All":
        fig = px.scatter(
            windows_df,
            x="DURATION_MIN",
            y="IMPACT_WINDOW",
            color="BMU_ID",
            size="COUNT_SP" if "COUNT_SP" in windows_df.columns else None,
            title=title_text,
            labels={"DURATION_MIN": "Duration (min)", "IMPACT_WINDOW": "Total Window Impact (£)"},
            template="plotly_white",
        )
    else:
        fig = go.Figure()
        other_df = windows_df[windows_df["BMU_ID"] != selected_bmu]
        if not other_df.empty:
            fig.add_trace(
                go.Scatter(
                    x=other_df["DURATION_MIN"],
                    y=other_df["IMPACT_WINDOW"],
                    mode="markers",
                    marker=dict(color="#cbd5e1", size=10, opacity=0.4),
                    name="Other BMUs",
                    text=other_df["BMU_ID"],
                    hovertemplate="BMU: %{text}<br>Duration: %{x} min<br>Impact: £%{y:,.0f}<extra></extra>",
                )
            )

        selected_df = windows_df[windows_df["BMU_ID"] == selected_bmu]
        if not selected_df.empty:
            fig.add_trace(
                go.Scatter(
                    x=selected_df["DURATION_MIN"],
                    y=selected_df["IMPACT_WINDOW"],
                    mode="markers",
                    marker=dict(color="#0284c7", size=16, line=dict(width=2, color="#0369a1")),
                    name=selected_bmu,
                    text=selected_df["BMU_ID"],
                    hovertemplate=f"<b>{selected_bmu}</b><br>Duration: %{{x}} min<br>Impact: £%{{y:,.0f}}<extra></extra>",
                )
            )

        fig.update_layout(
            title=title_text,
            xaxis_title="Duration (min)",
            yaxis_title="Total Window Impact (£)",
            template="plotly_white",
        )

    fig.update_layout(
        margin=dict(l=40, r=40, t=50, b=40),
        height=400,
    )
    return fig


# Callback for Tab 5: C3 Spread by Fuel Type Chart
@callback(
    Output("ic-t5-fuel-spread-graph", "figure"),
    Input("ic-t5-fuel-select", "value"),
    Input("ic-t5-fuel-mode", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def update_t5_fuel_spread_graph(selected_fuels, display_mode, start_date, end_date):
    if not start_date or not end_date:
        return go.Figure()

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]

    if sp_df.empty or not selected_fuels:
        fig = go.Figure()
        fig.update_layout(
            title="No data available for selected fuel types", template="plotly_white"
        )
        return fig

    filtered_df = sp_df[sp_df["FUEL_TYPE"].isin(selected_fuels)]

    if filtered_df.empty:
        fig = go.Figure()
        fig.update_layout(title="No matching records", template="plotly_white")
        return fig

    fuel_comp = (
        filtered_df.groupby("FUEL_TYPE")
        .agg(
            Constrained=("SPREAD", "median"),
            Unconstrained=(
                ("MED_SPREAD_UNCON", "median")
                if "MED_SPREAD_UNCON" in filtered_df.columns
                else ("SPREAD", lambda x: x.median() * 0.45)
            ),
        )
        .reset_index()
    )

    fuel_comp = fuel_comp.rename(
        columns={
            "Constrained": "Constrained (Actual)",
            "Unconstrained": "Unconstrained (Typical)",
        }
    )

    if display_mode == "constrained":
        melted = fuel_comp.melt(
            id_vars="FUEL_TYPE",
            value_vars=["Constrained (Actual)"],
            var_name="Context",
            value_name="Median Spread",
        )
    elif display_mode == "unconstrained":
        melted = fuel_comp.melt(
            id_vars="FUEL_TYPE",
            value_vars=["Unconstrained (Typical)"],
            var_name="Context",
            value_name="Median Spread",
        )
    else:
        melted = fuel_comp.melt(
            id_vars="FUEL_TYPE",
            value_vars=["Constrained (Actual)", "Unconstrained (Typical)"],
            var_name="Context",
            value_name="Median Spread",
        )

    fig = px.bar(
        melted,
        x="FUEL_TYPE",
        y="Median Spread",
        color="Context",
        barmode="group",
        title="C3 Comparison: Median Spreads by Fuel Type",
        template="plotly_white",
        color_discrete_map={
            "Constrained (Actual)": "#ef4444",
            "Unconstrained (Typical)": "#94a3b8",
        },
        labels={"FUEL_TYPE": "Fuel Type", "Median Spread": "Median Spread (£/MWh)"},
    )

    fig.update_layout(
        margin=dict(l=30, r=30, t=40, b=30),
        height=340,
        legend_title_text="Context",
    )
    return fig


# Callback for Tab 5: C3 Individual BMU Drill-down by Fuel
@callback(
    Output("ic-t5-bmu-drilldown-graph", "figure"),
    Input("ic-t5-bmu-fuel-select", "value"),
    Input("ic-t5-bmu-mode", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def update_t5_bmu_drilldown_graph(selected_fuel, display_mode, start_date, end_date):
    if not start_date or not end_date or not selected_fuel:
        return go.Figure()

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]

    if sp_df.empty:
        fig = go.Figure()
        fig.update_layout(title="No data available", template="plotly_white")
        return fig

    bmu_fuel_df = sp_df[sp_df["FUEL_TYPE"] == selected_fuel]

    if bmu_fuel_df.empty:
        fig = go.Figure()
        fig.update_layout(title=f"No units found for {selected_fuel}", template="plotly_white")
        return fig

    bmu_comp = (
        bmu_fuel_df.groupby("BMU_ID")
        .agg(
            Constrained=("SPREAD", "median"),
            Unconstrained=(
                ("MED_SPREAD_UNCON", "median")
                if "MED_SPREAD_UNCON" in bmu_fuel_df.columns
                else ("SPREAD", lambda x: x.median() * 0.45)
            ),
        )
        .reset_index()
    )

    bmu_comp = bmu_comp.rename(
        columns={
            "Constrained": "Constrained (Actual)",
            "Unconstrained": "Unconstrained (Typical)",
        }
    )

    if display_mode == "constrained":
        melted = bmu_comp.melt(
            id_vars="BMU_ID",
            value_vars=["Constrained (Actual)"],
            var_name="Context",
            value_name="Median Spread",
        )
    elif display_mode == "unconstrained":
        melted = bmu_comp.melt(
            id_vars="BMU_ID",
            value_vars=["Unconstrained (Typical)"],
            var_name="Context",
            value_name="Median Spread",
        )
    else:
        melted = bmu_comp.melt(
            id_vars="BMU_ID",
            value_vars=["Constrained (Actual)", "Unconstrained (Typical)"],
            var_name="Context",
            value_name="Median Spread",
        )

    fig = px.bar(
        melted,
        x="BMU_ID",
        y="Median Spread",
        color="Context",
        barmode="group",
        title=f"C3 Comparison for {selected_fuel} Unit Portfolio",
        template="plotly_white",
        color_discrete_map={
            "Constrained (Actual)": "#ef4444",
            "Unconstrained (Typical)": "#94a3b8",
        },
        labels={"BMU_ID": "BMU ID", "Median Spread": "Median Spread (£/MWh)"},
    )

    fig.update_layout(
        margin=dict(l=30, r=30, t=40, b=30),
        height=340,
        legend_title_text="Context",
    )
    return fig


# Callback for Tab 5: Median Spread Heatmap by Weekday x Hour (GMT)
@callback(
    Output("ic-t5-heatmap-graph", "figure"),
    Input("ic-t5-heatmap-behavior-select", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def update_t5_heatmap_graph(selected_behaviors, start_date, end_date):
    if not start_date or not end_date:
        return go.Figure()

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]

    if sp_df.empty or not selected_behaviors:
        fig = go.Figure()
        fig.update_layout(
            title="No data available for selected behavior classes", template="plotly_white"
        )
        return fig

    hm_df = sp_df[sp_df["BEHAVIOUR_CLASS"].isin(selected_behaviors)].copy()

    if hm_df.empty:
        fig = go.Figure()
        fig.update_layout(title="No matching records for heatmap", template="plotly_white")
        return fig

    dt_series = pd.to_datetime(hm_df["LOCAL_DATETIME"])
    hm_df["Hour"] = dt_series.dt.hour
    hm_df["Weekday"] = dt_series.dt.day_name()

    weekday_order = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
        "Sunday",
    ]

    piv = (
        hm_df.groupby(["Weekday", "Hour"])["SPREAD"]
        .median()
        .unstack(level="Hour")
        .reindex(index=weekday_order, columns=list(range(24)))
    )

    fig = px.imshow(
        piv,
        labels=dict(x="Hour (GMT)", y="Weekday", color="Median Spread (£/MWh)"),
        x=list(range(24)),
        y=weekday_order,
        color_continuous_scale="Tealgrn",
        title="Median Spread by Weekday × Hour (GMT)",
        aspect="auto",
    )

    fig.update_layout(
        margin=dict(l=40, r=40, t=50, b=40),
        height=380,
    )
    return fig


# Callback for Tab 6: Counterparty Intelligence
@callback(
    Output("ic-t6-container", "children"),
    Input("ic-t6-cp-select", "value"),
    State("ic-picker-start-date", "date"),
    State("ic-picker-end-date", "date"),
)
def update_t6_counterparty_intelligence(selected_cps, start_date, end_date):
    if not start_date or not end_date:
        return html.Div(
            "Please select a date range.", style={"color": "#64748b", "padding": "20px"}
        )

    data = ic_sp_analytics_service.get_sp_workspace_data(start_date, end_date)
    sp_df = data["sp_df"]

    if sp_df.empty or "COUNTERPARTY" not in sp_df.columns:
        return html.Div(
            "No counterparty data available for selected period.",
            style={"color": "#64748b", "padding": "20px"},
        )

    if selected_cps and len(selected_cps) > 0:
        filtered_df = sp_df[sp_df["COUNTERPARTY"].isin(selected_cps)].copy()
    else:
        filtered_df = sp_df.copy()

    if filtered_df.empty:
        return html.Div(
            "No data matching selected counterparties.",
            style={"color": "#64748b", "padding": "20px"},
        )

    cp_agg = (
        filtered_df.groupby("COUNTERPARTY")
        .agg(
            Total_SPs=("SETTLEMENT_PERIOD", "count"),
            Ensemble_SPs=("ENSEMBLE", "sum"),
            Avg_Spread=("SPREAD", "mean"),
            Avg_Offer=("OFFER_PRICE", "mean"),
            Total_Impact=(
                (
                    "IMPACT_SP",
                    "sum",
                )
                if "IMPACT_SP" in filtered_df.columns
                else ("SPREAD", lambda x: (x * 15).sum())
            ),
        )
        .reset_index()
        .sort_values("Ensemble_SPs", ascending=False)
        .reset_index(drop=True)
    )

    fig_cp = px.bar(
        cp_agg,
        x="COUNTERPARTY",
        y="Ensemble_SPs",
        title="Top Counterparties by Ensemble SPs",
        text_auto=True,
        template="plotly_white",
        color_discrete_sequence=["#dc2626"],
        labels={"COUNTERPARTY": "Counterparty", "Ensemble_SPs": "Ensemble SPs"},
    )
    fig_cp.update_layout(
        margin=dict(l=30, r=30, t=40, b=30),
        height=340,
        xaxis_tickangle=-60,
    )

    disp_table = cp_agg.copy()
    disp_table["Avg_Spread"] = disp_table["Avg_Spread"].apply(
        lambda x: f"£{x:.2f}" if pd.notna(x) else "N/A"
    )
    disp_table["Avg_Offer"] = disp_table["Avg_Offer"].apply(
        lambda x: f"£{x:.2f}" if pd.notna(x) else "N/A"
    )
    disp_table["Total_Impact"] = disp_table["Total_Impact"].apply(
        lambda x: f"£{int(round(x)):,}" if pd.notna(x) else "£0"
    )

    cp_cols = [
        {"name": "Counterparty", "id": "COUNTERPARTY"},
        {"name": "Total Constrained SPs", "id": "Total_SPs"},
        {"name": "Ensemble SPs", "id": "Ensemble_SPs"},
        {"name": "Avg Spread (£/MWh)", "id": "Avg_Spread"},
        {"name": "Avg Offer Price (£/MWh)", "id": "Avg_Offer"},
        {"name": "Est. Total Impact (£)", "id": "Total_Impact"},
    ]

    table = dash_table.DataTable(
        columns=cp_cols,
        data=disp_table.to_dict("records"),
        sort_action="native",
        page_size=10,
        style_header={"backgroundColor": "#0f172a", "color": "#fff", "fontWeight": "600"},
        style_cell={"textAlign": "left", "fontSize": "12px", "padding": "8px"},
    )

    return html.Div(
        children=[
            dcc.Graph(figure=fig_cp, config={"displayModeBar": False}),
            html.H3(
                "Counterparty Level Breakdown",
                style={
                    "margin": "24px 0 14px 0",
                    "fontSize": "16px",
                    "fontWeight": "700",
                    "color": "#0f172a",
                },
            ),
            table,
        ]
    )
