import dash
from dash import dcc, html, Input, Output, State, callback

dash.register_page(
    __name__,
    path="/",
    title="Market Monitoring Platform",
)

ANALYST_OPTIONS = [
    {"label": "Analyst 1", "value": "Analyst 1"},
    {"label": "Analyst 2", "value": "Analyst 2"},
    {"label": "Analyst 3", "value": "Analyst 3"},
]

layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "100%",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#eef2f6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        # 1. Top Header Row (NESO Logo, Title, Analyst Dropdown)
        html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "280px 1fr 320px",
                "gap": "24px",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                # Direct NESO Logo Image (No outer padded box container)
                html.Img(
                    src="/assets/logo.jpg",
                    alt="NESO Logo",
                    style={
                        "height": "76px",
                        "width": "100%",
                        "objectFit": "contain",
                        "borderRadius": "8px",
                    },
                ),
                # Central Title Box
                html.Div(
                    style={
                        "backgroundColor": "#f3e8ff",
                        "border": "2px solid #4e0038",
                        "borderRadius": "8px",
                        "padding": "18px 28px",
                        "textAlign": "center",
                    },
                    children=[
                        html.H1(
                            "Market Monitoring Platform",
                            style={
                                "margin": "0",
                                "color": "#4e0038",
                                "fontSize": "26px",
                                "fontWeight": "700",
                                "letterSpacing": "0.5px",
                            },
                        )
                    ],
                ),
                # Right Analyst Dropdown Box
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "border": "1px solid #cbd5e1",
                        "borderRadius": "8px",
                        "padding": "14px 18px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.05)",
                    },
                    children=[
                        html.Label(
                            "Select Analyst Context:",
                            style={
                                "display": "block",
                                "fontSize": "12px",
                                "fontWeight": "700",
                                "color": "#64748b",
                                "textTransform": "uppercase",
                                "marginBottom": "6px",
                                "letterSpacing": "0.5px",
                            },
                        ),
                        dcc.Dropdown(
                            id="landing-analyst-select",
                            options=ANALYST_OPTIONS,
                            placeholder="Choose Analyst...",
                            clearable=True,
                            style={"fontSize": "14px"},
                        ),
                    ],
                ),
            ],
        ),
        # 2. Welcome Banner Bar
        html.Div(
            style={
                "backgroundColor": "#4e0038",
                "color": "#ffffff",
                "borderRadius": "8px",
                "padding": "20px 32px",
                "marginBottom": "28px",
                "display": "flex",
                "alignItems": "center",
                "justifyContent": "center",
                "gap": "14px",
                "boxShadow": "0 2px 6px rgba(0,0,0,0.1)",
            },
            children=[
                html.Span(
                    "Welcome :",
                    style={
                        "fontSize": "22px",
                        "fontWeight": "500",
                        "letterSpacing": "0.4px",
                    },
                ),
                html.Div(
                    id="landing-welcome-name-pill",
                    style={
                        "backgroundColor": "#0284c7",
                        "color": "#ffffff",
                        "padding": "8px 24px",
                        "borderRadius": "6px",
                        "fontWeight": "700",
                        "fontSize": "18px",
                        "minWidth": "180px",
                        "textAlign": "center",
                        "letterSpacing": "0.5px",
                    },
                    children="Select Analyst",
                ),
            ],
        ),
        # Guardrail Warning Alert (hidden by default)
        html.Div(
            id="landing-guardrail-warning",
            style={"display": "none", "marginBottom": "20px"},
        ),
        # 3. Main Content Cards (Two Columns: Workstream & Rota)
        html.Div(
            style={
                "display": "grid",
                "gridTemplateColumns": "1fr 1fr",
                "gap": "28px",
                "alignItems": "start",
            },
            children=[
                # Column 1: Workstream Selection
                html.Div(
                    style={
                        "backgroundColor": "#800060",
                        "borderRadius": "12px",
                        "padding": "32px",
                        "boxShadow": "0 4px 12px rgba(0,0,0,0.15)",
                    },
                    children=[
                        html.Div(
                            style={
                                "backgroundColor": "#f3e8ff",
                                "borderRadius": "6px",
                                "padding": "14px 20px",
                                "marginBottom": "24px",
                                "textAlign": "center",
                            },
                            children=[
                                html.H2(
                                    "Workstream:",
                                    style={
                                        "margin": "0",
                                        "color": "#4e0038",
                                        "fontSize": "22px",
                                        "fontWeight": "700",
                                    },
                                )
                            ],
                        ),
                        html.Div(
                            style={
                                "display": "flex",
                                "flexDirection": "column",
                                "gap": "16px",
                            },
                            children=[
                                # Disabled Planned Workstreams
                                html.Button(
                                    "UMM (Planned)",
                                    id="btn-ws-umm",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "6px",
                                        "fontSize": "17px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                                html.Button(
                                    "TCLC (Planned)",
                                    id="btn-ws-tclc",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "6px",
                                        "fontSize": "17px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                                html.Button(
                                    "IOLC (Planned)",
                                    id="btn-ws-iolc",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "6px",
                                        "fontSize": "17px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                                html.Button(
                                    "IC (Planned)",
                                    id="btn-ws-ic",
                                    disabled=True,
                                    className="btn-ws-disabled",
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "16px",
                                        "borderRadius": "6px",
                                        "fontSize": "17px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                                # Operational Workstream Button
                                html.Button(
                                    "Import Constraints",
                                    id="btn-ws-import-constraints",
                                    n_clicks=0,
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "20px",
                                        "borderRadius": "6px",
                                        "fontSize": "19px",
                                        "fontWeight": "700",
                                        "cursor": "pointer",
                                        "boxShadow": "0 4px 8px rgba(0,0,0,0.2)",
                                        "transition": "all 0.2s ease",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
                # Column 2: Rota & Administration
                html.Div(
                    style={
                        "backgroundColor": "#800060",
                        "borderRadius": "12px",
                        "padding": "32px",
                        "boxShadow": "0 4px 12px rgba(0,0,0,0.15)",
                    },
                    children=[
                        html.Div(
                            style={
                                "backgroundColor": "#f3e8ff",
                                "borderRadius": "6px",
                                "padding": "14px 20px",
                                "marginBottom": "24px",
                                "textAlign": "center",
                            },
                            children=[
                                html.H2(
                                    "Rota:",
                                    style={
                                        "margin": "0",
                                        "color": "#4e0038",
                                        "fontSize": "22px",
                                        "fontWeight": "700",
                                    },
                                )
                            ],
                        ),
                        html.Div(
                            style={
                                "display": "flex",
                                "flexDirection": "column",
                                "gap": "20px",
                            },
                            children=[
                                html.Button(
                                    "Rota for this week (Planned)",
                                    id="btn-rota-this-week",
                                    disabled=True,
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "22px",
                                        "borderRadius": "6px",
                                        "fontSize": "18px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                                html.Button(
                                    "Admin Page (Planned)",
                                    id="btn-admin-page",
                                    disabled=True,
                                    style={
                                        "backgroundColor": "#0284c7",
                                        "opacity": "0.55",
                                        "color": "#ffffff",
                                        "border": "none",
                                        "padding": "26px",
                                        "borderRadius": "6px",
                                        "fontSize": "19px",
                                        "fontWeight": "600",
                                        "cursor": "not-allowed",
                                    },
                                ),
                            ],
                        ),
                    ],
                ),
            ],
        ),
    ],
)


@callback(
    Output("selected-analyst-store", "data", allow_duplicate=True),
    Output("landing-welcome-name-pill", "children"),
    Output("landing-welcome-name-pill", "style"),
    Input("landing-analyst-select", "value"),
    prevent_initial_call="initial_duplicate",
)
def update_welcome_pill(analyst_name):
    if analyst_name:
        style_active = {
            "backgroundColor": "#10b981",
            "color": "#ffffff",
            "padding": "8px 24px",
            "borderRadius": "6px",
            "fontWeight": "700",
            "fontSize": "18px",
            "minWidth": "180px",
            "textAlign": "center",
            "letterSpacing": "0.5px",
        }
        return analyst_name, analyst_name, style_active

    style_default = {
        "backgroundColor": "#0284c7",
        "color": "#ffffff",
        "padding": "8px 24px",
        "borderRadius": "6px",
        "fontWeight": "700",
        "fontSize": "18px",
        "minWidth": "180px",
        "textAlign": "center",
        "letterSpacing": "0.5px",
    }
    return None, "Select Analyst", style_default


@callback(
    Output("landing-analyst-select", "value"),
    Input("selected-analyst-store", "data"),
    State("landing-analyst-select", "value"),
)
def initialize_analyst_from_store(stored_analyst, current_val):
    if stored_analyst and not current_val:
        return stored_analyst
    return dash.no_update


@callback(
    Output("landing-guardrail-warning", "children"),
    Output("landing-guardrail-warning", "style"),
    Output("url", "pathname", allow_duplicate=True),
    Input("btn-ws-import-constraints", "n_clicks"),
    State("landing-analyst-select", "value"),
    State("selected-analyst-store", "data"),
    prevent_initial_call=True,
)
def navigate_to_import_constraints(n_clicks, analyst_dropdown_val, stored_analyst):
    if not n_clicks:
        return dash.no_update, dash.no_update, dash.no_update

    effective_analyst = analyst_dropdown_val or stored_analyst

    if not effective_analyst:
        alert_box = html.Div(
            style={
                "backgroundColor": "#fef2f2",
                "border": "1px solid #fca5a5",
                "borderRadius": "6px",
                "padding": "12px 18px",
                "color": "#991b1b",
                "fontSize": "14px",
                "fontWeight": "600",
                "display": "flex",
                "alignItems": "center",
                "gap": "8px",
            },
            children=[
                html.Span("⚠️ Guardrail Enforced:"),
                html.Span(
                    "Please select an Analyst from the top dropdown before accessing the operational workspace."
                ),
            ],
        )
        return alert_box, {"display": "block", "marginBottom": "20px"}, dash.no_update

    # Analyst is selected -> navigate to operational alert review workspace
    return dash.no_update, {"display": "none"}, "/alert-review"
