import urllib.parse
import dash
from dash import dash_table, dcc, html, Input, Output, callback
import pandas as pd

from src.charts.analytics_charts import (
    build_conditions_timeline,
    build_price_comparison_chart,
    build_spread_chart,
)
from src.services import alert_service, ic_analytics_service
from src.utils.bmrs_links import get_bmrs_bmu_url, get_bmrs_remit_url

dash.register_page(
    __name__, path="/analytical-support", title="Analytical Support - Market Monitoring Platform"
)

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Segoe UI, sans-serif"},
    children=[
        dcc.Location(id="url-analytical-support", refresh=False),
        html.Div(id="analytical-support-main-content"),
    ],
)


@callback(
    Output("analytical-support-main-content", "children"),
    Input("url-analytical-support", "search"),
)
def render_analytical_support_page(search_query):
    # Parse query parameters
    parsed = urllib.parse.parse_qs(search_query.lstrip("?")) if search_query else {}
    unique_ids = parsed.get("unique_id")

    # Mode 1: Workstream Selection Landing Page (No unique_id)
    if not unique_ids:
        return html.Div(
            children=[
                # Header
                html.Div(
                    style={
                        "marginBottom": "20px",
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "center",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.H2(
                                    "Investigation Intelligence & Analytical Support",
                                    className="neso-page-title",
                                ),
                                html.P(
                                    "Choose a monitoring workstream to access portfolio-wide intelligence workspaces.",
                                    className="neso-page-subtitle",
                                ),
                            ]
                        ),
                        html.A(
                            "← Back to Alert Review Queue",
                            href="/alert-review",
                            className="btn-neso-primary",
                            style={
                                "textDecoration": "none",
                                "fontSize": "13px",
                            },
                        ),
                    ],
                ),
                # Workstream Selection Cards
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.Div(
                            style={"marginBottom": "20px"},
                            children=[
                                html.H3(
                                    "Select Analytical Workstream",
                                    style={
                                        "color": "#4e0038",
                                        "margin": "0 0 6px 0",
                                    },
                                ),
                                html.P(
                                    "Portfolio-wide analytics, behavioral taxonomy, and detection condition diagnostics.",
                                    style={
                                        "color": "#64748b",
                                        "margin": "0",
                                        "fontSize": "14px",
                                    },
                                ),
                            ],
                        ),
                        html.Div(
                            style={
                                "display": "grid",
                                "gridTemplateColumns": ("repeat(auto-fit, minmax(280px, 1fr))"),
                                "gap": "20px",
                            },
                            children=[
                                # Card 1: Import Constraints (Active)
                                html.Div(
                                    style={
                                        "backgroundColor": "#ffffff",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "boxShadow": ("0 1px 3px rgba(0,0,0,0.1)"),
                                        "border": "1px solid #e2e8f0",
                                        "borderTop": "4px solid #4e0038",
                                        "display": "flex",
                                        "flexDirection": "column",
                                        "justifyContent": "space-between",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.H4(
                                                    "Import Constraints",
                                                    style={
                                                        "margin": "0 0 8px 0",
                                                        "color": "#1e293b",
                                                    },
                                                ),
                                                html.P(
                                                    "System-wide constraint landscape, ensemble SP diagnostics, window inference, and BMU deep dives.",
                                                    style={
                                                        "fontSize": "13px",
                                                        "color": "#64748b",
                                                        "lineHeight": "1.5",
                                                    },
                                                ),
                                            ]
                                        ),
                                        html.A(
                                            "Open Import Constraints Workspace →",
                                            href="/import-constraints-workspace",
                                            className="btn-neso-primary",
                                            style={
                                                "textDecoration": "none",
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "textAlign": "center",
                                                "fontSize": "13px",
                                            },
                                        ),
                                    ],
                                ),
                                # Card 2: TBC
                                html.Div(
                                    style={
                                        "backgroundColor": "#f8fafc",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "border": "1px dashed #cbd5e1",
                                        "opacity": "0.7",
                                    },
                                    children=[
                                        html.H4(
                                            "TBC",
                                            style={
                                                "margin": "0 0 8px 0",
                                                "color": "#94a3b8",
                                            },
                                        ),
                                        html.P(
                                            "Workstream analytics TBC",
                                            style={
                                                "fontSize": "13px",
                                                "color": "#94a3b8",
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                        html.Span(
                                            "Workstream Pending",
                                            style={
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "padding": "4px 10px",
                                                "backgroundColor": "#e2e8f0",
                                                "color": "#64748b",
                                                "borderRadius": "4px",
                                                "fontSize": "11px",
                                                "fontWeight": "600",
                                            },
                                        ),
                                    ],
                                ),
                                # Card 3: TBC
                                html.Div(
                                    style={
                                        "backgroundColor": "#f8fafc",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "border": "1px dashed #cbd5e1",
                                        "opacity": "0.7",
                                    },
                                    children=[
                                        html.H4(
                                            "TBC",
                                            style={
                                                "margin": "0 0 8px 0",
                                                "color": "#94a3b8",
                                            },
                                        ),
                                        html.P(
                                            "Workstream Analytics TBC",
                                            style={
                                                "fontSize": "13px",
                                                "color": "#94a3b8",
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                        html.Span(
                                            "Workstream Pending",
                                            style={
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "padding": "4px 10px",
                                                "backgroundColor": "#e2e8f0",
                                                "color": "#64748b",
                                                "borderRadius": "4px",
                                                "fontSize": "11px",
                                                "fontWeight": "600",
                                            },
                                        ),
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
            ]
        )

    # Mode 2: Per-Alert Investigation Deep Dive View
    unique_id = unique_ids[0]
    alert = alert_service.get_alert_by_id(unique_id)

    if not alert:
        return html.Div(
            f"Alert with UNIQUE_ID '{unique_id}' could not be found in database.",
            style={"color": "#dc2626", "padding": "20px"},
        )

    bmu_id = alert["BMU_ID"]

    payload = ic_analytics_service.get_alert_evidence_payload(
        bmu_id=bmu_id,
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
    )

    records = payload["sp_records"]
    metrics = payload["metrics"]
    info_for_analyst = payload["info_for_analyst"]

    # Alert summary banner
    banner = html.Div(
        style={
            "backgroundColor": "#ffffff",
            "padding": "20px",
            "borderRadius": "8px",
            "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
            "marginBottom": "20px",
        },
        children=[
            html.H3(
                (f"BMU: {bmu_id} " f"({alert.get('COUNTERPARTY') or 'Unknown Party'})"),
                style={
                    "margin": "0 0 8px 0",
                    "color": "#4e0038",
                },
            ),
            html.Div(
                style={
                    "fontSize": "13px",
                    "color": "#334155",
                    "display": "flex",
                    "gap": "20px",
                    "flexWrap": "wrap",
                },
                children=[
                    html.Span(
                        (
                            f"Alert Window: {alert.get('START_LOCAL')} "
                            f"to {alert.get('END_LOCAL')}"
                        )
                    ),
                    html.Span(
                        (
                            f"Duration: {alert.get('DURATION_MIN')} mins "
                            f"({alert.get('COUNT_SP')} SPs)"
                        )
                    ),
                    html.Span(f"Fuel: {alert.get('FUEL_TYPE')}"),
                    html.Span(
                        ("Review Status: " f"{alert.get('DISPLAY_STATUS')}"),
                        style={"fontWeight": "600"},
                    ),
                ],
            ),
            html.Div(
                style={
                    "marginTop": "10px",
                    "backgroundColor": "#f8fafc",
                    "padding": "10px",
                    "borderRadius": "6px",
                    "border": "1px solid #e2e8f0",
                },
                children=[
                    html.Strong(
                        "System Explanation (INFO_FOR_ANALYST): ",
                        style={
                            "fontSize": "13px",
                            "color": "#1e293b",
                        },
                    ),
                    html.Span(
                        (info_for_analyst or "No specific breach explanation flags"),
                        style={
                            "fontSize": "13px",
                            "color": "#475569",
                        },
                    ),
                ],
            ),
        ],
    )

    # KPI cards
    kpi_cards = html.Div(
        style={
            "display": "grid",
            "gridTemplateColumns": ("repeat(auto-fit, minmax(200px, 1fr))"),
            "gap": "16px",
            "marginBottom": "20px",
        },
        children=[
            html.Div(
                style={
                    "backgroundColor": "#f1f5f9",
                    "padding": "14px",
                    "borderRadius": "6px",
                    "borderLeft": "4px solid #0284c7",
                },
                children=[
                    html.Div(
                        "Avg Offer Price",
                        style={
                            "fontSize": "12px",
                            "color": "#64748b",
                            "fontWeight": "600",
                        },
                    ),
                    html.Div(
                        f"£{metrics['avg_offer_price']:.2f}",
                        style={
                            "fontSize": "20px",
                            "fontWeight": "700",
                            "color": "#0f172a",
                        },
                    ),
                ],
            ),
            html.Div(
                style={
                    "backgroundColor": "#f1f5f9",
                    "padding": "14px",
                    "borderRadius": "6px",
                    "borderLeft": "4px solid #16a34a",
                },
                children=[
                    html.Div(
                        "Avg Reference Price",
                        style={
                            "fontSize": "12px",
                            "color": "#64748b",
                            "fontWeight": "600",
                        },
                    ),
                    html.Div(
                        f"£{metrics['avg_ref_price']:.2f}",
                        style={
                            "fontSize": "20px",
                            "fontWeight": "700",
                            "color": "#0f172a",
                        },
                    ),
                ],
            ),
            html.Div(
                style={
                    "backgroundColor": "#f1f5f9",
                    "padding": "14px",
                    "borderRadius": "6px",
                    "borderLeft": "4px solid #ff7f0e",
                },
                children=[
                    html.Div(
                        "Avg Spread",
                        style={
                            "fontSize": "12px",
                            "color": "#64748b",
                            "fontWeight": "600",
                        },
                    ),
                    html.Div(
                        f"£{metrics['avg_spread']:.2f}",
                        style={
                            "fontSize": "20px",
                            "fontWeight": "700",
                            "color": "#0f172a",
                        },
                    ),
                ],
            ),
            html.Div(
                style={
                    "backgroundColor": "#fee2e2",
                    "padding": "14px",
                    "borderRadius": "6px",
                    "borderLeft": "4px solid #dc2626",
                },
                children=[
                    html.Div(
                        "Est. Financial Impact",
                        style={
                            "fontSize": "12px",
                            "color": "#991b1b",
                            "fontWeight": "600",
                        },
                    ),
                    html.Div(
                        f"£{metrics['total_estimated_impact']:,.2f}",
                        style={
                            "fontSize": "20px",
                            "fontWeight": "700",
                            "color": "#991b1b",
                        },
                    ),
                ],
            ),
        ],
    )

    fig_price = build_price_comparison_chart(records)
    fig_spread = build_spread_chart(records)

    charts_grid = html.Div(
        style={
            "display": "grid",
            "gridTemplateColumns": ("repeat(auto-fit, minmax(400px, 1fr))"),
            "gap": "20px",
            "marginBottom": "20px",
        },
        children=[
            html.Div(
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "16px",
                    "borderRadius": "8px",
                    "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                },
                children=[
                    dcc.Graph(
                        figure=fig_price,
                        responsive=True,
                    )
                ],
            ),
            html.Div(
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "16px",
                    "borderRadius": "8px",
                    "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                },
                children=[
                    dcc.Graph(
                        figure=fig_spread,
                        responsive=True,
                    )
                ],
            ),
        ],
    )

    sp_cols = [
        {
            "name": "Settlement Date",
            "id": "SETTLEMENT_DATE",
        },
        {
            "name": "SP",
            "id": "SETTLEMENT_PERIOD",
        },
        {
            "name": "Time (Local)",
            "id": "LOCAL_DATETIME",
        },
        {
            "name": "Offer Price (£)",
            "id": "OFFER_PRICE",
        },
        {
            "name": "Ref Price (£)",
            "id": "REFERENCE_PRICE",
        },
        {
            "name": "Spread (£)",
            "id": "SPREAD",
        },
        {
            "name": "Accepted Vol (MWh)",
            "id": "ACCEPTED_VOL_MWH",
        },
        {
            "name": "Ensemble Flag",
            "id": "ENSEMBLE",
        },
        {
            "name": "Est. Impact (£)",
            "id": "IMPACT_SP",
        },
        {
            "name": "WHY Flag",
            "id": "WHY",
        },
    ]

    sp_table = dash_table.DataTable(
        columns=sp_cols,
        data=records,
        style_table={
            "overflowX": "auto",
        },
        style_header={
            "backgroundColor": "#0f172a",
            "color": "#ffffff",
            "fontWeight": "600",
            "padding": "10px",
            "fontSize": "12px",
        },
        style_cell={
            "textAlign": "left",
            "padding": "8px",
            "fontSize": "12px",
            "fontFamily": "Segoe UI, sans-serif",
        },
        style_data_conditional=[
            {
                "if": {
                    "column_id": "ENSEMBLE",
                    "filter_query": "{ENSEMBLE} eq 1",
                },
                "backgroundColor": "#fee2e2",
                "color": "#991b1b",
                "fontWeight": "600",
            }
        ],
        page_size=10,
    )

    evidence_table_card = html.Div(
        style={
            "backgroundColor": "#ffffff",
            "padding": "20px",
            "borderRadius": "8px",
            "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
            "marginBottom": "20px",
        },
        children=[
            html.H3(
                "Settlement Period Level Analytical Evidence",
                style={
                    "margin": "0 0 14px 0",
                    "fontSize": "16px",
                    "color": "#1e293b",
                },
            ),
            sp_table,
        ],
    )

    return html.Div(
        children=[
            # Focused investigation header.
            # The original Alert Review page remains open in its own tab.
            html.Div(
                style={
                    "marginBottom": "20px",
                },
                children=[
                    html.H2(
                        f"Alert Investigation: {unique_id}",
                        className="neso-page-title",
                    ),
                    html.P(
                        (
                            "Settlement-period breakdown, price and spread "
                            "charts, and breach-condition explanations."
                        ),
                        className="neso-page-subtitle",
                    ),
                ],
            ),
            banner,
            kpi_cards,
            evidence_table_card,
            charts_grid,
        ]
    )
