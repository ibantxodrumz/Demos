from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from src.services import alert_service, ic_sp_analytics_service


def get_long_run_counterparty_stats(
    start_date: str,
    end_date: str,
    threshold_volume: int = 5,
    threshold_impact_gbp: float = 50000.0,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Calculates long-run counterparty statistics using ensemble settlement
    periods for alert volume and financial impact, and consolidated alert
    windows for window-level metrics.
    """

    # Review metadata remains sourced from IMPORT_ALERTS joined to ACTIVITY_LOG.
    review_result = alert_service.get_alerts_for_period(
        start_date=start_date,
        end_date=end_date,
        bmu_filter=bmu_filter,
        party_filter=party_filter,
        fuel_filter=fuel_filter,
        status_filter="All",
        db_path=db_path,
    )

    review_alerts = review_result["alerts"]

    # Use the Analytical Support dataset as the authoritative source for:
    # - ensemble SP alert volume
    # - consolidated alert windows
    # - estimated financial impact
    sp_workspace = ic_sp_analytics_service.get_sp_workspace_data(
        start_date=start_date,
        end_date=end_date,
        db_path=db_path,
    )

    ensemble_df = sp_workspace["alerts_df"].copy()
    windows_df = sp_workspace["windows_df"].copy()

    # Apply identical filters to ensemble SPs and consolidated windows.
    if bmu_filter:
        ensemble_df = ensemble_df[ensemble_df["BMU_ID"] == bmu_filter]
        windows_df = windows_df[windows_df["BMU_ID"] == bmu_filter]

    if party_filter:
        ensemble_df = ensemble_df[ensemble_df["COUNTERPARTY"] == party_filter]
        windows_df = windows_df[windows_df["COUNTERPARTY"] == party_filter]

    if fuel_filter:
        ensemble_df = ensemble_df[ensemble_df["FUEL_TYPE"] == fuel_filter]
        windows_df = windows_df[windows_df["FUEL_TYPE"] == fuel_filter]

    filter_options = sp_workspace["filter_options"]

    if ensemble_df.empty:
        return {
            "summary": {
                "total_alerts": 0,
                "total_windows": 0,
                "total_parties": 0,
                "parties_exceeding_vol_threshold": 0,
                "parties_exceeding_gbp_threshold": 0,
                "parties_exceeding_both": 0,
                "top_breaching_party": "-",
                "total_duration_mins": 0,
                "total_sps": 0,
                "total_gbp_impact": 0.0,
            },
            "counterparties": [],
            "filter_options": {
                "bmus": filter_options.get("bmus", []),
                "parties": filter_options.get("parties", []),
                "fuels": filter_options.get("fuels", []),
            },
        }

    # Build review-status counts separately.
    review_groups: Dict[str, List[Dict[str, Any]]] = {}

    for alert in review_alerts:
        counterparty = alert.get("COUNTERPARTY") or "Unknown Party"
        review_groups.setdefault(counterparty, []).append(alert)

    stats_list = []

    exceeding_vol_cnt = 0
    exceeding_gbp_cnt = 0
    exceeding_both_cnt = 0

    for counterparty, party_ensemble_df in ensemble_df.groupby(
        "COUNTERPARTY",
        dropna=False,
    ):
        counterparty_name = counterparty if counterparty is not None else "Unknown Party"

        party_windows_df = windows_df[windows_df["COUNTERPARTY"] == counterparty]

        party_review_alerts = review_groups.get(
            counterparty_name,
            [],
        )

        # Volume is the number of ensemble settlement periods.
        total_alerts = len(party_ensemble_df)

        # Windows are consecutive ensemble SPs grouped into episodes.
        total_windows = len(party_windows_df)

        # Impact uses the same IMPACT_SP methodology as Analytical Support.
        total_gbp_impact = float(party_ensemble_df["IMPACT_SP"].sum())

        # Each ensemble row represents one settlement period.
        total_sps = total_alerts

        total_duration_min = int(party_windows_df["DURATION_MIN"].sum())

        unreviewed_count = sum(
            1 for alert in party_review_alerts if alert.get("DISPLAY_STATUS") == "Unreviewed"
        )

        open_count = sum(
            1 for alert in party_review_alerts if alert.get("DISPLAY_STATUS") == "Open"
        )

        closed_count = sum(
            1 for alert in party_review_alerts if alert.get("DISPLAY_STATUS") == "Closed"
        )

        autoclose_count = sum(
            1
            for alert in party_review_alerts
            if (alert.get("ACTION_TAKEN") or "").lower() == "autoclose"
        )

        monitor_count = sum(
            1
            for alert in party_review_alerts
            if "monitor" in (alert.get("ACTION_TAKEN") or "").lower()
        )

        escalated_count = sum(
            1
            for alert in party_review_alerts
            if "escalat" in (alert.get("ACTION_TAKEN") or "").lower()
        )

        volume_breached = total_alerts >= threshold_volume
        impact_breached = total_gbp_impact >= threshold_impact_gbp

        if volume_breached:
            exceeding_vol_cnt += 1

        if impact_breached:
            exceeding_gbp_cnt += 1

        if volume_breached and impact_breached:
            exceeding_both_cnt += 1
            framing_status = "BREACHED BOTH (Volume & £ Impact)"
        elif volume_breached:
            framing_status = f"BREACHED VOLUME " f"(≥ {threshold_volume} Ensemble SPs)"
        elif impact_breached:
            framing_status = f"BREACHED £ IMPACT " f"(≥ £{threshold_impact_gbp:,.0f})"
        else:
            framing_status = "Within Limits"

        associated_bmus = sorted(party_ensemble_df["BMU_ID"].dropna().astype(str).unique().tolist())

        stats_list.append(
            {
                "COUNTERPARTY": counterparty_name,
                "TOTAL_ALERTS": total_alerts,
                "TOTAL_WINDOWS": total_windows,
                "TOTAL_GBP_IMPACT": total_gbp_impact,
                "FRAMING_STATUS": framing_status,
                "VOL_BREACHED": volume_breached,
                "GBP_BREACHED": impact_breached,
                "UNREVIEWED_COUNT": unreviewed_count,
                "OPEN_COUNT": open_count,
                "CLOSED_COUNT": closed_count,
                "AUTOCLOSE_COUNT": autoclose_count,
                "MONITOR_COUNT": monitor_count,
                "ESCALATED_COUNT": escalated_count,
                "TOTAL_DURATION_MIN": total_duration_min,
                "TOTAL_SPS": total_sps,
                "BMUS": associated_bmus,
            }
        )

    stats_list.sort(
        key=lambda item: (
            item["TOTAL_ALERTS"],
            item["TOTAL_GBP_IMPACT"],
        ),
        reverse=True,
    )

    top_party = stats_list[0]["COUNTERPARTY"] if stats_list else "-"

    return {
        "summary": {
            "total_alerts": len(ensemble_df),
            "total_windows": len(windows_df),
            "total_parties": int(ensemble_df["COUNTERPARTY"].nunique()),
            "parties_exceeding_vol_threshold": (exceeding_vol_cnt),
            "parties_exceeding_gbp_threshold": (exceeding_gbp_cnt),
            "parties_exceeding_both": exceeding_both_cnt,
            "top_breaching_party": top_party,
            "total_duration_mins": int(windows_df["DURATION_MIN"].sum()),
            "total_sps": len(ensemble_df),
            "total_gbp_impact": float(ensemble_df["IMPACT_SP"].sum()),
        },
        "counterparties": stats_list,
        "filter_options": {
            "bmus": filter_options.get("bmus", []),
            "parties": filter_options.get("parties", []),
            "fuels": filter_options.get("fuels", []),
        },
    }
