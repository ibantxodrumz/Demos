from dash import dcc, html
import dash


def create_header() -> html.Header:
    """
    Creates the NESO top header bar featuring the NESO logo, platform title,
    and search input.
    """
    return html.Header(
        className="neso-header",
        children=[
            html.Div(
                className="neso-logo-container",
                children=[
                    html.Img(
                        src="/assets/logo.jpg",
                        alt="NESO Logo",
                        className="neso-logo-img",
                    ),
                    html.Div(
                        style={
                            "height": "28px",
                            "width": "1px",
                            "backgroundColor": "#e2e8f0",
                            "margin": "0 4px",
                        }
                    ),
                    html.H1(
                        "Market Monitoring Platform",
                        className="neso-platform-title",
                    ),
                ],
            ),
            html.Div(
                className="neso-header-right",
                children=[
                    dcc.Link(
                        "← Main Landing Page",
                        href="/",
                        style={
                            "backgroundColor": "#4e0038",
                            "color": "#ffffff",
                            "padding": "8px 16px",
                            "borderRadius": "6px",
                            "textDecoration": "none",
                            "fontSize": "13px",
                            "fontWeight": "600",
                            "display": "inline-flex",
                            "alignItems": "center",
                            "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        },
                    ),
                ],
            ),
        ],
    )


def create_sidebar() -> html.Div:
    """
    Creates the NESO deep plum navigation sidebar.
    """
    return html.Div(
        className="neso-sidebar",
        children=[
            html.Div(
                className="neso-sidebar-brand",
                children=[
                    html.H2("Market Monitoring", className="neso-sidebar-app-name"),
                    html.Span(
                        "Operational Decision Workspace",
                        style={
                            "color": "rgba(255, 255, 255, 0.7)",
                            "fontSize": "11px",
                            "textTransform": "uppercase",
                            "letterSpacing": "0.5px",
                        },
                    ),
                ],
            ),
            html.Nav(
                className="neso-sidebar-nav",
                children=[
                    dcc.Link(
                        html.Span("← Main Landing Page"),
                        href="/",
                        className="neso-nav-link",
                        style={
                            "borderBottom": "1px solid rgba(255, 255, 255, 0.15)",
                            "marginBottom": "8px",
                            "paddingBottom": "10px",
                        },
                    ),
                    dcc.Link(
                        html.Span("Alert Review"),
                        href="/alert-review",
                        className="neso-nav-link",
                    ),
                    dcc.Link(
                        html.Span("Dashboards"),
                        href="/analytical-support",
                        className="neso-nav-link",
                    ),
                    dcc.Link(
                        html.Span("Open Reviews"),
                        href="/open-reviews",
                        className="neso-nav-link",
                    ),
                    dcc.Link(
                        html.Span("Closed Reviews"),
                        href="/closed-reviews",
                        className="neso-nav-link",
                    ),
                    dcc.Link(
                        html.Span("Long-Run Statistics"),
                        href="/long-run-analytics",
                        className="neso-nav-link",
                    ),
                ],
            ),
            html.Div(
                style={
                    "marginTop": "auto",
                    "paddingTop": "20px",
                    "borderTop": "1px solid rgba(255, 255, 255, 0.15)",
                },
                children=[
                    dcc.Link(
                        html.Span("User Guide"),
                        href="/user-guide",
                        className="neso-nav-link-userguide",
                    ),
                ],
            ),
        ],
    )


def create_navbar() -> html.Div:
    """
    Backward-compatible combined wrapper returning top header bar.
    """
    return create_header()
