# Market Monitoring Platform — Phase 2 Release 3

## Release Overview

**Release Identifier**: `phase2_release_3_navigation_and_analyst_routing`  
**Target Environments**: Windows 11 (VS Code Local Execution) & macOS  
**Database Backend**: Azure SQL Database (`DATABASE_MODE=azure`) with SQLite local fallback (`DATABASE_MODE=sqlite`)

This release introduces the complete **4-Level Platform Navigation Architecture**, **Analyst Session Context Persistence**, **SQL Audit Trail Filtering**, and **Read-Only Workstream Locking** across the Market Monitoring Platform.

---

## What's Implemented in Phase 2 Release 3

1. **4-Level Platform Navigation & Page Routing Architecture**:
   - **Level 1: Platform Landing Page (`/`)**:
     - Rendered on a full 100% canvas without top header or sidebar.
     - Features direct full-height NESO logo image (`/assets/logo.jpg`), central title box, Analyst selection dropdown (`Analyst 1`, `Analyst 2`, `Analyst 3`), and dynamic welcome banner.
     - **Guardrail Enforced**: Selecting an analyst context is mandatory before entering workstreams. Unselected attempts block navigation with an inline warning.
   - **Level 2: Workstream Operational Workspace (`/alert-review`)**:
     - Operational Alert Queue table, dynamic date pickers (August 2022 to forward buffer), filters, KPI metric cards, and Analyst Decision & Capture card.
     - Includes explicit **`← Main Landing Page`** back links in both the header bar and the plum sidebar.
   - **Level 3: Dashboards Portal (`/analytical-support`)**:
     - Investigation Intelligence & Analytical Support portal featuring workstream selection cards and a top right **`← Back to Alert Review Queue`** button.
   - **Level 4: Import Constraints Intelligence Workspace (`/import-constraints-workspace`)**:
     - Detailed 7-tab intelligence workspace (*Info & Context*, *System Overview*, *Ensemble SP Intelligence*, *Ensemble Windows*, *BMU Deep Dive*, *Spread Analysis*, *Counterparty Intelligence*) with a top right **`← Back to Workstreams`** button.

2. **Analyst Session Context & SQL Audit Trail Persistence**:
   - Analyst context (`Analyst 1`, `Analyst 2`, `Analyst 3`) is preserved across all navigation transitions and restored when returning to the Platform Landing Page (`/`).
   - The decision capture panel displays an explicit **`👤 Active Analyst Context: [Analyst Name]`** badge.
   - Static placeholder text (`"Local Prototype Analyst"`) has been replaced. Saved decisions persist the active analyst name into the `PERSON_RAISING` column of `dbo.MM_ACTIVITY_LOG` in Azure SQL.

3. **Read-Only Active Workstream Domain**:
   - Replaced interactive workstream dropdown on the Operational Alert Review page with a locked, read-only informative badge: `Import Constraints (Active)` with `🔒 Locked Workstream Context`.

---

## Instructions for Colleagues Testing on Windows 11 (VS Code)

### Step 1: Environment Setup
Open the folder `releases/phase2_release_3_navigation_and_analyst_routing` in VS Code and install dependencies:

```powershell
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables
Set your environment variables in your PowerShell terminal or `.env` file:

```powershell
$env:DATABASE_MODE="azure"
$env:AZURE_SQL_SERVER="your_server.database.windows.net"
$env:AZURE_SQL_DATABASE="your_db_name"
$env:AZURE_SQL_USER="your_username"
$env:AZURE_SQL_PASSWORD="your_password"
```

*(To run locally in SQLite test mode without Azure SQL credentials, set `$env:DATABASE_MODE="sqlite"`)*

### Step 3: Run the Application
Launch the Market Monitoring Platform Dash application:

```powershell
python src/app.py
```

Access the application in your browser at `http://127.0.0.1:8050`.

---

## Acceptance Testing Verification Checklist

- [ ] **Level 1 Landing Page (`/`)**: Verify standalone logo, title, analyst dropdown, dynamic welcome pill, and guardrail blocking when no analyst is chosen.
- [ ] **Level 2 Operational Workspace (`/alert-review`)**: Verify header/sidebar back button (`← Main Landing Page`), read-only `Import Constraints (Active)` badge, active analyst context badge, and alert queue table.
- [ ] **Level 3 Dashboards Portal (`/analytical-support`)**: Verify card selection grid and `← Back to Alert Review Queue` header button.
- [ ] **Level 4 Intelligence Workspace (`/import-constraints-workspace`)**: Verify 7 horizontal analytical tabs and `← Back to Workstreams` header button.
- [ ] **Analyst Context & SQL Persistence**: Select `Analyst 1` or `Analyst 2`, submit a review decision on `/alert-review`, and verify that `PERSON_RAISING` records the selected analyst name in `dbo.MM_ACTIVITY_LOG`. Confirm analyst choice is preserved when navigating back to `/`.

---

## Technical Verification Evidence

- **Unit & Integration Suite**: `55 / 55 tests passed` (100% pass rate in 2.34s).
- **Execution Command**: `uv run python -m pytest tests/` inside release directory.
