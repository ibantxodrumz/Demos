# Phase 2 — P2: Platform vs Workstream Codebase Classification & Architectural Review

**Document Status**: **REVISED & ALIGNED WITH OPERATIONAL VISION**  
**Date**: 2026-09-25  
**Scope**: Folder-by-folder audit of `phase2/src/` for the Market Monitoring Platform  

---

## 1. Executive Summary & Operational Vision

The core objective of **P2** is to establish a clear architectural classification of every file, module, and folder in `phase2/src/` before implementing new features.

### Key Architectural & Operational Principles
1. **Universal Analyst Workflow**: The core analyst workflow (reviewing alerts, updating status, adding review comments, saving decisions, viewing Open/Closed review queues) is **identical across all workstreams**.
2. **Workstream Landing Page Parity**: Once an analyst selects a workstream from the Platform Landing Page (P3), the operational workspace that appears is structurally equivalent to what currently exists for *Import Constraints* (alerts table, filtering controls, navigation bar, and sidebar).
3. **Primary Differentiators Between Workstreams**:
   - **Database Queries & Tables**: Queries point to workstream-specific alert/evidence tables in Azure SQL (e.g. `dbo.IMPORT_ALERTS` vs `dbo.IC_ALERTS` vs `dbo.TCLC_ALERTS`).
   - **Workstream Analytics**: Analytical breakdown charts, statistical views, and evidence tables vary by workstream.

---

## 2. Folder-by-Folder Classification Matrix

Every directory and file in `phase2/src/` has been audited and classified according to the agreed platform boundaries:

### 2.1 Root (`src/`)
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/app.py` | **Platform Shared** | Main Dash application entry point, layout root, and URL router. |

### 2.2 `src/components/` (All Platform Shared)
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/components/navbar.py` | **Platform Shared** | Universal platform top navigation bar. Will support Platform Landing Page link (`/`) and active workstream context. |
| `src/components/alert_table.py` | **Platform Shared** | Universal Dash DataTable component used to render alerts across all workstreams. |

### 2.3 `src/models/` (All Platform Shared)
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/models/alert.py` | **Platform Shared** | Universal `Alert` data contract defining core alert properties (`alert_unique_id`, `bmu_id`, `start_date`, `end_date`, status fields) common to all workstreams. |
| `src/models/activity_log.py` | **Platform Shared** | Universal `ActivityLogEntry` review persistence model containing `WORKSTREAM_NAME` partitioning. |

### 2.4 `src/utils/` (All Platform Shared)
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/utils/date_utils.py` | **Platform Shared** | Dynamic ISO week, month, and date range calculation engine used by all workstreams. |
| `src/utils/formatting.py` | **Platform Shared** | Universal text, number, and HTML formatting utilities. |
| `src/utils/bmrs_links.py` | **Platform Shared** | External Elexon BMRS link generator utility for BMUs. |

### 2.5 `src/config/` (Infrastructure)
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/config/constants.py` | **Infrastructure** | Global configuration tokens (`SQL_TABLE_ACTIVITY_LOG = "MM_ACTIVITY_LOG"`, default workstream names). |
| `src/config/settings.py` | **Infrastructure** | Environment variables, database mode dispatcher (`sqlite` / `azure`). |
| `src/config/create_mm_activity_log.sql` | **Infrastructure** | DDL specification for `dbo.MM_ACTIVITY_LOG` single operational review table. |

### 2.6 `src/repositories/`
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/repositories/connection.py` | **Infrastructure** | Multi-DB connection interface router. |
| `src/repositories/azure_connection.py` | **Infrastructure** | PyODBC connection pool manager for Azure SQL. |
| `src/repositories/activity_log_repository.py` | **Platform Shared** | Universal operational persistence layer for `dbo.MM_ACTIVITY_LOG` partitioned by `WORKSTREAM_NAME`. |
| `src/repositories/alert_repository.py` | **Platform Shared / Generalized** | Core alert query engine; parameterized to load alerts for the selected active workstream. |
| `src/repositories/analytics_repository.py` | **Workstream Specific (IC)** | **Action**: Rename to `ic_analytics_repository.py` to explicitly scope IC BOALH and BMRS physical evidence queries. |
| `src/repositories/sp_analytics_repository.py` | **Workstream Specific (IC)** | **Action**: Rename to `ic_sp_analytics_repository.py` to explicitly scope IC settlement period queries. |

### 2.7 `src/services/`
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/services/activity_log_service.py` | **Platform Shared** | Universal review validation and persistence business logic. |
| `src/services/alert_service.py` | **Platform Shared / Generalized** | Universal alert filtering, date bound generation, and status derivation service. |
| `src/services/analytics_service.py` | **Workstream Specific (IC)** | **Action**: Rename to `ic_analytics_service.py` for Import Constraints C1, C2, C3 domain calculations. |
| `src/services/sp_analytics_service.py` | **Workstream Specific (IC)** | **Action**: Rename to `ic_sp_analytics_service.py` for Import Constraints settlement period processing. |
| `src/services/long_run_service.py` | **Platform Shared Feature Structure** | Universal Long-Run statistical service structure; currently provides counterparty calculations for Import Constraints. |

### 2.8 `src/charts/`
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/charts/analytics_charts.py` | **Platform / Workstream Hub** | Chart generator hub for analytical figures. Workstream-specific visualizations (such as IC settlement period plots) are organized by workstream via explicit code blocks and comments. |

### 2.9 `src/pages/`
| File | Category | Operational Purpose & Required Action |
| :--- | :--- | :--- |
| `src/pages/open_reviews.py` | **Platform Shared** | Universal Open Reviews queue for the active workstream context. |
| `src/pages/closed_reviews.py` | **Platform Shared** | Universal Closed Reviews archive for the active workstream context. |
| `src/pages/saved_reviews.py` | **Platform Shared** | Universal Draft / Saved Reviews page layout. |
| `src/pages/user_guide.py` | **Platform Shared** | Universal User Guide and help documentation page. |
| `src/pages/long_run_analytics.py` | **Platform Shared Feature Structure** | Long-Run Statistics page present for all workstreams (currently displaying Import Constraints statistical breakdown). |
| `src/pages/alert_review.py` | **Platform Shared Analyst Workflow** | Universal Alert Review detail page detailing alert parameters, historical reviews, and decision submission controls. |
| `src/pages/import_constraints.py` | **Workstream Specific (IC)** | **Action**: Rename to `ic_import_constraints.py` (main operational workspace layout for Import Constraints). |
| `src/pages/analytical_support.py` | **Platform Portal / Workstream Specific (IC)** | **Action**: Rename/refactor IC specific view to `ic_analytical_support.py`; retains Dashboards portal structure for selecting workstream. |

---

## 3. Agreed Refactoring Action Plan

1. **Explicit Repository Scoping for IC**:
   - Rename `src/repositories/analytics_repository.py` $\rightarrow$ `src/repositories/ic_analytics_repository.py`
   - Rename `src/repositories/sp_analytics_repository.py` $\rightarrow$ `src/repositories/ic_sp_analytics_repository.py`
2. **Explicit Service Scoping for IC**:
   - Rename `src/services/analytics_service.py` $\rightarrow$ `src/services/ic_analytics_service.py`
   - Rename `src/services/sp_analytics_service.py` $\rightarrow$ `src/services/ic_sp_analytics_service.py`
3. **Explicit Page Scoping for IC**:
   - Rename `src/pages/import_constraints.py` $\rightarrow$ `src/pages/ic_import_constraints.py`
   - Scope IC analytical support page to `src/pages/ic_analytical_support.py` while keeping the Dashboards portal structure.
4. **Platform Landing Page & Workstream Context (P3 & P4)**:
   - Create new `src/pages/landing_page.py` for root URL `/`.
   - Store selected `workstream` and `analyst` in a session `dcc.Store`.
   - Workstream selection routes to the active workstream page (e.g. `/import-constraints` / `/ic`) while preserving the universal analyst workflow.

---

## 4. Verification & References

- **Updated Review File**: [`phase2/docs/P2_PLATFORM_VS_WORKSTREAM_REVIEW.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/docs/P2_PLATFORM_VS_WORKSTREAM_REVIEW.md)
- **Development Log**: [`phase2/DEVELOPMENT_LOG.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/DEVELOPMENT_LOG.md)
- **Foundational Document**: [`phase2/phase2_platform_FoundationalDocument.md`](file:///Users/ivansanz/Desktop/PoC_1/phase2/phase2_platform_FoundationalDocument.md)
