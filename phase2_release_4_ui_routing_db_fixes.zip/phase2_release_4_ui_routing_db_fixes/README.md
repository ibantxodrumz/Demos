# Market Monitoring Platform — Phase 2 Release 4

## Release Overview

**Release Identifier**: `phase2_release_4_ui_routing_db_fixes`  
**Target Environments**: Windows 11 (VS Code Local Execution) & macOS  
**Database Backend**: Azure SQL Database (`DATABASE_MODE=azure`) with SQLite local fallback (`DATABASE_MODE=sqlite`)

This release implements the full suite of feedback requested from Release 3. It features unified aesthetic coloring across the landing page, restructured Long-Run Analytics routing, isolated analytical evidence windows, and robust SQL validation to prevent silent database update failures.

---

## What's Implemented in Phase 2 Release 4

1. **Color Alignment & Landing Page UI Polish**:
   - The landing page layout has been unified to mirror the professional aesthetics of the operational Alert Review workspace.
   - The overall canvas background now uses a soft `#F4F4F6`.
   - "Workstream" and "Rota" control panels are styled with deep plum (`#4e0038`) backgrounds to match the main navigation sidebar, featuring centered white typography and translucent divider lines.
   - All interactive workstream buttons now match the sidebar's ghosted UI logic (`rgba(255,255,255,0.14)` background with a clean white contour).
   - Removed conflicting blue styling; the default analyst dropdown pill restores its bright green (`#46C18A`) styling with the label properly renamed to "Select Analyst Space".

2. **Dashboard & Routing Restructure**:
   - Long-Run Analytics has been fully decoupled from in-page dropdown selections.
   - Established a dedicated `long_run_landing.py` template that infers workstream context dynamically from the URL route (e.g., `/import-constraints-long-run-analytics`).

3. **Navigation & Analytical Evidence Views**:
   - Clicking "View Dashboards" or "View Long-Run Statistics" from the Analytical Support portal now launches a completely standalone, distraction-free browser tab (`target="_blank"`).
   - Stripped away the top header and sidebars on these evidence routes, maximizing screen real estate for charts.

4. **Database Persistence Guardrails**:
   - Implemented strict rowcount validation within `azure_connection.py`.
   - Operations modifying database states (e.g., status updates) actively throw a `ValueError("Update failed: No rows affected")` rather than failing silently.

---

## Instructions for Colleagues Testing on Windows 11 (VS Code)

### Step 1: Environment Setup
Open the folder `releases/phase2_release_4_ui_routing_db_fixes` in VS Code and install dependencies:

```powershell
pip install -r requirements.txt
```

### Step 2: Configure Environment Variables
Set your environment variables in your PowerShell terminal or `.env` file:

```powershell
$env:DATABASE_MODE="azure"
$env:AZURE_SQL_SERVER="your_server.database.windows.net"
$env:AZURE_SQL_DATABASE="your_db_name"
$env:AZURE_SQL_USER="your_username"
$env:AZURE_SQL_PASSWORD="your_password"
```

*(To run locally in SQLite test mode without Azure SQL credentials, set `$env:DATABASE_MODE="sqlite"`)*

### Step 3: Run the Application
Ensure your virtual environment is activated and start the Dash server:

```powershell
python src/app.py
```

### Step 4: Run the Test Suite
To confirm all 55 components pass across the UI, service, and repository layers, execute:

```powershell
pytest
```

---

## Acceptance Testing Objectives
1. **Landing Page Aesthetic**: Confirm the "Workstream" and "Rota" cards use deep plum aesthetics that precisely mimic the operational sidebar, and typography is perfectly centered.
2. **Tab Isolation**: When accessing analytical evidence (Dashboards / Long-Run Statistics), verify they launch in clean, detached tabs with zero top-bars or sidebars.
3. **Database Integrity**: Try processing alerts; if network issues or stale records exist, you should see explicit application-level errors rather than silent failures. 
