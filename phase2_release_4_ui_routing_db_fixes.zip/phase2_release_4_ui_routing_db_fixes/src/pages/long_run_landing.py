import dash
from dash import html

dash.register_page(
    __name__, path="/long-run-analytics", title="Long-Run Statistics - Market Monitoring Platform"
)

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Segoe UI, sans-serif"},
    children=[
        html.Div(
            children=[
                # Header
                html.Div(
                    style={
                        "marginBottom": "20px",
                        "display": "flex",
                        "justifyContent": "space-between",
                        "alignItems": "center",
                    },
                    children=[
                        html.Div(
                            children=[
                                html.H2(
                                    "Long-Run Statistics & Analytics",
                                    className="neso-page-title",
                                ),
                                html.P(
                                    "Choose a monitoring workstream to access long-run statistics and repeat behavioral analytics.",
                                    className="neso-page-subtitle",
                                ),
                            ]
                        ),
                        html.A(
                            "← Back to Alert Review Queue",
                            href="/alert-review",
                            className="btn-neso-primary",
                            style={
                                "textDecoration": "none",
                                "fontSize": "13px",
                            },
                        ),
                    ],
                ),
                # Workstream Selection Cards
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.Div(
                            style={"marginBottom": "20px"},
                            children=[
                                html.H3(
                                    "Select Statistical Workstream",
                                    style={
                                        "color": "#4e0038",
                                        "margin": "0 0 6px 0",
                                    },
                                ),
                                html.P(
                                    "Evaluate dual threshold framing, analyze repeat market participant behavior, and support regulatory governance.",
                                    style={
                                        "color": "#64748b",
                                        "margin": "0",
                                        "fontSize": "14px",
                                    },
                                ),
                            ],
                        ),
                        html.Div(
                            style={
                                "display": "grid",
                                "gridTemplateColumns": ("repeat(auto-fit, minmax(280px, 1fr))"),
                                "gap": "20px",
                            },
                            children=[
                                # Card 1: Import Constraints (Active)
                                html.Div(
                                    style={
                                        "backgroundColor": "#ffffff",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "boxShadow": ("0 1px 3px rgba(0,0,0,0.1)"),
                                        "border": "1px solid #e2e8f0",
                                        "borderTop": "4px solid #4e0038",
                                        "display": "flex",
                                        "flexDirection": "column",
                                        "justifyContent": "space-between",
                                    },
                                    children=[
                                        html.Div(
                                            children=[
                                                html.H4(
                                                    "Import Constraints",
                                                    style={
                                                        "margin": "0 0 8px 0",
                                                        "color": "#1e293b",
                                                    },
                                                ),
                                                html.P(
                                                    "Long-term analysis of BMU pricing behavior during import constraints.",
                                                    style={
                                                        "fontSize": "13px",
                                                        "color": "#64748b",
                                                        "lineHeight": "1.5",
                                                    },
                                                ),
                                            ]
                                        ),
                                        html.A(
                                            "Open Import Constraints Statistics →",
                                            href="/import-constraints-long-run-analytics",
                                            className="btn-neso-primary",
                                            style={
                                                "textDecoration": "none",
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "textAlign": "center",
                                                "fontSize": "13px",
                                            },
                                        ),
                                    ],
                                ),
                                # Card 2: TBC
                                html.Div(
                                    style={
                                        "backgroundColor": "#f8fafc",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "border": "1px dashed #cbd5e1",
                                        "opacity": "0.7",
                                    },
                                    children=[
                                        html.H4(
                                            "TBC",
                                            style={
                                                "margin": "0 0 8px 0",
                                                "color": "#94a3b8",
                                            },
                                        ),
                                        html.P(
                                            "Workstream statistics TBC",
                                            style={
                                                "fontSize": "13px",
                                                "color": "#94a3b8",
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                        html.Span(
                                            "Workstream Pending",
                                            style={
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "padding": "4px 10px",
                                                "backgroundColor": "#e2e8f0",
                                                "color": "#64748b",
                                                "borderRadius": "4px",
                                                "fontSize": "11px",
                                                "fontWeight": "600",
                                            },
                                        ),
                                    ],
                                ),
                                # Card 3: TBC
                                html.Div(
                                    style={
                                        "backgroundColor": "#f8fafc",
                                        "borderRadius": "8px",
                                        "padding": "24px",
                                        "border": "1px dashed #cbd5e1",
                                        "opacity": "0.7",
                                    },
                                    children=[
                                        html.H4(
                                            "TBC",
                                            style={
                                                "margin": "0 0 8px 0",
                                                "color": "#94a3b8",
                                            },
                                        ),
                                        html.P(
                                            "Workstream Statistics TBC",
                                            style={
                                                "fontSize": "13px",
                                                "color": "#94a3b8",
                                                "lineHeight": "1.5",
                                            },
                                        ),
                                        html.Span(
                                            "Workstream Pending",
                                            style={
                                                "display": "inline-block",
                                                "marginTop": "16px",
                                                "padding": "4px 10px",
                                                "backgroundColor": "#e2e8f0",
                                                "color": "#64748b",
                                                "borderRadius": "4px",
                                                "fontSize": "11px",
                                                "fontWeight": "600",
                                            },
                                        ),
                                    ],
                                ),
                            ],
                        ),
                    ],
                ),
            ]
        )
    ],
)
