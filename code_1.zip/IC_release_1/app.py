import streamlit as st
import pandas as pd
import plotly.express as px
import os
import subprocess
import time
from pathlib import Path
from datetime import datetime
import sys

# Import constants to get configured ICs
# We need to add the current directory to sys.path to import local modules if not already there
sys.path.append(os.getcwd())
try:
    from constants import IC_PATHS, OUTPUTS_DIR
except ImportError:
    st.error("Could not import constants. Make sure you are running this from the project root.")
    st.stop()

# Page Config
st.set_page_config(
    page_title="IC Reconciliation Tool",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------
def load_data(ic_code):
    """Load the latest outputs for the given IC, ensuring they match the latest run."""
    
    # 1. Find the latest Run Summary to establish "Freshness" baseline
    summary_files = sorted(OUTPUTS_DIR.glob(f"Run_Summary_{ic_code}_*.json"), key=os.path.getmtime, reverse=True)
    if not summary_files:
        return {} # No runs ever?
        
    latest_summary_path = summary_files[0]
    summary_mtime = latest_summary_path.stat().st_mtime
    
    files_map = {
        "trade_results": f"Comparison2_trade_results_{ic_code}.csv",
        "hourly_summary": f"Comparison2_hourly_summary_{ic_code}.csv",
        "advisory": f"Forward_PN_Advisory_{ic_code}.csv"
    }
    
    data_dict = {}
    for key, filename in files_map.items():
        path = OUTPUTS_DIR / filename
        if path.exists():
            # FRESHNESS CHECK
            # If the CSV is significantly older than the Summary (e.g. > 15 seconds), 
            # it belongs to a previous run and should be ignored.
            # (Summary is typically written last, so CSVs should be slightly older or equal)
            file_mtime = path.stat().st_mtime
            age_diff = summary_mtime - file_mtime
            
            # If age_diff is large (e.g. > 15s), it means the CSV wasn't updated in this run.
            if age_diff > 15.0: 
                # Stale file - ignore
                continue
                
            try:
                # Read CSVs. For advisory, parse dates to help with logic later
                if key == "advisory":
                    # Check columns first or just try/except? 
                    # The file has ReceiptLocal, not ReceiptUTC
                    data_dict[key] = pd.read_csv(path, parse_dates=["HourLocal", "ReceiptLocal"])
                else:
                    data_dict[key] = pd.read_csv(path)
            except Exception as e:
                st.warning(f"Could not read {filename}: {e}")
    return data_dict

# Title and Header
st.title("⚡ Interconnector Position Reconciliation Tool")
st.markdown("---")

# =====================
# Sidebar Configuration
# =====================
st.sidebar.header("Configuration")

# IC Selection
# Filter IC_PATHS to only available ones (commented out ones in python are not in the dict)
available_ics = list(IC_PATHS.keys())
ic_options = ["ALL"] + available_ics
selected_ic = st.sidebar.selectbox("Select Interconnector", ic_options, index=0)

# Toggles
st.sidebar.subheader("Run Settings")
forward_only = st.sidebar.checkbox("Forward Only (H+1 → Midnight)", value=True, help="If checked, only analyzes future hours.")
adhoc_pairwise = st.sidebar.checkbox("Ad-hoc Pairwise Only", value=True, help="Compare only the latest two files.")
filter_trades = st.sidebar.checkbox("Filter Trades to IC BMUs", value=True)

# Run Button
if st.sidebar.button("🚀 Run Analysis", type="primary"):
    with st.spinner(f"Running analysis for {selected_ic}..."):
        
        # Define the list of ICs to run
        ics_to_run = available_ics if selected_ic == "ALL" else [selected_ic]
        
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        results_summary = []

        for i, ic_code in enumerate(ics_to_run):
            status_text.text(f"Processing {ic_code} ({i+1}/{len(ics_to_run)})...")
            
            # Prepare Environment Variables
            env = os.environ.copy()
            env["IC"] = ic_code
            env["FORWARD_ONLY"] = "true" if forward_only else "false"
            env["FILTER_TRADES_TO_IC_BMUS"] = "true" if filter_trades else "false"
            env["ADHOC_PAIRWISE_ONLY"] = "true" if adhoc_pairwise else "false"
            
            # Execute click_2.py
            # We assume python is in path as 'python3' or 'python'
            python_cmd = sys.executable 
            
            try:
                # Capture output to show logs if needed
                result = subprocess.run(
                    [python_cmd, "click_2.py"],
                    capture_output=True,
                    text=True,
                    env=env,
                    cwd=os.getcwd()
                )
                
                if result.returncode != 0:
                    st.error(f"Error running {ic_code}:")
                    st.code(result.stderr)
                    results_summary.append({"IC": ic_code, "Status": "Failed", "Details": "Check Logs"})
                else:
                    results_summary.append({"IC": ic_code, "Status": "Success", "Details": "Completed"})
                    
            except Exception as e:
                st.error(f"Execution failed for {ic_code}: {e}")
                results_summary.append({"IC": ic_code, "Status": "Error", "Details": str(e)})
            
            progress_bar.progress((i + 1) / len(ics_to_run))
            
        progress_bar.empty()
        
        # Get Local Time for completion message
        now_local = pd.Timestamp.now(tz="Europe/London").strftime("%H:%M")
        
        # Show mini summary of the batch run
        if selected_ic == "ALL":
            st.success(f"Batch run completed at {now_local} (Local Time)")
            st.dataframe(pd.DataFrame(results_summary))
        else:
             st.success(f"Run completed at {now_local} (Local Time)")

# =====================
# Results Visualization
# =====================

# Determine which IC to show results for
# If ALL was run, let user pick which one to view details for (or default to the first one)
view_ic = selected_ic
if selected_ic == "ALL":
    st.markdown("### 📊 View Results")
    view_ic = st.selectbox("Select IC to view details:", available_ics)
else:
    st.markdown(f"### 📊 Results for {view_ic}")

# Load Data for the selected IC to view
data = load_data(view_ic)

if not data and not any(OUTPUTS_DIR.glob(f"Run_Summary_{view_ic}_*.json")):
    st.info(f"No results found for {view_ic}. Run the analysis to generate data.")
else:
    # ------------------
    # Run Summary & Status
    # ------------------
    import json
    
    # Try to find the latest Run Summary JSON for this IC
    summary_files = sorted(OUTPUTS_DIR.glob(f"Run_Summary_{view_ic}_*.json"), key=os.path.getmtime, reverse=True)
    c1_status = None
    c1_msg = ""
    h_plus_1_str = "Unknown"
    
    if summary_files:
        latest_summary_path = summary_files[0]
        try:
            with open(latest_summary_path, "r") as f:
                run_summary = json.load(f)
                c1_status = run_summary.get("c1_status", "UNKNOWN")
                c1_msg = run_summary.get("c1_message", "")
                
                # Parse and convert H+1 time to Local
                if "h_plus_1_utc" in run_summary:
                    ts_utc = pd.Timestamp(run_summary["h_plus_1_utc"])
                    # Assuming input is UTC naive, localize to UTC then convert to London
                    ts_local = ts_utc.tz_localize("UTC").tz_convert("Europe/London")
                    h_plus_1_str = ts_local.strftime("%H:%M")
                    
        except Exception as e:
            st.error(f"Failed to load run summary: {e}")
            
    # Display Checks (Enhanced)
    st.markdown("### 🚦 Compliance Checks")
    
    # Create a container with border for prominence
    with st.container(border=True):
        check_col1, check_col2 = st.columns(2)
        
        if summary_files:
            try:
                with open(summary_files[0], "r") as f:
                    run_summary = json.load(f)
                    c1_status = run_summary.get("c1_status", "UNKNOWN")
                    c1_msg = run_summary.get("c1_message", "")
                    
                    # Parse and convert H+1 time to Local
                    if "h_plus_1_utc" in run_summary:
                        ts_utc = pd.Timestamp(run_summary["h_plus_1_utc"])
                        # Assuming input is UTC naive, localize to UTC then convert to London
                        ts_local = ts_utc.tz_localize("UTC").tz_convert("Europe/London")
                        h_plus_1_str = ts_local.strftime("%H:%M")
            except Exception as e:
                st.error(f"Failed to load run summary: {e}")
                run_summary = {}
        else:
            run_summary = {}

        # Prepare Forward Check Data (Excluding H+1)
        # Filters:
        # 1. Day matches selected day (implicitly handled if file is daily, but good to be safe)
        # 2. Hour > H+1 (Strictly future)
        # 3. Delta != 0
        forward_changes = False
        forward_affected_str = ""
        
        if "advisory" in data and not data["advisory"].empty:
            adv_df = data["advisory"]
            # Re-derive H+1 DT from the summary logic
            if "h_plus_1_utc" in run_summary:
                try:
                    h_plus_1_utc_dt = pd.to_datetime(run_summary.get("h_plus_1_utc")).tz_localize("UTC")
                    h_plus_1_local_dt = h_plus_1_utc_dt.tz_convert("Europe/London")
                    
                    forward_df = adv_df[
                        (adv_df["HourLocal"] > h_plus_1_local_dt) & 
                        (adv_df["Total_DeltaPN_MW"] != 0) 
                    ]
                    forward_changes = not forward_df.empty
                    forward_affected = sorted(forward_df["HourLocal"].dt.strftime("%H:%M").unique())
                    forward_affected_str = ", ".join(forward_affected)
                except Exception as e:
                    # Fallback if date parsing fails
                    pass
        
        # --- H+1 Check Logic ---
        with check_col1:
            st.markdown(f"#### H+1 Check ({h_plus_1_str} Local)")
            
            if c1_status == "NO_CHANGES" or c1_status == "FORWARD_CHANGES": # FORWARD_ONLY means Clean at H+1
                 st.success("✅ **No Changes** (For the next hour)")
            elif c1_status == "H_PLUS_1_CHANGES" or c1_status == "CHANGES_DETECTED": # Generic catch-all
                 st.error("🚨 **Changes Detected**")
                 # Optional: Show Delta for H+1 if available in adv_df
            else:
                 st.info(f"Status: {c1_status}")

        # --- Forward Check Logic ---
        with check_col2:
            st.markdown("#### Forward Check (Future Hours)")
            
            if not forward_changes:
                st.success("✅ **No Changes**")
            else:
                st.warning(f"⚠️ **Changes Detected**")
                st.markdown(f"**Affected Times (Local):** {forward_affected_str}")
                
    st.markdown("---")

    # ------------------
    # Top Level Metrics
    # ------------------
    if "hourly_summary" in data:
        df_sum = data["hourly_summary"]
        
        # Calculate totals
        total_mismatches = df_sum["Not_met_on_IC"].sum() if "Not_met_on_IC" in df_sum.columns else 0
        total_shortfall = df_sum["Shortfall_MW_on_IC_sum"].sum() if "Shortfall_MW_on_IC_sum" in df_sum.columns else 0
        total_countertrades = df_sum["Countertrade_count"].sum() if "Countertrade_count" in df_sum.columns else 0
        
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Trade Mismatches", f"{total_mismatches}", delta_color="inverse")
        col2.metric("Total MW Shortfall", f"{total_shortfall:.1f} MW", delta_color="inverse")
        col3.metric("Countertrades Detected", f"{total_countertrades}", delta_color="off")

    # ---- Tabs ----
    tab1, tab2, tab3 = st.tabs(["🚨 Advisory", " Trade Details", "ℹ️ Help / Legend"])

    # Tab 1: Advisory
    with tab1:
        st.subheader("Forward PN Advisory (Actionable)")
        if "advisory" in data and not data["advisory"].empty:
            adv_df = data["advisory"]
            
            # Format nicely
            st.dataframe(
                adv_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "HourLocal": st.column_config.DatetimeColumn("Hour", format="HH:mm"),
                    "Total_DeltaPN_MW": st.column_config.NumberColumn("Delta PN (MW)", format="%.1f"),
                }
            )
            
            # Download button
            csv = adv_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                "⬇️ Download Advisory CSV",
                csv,
                f"advisory_{view_ic}.csv",
                "text/csv",
                key='download-adv'
            )
            
        else:
            st.success("✅ No critical advisories found (or no data).")

    # Tab 2: Trade Details (Renamed from Tab 3, shifted up)
    with tab2:
        st.subheader("Detailed Trade Analysis")
        if "trade_results" in data and not data["trade_results"].empty:
            df_trades = data["trade_results"]
            
            # Filters
            col_f1, col_f2 = st.columns(2)
            with col_f1:
                decision_filter = st.multiselect("Filter by Decision", options=df_trades["Decision"].unique(), default=df_trades["Decision"].unique())
            with col_f2:
                bmu_filter = st.multiselect("Filter by CP Code", options=df_trades["CP Code"].unique(), default=df_trades["CP Code"].unique())
            
            filtered_df = df_trades[
                (df_trades["Decision"].isin(decision_filter)) &
                (df_trades["CP Code"].isin(bmu_filter))
            ]
            
            st.dataframe(
                filtered_df, 
                use_container_width=True, 
                hide_index=True,
                height=500
            )
        else:
            st.info("No trade results data.")

    # Tab 3: Help / Legend
    with tab3:
        st.markdown("""
        ### 📖 Decision Guide
        
        **Actionable Outcomes (Red/Critical)**
        - **YES3**: **⚠️ ACTION: Market Moved / Insufficient PN**. A physical position change occurred, but there is no matching trade to cover it. **Action**: Find remaining MW elsewhere. (Or Countertraded if opposite PN on same IC).
        - **YES2**: **♻️ OK (Across)**. The volume is covered, but on a different Interconnector. **Action**: Investigate/Credit.
        - **YES1**: **⏳ WAIT**. Trade exists but the "Awareness" time hasn't started yet. **Action**: No action now.
        - **NO**: **🚨 URGENT: Non-Compliant**. Position change with no trade coverage. **Action**: Chase immediately.
        
        **Informational Outcomes**
        - **INFO**: **✅ OK: Position Fully Balanced**. The position change is fully covered by a clean trade. No action required.
        """)
            


# Footer
st.markdown("---")

