# Interconnector Position Reconciliation Tool

This tool is designed to reconcile Day-Ahead positions against Physical Notifications (PNs) and Trades for Interconnectors.

## Setup Instructions

### 1. Prerequisites
- **Python 3.9+**
- **VS Code** (recommended)
- Access to the **ENCC** corporate network (for API access)

### 2. Environment Setup
We recommend using the existing `ENCC` environment or creating a new one with `uv`:

```bash
# Update dependencies in your current environment
uv pip install -r requirements.txt
```

### 3. Configuration
1.  Open the `.env` file in the root directory.
2.  Ensure your `ENTRADER_API_KEY` is correct.
3.  Adjust any operational toggles if needed (e.g., `FORWARD_ONLY=true`).

## How to Run

### Option A: Interactive Dashboard (Streamlit)
The best way to visualize the results is via the dashboard:

```bash
streamlit run app.py
```
This will open a browser window with the interactive tool.

### Option B: Command Line Interface
To run a quick analysis and generate CSV reports:

```bash
python click_2.py
```
Outputs will be saved in the `outputs/` folder.

## Data Ingestion
Place your real Excel MCNN files in the following folder:
`data/April_IFA/`

The tool will automatically detect and process the latest files in this directory.

## Technical Reference
See `prompt.txt` for details on temporal logic (Local vs UTC) and classification rules (YES1, YES2, YES3, NO).
