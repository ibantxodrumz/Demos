# Market Monitoring: Physical Notification (PN) Accuracy Dashboard — Release 8

## Structure

```text
release_8_azure/
├── app.py                      # Orchestration layer only (~200–300 lines)
├── constants.py                # Environment endpoints & available years
├── pyproject.toml              # Formal reproducible dependency definition
├── data/
│   ├── __init__.py
│   ├── azure_blob_helper.py    # Azure Blob Storage client & Parquet URL resolution
│   ├── data_loader.py          # Unified data loading boundary for Annual/Monthly & SP metadata
│   └── sp_repository.py        # DuckDB engine, Parquet/CSV queries, deduplication, MW conversions
├── services/
│   ├── __init__.py
│   └── data_processing.py      # Core analytics: process_data, apply_filters, categorize_error, get_reason
├── utils/
│   ├── __init__.py
│   └── chart_utils.py          # Shared Plotly theme & render helpers (force_light_chart, render_chart)
├── views/
│   ├── __init__.py
│   ├── executive_summary.py    # Tab 1: Fleet Overview & Fuel Summary
│   ├── median_error.py         # Tab 2: Median Error Distribution
│   ├── total_gwh_error.py      # Tab 3: Aggregate GWh Volume Risk
│   ├── technology.py           # Tab 4: Top & Bottom BMU Breakdown
│   ├── bmu_explorer.py         # Tab 5: Individual BMU Deep Dive
│   ├── physical_profile.py     # Tab 6: Controls, session state, diagnostics, 4 charts & SP CSV download
│   ├── require_attention.py    # Tab 7: Tolerance Breaches
│   └── exports.py              # Tab 8: Central Export Hub
├── inputs/                     # Canonical local datasets
├── assets/                     # Corporate logos & branding
├── documentation/              # Supporting user documentation
└── tests/                      # Guardian test suites updated for modular package imports
```

---

## Running on Windows 11 (VS Code & Conda)

### 1. Open Terminal in VS Code
Open the `release_8_azure` directory in VS Code and open an integrated terminal (`Ctrl + \``).

### 2. Create and Activate Conda Environment
```bash
conda create -n dashboard python=3.11 -y
conda activate dashboard
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. (Optional) Authenticate for Azure Blob Storage
If using live Azure Blob Storage mode:
```bash
az login
```
*Note: If operating offline, select "Local (inputs/ folder)" in the dashboard sidebar.*

### 5. Run Guardian Test Suite
```bash
python tests/run_tests.py
```

### 6. Launch the Dashboard
```bash
streamlit run app.py
```
