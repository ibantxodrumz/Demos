import calendar
from datetime import date, timedelta
import os
import time
from typing import List, Optional, Union

import duckdb
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from constants import CONTAINER_NAME, PROJECT_BASE_NAME
from data.sp_repository import query_sp_data
from utils.chart_utils import render_chart


def render_physical_profile(
    data_source: str,
    sp_target_path: Optional[str],
    sp_is_azure: bool,
    sp_source_label: Optional[str],
    sp_local_filename: str,
    sp_azure_filename: str,
    selected_year: Union[int, str],
    available_bmus: List[str],
    sp_azure_token: Optional[str] = None,
) -> None:
    """Render Tab 6: BMU Units Physical Profile (granular half-hourly physical generation)."""
    st.header("BMU Units Physical Profile")
    st.caption("Granular half-hourly physical generation profile and settlement data.")

    # Check availability of SP dataset based on active source
    if not sp_target_path:
        if data_source == "Azure Blob Storage":
            st.warning(
                f"Settlement Period dataset (`{sp_azure_filename}`) "
                f"was not found in Azure Blob Storage "
                f"(`{CONTAINER_NAME}/"
                f"{PROJECT_BASE_NAME}-{selected_year}/internal/`). "
                f"Granular half-hourly investigation is available "
                f"for years with an SP Parquet file. "
                f"All other dashboard tabs remain fully operational."
            )
        else:
            st.warning(
                f"Settlement Period dataset (`{sp_local_filename}`) "
                f"is not currently present in `inputs/`. "
                f"Granular half-hourly investigation is available "
                f"for years with an SP file. "
                f"All other dashboard tabs remain fully operational."
            )
        return

    if "test" in (sp_source_label or "").lower():
        st.info("Notice: Using sp_summary_test.csv - no sp_summary available")

    # Section 1: Investigation Controls
    # Identify units present in the SP dataset to ensure sample units (e.g. FOMO-1) are selectable
    sp_sample_bmus = []
    if sp_target_path and not sp_is_azure and os.path.exists(sp_target_path):
        try:
            con_peek = duckdb.connect()
            peek_target = sp_target_path.replace("\\", "/")
            sample_rows = con_peek.execute(
                f"SELECT DISTINCT nationalGridBmUnit FROM read_csv_auto('{peek_target}', header=True) LIMIT 20"
            ).fetchall()
            sp_sample_bmus = [r[0] for r in sample_rows if r[0]]
            con_peek.close()
        except Exception:
            pass

    investigation_bmus = sorted(list(set(available_bmus).union(set(sp_sample_bmus))))
    if not investigation_bmus:
        investigation_bmus = available_bmus

    # BMU Search by Name and Selection
    col_search1, col_search2 = st.columns([3, 1])
    with col_search1:
        sp_search_query = (
            st.text_input(
                "Search BMU by name",
                value="",
                placeholder="e.g. FOMO-1",
                key="sp_bmu_search",
            )
            .strip()
            .upper()
        )
    with col_search2:
        st.write("")
        st.write("")
        sp_reset_search = st.button("Reset Search", key="btn_reset_sp_bmu")

    if sp_reset_search or not sp_search_query:
        filtered_sp_bmus = investigation_bmus
    else:
        filtered_sp_bmus = [b for b in investigation_bmus if sp_search_query in b]

    if not filtered_sp_bmus:
        st.warning(f"No BMUs found matching '{sp_search_query}'.")
        graph_bmu_pick = investigation_bmus[0] if investigation_bmus else None
    else:
        default_bmu_idx = 0
        if "FOMO-1" in filtered_sp_bmus:
            default_bmu_idx = filtered_sp_bmus.index("FOMO-1")
        elif "FOMO2" in filtered_sp_bmus:
            default_bmu_idx = filtered_sp_bmus.index("FOMO2")

        graph_bmu_pick = st.selectbox(
            "Select BMU",
            filtered_sp_bmus,
            index=default_bmu_idx,
            key="graph_bmu_select",
        )

    # Date Selection Controls: Day, Week, Month, Custom Range
    is_test_dataset = "test" in (sp_source_label or "").lower()
    active_year = int(selected_year) if not is_test_dataset else 2025

    c_date_mode, c_date_pick = st.columns([1.5, 2.5])
    with c_date_mode:
        date_selection_mode = st.radio(
            "Date Selection",
            [
                "Specific Day",
                "Specific Week",
                "Specific Month",
                "Custom Date Range",
            ],
            index=0,
            key="sp_date_selection_mode",
        )

    with c_date_pick:
        if date_selection_mode == "Specific Day":
            if is_test_dataset:
                day_min = date(2025, 1, 1)
                day_max = date(2025, 1, 31)
                day_default = date(2025, 1, 1)
            else:
                day_min = date(active_year, 1, 1)
                day_max = date(active_year, 12, 31)
                day_default = date(active_year, 1, 1)

            picked_day = st.date_input(
                "Select Day",
                value=day_default,
                min_value=day_min,
                max_value=day_max,
                key="sp_single_day_picker",
            )
            sp_start_date = picked_day
            sp_end_date = picked_day

        elif date_selection_mode == "Specific Week":
            if is_test_dataset:
                week_options = {
                    "Week 1 (01 Jan - 07 Jan 2025)": (
                        date(2025, 1, 1),
                        date(2025, 1, 7),
                    ),
                    "Week 2 (08 Jan - 14 Jan 2025)": (
                        date(2025, 1, 8),
                        date(2025, 1, 14),
                    ),
                    "Week 3 (15 Jan - 21 Jan 2025)": (
                        date(2025, 1, 15),
                        date(2025, 1, 21),
                    ),
                    "Week 4 (22 Jan - 28 Jan 2025)": (
                        date(2025, 1, 22),
                        date(2025, 1, 28),
                    ),
                    "Week 5 (29 Jan - 31 Jan 2025)": (
                        date(2025, 1, 29),
                        date(2025, 1, 31),
                    ),
                }
            else:
                week_options = {}
                cur_start = date(active_year, 1, 1)
                for w in range(1, 53):
                    cur_end = min(
                        cur_start + timedelta(days=6), date(active_year, 12, 31)
                    )
                    week_label = f"Week {w} ({cur_start.strftime('%d %b')} - {cur_end.strftime('%d %b %Y')})"
                    week_options[week_label] = (cur_start, cur_end)
                    cur_start = cur_end + timedelta(days=1)
                    if cur_start.year > active_year:
                        break

            chosen_week = st.selectbox(
                "Select Week", list(week_options.keys()), key="sp_week_picker"
            )
            sp_start_date, sp_end_date = week_options[chosen_week]

        elif date_selection_mode == "Specific Month":
            month_names = [
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December",
            ]
            if is_test_dataset:
                st.selectbox(
                    "Select Month", ["January"], index=0, key="sp_month_picker"
                )
                sp_start_date = date(2025, 1, 1)
                sp_end_date = date(2025, 1, 31)
            else:
                chosen_month = st.selectbox(
                    "Select Month", month_names, index=0, key="sp_month_picker"
                )
                m_idx = month_names.index(chosen_month) + 1
                sp_start_date = date(active_year, m_idx, 1)
                last_day = calendar.monthrange(active_year, m_idx)[1]
                sp_end_date = date(active_year, m_idx, last_day)

        else:
            c_range1, c_range2 = st.columns(2)
            if is_test_dataset:
                min_sp_bound = date(2025, 1, 1)
                max_sp_bound = date(2025, 1, 31)
                default_sp_start = date(2025, 1, 1)
                default_sp_end = date(2025, 1, 31)
            else:
                min_sp_bound = date(active_year, 1, 1)
                max_sp_bound = date(active_year, 12, 31)
                default_sp_start = date(active_year, 1, 1)
                default_sp_end = date(active_year, 1, 31)

            with c_range1:
                sp_start_date = st.date_input(
                    "Start Date",
                    value=default_sp_start,
                    min_value=min_sp_bound,
                    max_value=max_sp_bound,
                    key="sp_start_picker",
                )
            with c_range2:
                sp_end_date = st.date_input(
                    "End Date",
                    value=default_sp_end,
                    min_value=min_sp_bound,
                    max_value=max_sp_bound,
                    key="sp_end_picker",
                )

    load_profile = st.button(
        "Load Physical Profile",
        type="primary",
        key="load_physical_profile",
    )

    st.markdown("---")

    query_key = (
        sp_target_path,
        graph_bmu_pick,
        str(sp_start_date),
        str(sp_end_date),
        sp_is_azure,
    )

    if load_profile:
        if graph_bmu_pick is None:
            st.error("Please select a BMU.")
        elif sp_start_date > sp_end_date:
            st.error("Start Date must be before or equal to End Date.")
        else:
            try:
                with st.spinner(
                    f"Loading Settlement Period data for {graph_bmu_pick}..."
                ):
                    query_start = time.perf_counter()

                    queried_sp_df = query_sp_data(
                        sp_target_path,
                        graph_bmu_pick,
                        str(sp_start_date),
                        str(sp_end_date),
                        is_azure=sp_is_azure,
                        azure_token=sp_azure_token,
                    )

                    query_duration = time.perf_counter() - query_start

                st.session_state["sp_query_result"] = queried_sp_df
                st.session_state["sp_query_key"] = query_key
                st.session_state["sp_query_duration"] = query_duration
                st.session_state["sp_query_error"] = None

            except Exception as query_exc:
                st.session_state.pop("sp_query_result", None)
                st.session_state.pop("sp_query_key", None)
                st.session_state["sp_query_error"] = str(query_exc)

    stored_query_key = st.session_state.get("sp_query_key")
    stored_query_error = st.session_state.get("sp_query_error")
    stored_query_duration = st.session_state.get("sp_query_duration")

    if stored_query_error:
        st.error(f"Settlement Period query failed: {stored_query_error}")

    if stored_query_key == query_key:
        sp_df = st.session_state.get("sp_query_result", pd.DataFrame())
        query_has_run = True
    else:
        sp_df = pd.DataFrame()
        query_has_run = False
        if not stored_query_error:
            st.info(
                "Select a BMU and date range, then click **Load Physical Profile**."
            )

    if query_has_run:
        bmu_unfiltered_rows = len(sp_df)
        query_diag_error = None

        if (
            sp_df.empty
            and sp_target_path
            and not sp_is_azure
            and os.path.exists(sp_target_path)
        ):
            try:
                con_diag = duckdb.connect()
                diag_query_target = sp_target_path.replace("\\", "/")
                bmu_unfiltered_rows = con_diag.execute(
                    f"SELECT count(*) FROM read_csv_auto('{diag_query_target}', header=True) WHERE nationalGridBmUnit = ?",
                    [graph_bmu_pick],
                ).fetchone()[0]
                con_diag.close()
            except Exception as diag_err:
                query_diag_error = str(diag_err)

        # Diagnostics Expander (Zero Icons)
        with st.expander("Settlement Period Query Diagnostics", expanded=False):
            diag_c1, diag_c2 = st.columns(2)
            with diag_c1:
                st.markdown(f"**Data Source Mode**: `{sp_source_label}`")
                st.markdown(f"**Resolved SP Target**: `{sp_target_path}`")
                st.markdown(f"**Selected BMU**: `{graph_bmu_pick}`")
                st.markdown(
                    f"**Selected Date Range**: `{sp_start_date}` to `{sp_end_date}`"
                )
            with diag_c2:
                st.markdown(f"**BMU Rows (In Date Range)**: `{len(sp_df):,}`")
                st.markdown(
                    f"**BMU Total Rows in Source**: `{bmu_unfiltered_rows:,}`"
                    if isinstance(bmu_unfiltered_rows, int)
                    else f"`{bmu_unfiltered_rows}`"
                )
                if query_diag_error:
                    st.markdown(
                        f"**Query Status**: `Query Notice: {query_diag_error}`"
                    )
                else:
                    st.markdown(
                        f"**Query Status**: `{'Success' if not sp_df.empty else ('BMU Not in Dataset' if bmu_unfiltered_rows == 0 else 'Zero Rows in Date Range')}`"
                    )
                if stored_query_duration is not None:
                    st.markdown(
                        f"**Query Duration**: `{stored_query_duration:.2f} seconds`"
                    )

        if sp_df.empty:
            if bmu_unfiltered_rows == 0:
                bmu_sample_str = (
                    ", ".join(sp_sample_bmus[:10])
                    if sp_sample_bmus
                    else "None detected"
                )
                st.info(
                    f"BMU **{graph_bmu_pick}** has no records in this Settlement Period dataset (`{sp_source_label}`).\n\n"
                    f"Sample units present in this dataset: **{bmu_sample_str}**"
                )
            else:
                st.info(
                    f"BMU **{graph_bmu_pick}** has {bmu_unfiltered_rows:,} records in this dataset, but none between {sp_start_date} and {sp_end_date}. "
                    f"Please adjust the investigation date range."
                )
        else:
            # Prepare datetime and clean date formatting for all charts
            sp_plot_df = sp_df.copy()
            sp_plot_df["timeFrom"] = pd.to_datetime(sp_plot_df["timeFrom"])

            num_days = (
                (sp_end_date - sp_start_date).days + 1
                if hasattr(sp_end_date, "day") and hasattr(sp_start_date, "day")
                else 1
            )

            if num_days == 1:
                x_tick_format = "%H:%M"
                x_hover_format = "%H:%M"
                x_tick_angle = 0
            elif num_days <= 7:
                x_tick_format = "%d %b %H:%M"
                x_hover_format = "%d %b %Y %H:%M"
                x_tick_angle = -30
            elif num_days <= 31:
                x_tick_format = "%d %b"
                x_hover_format = "%d %b %Y %H:%M"
                x_tick_angle = -45
            else:
                x_tick_format = "%d %b %Y"
                x_hover_format = "%d %b %Y %H:%M"
                x_tick_angle = -45

            # CHART 1: Primary Physical Profile (PN, Metered Output, MEL, MIL, ABSVD)
            st.subheader(f"{graph_bmu_pick} Physical Profile")
            st.caption(
                "Physical Notification (PN), Settlement Metered Output, Maximum Export Limit (MEL), Stable Minimum Limit (MIL), and ABSVD in MW."
            )

            fig_primary = go.Figure()

            if "PNLevel_MW" in sp_plot_df.columns:
                fig_primary.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["PNLevel_MW"],
                        mode="lines",
                        name="PN",
                        line=dict(color="#0284c7", width=2.2),
                        hovertemplate="PN: %{y:.2f} MW<extra></extra>",
                    )
                )

            if "Metered_MW" in sp_plot_df.columns:
                fig_primary.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["Metered_MW"],
                        mode="lines",
                        name="Metered Output",
                        line=dict(color="#cf3e9e", width=2.2),
                        hovertemplate="Metered Output: %{y:.2f} MW<extra></extra>",
                    )
                )

            if "MELLevel_MW" in sp_plot_df.columns:
                fig_primary.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["MELLevel_MW"],
                        mode="lines",
                        name="MEL",
                        line=dict(color="#400732", width=2.2, shape="hv"),
                        hovertemplate="MEL: %{y:.2f} MW<extra></extra>",
                    )
                )

            if "MILLevel_MW" in sp_plot_df.columns:
                fig_primary.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["MILLevel_MW"],
                        mode="lines",
                        name="MIL",
                        line=dict(
                            color="#6b7280", width=1.8, shape="hv", dash="dot"
                        ),
                        hovertemplate="MIL: %{y:.2f} MW<extra></extra>",
                    )
                )

            if "ABSVD_MW" in sp_plot_df.columns:
                fig_primary.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["ABSVD_MW"],
                        mode="lines",
                        name="ABSVD",
                        line=dict(color="#d97706", width=2.0),
                        hovertemplate="ABSVD: %{y:.2f} MW<extra></extra>",
                    )
                )

            fig_primary.update_layout(
                title=f"{graph_bmu_pick} Physical Profile",
                hovermode="x unified",
                yaxis_title="MW",
                legend=dict(
                    orientation="h",
                    yanchor="bottom",
                    y=1.02,
                    xanchor="right",
                    x=1,
                ),
            )
            fig_primary.update_xaxes(
                title=None,
                tickformat=x_tick_format,
                hoverformat=x_hover_format,
                tickangle=x_tick_angle,
                showgrid=True,
                gridcolor="#f1f5f9",
            )
            fig_primary.update_yaxes(
                zeroline=True, zerolinewidth=1.5, zerolinecolor="#000000"
            )
            render_chart(fig_primary)

            col_g1, col_g2 = st.columns(2)

            # CHART 2: Expected Output vs Metered
            with col_g1:
                st.subheader("Expected Output vs Metered")
                st.caption(
                    "Comparison of expected delivered output, including ABSVD volume, "
                    "against actual metered generation."
                )

                fig_expected_vs_metered = go.Figure()

                if "ExpectOT_MW" in sp_plot_df.columns:
                    fig_expected_vs_metered.add_trace(
                        go.Scatter(
                            x=sp_plot_df["timeFrom"],
                            y=sp_plot_df["ExpectOT_MW"],
                            mode="lines",
                            name="Expected Output",
                            line=dict(
                                color="#0284c7",
                                width=2.0,
                            ),
                            hovertemplate=(
                                "Expected Output: %{y:.2f} MW<extra></extra>"
                            ),
                        )
                    )

                if "Metered_MW" in sp_plot_df.columns:
                    fig_expected_vs_metered.add_trace(
                        go.Scatter(
                            x=sp_plot_df["timeFrom"],
                            y=sp_plot_df["Metered_MW"],
                            mode="lines",
                            name="Metered",
                            line=dict(
                                color="#cf3e9e",
                                width=2.0,
                            ),
                            hovertemplate=(
                                "Metered: %{y:.2f} MW<extra></extra>"
                            ),
                        )
                    )

                fig_expected_vs_metered.update_layout(
                    title=f"Expected Output vs Metered — {graph_bmu_pick}",
                    yaxis_title="MW",
                    hovermode="x unified",
                )

                fig_expected_vs_metered.update_xaxes(
                    title=None,
                    tickformat=x_tick_format,
                    hoverformat=x_hover_format,
                    tickangle=x_tick_angle,
                    showgrid=True,
                    gridcolor="#f1f5f9",
                )

                fig_expected_vs_metered.update_yaxes(
                    zeroline=True,
                    zerolinewidth=1.2,
                    zerolinecolor="#000000",
                )

                render_chart(fig_expected_vs_metered)

            # CHART 3: Net Error Profile (in % with positive/negative colors)
            with col_g2:
                st.subheader("Net Error Profile")
                st.caption(
                    "Directional bias (Net Error %) centered around zero reference line."
                )
                fig_neterr = go.Figure()
                if "NetError%" in sp_plot_df.columns:
                    err_colors = [
                        "#0284c7" if val >= 0 else "#d97706"
                        for val in sp_plot_df["NetError%"]
                    ]
                    fig_neterr.add_trace(
                        go.Bar(
                            x=sp_plot_df["timeFrom"],
                            y=sp_plot_df["NetError%"],
                            name="Net Error (%)",
                            marker_color=err_colors,
                            hovertemplate="Net Error: %{y:.2f}%<extra></extra>",
                        )
                    )
                fig_neterr.add_hline(
                    y=0,
                    line_dash="solid",
                    line_color="#000000",
                    line_width=1.5,
                )
                fig_neterr.update_layout(
                    title=f"Net Error Profile — {graph_bmu_pick}",
                    yaxis_title="Net Error (%)",
                    hovermode="x unified",
                )
                fig_neterr.update_xaxes(
                    title=None,
                    tickformat=x_tick_format,
                    hoverformat=x_hover_format,
                    tickangle=x_tick_angle,
                    showgrid=True,
                    gridcolor="#f1f5f9",
                )
                render_chart(fig_neterr)

            # CHART 4: MEL / MIL vs PN
            st.subheader("MEL / MIL vs PN")
            st.caption(
                "Physical Notification compared against Maximum Export Limits (MEL) and Minimum Import/Export Limits (MIL)."
            )
            fig_envelope = go.Figure()

            if "MELLevel_MW" in sp_plot_df.columns:
                fig_envelope.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["MELLevel_MW"],
                        mode="lines",
                        name="MEL",
                        line=dict(color="#400732", width=2.0, shape="hv"),
                        hovertemplate="MEL: %{y:.2f} MW<extra></extra>",
                    )
                )
            if "MILLevel_MW" in sp_plot_df.columns:
                fig_envelope.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["MILLevel_MW"],
                        mode="lines",
                        name="MIL",
                        line=dict(
                            color="#6b7280", width=1.8, shape="hv", dash="dot"
                        ),
                        hovertemplate="MIL: %{y:.2f} MW<extra></extra>",
                    )
                )
            if "PNLevel_MW" in sp_plot_df.columns:
                fig_envelope.add_trace(
                    go.Scatter(
                        x=sp_plot_df["timeFrom"],
                        y=sp_plot_df["PNLevel_MW"],
                        mode="lines",
                        name="PN",
                        line=dict(color="#0284c7", width=2.2),
                        hovertemplate="PN: %{y:.2f} MW<extra></extra>",
                    )
                )
            fig_envelope.update_layout(
                title=f"MEL / MIL vs PN — {graph_bmu_pick}",
                yaxis_title="MW",
                hovermode="x unified",
            )
            fig_envelope.update_xaxes(
                title=None,
                tickformat=x_tick_format,
                hoverformat=x_hover_format,
                tickangle=x_tick_angle,
                showgrid=True,
                gridcolor="#f1f5f9",
            )
            fig_envelope.update_yaxes(
                zeroline=True, zerolinewidth=1.2, zerolinecolor="#000000"
            )
            render_chart(fig_envelope)

            # Export Queried SP Records
            csv_sp = sp_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                label=f"Download Settlement Period Data ({graph_bmu_pick})",
                data=csv_sp,
                file_name=f"{graph_bmu_pick}_sp_data_{sp_start_date}_to_{sp_end_date}.csv",
                mime="text/csv",
            )
