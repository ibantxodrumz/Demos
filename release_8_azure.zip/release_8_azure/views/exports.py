from typing import Union
import pandas as pd
import streamlit as st


def render_exports(
    df_annual_raw: pd.DataFrame,
    df_monthly_raw: pd.DataFrame,
    df_annual: pd.DataFrame,
    df_monthly: pd.DataFrame,
    selected_year: Union[int, str],
) -> None:
    """Render Tab 8: Central Export Hub."""
    st.header("Central Export Hub")
    st.caption(
        f"Consolidated download center for all fleet, monthly, fuel, and unit datasets ({selected_year})."
    )
    st.markdown("---")

    attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()

    fuel_summary = (
        df_annual.groupby("Fuel")
        .agg(
            Median_Error_Pct=("A_ABS_Error%", "median"),
            Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
            Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
            BMU_Count=("BMU", "nunique"),
        )
        .reset_index()
        .sort_values("Total_ABS_GWh", ascending=False)
    )

    ex_col1, ex_col2, ex_col3 = st.columns(3)
    with ex_col1:
        st.subheader("1. Annual Summary")
        st.caption("Fleet-wide performance evaluation and metrics per BMU.")
        csv_annual = df_annual.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Annual Summary (CSV)",
            data=csv_annual,
            file_name=f"annual_summary_{selected_year}_filtered.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with ex_col2:
        st.subheader("2. Monthly Summary")
        st.caption("Granular monthly records per BMU across the calendar year.")
        csv_monthly = df_monthly.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Monthly Summary (CSV)",
            data=csv_monthly,
            file_name=f"monthly_summary_{selected_year}_filtered.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with ex_col3:
        st.subheader("3. Require Attention Dataset")
        st.caption("BMUs exceeding operational error tolerances.")
        if not attention_df.empty:
            csv_attn = attention_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="Download Attention Dataset (CSV)",
                data=csv_attn,
                file_name=f"needs_attention_list_{selected_year}.csv",
                mime="text/csv",
                use_container_width=True,
            )
        else:
            st.info("No attention units to download.")

    st.markdown("---")

    ex_col4, ex_col5, ex_col6 = st.columns(3)
    with ex_col4:
        st.subheader("4. Fuel Performance Summary")
        st.caption("Aggregate volume, net bias, and median error per fuel.")
        csv_fuel = fuel_summary.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Fuel Summary (CSV)",
            data=csv_fuel,
            file_name=f"fuel_performance_summary_{selected_year}.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with ex_col5:
        st.subheader("5. Error Band Composition")
        st.caption("Distribution of units across the 5 operational error bands.")
        band_export = df_annual[
            ["BMU", "Fuel", "ErrorBand", "A_ABS_Error%"]
        ].sort_values(["ErrorBand", "A_ABS_Error%"])
        csv_band = band_export.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Error Bands (CSV)",
            data=csv_band,
            file_name=f"error_band_composition_{selected_year}.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with ex_col6:
        st.subheader("6. Technology Summary")
        st.caption("Comprehensive technology deep dive and metrics per fuel type.")
        tech_summary = (
            df_annual.groupby("Fuel")
            .agg(
                BMU_Count=("BMU", "nunique"),
                Median_ABS_Error=("A_ABS_Error%", "median"),
                Worst_ABS_Error=("A_ABS_Error%", "max"),
                Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
                Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
            )
            .reset_index()
            .sort_values("Total_ABS_GWh", ascending=False)
        )
        csv_tech = tech_summary.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="Download Technology Summary (CSV)",
            data=csv_tech,
            file_name=f"technology_summary_{selected_year}.csv",
            mime="text/csv",
            use_container_width=True,
        )
