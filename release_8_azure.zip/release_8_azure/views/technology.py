from typing import List, Union
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.chart_utils import render_chart


def render_technology(
    df_annual: pd.DataFrame,
    df_monthly: pd.DataFrame,
    all_fuels: List[str],
    selected_year: Union[int, str],
) -> None:
    """Render Tab 4: Top & Bottom BMU Breakdown by Technology."""
    st.header("Technology Deep Dive")
    selected_tech = st.selectbox(
        "Select Technology / Fuel Type", all_fuels, key="tech_selector"
    )

    tech_df = df_annual[df_annual["Fuel"] == selected_tech]
    tech_monthly = df_monthly[df_monthly["Fuel"] == selected_tech]

    if tech_df.empty:
        st.info(f"No units available for technology '{selected_tech}'.")
        return

    tc1, tc2, tc3 = st.columns(3)
    tc1.metric("BMU Count", len(tech_df))
    tc2.metric("Median ABS Error %", f"{tech_df['A_ABS_Error%'].median():.2f}%")
    worst_unit = tech_df.loc[tech_df["A_ABS_Error%"].idxmax()]
    tc3.metric(
        "Worst BMU Error %",
        f"{worst_unit['A_ABS_Error%']:.2f}%",
        delta=worst_unit["BMU"],
        delta_color="off",
    )

    col_t1, col_t2 = st.columns(2)
    with col_t1:
        fig_tdist = px.histogram(
            tech_df,
            x="A_ABS_Error%",
            title=f"Error Distribution — {selected_tech}",
            color_discrete_sequence=["#400732"],
            template="plotly_white",
        )
        render_chart(fig_tdist)

    with col_t2:
        if not tech_monthly.empty:
            trend = (
                tech_monthly.groupby("YearMonth")["M_ABS_Error%"]
                .median()
                .reset_index(name="Monthly_Median")
            )
            fig_ttrend = px.line(
                trend,
                x="YearMonth",
                y="Monthly_Median",
                markers=True,
                title=f"Monthly Median Error Trend — {selected_tech}",
                color_discrete_sequence=["#cf3e9e"],
                template="plotly_white",
            )
            render_chart(fig_ttrend)

    col_bench1, col_bench2 = st.columns(2)
    with col_bench1:
        st.subheader(f"Top Performing BMUs — {selected_tech}")
        st.caption(
            "Top 10 units with the lowest annual absolute error (best performers)."
        )
        top_best = tech_df.nsmallest(10, "A_ABS_Error%")[
            ["BMU", "A_ABS_Error%", "A_Net_Error%"]
        ]
        top_best = top_best.rename(
            columns={
                "A_ABS_Error%": "Annual ABS Error %",
                "A_Net_Error%": "Annual Net Error %",
            }
        )
        st.dataframe(
            top_best.style.format(
                {
                    "Annual ABS Error %": "{:.2f}%",
                    "Annual Net Error %": "{:+.2f}%",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )

    with col_bench2:
        st.subheader(f"Bottom BMUs — {selected_tech}")
        st.caption(
            "Top 10 units with the highest annual absolute error (investigation targets)."
        )
        bottom_worst = tech_df.nlargest(10, "A_ABS_Error%")[
            ["BMU", "A_ABS_Error%", "A_Net_Error%"]
        ]
        bottom_worst = bottom_worst.rename(
            columns={
                "A_ABS_Error%": "Annual ABS Error %",
                "A_Net_Error%": "Annual Net Error %",
            }
        )
        st.dataframe(
            bottom_worst.style.format(
                {
                    "Annual ABS Error %": "{:.2f}%",
                    "Annual Net Error %": "{:+.2f}%",
                }
            ),
            use_container_width=True,
            hide_index=True,
        )
