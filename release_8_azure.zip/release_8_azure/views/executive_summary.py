from typing import Union
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.chart_utils import render_chart


def render_executive_summary(
    df_annual: pd.DataFrame,
    df_monthly: pd.DataFrame,
    selected_year: Union[int, str],
) -> None:
    """Render Tab 1: Executive Summary (Fleet Overview & Fuel Summary)."""
    st.markdown(
        f"""
        <div style="margin-bottom: 6px;">
            <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 14px; letter-spacing: -0.015em;">Executive Summary</h2>
        </div>
        <div class="neso-active-window-card">
            <span>Active Review Window:</span>
            <span class="neso-aw-badge">Dataset: <strong>{selected_year} Calendar Year</strong></span>
            <span style="color: #6b7280; font-weight: 700;">|</span>
            <span class="neso-aw-badge">Status: <strong>Fleet Baseline (Active)</strong></span>
            <span style="color: #000000; font-size: 0.85rem; font-weight: 600;">({len(df_annual):,} BMUs Evaluated • {len(df_monthly):,} Monthly Records)</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
    fleet_median_error = df_annual["A_ABS_Error%"].median()

    max_err_idx = df_annual["A_ABS_Error%"].idxmax()
    max_err_row = df_annual.loc[max_err_idx]
    fleet_max_error = max_err_row["A_ABS_Error%"]
    max_bmu_info = f"{max_err_row['BMU']} ({max_err_row['Fuel']})"

    bmu_count = df_annual["BMU"].nunique()
    fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
    fleet_net_gwh = df_annual["NetError"].sum() / 1000

    kpi1.metric("Fleet Median Error %", f"{fleet_median_error:.2f}%")
    kpi2.metric(
        "Max Individual Error %",
        f"{fleet_max_error:.2f}%",
        delta=max_bmu_info,
        delta_color="off",
    )
    kpi3.metric("BMU Count", f"{bmu_count}")
    kpi4.metric("Total ABS Error (GWh)", f"{fleet_abs_gwh:,.2f}")
    kpi5.metric("Net Bias (GWh)", f"{fleet_net_gwh:,.2f}")

    fuel_summary = (
        df_annual.groupby("Fuel")
        .agg(
            Median_Error_Pct=("A_ABS_Error%", "median"),
            Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
            Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
            BMU_Count=("BMU", "nunique"),
        )
        .reset_index()
        .sort_values("Total_ABS_GWh", ascending=False)
    )

    st.markdown("---")

    # 1. Fuel Performance Summary
    st.subheader("Fuel Performance Summary")
    st.caption(
        "Detailed volume and error performance ranked by aggregate ABS GWh volume impact across all fuel types."
    )
    st.dataframe(
        fuel_summary.style.format(
            {
                "Median_Error_Pct": "{:.2f}%",
                "Total_ABS_GWh": "{:,.2f}",
                "Net_Bias_GWh": "{:,.2f}",
                "BMU_Count": "{:,d}",
            }
        ),
        use_container_width=True,
        hide_index=True,
    )

    csv_fuel = fuel_summary.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download Fuel Summary (CSV)",
        data=csv_fuel,
        file_name=f"fuel_performance_summary_{selected_year}.csv",
        mime="text/csv",
    )

    st.markdown("---")

    # 2. Fleet Error Distribution (Colorized by Operational Risk Band)
    st.subheader("Fleet Error Distribution by Operational Risk Band")
    st.caption(
        "Distribution of BMU annual absolute error percentages categorized by operational risk level: "
        "0–1% (Green), 1–2% (Light Green), 2–4% (Amber), 4–10% (Orange), >10% (Red)."
    )

    band_order = ["0-1%", "1-2%", "2-4%", "4-10%", ">10%"]
    band_palette = {
        "0-1%": "#10b981",  # Green
        "1-2%": "#84cc16",  # Light Green
        "2-4%": "#eab308",  # Amber
        "4-10%": "#f97316",  # Orange
        ">10%": "#ef4444",  # Red
    }

    band_df = (
        df_annual["ErrorBand"]
        .value_counts()
        .reindex(band_order)
        .fillna(0)
        .reset_index()
    )
    band_df.columns = ["ErrorBand", "Count"]
    band_df["Count"] = band_df["Count"].astype(int)
    band_df["Percentage"] = (band_df["Count"] / len(df_annual) * 100).round(1)

    fig_hist = px.bar(
        band_df,
        x="ErrorBand",
        y="Count",
        color="ErrorBand",
        color_discrete_map=band_palette,
        category_orders={"ErrorBand": band_order},
        text=band_df.apply(lambda r: f"{r['Count']} ({r['Percentage']}%)", axis=1),
        title=f"Fleet Error Distribution by Operational Risk Band ({selected_year})",
        template="plotly_white",
    )
    fig_hist.update_traces(textposition="outside")
    fig_hist.update_layout(
        xaxis=dict(title="Annual Error Band (Operational Risk Level)"),
        yaxis=dict(title="Count of BMUs"),
        showlegend=False,
        height=380,
    )
    render_chart(fig_hist)
