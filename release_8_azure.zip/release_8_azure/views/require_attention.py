from typing import Union
import pandas as pd
import streamlit as st

from services.data_processing import get_reason


def render_require_attention(
    df_annual_raw: pd.DataFrame,
    selected_year: Union[int, str],
) -> None:
    """Render Tab 7: Tolerance Breaches (Units Exceeding Thresholds)."""
    st.markdown(
        """
        <div style="margin-bottom: 12px;">
            <h2 style="color: #400732; font-size: 1.6rem; font-weight: 700; margin-bottom: 4px;">Require Attention: Units Exceeding Thresholds</h2>
            <p style="color: #000000; font-size: 0.92rem; font-weight: 500; margin-top: 0; margin-bottom: 14px;">
                Balancing Mechanism Units exceeding operational error tolerances (Wind/Solar: Net Error outside ±3% or ABS Error ≥ 9.4%; Other Fuels: Net Error outside ±1% or ABS Error ≥ 2.6%).
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()

    if attention_df.empty:
        st.success(
            "No BMUs require attention! All units within operational tolerances."
        )
        return

    attention_df["Reason"] = attention_df.apply(get_reason, axis=1)

    st.markdown(
        f"**{len(attention_df)}** BMUs triggered attention thresholds across the fleet:<br>"
        "• **Wind & Solar**: Net Error outside ±3.0% OR Absolute Error ≥ 9.4%<br>"
        "• **All Other Fuels**: Net Error outside ±1.0% OR Absolute Error ≥ 2.6%",
        unsafe_allow_html=True,
    )

    # Compact Fuel Selector preventing vertical bloat
    available_att_fuels = sorted(attention_df["Fuel"].unique().tolist())
    fuel_counts = attention_df["Fuel"].value_counts().to_dict()
    fuel_options = [f"All Fuels ({len(attention_df)} units)"] + [
        f"{f} ({fuel_counts[f]} units)" for f in available_att_fuels
    ]

    selected_att_option = st.selectbox(
        "Filter Attention Units by Fuel Type",
        fuel_options,
        index=0,
        key="att_fuel_selector",
    )

    if selected_att_option.startswith("All Fuels"):
        subset = attention_df.sort_values("A_ABS_Error%", ascending=False)
        active_fuel_label = "All Fuels"
        total_fuel_bmus = df_annual_raw["BMU"].nunique()
    else:
        fuel_name = selected_att_option.split(" (")[0]
        subset = attention_df[attention_df["Fuel"] == fuel_name].sort_values(
            "A_ABS_Error%", ascending=False
        )
        active_fuel_label = fuel_name
        total_fuel_bmus = df_annual_raw[df_annual_raw["Fuel"] == fuel_name][
            "BMU"
        ].nunique()

    pct_fleet_flagged = (
        (len(subset) / total_fuel_bmus * 100) if total_fuel_bmus > 0 else 0.0
    )

    # 5 Key metrics for selected fuel group
    k1, k2, k3, k4, k5 = st.columns(5)
    k1.metric("Flagged BMUs", len(subset))
    k2.metric(
        "% Fuel Fleet Flagged",
        f"{pct_fleet_flagged:.1f}%",
        delta=f"{len(subset)} / {total_fuel_bmus} units",
        delta_color="off",
    )
    k3.metric("Median ABS Error %", f"{subset['A_ABS_Error%'].median():.2f}%")
    k4.metric("Max ABS Error %", f"{subset['A_ABS_Error%'].max():.2f}%")
    k5.metric(
        "Total ABS Volume Error", f"{subset['ABSError'].sum()/1000:,.2f} GWh"
    )

    st.markdown(f"### {active_fuel_label} — List of Units")
    display_cols = ["BMU", "Fuel", "Reason", "A_Net_Error%", "A_ABS_Error%"]
    if "installedCapacity_mwh" in subset.columns:
        display_cols.append("installedCapacity_mwh")

    st.dataframe(
        subset[display_cols].style.format(
            {
                "A_Net_Error%": "{:+.2f}%",
                "A_ABS_Error%": "{:.2f}%",
                "installedCapacity_mwh": "{:,.1f}",
            }
        ),
        use_container_width=True,
        hide_index=True,
    )

    csv_att = subset.to_csv(index=False).encode("utf-8")
    st.download_button(
        label=f"Download {active_fuel_label} Attention Units (CSV)",
        data=csv_att,
        file_name=f"bmus_requiring_attention_{active_fuel_label.lower().replace(' ', '_')}_{selected_year}.csv",
        mime="text/csv",
    )
