from typing import Union
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.chart_utils import render_chart


def render_total_gwh_error(
    df_annual: pd.DataFrame,
    df_monthly: pd.DataFrame,
    selected_year: Union[int, str],
) -> None:
    """Render Tab 3: Aggregate GWh Volume Risk."""
    st.header("Total Volume (GWh) Error by Fuel")
    st.caption(
        "Aggregate volume impact: Total Absolute Error vs Net Directional Bias."
    )

    total_fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
    gwh_summary = (
        df_annual.groupby("Fuel")
        .agg(
            Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
            Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
        )
        .reset_index()
        .sort_values("Total_ABS_GWh", ascending=False)
    )
    gwh_summary["Pct_Fleet_Contribution"] = (
        (gwh_summary["Total_ABS_GWh"] / total_fleet_abs_gwh * 100)
        if total_fleet_abs_gwh > 0
        else 0.0
    )

    fig_gwh = px.bar(
        gwh_summary,
        x="Fuel",
        y=["Total_ABS_GWh", "Net_Bias_GWh"],
        barmode="group",
        title="Total Absolute Error vs Net Directional Bias (GWh)",
        color_discrete_sequence=["#400732", "#cf3e9e"],
        template="plotly_white",
    )
    render_chart(fig_gwh)

    st.subheader("Fuel Volume Impact & Fleet Contribution")
    st.caption(
        "Total absolute error, directional net bias, and percentage contribution to overall fleet volume error."
    )
    gwh_display = gwh_summary.rename(
        columns={
            "Total_ABS_GWh": "ABS Error GWh",
            "Net_Bias_GWh": "Net Bias GWh",
            "Pct_Fleet_Contribution": "% Fleet Contribution",
        }
    )
    st.dataframe(
        gwh_display.style.format(
            {
                "ABS Error GWh": "{:,.2f}",
                "Net Bias GWh": "{:,.2f}",
                "% Fleet Contribution": "{:.1f}%",
            }
        ),
        use_container_width=True,
        hide_index=True,
    )
