from typing import Union
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.chart_utils import render_chart


def render_median_error(
    df_annual: pd.DataFrame,
    df_monthly: pd.DataFrame,
    selected_year: Union[int, str],
) -> None:
    """Render Tab 2: Median Error Distribution."""
    st.header("Median Error by Fuel")
    st.caption("Distribution of Median Absolute Net Error % across fuel types.")

    fuel_median = (
        df_annual.groupby("Fuel")["A_ABS_Error%"]
        .median()
        .reset_index()
        .sort_values("A_ABS_Error%", ascending=True)
    )
    fig_hm1 = px.bar(
        fuel_median,
        x="Fuel",
        y="A_ABS_Error%",
        title="Median Error % by Fuel",
        color="A_ABS_Error%",
        color_continuous_scale=["#fcf4fa", "#cf3e9e", "#8a156e", "#400732"],
        template="plotly_white",
    )
    render_chart(fig_hm1)

    # Context Table directly underneath chart
    st.subheader("Fuel Median Performance & Sample Context")
    st.caption(
        "Contextual breakdown linking median error percentage with fleet sample size (BMU count)."
    )
    fuel_median_context = (
        df_annual.groupby("Fuel")
        .agg(
            Median_Error_Pct=("A_ABS_Error%", "median"),
            BMU_Count=("BMU", "nunique"),
        )
        .reset_index()
        .sort_values("Median_Error_Pct", ascending=False)
    )
    fuel_median_context.columns = ["Fuel", "Median Error %", "BMU Count"]
    st.dataframe(
        fuel_median_context.style.format(
            {"Median Error %": "{:.2f}%", "BMU Count": "{:,d}"}
        ),
        use_container_width=True,
        hide_index=True,
    )

    st.subheader("Annual Error Band Breakdown by Fuel")
    band_pivot = (
        pd.crosstab(
            df_annual["Fuel"],
            df_annual["ErrorBand"],
            normalize="index",
        )
        * 100
    )
    st.dataframe(
        band_pivot.style.format("{:.1f}%"),
        use_container_width=True,
    )

    band_export = df_annual[
        ["BMU", "Fuel", "ErrorBand", "A_ABS_Error%"]
    ].sort_values(["ErrorBand", "A_ABS_Error%"])
    csv_band = band_export.to_csv(index=False).encode("utf-8")
    st.download_button(
        label="Download Error Band Composition (CSV)",
        data=csv_band,
        file_name=f"error_band_composition_{selected_year}.csv",
        mime="text/csv",
    )
