from typing import List, Union
import pandas as pd
import plotly.express as px
import streamlit as st

from utils.chart_utils import render_chart


def render_bmu_explorer(
    df_annual_raw: pd.DataFrame,
    df_monthly_raw: pd.DataFrame,
    available_bmus: List[str],
    selected_year: Union[int, str],
) -> None:
    """Render Tab 5: Individual BMU Deep Dive."""
    st.header("BMU Explorer")
    st.caption(
        "Detailed historical performance profile for an individual Balancing Mechanism Unit."
    )

    col_search1, col_search2 = st.columns([3, 1])
    with col_search1:
        search_query = (
            st.text_input(
                "Search BMU by name",
                value="",
                placeholder="e.g. ABERU-1",
                key="bmu_exp_search",
            )
            .strip()
            .upper()
        )
    with col_search2:
        st.write("")
        st.write("")
        reset_search = st.button("Reset Search", key="btn_reset_bmu_exp")

    if reset_search or not search_query:
        bmu_options = available_bmus
    else:
        bmu_options = [b for b in available_bmus if search_query in b]

    if not bmu_options:
        st.warning(f"No BMUs found matching '{search_query}'.")
        bmu_pick = available_bmus[0] if available_bmus else None
    else:
        bmu_pick = st.selectbox("Select BMU", bmu_options, key="bmu_exp_select")

    if bmu_pick:
        bmu_annual = df_annual_raw[df_annual_raw["BMU"] == bmu_pick].iloc[0]
        bmu_monthly = df_monthly_raw[df_monthly_raw["BMU"] == bmu_pick].sort_values(
            "YearMonth"
        )

        st.subheader(f"Profile: {bmu_pick}")
        bc1, bc2, bc3 = st.columns(3)

        with bc1:
            st.markdown("### Annual Metrics")
            st.write(f"**Fuel:** {bmu_annual['Fuel']}")
            st.write(f"**Annual Net Error %:** {bmu_annual['A_Net_Error%']:.2f}%")
            st.write(f"**Annual ABS Error %:** {bmu_annual['A_ABS_Error%']:.2f}%")
            st.write(
                f"**Total ABS Error (GWh):** {bmu_annual['ABSError']/1000:,.2f}"
            )
            st.write(f"**Net Error (GWh):** {bmu_annual['NetError']/1000:,.2f}")
            if bmu_annual["NeedsAttention"]:
                st.error("Flagged: Needs Attention")
            else:
                st.success("Status: OK")

        with bc2:
            st.markdown("### Monthly Trend")
            if not bmu_monthly.empty:
                fig_spark = px.line(
                    bmu_monthly,
                    x="YearMonth",
                    y="M_ABS_Error%",
                    markers=True,
                    title="Monthly Absolute Error %",
                    color_discrete_sequence=["#400732"],
                    template="plotly_white",
                )
                render_chart(fig_spark)
            else:
                st.info("No monthly data available.")

        with bc3:
            st.markdown("### Monthly Data Table")
            st.dataframe(
                bmu_monthly[["YearMonth", "M_Net_Error%", "M_ABS_Error%"]],
                use_container_width=True,
                hide_index=True,
            )

            csv_bmu = bmu_monthly.to_csv(index=False).encode("utf-8")
            st.download_button(
                label=f"Download {bmu_pick} Data (CSV)",
                data=csv_bmu,
                file_name=f"{bmu_pick}_monthly_data_{selected_year}.csv",
                mime="text/csv",
            )
