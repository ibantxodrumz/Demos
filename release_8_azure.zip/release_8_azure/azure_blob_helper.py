"""
Backward-compatibility re-export.
Canonical implementation lives in `data.azure_blob_helper`.
"""

from data.azure_blob_helper import (
    AzureBlobStorage,
    AZURE_PACKAGES_AVAILABLE,
)

__all__ = ["AzureBlobStorage", "AZURE_PACKAGES_AVAILABLE"]
