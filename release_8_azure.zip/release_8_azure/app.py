import base64
import os
import pandas as pd
import streamlit as st

from constants import AVAILABLE_YEARS, DEFAULT_YEAR
from data.data_loader import (
    find_local_input_file,
    get_sp_filenames,
    load_local_summaries,
    load_azure_summaries,
)
from data.sp_repository import query_sp_data
from services.data_processing import (
    categorize_error,
    get_reason,
    process_data,
    apply_filters,
)
from views.executive_summary import render_executive_summary
from views.median_error import render_median_error
from views.total_gwh_error import render_total_gwh_error
from views.technology import render_technology
from views.bmu_explorer import render_bmu_explorer
from views.physical_profile import render_physical_profile
from views.require_attention import render_require_attention
from views.exports import render_exports

__all__ = [
    "find_local_input_file",
    "query_sp_data",
    "process_data",
    "apply_filters",
    "categorize_error",
    "get_reason",
    "run_streamlit_app",
]

CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap');
    .stApp { background-color: #fcfcfd; color: #111827; font-family: 'Poppins', sans-serif !important; }
    * { font-family: 'Poppins', sans-serif; }
    section[data-testid="stSidebar"] { background-color: #ffffff !important; border-right: 1px solid #000000; }
    .neso-sidebar-header { padding: 10px 0 16px 0; margin-bottom: 12px; border-bottom: 2px solid #000000; text-align: center; }
    .neso-sidebar-logo { max-width: 130px; height: auto; margin-bottom: 8px; }
    .neso-sidebar-title { color: #400732; font-weight: 800; font-size: 1.05rem; letter-spacing: -0.01em; margin: 0; }
    .neso-sidebar-subtitle { color: #000000; font-size: 0.8rem; font-weight: 600; margin-top: 2px; }
    .neso-active-window-card { background: #fdf2f8; border: 1px solid #000000; border-left: 5px solid #400732; border-radius: 6px; padding: 8px 14px; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: #000000; font-weight: 600; }
    .neso-aw-badge { background: #fce7f3; color: #000000; font-weight: 700; padding: 2px 8px; border-radius: 4px; border: 1px solid #000000; font-size: 0.8rem; }
    div[data-testid="stMetric"] { background-color: #ffffff; border: 1px solid #000000; border-radius: 8px; padding: 12px 16px; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.08); }
    div[data-testid="stMetricLabel"] { color: #000000 !important; font-size: 0.85rem !important; font-weight: 700 !important; }
    div[data-testid="stMetricValue"] { color: #400732 !important; font-weight: 800 !important; font-size: 1.65rem !important; }
    div[data-baseweb="tab-list"] { border-bottom: 2px solid #000000 !important; gap: 6px; padding-bottom: 2px; display: flex !important; flex-wrap: wrap !important; overflow-x: auto !important; }
    button[data-baseweb="tab"] { background-color: #fdf2f8 !important; border: 1px solid #000000 !important; border-radius: 6px 6px 0 0 !important; padding: 8px 14px !important; color: #000000 !important; font-weight: 700 !important; font-size: 0.88rem !important; white-space: nowrap !important; flex-shrink: 0 !important; transition: all 0.15s ease-in-out; }
    button[data-baseweb="tab"]:hover { background-color: #fce7f3 !important; border-color: #000000 !important; color: #000000 !important; }
    button[data-baseweb="tab"][aria-selected="true"] { background-color: #fbcfe8 !important; border: 2px solid #000000 !important; border-bottom: 2px solid #fbcfe8 !important; color: #000000 !important; font-weight: 800 !important; }
    button[data-baseweb="tab"] div { color: #000000 !important; font-weight: 700 !important; }
    button[data-baseweb="tab"][aria-selected="true"] div { color: #000000 !important; font-weight: 800 !important; }
</style>
"""


def run_streamlit_app():
    st.set_page_config(
        page_title="PN Accuracy Dashboard",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # Assets & Styling with Poppins Font, Light Pink Tabs, and Black Borders
    script_dir = os.path.dirname(os.path.abspath(__file__))
    logo_path = os.path.join(script_dir, "assets", "neso_logo.jpg")
    logo_b64 = None
    if os.path.exists(logo_path):
        with open(logo_path, "rb") as img_f:
            logo_b64 = base64.b64encode(img_f.read()).decode("utf-8")

    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

    # Sidebar: Branding
    if logo_b64:
        st.sidebar.markdown(
            f"""
            <div class="neso-sidebar-header">
                <img src="data:image/jpeg;base64,{logo_b64}" class="neso-sidebar-logo" alt="NESO Logo" />
                <div class="neso-sidebar-title">Market Monitoring</div>
                <div class="neso-sidebar-subtitle">PN Accuracy Dashboard</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.sidebar.subheader("Data Selection")

    # Calendar Year Selection
    default_year_idx = (
        AVAILABLE_YEARS.index(DEFAULT_YEAR) if DEFAULT_YEAR in AVAILABLE_YEARS else 0
    )
    selected_year = st.sidebar.selectbox(
        "Calendar Year",
        AVAILABLE_YEARS,
        index=default_year_idx,
        key="selected_year_selectbox",
    )

    annual_filename = f"annual_summary_{selected_year}.csv"
    monthly_filename = f"monthly_summary_{selected_year}.csv"
    sp_local_filename, sp_azure_filename = get_sp_filenames(selected_year)

    # Data Source Toggle
    if "data_source_selection" not in st.session_state:
        st.session_state["data_source_selection"] = "Azure Blob Storage"

    data_source_options = [
        "Azure Blob Storage",
        "Local (inputs/ folder)",
        "Manual Upload (CSV)",
    ]

    current_index = 0
    if st.session_state["data_source_selection"] in data_source_options:
        current_index = data_source_options.index(
            st.session_state["data_source_selection"]
        )

    data_source = st.sidebar.radio(
        "Data Source",
        data_source_options,
        index=current_index,
        key="data_source_radio",
    )
    st.session_state["data_source_selection"] = data_source

    annual_raw, monthly_raw = None, None
    sp_target_path = None
    sp_is_azure = False
    sp_source_label = None
    sp_azure_token = None

    if data_source == "Azure Blob Storage":
        try:
            with st.sidebar.status(
                f"Fetching {selected_year} data from Azure...",
                expanded=False,
            ):
                st.write(f"Connecting to container and reading {selected_year} summaries...")
                annual_raw, monthly_raw, sp_target_path, sp_is_azure, sp_source_label = (
                    load_azure_summaries(selected_year)
                )
                st.write(f"Fetched Annual Summary ({annual_filename}).")
                st.write(f"Fetched Monthly Summary ({monthly_filename}).")

            st.sidebar.success(f"Azure {selected_year} Data Loaded Successfully")

        except Exception as e:
            error_details = str(e)
            st.sidebar.error(f"Azure Connection Notice: {error_details}")
            st.error(
                f"**Unable to connect to Azure Blob Storage**\n\n"
                f"Connection details: `{error_details}`\n\n"
                f"Please ensure Azure authentication is available.\n\n"
                f"To operate offline, switch **Data Source** to "
                f"**Local (inputs/ folder)**."
            )
            st.stop()

    elif data_source == "Local (inputs/ folder)":
        annual_raw, monthly_raw, sp_target_path, sp_is_azure, sp_source_label = (
            load_local_summaries(selected_year)
        )
        if annual_raw is not None and monthly_raw is not None:
            st.sidebar.success(f"Local {selected_year} inputs loaded from 'inputs/'")
        else:
            st.sidebar.error(
                f"Could not find `{annual_filename}` or `{monthly_filename}` in 'inputs/' folder."
            )
            st.info(
                f"Local files for {selected_year} are not present in `inputs/`. Please choose another year or use Manual Upload."
            )
            st.stop()

    else:
        # Manual CSV Upload
        st.sidebar.markdown("### Upload Custom Data")
        uploaded_annual = st.sidebar.file_uploader(
            f"Upload Annual Summary ({selected_year})", type=["csv"]
        )
        uploaded_monthly = st.sidebar.file_uploader(
            f"Upload Monthly Summary ({selected_year})", type=["csv"]
        )
        if uploaded_annual and uploaded_monthly:
            annual_raw = pd.read_csv(uploaded_annual)
            monthly_raw = pd.read_csv(uploaded_monthly)
            st.sidebar.success("Custom CSV datasets loaded successfully.")
        else:
            st.sidebar.info(
                f"Please upload both Annual and Monthly CSV files for {selected_year}."
            )
            st.stop()

    # Process Datasets
    df_annual_raw, df_monthly_raw, error_msg = process_data(
        annual_raw, monthly_raw, year=selected_year
    )
    if error_msg:
        st.error(error_msg)
        st.stop()

    st.sidebar.markdown("---")
    st.sidebar.subheader("Filters")

    all_fuels = sorted(df_annual_raw["Fuel"].unique().tolist())
    selected_fuels = st.sidebar.multiselect(
        "Select Fuel(s)", all_fuels, default=all_fuels
    )

    needs_attention_only = st.sidebar.checkbox("Needs Attention only", value=False)

    df_annual, df_monthly = apply_filters(
        df_annual_raw, df_monthly_raw, selected_fuels, None, needs_attention_only
    )
    available_bmus = sorted(df_annual["BMU"].unique().tolist())

    if df_annual.empty:
        st.warning("No BMUs match the current filters.")
        st.stop()

    # Main Page Header
    st.markdown(
        """
        <div style="margin-bottom: 1rem;">
            <h1 style="color: #400732; font-size: 2.05rem; font-weight: 800; margin: 0; letter-spacing: -0.02em;">
                Market Monitoring: PN Accuracy Dashboard
            </h1>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # 8 Clean Tabs (No Icons, Light Pink with Black Borders)
    tab1, tab1_m, tab1_gwh, tab3, tab4, tab_graph, tab5, tab6 = st.tabs(
        [
            "Executive Summary",
            "Median Error",
            "Total GWh Error",
            "By Technology",
            "BMU Explorer",
            "BMU Units Physical Profile",
            "Require Attention",
            "Exports",
        ]
    )

    with tab1:
        render_executive_summary(df_annual, df_monthly, selected_year)

    with tab1_m:
        render_median_error(df_annual, df_monthly, selected_year)

    with tab1_gwh:
        render_total_gwh_error(df_annual, df_monthly, selected_year)

    with tab3:
        render_technology(df_annual, df_monthly, all_fuels, selected_year)

    with tab4:
        render_bmu_explorer(df_annual_raw, df_monthly_raw, available_bmus, selected_year)

    with tab_graph:
        render_physical_profile(
            data_source,
            sp_target_path,
            sp_is_azure,
            sp_source_label,
            sp_local_filename,
            sp_azure_filename,
            selected_year,
            available_bmus,
            sp_azure_token,
        )

    with tab5:
        render_require_attention(df_annual_raw, selected_year)

    with tab6:
        render_exports(
            df_annual_raw,
            df_monthly_raw,
            df_annual,
            df_monthly,
            selected_year,
        )


if __name__ == "__main__" or st.runtime.exists():
    if st.runtime.exists():
        run_streamlit_app()
