from datetime import datetime
import pandas as pd
import streamlit as st


def categorize_error(x):
    """Categorize error percentage into predefined operational bands."""
    if x <= 1:
        return "0-1%"
    elif x <= 2:
        return "1-2%"
    elif x <= 4:
        return "2-4%"
    elif x <= 10:
        return "4-10%"
    else:
        return ">10%"


def get_reason(row):
    """Generate detailed reason string for BMUs exceeding operational thresholds.

    Wind/Solar: Net outside [-3%, +3%] OR ABS >= 9.4%
    Other fuels: Net outside [-1%, +1%] OR ABS >= 2.6%
    """
    reasons = []
    fuel_upper = str(row.get("Fuel", "")).upper()

    # Universal column resolution across schema variants
    net_err = row.get(
        "A_Net_Error%", row.get("A_Net_error%", row.get("A_NetError%", 0.0))
    )
    abs_err = row.get(
        "A_ABS_Error%", row.get("A_ABS_error%", row.get("A_ABS_NetError%", 0.0))
    )

    if fuel_upper in ["WIND", "SOLAR"]:
        if abs(net_err) > 3.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±3%)")
        if abs_err >= 9.4:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 9.4%)")
    else:
        if abs(net_err) > 1.0:
            reasons.append(f"Net Error {net_err:+.2f}% (outside ±1%)")
        if abs_err >= 2.6:
            reasons.append(f"ABS Error {abs_err:.2f}% (≥ 2.6%)")
    return "; ".join(reasons) if reasons else "Within Tolerances"


@st.cache_data
def process_data(df_annual_raw, df_monthly_raw, year: int = 2025):
    """Clean, coerce, and normalize Annual and Monthly datasets.

    Provides universal dual-mapping for all error column conventions:
    A_Net_Error% <-> A_Net_error% <-> A_NetError%
    A_ABS_Error% <-> A_ABS_error% <-> A_ABS_NetError%
    """
    # 1. Process Annual
    try:
        df_annual = df_annual_raw.copy()

        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)
        df_annual["Year"] = int(year)
        df_annual["Grain"] = "annual"

        numeric_cols_annual = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_annual:
            if col in df_annual.columns:
                df_annual[col] = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )

        # Standardize Annual Net Error
        net_err_series = None
        for col in ["A_Net_Error%", "A_Net_error%", "A_NetError%"]:
            if col in df_annual.columns:
                net_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )
                break
        if net_err_series is None:
            net_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_Net_Error%"] = net_err_series
        df_annual["A_Net_error%"] = net_err_series
        df_annual["A_NetError%"] = net_err_series

        # Standardize Annual ABS Error
        abs_err_series = None
        for col in ["A_ABS_Error%", "A_ABS_error%", "A_ABS_NetError%"]:
            if col in df_annual.columns:
                abs_err_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(
                    0
                )
                break
        if abs_err_series is None:
            abs_err_series = pd.Series(0.0, index=df_annual.index)
        df_annual["A_ABS_Error%"] = abs_err_series
        df_annual["A_ABS_error%"] = abs_err_series
        df_annual["A_ABS_NetError%"] = abs_err_series

        # Standardize Max Monthly Error
        max_m_series = None
        for col in ["max_M_ABS_Error%", "max_M_ABS_NetError%"]:
            if col in df_annual.columns:
                max_m_series = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
                break
        if max_m_series is None:
            max_m_series = pd.Series(0.0, index=df_annual.index)
        df_annual["max_M_ABS_Error%"] = max_m_series
        df_annual["max_M_ABS_NetError%"] = max_m_series

        df_annual["SizeBasis"] = pd.to_numeric(
            df_annual.get("installedCapacity_mwh", 0), errors="coerce"
        ).fillna(0)

    except Exception as e:
        return None, None, f"Error processing Annual data: {str(e)}"

    # 2. Process Monthly
    try:
        df_monthly = df_monthly_raw.copy()

        def parse_date(x):
            try:
                parts = str(x).split("-")
                if len(parts) == 2:
                    return datetime(int(parts[0]), int(parts[1]), 1)
                return pd.NaT
            except Exception:
                return pd.NaT

        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_date)
        df_monthly["Year"] = df_monthly["YearMonthObj"].dt.year
        df_monthly["Month"] = df_monthly["YearMonthObj"].dt.month
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        df_monthly["YearMonth"] = df_monthly["YearMonthObj"].dt.strftime("%Y-%m")

        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)
        df_monthly["Grain"] = "monthly"

        numeric_cols_monthly = [
            "PNLevel",
            "MELLevel",
            "MILLevel",
            "BidVolume",
            "OfferVolume",
            "Metered",
            "ExpectOT",
            "CapacityCalibrated",
            "CapacityNorm",
            "ABSVD_MWh",
            "NetError",
            "ABSError",
            "installedCapacity_mwh",
        ]
        for col in numeric_cols_monthly:
            if col in df_monthly.columns:
                df_monthly[col] = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)

        # Standardize Monthly Net Error
        m_net_err_series = None
        for col in ["M_Net_Error%", "M_Net_error%", "M_NetError%"]:
            if col in df_monthly.columns:
                m_net_err_series = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)
                break
        if m_net_err_series is None:
            m_net_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_Net_Error%"] = m_net_err_series
        df_monthly["M_Net_error%"] = m_net_err_series
        df_monthly["M_NetError%"] = m_net_err_series

        # Standardize Monthly ABS Error
        m_abs_err_series = None
        for col in ["M_ABS_Error%", "M_ABS_error%", "M_ABS_NetError%"]:
            if col in df_monthly.columns:
                m_abs_err_series = pd.to_numeric(
                    df_monthly[col], errors="coerce"
                ).fillna(0)
                break
        if m_abs_err_series is None:
            m_abs_err_series = pd.Series(0.0, index=df_monthly.index)
        df_monthly["M_ABS_Error%"] = m_abs_err_series
        df_monthly["M_ABS_error%"] = m_abs_err_series
        df_monthly["M_ABS_NetError%"] = m_abs_err_series

    except Exception as e:
        return None, None, f"Error processing Monthly data: {str(e)}"

    # 3. P90 Calculation retired
    df_annual["P90_monthly_error"] = 0.0

    # 4. Logic: Needs Attention (Fuel-specific thresholds)
    is_wind_solar = df_annual["Fuel"].astype(str).str.upper().isin(["WIND", "SOLAR"])
    cond_wind_solar = is_wind_solar & (
        (df_annual["A_NetError%"].abs() > 3.0) | (df_annual["A_ABS_Error%"] >= 9.4)
    )
    cond_other_fuels = (~is_wind_solar) & (
        (df_annual["A_NetError%"].abs() > 1.0) | (df_annual["A_ABS_Error%"] >= 2.6)
    )
    df_annual["NeedsAttention"] = cond_wind_solar | cond_other_fuels

    # 5. Logic: Error Band Classification
    df_annual["ErrorBand"] = df_annual["A_ABS_Error%"].apply(categorize_error)
    df_annual["ErrorBand"] = pd.Categorical(
        df_annual["ErrorBand"],
        categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"],
        ordered=True,
    )

    return df_annual, df_monthly, None


def apply_filters(df_a, df_m, fuels, bmus=None, attention_only=False):
    """Filter annual and monthly datasets based on active sidebar selections."""
    res_a = df_a[df_a["Fuel"].isin(fuels)]
    if bmus is not None:
        res_a = res_a[res_a["BMU"].isin(bmus)]
    if attention_only:
        res_a = res_a[res_a["NeedsAttention"] == True]

    filtered_bmus = res_a["BMU"].unique()
    res_m = df_m[df_m["BMU"].isin(filtered_bmus)]
    res_m = res_m[res_m["Fuel"].isin(fuels)]

    return res_a, res_m
