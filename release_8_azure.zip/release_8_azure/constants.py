ACCOUNT_URL = "https://dlaaencmmdsffuks01.blob.core.windows.net/"
CONTAINER_NAME = "datalake"
PROJECT_BASE_NAME = "pn-accuracy"
PROJECT_NAME = "pn-accuracy-2025"  # Backward compatibility

VERSION = "Release 8 (Modular Architecture Refactor)"
AVAILABLE_YEARS = [2025, 2026]
DEFAULT_YEAR = 2025

DEFAULT_ANNUAL_FILE = "annual_summary_2025.csv"
DEFAULT_MONTHLY_FILE = "monthly_summary_2025.csv"
DEFAULT_SP_FILE = "sp_summary_2025.csv"
DEFAULT_SP_TEST_FILE = "sp_summary_test.csv"
INPUT_DIR = "inputs"
