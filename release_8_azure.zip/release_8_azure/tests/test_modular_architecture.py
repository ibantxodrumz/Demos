import os
import unittest


class TestModularArchitecture(unittest.TestCase):
    """Guards Release 8 modular boundaries, package imports, and orchestration scope."""

    def test_data_package_exports(self):
        from data import (
            AzureBlobStorage,
            find_local_input_file,
            get_sp_filenames,
            load_local_summaries,
            load_azure_summaries,
            query_sp_data,
        )

        self.assertTrue(callable(find_local_input_file))
        self.assertTrue(callable(get_sp_filenames))
        self.assertTrue(callable(load_local_summaries))
        self.assertTrue(callable(load_azure_summaries))
        self.assertTrue(callable(query_sp_data))
        self.assertTrue(hasattr(AzureBlobStorage, "get_sp_azure_url"))

    def test_services_package_exports(self):
        from services import (
            categorize_error,
            get_reason,
            process_data,
            apply_filters,
        )

        self.assertTrue(callable(categorize_error))
        self.assertTrue(callable(get_reason))
        self.assertTrue(callable(process_data))
        self.assertTrue(callable(apply_filters))

    def test_utils_package_exports(self):
        from utils import force_light_chart, render_chart

        self.assertTrue(callable(force_light_chart))
        self.assertTrue(callable(render_chart))

    def test_views_package_exports(self):
        from views import (
            render_executive_summary,
            render_median_error,
            render_total_gwh_error,
            render_technology,
            render_bmu_explorer,
            render_physical_profile,
            render_require_attention,
            render_exports,
        )

        self.assertTrue(callable(render_executive_summary))
        self.assertTrue(callable(render_median_error))
        self.assertTrue(callable(render_total_gwh_error))
        self.assertTrue(callable(render_technology))
        self.assertTrue(callable(render_bmu_explorer))
        self.assertTrue(callable(render_physical_profile))
        self.assertTrue(callable(render_require_attention))
        self.assertTrue(callable(render_exports))

    def test_app_orchestration_line_count(self):
        """Ensure app.py serves solely as orchestration layer without bloat."""
        from tests import APP_DIR
        app_path = os.path.join(APP_DIR, "app.py")
        self.assertTrue(os.path.exists(app_path))
        with open(app_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        line_count = len(lines)
        self.assertLessEqual(
            line_count,
            360,
            f"app.py should be a lean orchestration layer (~200-300 lines), but has {line_count} lines",
        )
        self.assertGreaterEqual(
            line_count,
            180,
            f"app.py is unexpectedly truncated with only {line_count} lines",
        )


if __name__ == "__main__":
    unittest.main()
