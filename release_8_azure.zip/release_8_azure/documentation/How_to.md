# Market Monitoring — Operational User Guide
## Physical Notification (PN) Accuracy Dashboard

**Platform Release:** Release 8 (Modular Cloud Architecture)  
**Standard:** NESO Market Monitoring  

---

## 1. Executive Overview and Purpose

The **Physical Notification (PN) Accuracy Dashboard** is the core supervisory tool designed for market monitoring analysts, operations planners, and regulatory compliance teams to evaluate the forecasting fidelity of generation assets registered in the Great Britain Balancing Mechanism (BM).

The dashboard benchmarks what balancing mechanism units (BMUs) submitted as their expected generation schedule (**Physical Notification** or **PN**) against what units physically generated (**Metered Volume**). Accurate physical notifications are the foundation of efficient transmission system operation, constraint management, and reserve procurement.

### Strategic Objectives:
- **System Balancing and Reliability**: Accurate notifications minimize unexpected imbalances between generation and demand.
- **Cost Mitigation**: Erroneous notifications require costly last-minute reserve actions and balancing mechanism instructions.
- **Grid Code Compliance**: Evaluates generator fidelity against statutory submission guidelines and dynamic tolerance bands.
- **Market Transparency**: Delivers standardized benchmarking across technology classes (Wind, CCGT, Nuclear, Biomass, Hydro, Battery).

---

## 2. Glossary and Core Analytical Metrics

The application employs standardized industry metrics normalized for capacity to ensure fair comparison across small embedded renewable generators and large centralized power plants.

| Metric / Concept | Formula / Definition | Operational Application |
| :--- | :--- | :--- |
| **BMU** | Balancing Mechanism Unit | Individual generation or demand entity registered in the GB market. |
| **PN (MW / MWh)** | Physical Notification schedule | Generation schedule submitted by the operator by gate closure. |
| **Metered (MW / MWh)** | Actual metered generation output | Physical power exported onto the transmission or distribution network. |
| **Annual Absolute Net Error %** | `abs(Expected - Metered) / Capacity * 100` | Capacity-normalized efficiency. Lower percentage indicates higher fidelity. |
| **Net Error (GWh)** | `sum(Expected - Metered)` in GWh | Directional bias indicator. Positive = Over-forecast; Negative = Under-forecast. |
| **Total Absolute Error (GWh)** | `sum(abs(Expected - Metered))` in GWh | System volume impact. Quantifies aggregate energy imbalance caused on the grid. |
| **P90 Error %** | 90th percentile of monthly absolute error | Tail risk indicator. Identifies assets prone to severe volatility spikes. |
| **Needs Attention Flag** | Flagged if error breaches tolerance limit | Automated regulatory flag (e.g. >25% error or fuel dual thresholds). |

---

## 3. Operating Environments and Data Sourcing

The Release 8 dashboard features a unified data loading boundary designed for complete separation between corporate cloud data lake access and local offline self-containment:

- **Azure Blob Storage Mode**: Directly queries corporate Azure Data Lake storage via `AzureCliCredential`. Utilizes modern DuckDB remote Parquet range requests to slice high-resolution settlement-period data with minimal network payload.
- **Local (inputs/ folder) Mode**: Completely offline operation. Reads canonical baseline datasets (`annual_summary_2025.csv`, `monthly_summary_2025.csv`, and `sp_summary_2025.csv`) directly from the `inputs/` folder with zero external network connectivity.
- **Manual Upload (CSV) Mode**: Enables users to drag and drop custom annual or monthly CSV summaries for exploratory analysis, stress testing, or audits without modifying repository inputs.

---

## 4. Tab-by-Tab Functional Guide

### Tab 1: Fleet Overview and Fuel Summary
*Provides high-level portfolio oversight across the entire national generation fleet.*
- **Fleet KPI Cards**: Total registered BMUs, fleet-wide median error percentage, aggregate absolute error in GWh, and net directional imbalance.
- **Fuel Performance Summary Table**: Breaks down performance metrics by generation technology (Gas CCGT, Wind, Nuclear, Biomass, Hydro, Battery Storage, etc.).
- **Fuel Error Profile Comparison**: Comparative visualization highlighting median error and volume exposure by fuel type.

### Tab 2: Median Error Distribution
*Examines fleet distribution characteristics and capacity-normalized error segmentation.*
- **Error Band Composition**: Categorizes units into standard regulatory error bands (0-1%, 1-2%, 2-4%, 4-10%, and >10%).
- **Size Category Analysis**: Segregates performance into Small (<50 MW), Medium (50-300 MW), and Large (>300 MW) generation classes to evaluate capacity scaling impacts.
- **Cumulative Distribution**: Displays the distribution curve to evaluate overall fleet predictability.

### Tab 3: Aggregate GWh Volume Risk
*Identifies high-impact generation assets driving aggregate grid energy imbalances.*
- **Capacity vs. Total Error (GWh) Bubble Chart**: Plots asset size against absolute volume mismatch, with bubble size representing total volume and color indicating directional bias.
- **Pareto Cumulative Volume Analysis**: Illustrates the top tier of units responsible for the majority of fleet-wide energy imbalances.
- **Volume Risk Quartiles**: Sorts units by gross balancing impact to support prioritized control room oversight.

### Tab 4: Top and Bottom BMU Breakdown
*Delivers comparative benchmarking filtered by individual generation technology.*
- **Technology Selector**: Filter analysis by specific fuel type (e.g. Wind, Gas, Nuclear).
- **Top 10 Benchmark Table**: Highlights the most accurate, reliable units within the chosen technology class.
- **Bottom 10 Alert Table**: Highlights poor performers exhibiting systematic forecasting deviation.
- **Directional Bias Visualizer**: Contrasts over-forecasting vs under-forecasting bias across unit peer groups.

### Tab 5: Individual BMU Deep Dive
*Forensic investigation workbench for individual generation assets.*
- **Unit Selector**: Instant search and filtering across all registered BMUs by unit identifier.
- **Asset Profile Card**: Displays registered fuel type, installed capacity (MW), annual error percentage, and gross GWh impact.
- **Monthly Trend Progression**: Chronological trend showing monthly accuracy variations across the calendar year to identify chronic under-performance versus acute seasonal anomalies.

### Tab 6: Physical Notification and Generation Profile
*High-resolution settlement period (half-hourly) engineering inspection powered by DuckDB in-memory engine.*
- **Settlement Date Range and Period Selectors**: Filter investigation windows down to individual dates and settlement periods (SP 1 to 48/50).
- **DuckDB In-Memory Query Engine**: Rapidly queries and slices multi-million row settlement period Parquet/CSV data without downloading entire files.
- **Four Synchronized Diagnostic Charts**:
  1. *Physical Notification vs Metered Volume*: Real-time half-hourly MW schedule versus actual physical output.
  2. *Forecast Error MW*: Instantaneous MW delta (Expected minus Metered) across each half-hour interval.
  3. *Cumulative Deviation MWh*: Integral energy mismatch accumulated over the chosen observation window.
  4. *Bid-Offer Acceptances (BOA) and Balancing Actions*: Overlaid dispatch instructions contextualizing grid operator interventions.
- **Settlement Period Data Export**: Download filtered high-resolution half-hourly profile data directly to CSV for offline forensic audits.

### Tab 7: Tolerance Breaches (Require Attention)
*Dedicated exception management interface for operational and compliance prioritization.*
- **Automated Breach Detection**: Applies regulatory threshold limits (default 25% error limit or fuel-specific dual criteria).
- **Breach Exception Table**: Lists non-compliant units alongside installed capacity, primary breach trigger, and operational violation category.
- **Targeted Operational Hit List**: Ready-to-export exception list for dispatchers and market monitoring investigations.

### Tab 8: Central Export Hub
*Consolidated data extraction center for external analysis and executive reporting.*
- **Annual Fleet Summary CSV**: One record per BMU containing capacity, fuel type, and aggregated annual metrics.
- **Monthly Breakdown CSV**: Time-series record per BMU per calendar month.
- **Filtered Exception Hit List CSV**: Export of all currently flagged tolerance breach records.

---

## 5. Standard Operating Procedure (Windows 11 & VS Code)

The dashboard release is certified for deployment on Windows 11 enterprise devices using Conda and VS Code:

### Step 1: Open VS Code Terminal
Open the `release_8_azure` directory in VS Code and launch the integrated terminal (`Ctrl + \``).

### Step 2: Initialize Conda Environment
```bash
conda create -n dashboard python=3.11 -y
conda activate dashboard
```

### Step 3: Install Pinned Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Azure Authentication (Optional for Cloud Mode)
If connecting to live Azure Blob Storage, authenticate via:
```bash
az login
```
*Note: If working offline or in an air-gapped network, select "Local (inputs/ folder)" in the dashboard sidebar.*

### Step 5: Run Guardian Regression Test Gate
```bash
python tests/run_tests.py
```
Verify that all 47 guardian regression tests pass with 0 errors and 0 failures.

### Step 6: Launch Dashboard
```bash
streamlit run app.py
```
The browser will open automatically at `http://localhost:8501`.

---

> **Corporate Policy Notice:**  
> In accordance with institutional market monitoring guidelines, all dashboard components, visualizations, stylesheets, and documentation adhere strictly to corporate reporting standards. All decorative icons and emojis are strictly prohibited across all code and documentation.
