import base64
import functools
import os


@functools.lru_cache(maxsize=1)
def get_custom_css(assets_dir: str = None) -> str:
    """Generate custom CSS with offline Poppins font embedded as Base64 data URIs.

    Reads Poppins .woff2 font files from assets/fonts/ to eliminate external HTTP
    requests to Google Fonts CDN, ensuring self-contained offline execution.
    """
    if assets_dir is None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        assets_dir = os.path.join(os.path.dirname(current_dir), "assets")

    fonts_dir = os.path.join(assets_dir, "fonts")
    font_faces = []
    weights = ["400", "500", "600", "700", "800"]

    if os.path.exists(fonts_dir):
        for w in weights:
            font_path = os.path.join(fonts_dir, f"Poppins-{w}.woff2")
            if os.path.exists(font_path):
                with open(font_path, "rb") as f:
                    b64 = base64.b64encode(f.read()).decode("utf-8")
                font_faces.append(
                    f"@font-face {{\n"
                    f"    font-family: 'Poppins';\n"
                    f"    font-style: normal;\n"
                    f"    font-weight: {w};\n"
                    f"    font-display: swap;\n"
                    f"    src: url('data:font/woff2;base64,{b64}') format('woff2');\n"
                    f"}}"
                )

    fonts_css = "\n".join(font_faces)

    return f"""<style>
{fonts_css}
    .stApp {{ background-color: #fcfcfd; color: #111827; font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif !important; }}
    * {{ font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }}
    section[data-testid="stSidebar"] {{ background-color: #ffffff !important; border-right: 1px solid #000000; }}
    .neso-sidebar-header {{ padding: 10px 0 16px 0; margin-bottom: 12px; border-bottom: 2px solid #000000; text-align: center; }}
    .neso-sidebar-logo {{ max-width: 130px; height: auto; margin-bottom: 8px; }}
    .neso-sidebar-title {{ color: #400732; font-weight: 800; font-size: 1.05rem; letter-spacing: -0.01em; margin: 0; }}
    .neso-sidebar-subtitle {{ color: #000000; font-size: 0.8rem; font-weight: 600; margin-top: 2px; }}
    .neso-active-window-card {{ background: #fdf2f8; border: 1px solid #000000; border-left: 5px solid #400732; border-radius: 6px; padding: 8px 14px; margin-bottom: 16px; display: flex; align-items: center; gap: 10px; font-size: 0.88rem; color: #000000; font-weight: 600; }}
    .neso-aw-badge {{ background: #fce7f3; color: #000000; font-weight: 700; padding: 2px 8px; border-radius: 4px; border: 1px solid #000000; font-size: 0.8rem; }}
    div[data-testid="stMetric"] {{ background-color: #ffffff; border: 1px solid #000000; border-radius: 8px; padding: 12px 16px; box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.08); }}
    div[data-testid="stMetricLabel"] {{ color: #000000 !important; font-size: 0.85rem !important; font-weight: 700 !important; }}
    div[data-testid="stMetricValue"] {{ color: #400732 !important; font-weight: 800 !important; font-size: 1.65rem !important; }}
    div[data-baseweb="tab-list"] {{ border-bottom: 2px solid #000000 !important; gap: 6px; padding-bottom: 2px; display: flex !important; flex-wrap: wrap !important; overflow-x: auto !important; }}
    button[data-baseweb="tab"] {{ background-color: #fdf2f8 !important; border: 1px solid #000000 !important; border-radius: 6px 6px 0 0 !important; padding: 8px 14px !important; color: #000000 !important; font-weight: 700 !important; font-size: 0.88rem !important; white-space: nowrap !important; flex-shrink: 0 !important; transition: all 0.15s ease-in-out; }}
    button[data-baseweb="tab"]:hover {{ background-color: #fce7f3 !important; border-color: #000000 !important; color: #000000 !important; }}
    button[data-baseweb="tab"][aria-selected="true"] {{ background-color: #fbcfe8 !important; border: 2px solid #000000 !important; border-bottom: 2px solid #fbcfe8 !important; color: #000000 !important; font-weight: 800 !important; }}
    button[data-baseweb="tab"] div {{ color: #000000 !important; font-weight: 700 !important; }}
    button[data-baseweb="tab"][aria-selected="true"] div {{ color: #000000 !important; font-weight: 800 !important; }}
</style>"""
