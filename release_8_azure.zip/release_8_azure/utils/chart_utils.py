import streamlit as st


def force_light_chart(fig):
    """Force high-contrast light background and clear typography on Plotly charts."""
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#111827", family="Poppins, sans-serif"),
        xaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#000000",
            tickfont=dict(color="#111827", size=11),
            title_font=dict(color="#000000", size=12, family="Poppins, sans-serif"),
        ),
        yaxis=dict(
            gridcolor="#f3f4f6",
            linecolor="#000000",
            tickfont=dict(color="#111827", size=11),
            title_font=dict(color="#000000", size=12, family="Poppins, sans-serif"),
        ),
        title_font=dict(color="#400732", size=14, family="Poppins, sans-serif"),
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig


def render_chart(fig):
    """Convenience helper to style and render a chart in Streamlit."""
    styled = force_light_chart(fig)
    st.plotly_chart(styled, use_container_width=True)
