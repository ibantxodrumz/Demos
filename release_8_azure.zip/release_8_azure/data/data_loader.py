import os
from typing import Optional, Tuple, Union
import pandas as pd

from constants import (
    ACCOUNT_URL,
    CONTAINER_NAME,
    PROJECT_BASE_NAME,
)
from data.azure_blob_helper import AzureBlobStorage


def find_local_input_file(filename: str) -> Optional[str]:
    """Robust local file resolver across test runners and Streamlit execution."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(script_dir, "..", "inputs", filename),
        os.path.join(script_dir, "inputs", filename),
        os.path.join(os.getcwd(), "inputs", filename),
        os.path.join(script_dir, "..", "..", "inputs", filename),
        os.path.join(script_dir, "..", "..", "release_7_azure", "inputs", filename),
        os.path.join(os.getcwd(), "release_8_azure", "inputs", filename),
        os.path.join(os.getcwd(), "release_7_azure", "inputs", filename),
        (
            os.path.join(
                script_dir, "..", "..", "release_6_prompt", "sample_sp_january_2025_FOMO.csv"
            )
            if "sp_summary" in filename
            else None
        ),
        (
            os.path.join(
                os.getcwd(), "release_6_prompt", "sample_sp_january_2025_FOMO.csv"
            )
            if "sp_summary" in filename
            else None
        ),
        os.path.join("inputs", filename),
        os.path.join(script_dir, "..", filename),
        os.path.join(script_dir, filename),
        os.path.join(os.getcwd(), filename),
    ]
    for path in candidates:
        if path and os.path.exists(path):
            return os.path.abspath(path)
    return None


def get_sp_filenames(selected_year: Union[int, str]) -> Tuple[str, str]:
    """Return local CSV and Azure Parquet filenames for the given year."""
    sp_local_filename = f"sp_summary_{selected_year}.csv"
    sp_azure_filename = f"sp_summary_{selected_year}.parquet"
    return sp_local_filename, sp_azure_filename


def load_local_summaries(
    selected_year: Union[int, str],
) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame], Optional[str], bool, str]:
    """Load annual and monthly summaries from local inputs/ directory, resolving SP source."""
    annual_filename = f"annual_summary_{selected_year}.csv"
    monthly_filename = f"monthly_summary_{selected_year}.csv"
    sp_local_filename, _ = get_sp_filenames(selected_year)

    default_annual_path = find_local_input_file(annual_filename)
    default_monthly_path = find_local_input_file(monthly_filename)

    default_sp_path = (
        find_local_input_file(sp_local_filename)
        or find_local_input_file("sp_summary_test.csv")
        or find_local_input_file("sp_summary.csv")
    )

    if not (default_annual_path and default_monthly_path):
        return None, None, None, False, f"Local files not found for {selected_year}"

    annual_raw = pd.read_csv(default_annual_path)
    monthly_raw = pd.read_csv(default_monthly_path)

    if default_sp_path:
        sp_target_path = default_sp_path
        sp_is_azure = False
        base_name = os.path.basename(default_sp_path)
        sp_source_label = (
            f"Local Test Dataset ({base_name})"
            if "test" in base_name.lower()
            else f"Local Inputs ({base_name})"
        )
    else:
        sp_target_path = None
        sp_is_azure = False
        sp_source_label = (
            f"Local Inputs (Not Found in inputs/{sp_local_filename} or inputs/sp_summary_test.csv)"
        )

    return annual_raw, monthly_raw, sp_target_path, sp_is_azure, sp_source_label


def load_azure_summaries(
    selected_year: Union[int, str],
    azure_blob: Optional[AzureBlobStorage] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame, Optional[str], bool, str]:
    """Load annual and monthly summaries from Azure Blob Storage, resolving SP Parquet source."""
    project_folder = f"{PROJECT_BASE_NAME}-{selected_year}"
    if azure_blob is None:
        azure_blob = AzureBlobStorage(ACCOUNT_URL, CONTAINER_NAME, project_folder)

    annual_raw = azure_blob.read_annual_summary()
    monthly_raw = azure_blob.read_monthly_summary()

    _, sp_azure_filename = get_sp_filenames(selected_year)

    if azure_blob.sp_blob_exists(selected_year):
        sp_target_path = azure_blob.get_sp_azure_url(selected_year)
        sp_is_azure = True
        sp_source_label = (
            f"Azure Cloud Blob "
            f"({CONTAINER_NAME}/{project_folder}/internal/{sp_azure_filename})"
        )
    else:
        sp_target_path = None
        sp_is_azure = False
        sp_source_label = (
            f"Azure Blob Storage "
            f"(Not Available in {CONTAINER_NAME}/{project_folder}/internal/{sp_azure_filename})"
        )

    return annual_raw, monthly_raw, sp_target_path, sp_is_azure, sp_source_label
