import os
import duckdb  # type: ignore
import numpy as np
import pandas as pd
from constants import ACCOUNT_URL


def query_sp_data(
    sp_source: str,
    bmu: str,
    start_date: str,
    end_date: str,
    is_azure: bool = False,
    azure_token: str = None,
) -> pd.DataFrame:
    """Query Settlement Period data directly using DuckDB.

    Azure Settlement Period data is queried from Parquet.
    Local Settlement Period data continues to use CSV.

    DuckDB's Azure credential chain supports the configured Azure identity.
    """
    del azure_token  # Retained temporarily for caller compatibility.

    if not sp_source:
        return pd.DataFrame()

    con = duckdb.connect()

    try:
        if is_azure:
            account_name = (
                ACCOUNT_URL.replace("https://", "").replace("http://", "").split(".")[0]
            )

            con.execute("INSTALL azure;")
            con.execute("LOAD azure;")

            con.execute(f"""
                CREATE OR REPLACE SECRET azure_storage_secret (
                    TYPE AZURE,
                    PROVIDER CREDENTIAL_CHAIN,
                    ACCOUNT_NAME '{account_name}'
                );
                """)

            query_target = sp_source

        else:
            if not os.path.exists(sp_source):
                raise FileNotFoundError(
                    f"Settlement Period file not found: {sp_source}"
                )

            query_target = sp_source.replace("\\", "/")

        escaped_target = query_target.replace("'", "''")

        if is_azure:
            query = f"""
                SELECT *
                FROM read_parquet('{escaped_target}')
                WHERE nationalGridBmUnit = ?
                  AND CAST(settlementDate AS DATE) >= CAST(? AS DATE)
                  AND CAST(settlementDate AS DATE) <= CAST(? AS DATE)
                ORDER BY timeFrom
            """
        else:
            query = f"""
                SELECT *
                FROM read_csv_auto(
                    '{escaped_target}',
                    header = true
                )
                WHERE nationalGridBmUnit = ?
                  AND CAST(settlementDate AS DATE) >= CAST(? AS DATE)
                  AND CAST(settlementDate AS DATE) <= CAST(? AS DATE)
                ORDER BY timeFrom
            """

        df = con.execute(
            query,
            [bmu, str(start_date), str(end_date)],
        ).df()

    except Exception as exc:
        source_type = "Azure Blob Storage Parquet" if is_azure else "local CSV"

        raise RuntimeError(
            "DuckDB Settlement Period query failed. "
            f"Source type: {source_type}. "
            f"Source: {sp_source}. "
            f"Error: {exc}"
        ) from exc

    finally:
        con.close()

    if df.empty:
        return df

    # Analytical deduplication contract.
    df = df.drop_duplicates(
        subset=[
            "nationalGridBmUnit",
            "settlementDate",
            "settlementPeriod",
        ],
        keep="first",
    ).reset_index(drop=True)

    if "duration_min" in df.columns:
        duration = pd.to_numeric(
            df["duration_min"],
            errors="coerce",
        ).fillna(30.0)
    else:
        duration = pd.Series(
            30.0,
            index=df.index,
        )

    mw_factor = np.where(
        duration > 0,
        60.0 / duration,
        2.0,
    )

    for col in [
        "PNLevel",
        "MELLevel",
        "MILLevel",
        "Metered",
        "ExpectOT",
    ]:
        if col in df.columns:
            df[f"{col}_MW"] = (
                pd.to_numeric(
                    df[col],
                    errors="coerce",
                )
                * mw_factor
            )
        else:
            df[f"{col}_MW"] = 0.0

    absvd_col = None

    if "ABSVD_MWh" in df.columns:
        absvd_col = "ABSVD_MWh"
    elif "ABSVD" in df.columns:
        absvd_col = "ABSVD"

    if absvd_col:
        df["ABSVD_MW"] = (
            pd.to_numeric(
                df[absvd_col],
                errors="coerce",
            )
            * mw_factor
        )
    else:
        df["ABSVD_MW"] = 0.0

    if "BidVolume" in df.columns:
        df["BidVolume_abs"] = (
            pd.to_numeric(
                df["BidVolume"],
                errors="coerce",
            )
            .abs()
            .fillna(0.0)
            * mw_factor
        )

    if "OfferVolume" in df.columns:
        df["OfferVolume_abs"] = (
            pd.to_numeric(
                df["OfferVolume"],
                errors="coerce",
            )
            .abs()
            .fillna(0.0)
            * mw_factor
        )

    if "NetError%" in df.columns:
        df["NetError%"] = pd.to_numeric(
            df["NetError%"],
            errors="coerce",
        ).fillna(0.0)

    elif "NetError" in df.columns:
        df["NetError%"] = pd.to_numeric(
            df["NetError"],
            errors="coerce",
        ).fillna(0.0)

    return df
