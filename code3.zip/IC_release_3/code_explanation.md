# Interconnector Reconciliation Tool: The "Under the Hood" Guide
**For Data Scientists & Engineers**

This document explains the architecture (how it fits together) and provides a **line-by-line breakdown** of the critical logic.

---

## Part 1: Architecture (The "Forest")

### The Concept
We are building a **Reconciliation Engine**. It compares two moving datasets:
1.  **Physical Notifications (PNs)**: Operational files saying "We will flow 1000MW".
2.  **Trades**: Commercial API data saying "We sold 1000MW".

### The Files
*   **`click_2.py` (The Conductor)**: Runs the 12-step script. It doesn't do math; it just calls functions.
*   **`utilities.py` (The Musicians)**: Contains all the math, API calls, and logic.
*   **`constants.py` (The Sheet Music)**: Holds settings like paths and threshold values.

---

## Part 2: Detailed Line-by-Line Walkthrough (The "Trees")

Here we break down the critical sections of code.

### A. `click_2.py`: The Orchestrator
This script runs from top to bottom. Here is the logic flow explained line-by-line.

#### Step 1: Setup & Environment (Lines 95-153)
```python
# We define the main entry point function
def main():
    # We check if a "SIMULATED_TIME" environment variable exists.
    # This lets us travel back in time for testing (e.g., pretend it's 2023).
    sim_time_env = os.environ.get("SIMULATED_TIME", "").strip()
    if sim_time_env:
       # ... logic to parse the fake time ...
    
    # We load configuration toggles from the environment (.env file).
    # Default is "IFA" interconnector if not specified.
    ic = os.environ.get("IC", "IFA")
    
    # CRITICAL STEP: We look at the folder of Excel files and guess the "Run Day"
    # based on the most recent file found.
    inferred = infer_latest_day_and_pair(Path(folder))
    
    # We set up the "Logger. This is better than print() because it saves to a file.
    logger, log_path, run_id = setup_logger(ic, ymd_chosen)
    
    # We list exactly what files we are going to process in the logs.
    files_in_window = get_files_in_window(folder, start_dt, end_dt)
```

#### Step 2-3: Ingesting Data (Lines 158-195)
```python
    # We loop through every Excel file found and "Melt" it.
    # "Melting" turns a wide Excel sheet (Time as columns) into a long list (Time as rows).
    frames = [read_and_melt_pn(f, ic) for _, f in files_in_window]
    pn_all = pd.concat(frames) # Combine them into one giant table.
    
    # We calculate the "Delivery Horizon".
    # We only care about Future data (H+1 onwards), not the past.
    delivery_start, ... = compute_delivery_horizon(...)
    pn_all = filter_forward_horizon(pn_all, delivery_start, ...)
```

#### Step 4: Change Detection (Lines 200-210)
```python
    # We calculate the "Delta" (Difference).
    # Did the PN change since the last file?
    pn_with_delta = compute_delta_pn(pn_all)
    
    # We check specifically if the very next hour (H+1) has changed.
    # If yes, we need to alert the operator immediately.
    h_plus_1_changed = (h_plus_1_view["DeltaPN"].abs() > 0).any()
```

#### Step 5: Fetching Trades (Lines 237-265)
```python
    # We define a 3-day window to widen our search for trades.
    window_start = day_start - timedelta(days=1)
    
    # We call the API wrapper.
    trades = fetch_trades(window_start, ...)
    
    # IRONCLAD CHECK: If the API returns garbage or is empty, we create an empty frame
    # so the code doesn't crash later.
    if trades is None: trades = pd.DataFrame(columns=[...])
    
    # IRONCLAD CHECK: specific logic to detect Duplicate Trade IDs.
    # If found, we flag them True so `classify_v2` can mark them as DATA_ERROR later.
    dupes = trades[...] 
```

#### The "Early Exit" (Lines 268-322)
```python
    # OPTIMIZATION: If PNs haven't moved (no changes) AND we found no trades...
    if not has_changes and trades.empty:
        # ... We stop right here.
        logger.info("NO CHANGES & NO TRADES — All good until next run.")
        return # The script ends.
```

---

### B. `utilities.py`: The Logic Engine

This is where the complex data science lives.

#### 1. `match_pn_to_trades` (The Join Logic)
This function connects the operational world (PNs) to the commercial world (Trades).

```python
def match_pn_to_trades(pn_with_delta, trades):
    # 1. Left Join: We take every PN change and try to attach a trade to it.
    # joining on "BMU_ID" (Who?) and "HourUTC" (When?).
    merged = pn.merge(tr, how="left", on=["BMU_ID", "HourUTC"])
    
    # 2. The "Awareness" Filter (CRITICAL LOGIC)
    # A trade only "counts" if the Operator knew about it when they sent the PN.
    # We compare the File Receipt Time (r_utc) vs the Trade Awareness Time (a_utc).
    mask = a_utc.isna() | (r_utc >= a_utc)
    merged = merged[mask] 
    
    # 3. Aggregation
    # We sum up all the PN movements and all the Trades for one hour.
    agg = merged.groupby(...).agg(
        Net_PN_Change_MW=("Point_Delta", "mean"), 
        Total_Volume=("Total_Volume", "first")
    )
    
    # 4. The Matching Test
    # Do the signs match? (Buying vs Selling)
    same_sign = (np.sign(agg["Total_Volume"]) == np.sign(agg["Net_PN_Change_MW"]))
    
    # Is the volume sufficient? (Within 5MW tolerance)
    agg["Trade_met_on_IC"] = (
        same_sign & 
        (agg["Net_PN_Change_MW"].abs() >= agg["Total_Volume"].abs() - 5)
    )
```

#### 2. `classify_v2` (The Decision Logic)
This is the heart of the tool. It looks at one row (one hour) and decides the status.

```python
def classify_v2(row, now_utc):
    
    # -- BLOCK 1: IRONCLAD GUARDS (Security) --
    # Before checking logic, we check for "Garbage In".
    
    # Check 1: Duplicate Trades
    if row["Duplicate_Trade_Error"]:
        return "DATA_ERROR", "ERROR: Duplicate Trade ID detected."
        
    # Check 2: Missing Mapping (BMU not found in CP_codes.csv)
    # [UAT 2 Update]: Downgraded from ERROR to INFO. Informative only.
    if pd.isna(row["CP Code"]):
        return "INFO", "BMU mapping missing. Check CP_codes.csv."
        
    # Check 3: Extreme Volumes (Typo check)
    if abs(row["Net_PN_Change_MW"]) > 2000:
        return "DATA_ERROR", "ERROR: Extreme PN Move > 2000MW."

    # -- BLOCK 2: NOISE FILTER --
    # If there is NO trade (Volume ~ 0), we don't want to flag tiny 1MW wobbles.
    if abs(trade_vol) < 0.01:
        # If the move is huge (>50MW) but untraded, we warn them.
        if abs(pn_on_ic) > 50:
            # [UAT 2 Update]: If this happens at H+1, it's URGENT.
            if is_h_plus_1:
                return "NO", "RED ALERT H+1: Large un-traded move detected!"
            return "INFO", "Significant un-traded move."
        else:
            return "INFO", "OK: Position Balanced."

    # -- BLOCK 3: ACROSS-IC CHECK --
    # "I didn't move volume on THIS cable, but I did on another one."
    # If Trade_met_across_IC is True, we let them pass.
    if (not trade_met_on_ic) and trade_met_across:
        return "YES2", "OK (Across): Covered by other Interconnectors."
    
    # -- BLOCK 4: TIME BUFFER --
    # "I haven't moved yet, but I still have time before the deadline."
    if (not trade_met_on_ic) and still_time_left:
        return "YES1", "WAIT: Trade confirmed; window not yet reached."

    # -- BLOCK 5: FAILURE --
    # If we get here:
    # 1. You haven't met the trade on this cable.
    # 2. You haven't met it on other cables.
    # 3. Time is up.
    
    # [UAT 2 Update]: Sharp red alert message for H+1.
    if is_h_plus_1:
        return "NO", "RED ALERT H+1: No movement detected for next hour!"
    return "NO", "URGENT: No movement. Chase Counterparty."
```

## Part 3: Cheat Sheet for Key Variables

| Variable | Source | Meaning |
| :--- | :--- | :--- |
| `DeltaPN` | `compute_delta_pn` | How much the PN changed since the last file. |
| `ReceiptUTC` | Filename | When the file arrived (e.g., `MCNN..._14.xls` = 14:00). |
| `Awareness_Start` | `fetch_trades` | The moment the Operator "should have known" about the trade (Trade Time + Lag). |
| `Trade_met_on_IC` | `match_pn_to_trades`| Boolean: Did the PN delta cover the trade volume on *this* cable? |
| `Trade_met_across_IC`| `rollup_company` | Boolean: Did the PN delta cover the trade volume across *any* cable for this company? |
| `Decision` | `classify_v2` | Final output: `YES1`, `YES2`, `YES3`, `NO`, `INFO`, or `DATA_ERROR`. |
