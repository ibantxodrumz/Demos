# Caso Agente IA Monte Carlo

Proyecto de demo para comparar decisiones de crecimiento con un pipeline de ML + contrafactuales + simulacion Monte Carlo + recomendacion final de un agente.

## Estructura

- `caso_agente_ia_montecarlo.ipynb`: notebook principal para la demo.
- `scripts/simulacion_montecarlo.py`: pipeline completo que genera datos, parametros, simulacion y dashboard live.
- `scripts/agente_montecarlo.py`: funciones auxiliares, tools del agente y `run_agent(...)`.
- `scripts/dashboard_agente_demo.py`: genera una consola HTML completa para hacer la demo entera sin usar el notebook.
- `datos/`: dataset sintetico y CSV de resultados.
- `dashboards/`: dashboards HTML y estado live.
- `environment.yml`: entorno conda reproducible.
- `requirements.txt`: alternativa pip.
- `.env`: lugar donde definir `OPENAI_API_KEY`.

## Instalacion del entorno

### Opcion 1. Conda

```powershell
conda env create -f environment.yml
conda activate montecarlo
python -m ipykernel install --user --name montecarlo --display-name "Python (montecarlo)"
```

### Opcion 2. Pip

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m ipykernel install --user --name montecarlo --display-name "Python (montecarlo)"
```

## Configurar la API key de OpenAI

Edita el archivo `.env` en la raiz del proyecto:

```env
OPENAI_API_KEY=tu_api_key_aqui
```

El modulo `scripts/agente_montecarlo.py` carga automaticamente ese archivo con `python-dotenv`.

## Como usar el proyecto

### Flujo recomendado con notebook

1. Abre `caso_agente_ia_montecarlo.ipynb`.
2. Selecciona el kernel `Python (montecarlo)`.
3. Ejecuta las celdas en orden.
4. En el paso de simulacion, se lanzara la Monte Carlo en vivo y se ira actualizando `dashboards/dashboard_live_montecarlo.html`.
5. Cuando el progreso llegue al 100%, recarga resultados en el notebook.
6. Ejecuta la celda final del agente para obtener la recomendacion ejecutiva.

### Flujo por script

Puedes regenerar toda la simulacion sin abrir el notebook:

```powershell
conda activate montecarlo
python scripts/simulacion_montecarlo.py --simulations 10000 --live-dashboard --progress-every 100
```

Esto actualiza:

- `datos/dataset_ventas_transaccional_sintetico_es.csv`
- `datos/parametros_estimados_desde_historico.csv`
- `datos/resultados_simulacion_10000.csv`
- `datos/resumen_simulacion.csv`
- `dashboards/dashboard_live_montecarlo.html`
- `dashboards/estado_live_montecarlo.json`

### Consola completa del agente

Para generar la app HTML principal de la demo:

```powershell
conda activate montecarlo
python scripts/dashboard_agente_demo.py
```

Esto crea `dashboards/agente_mission_control.html`, una interfaz tipo mission control con cinco etapas:

- briefing del agente
- carga de datos
- modelos uplift
- simulacion Monte Carlo integrada
- informe final y recomendacion

### Consola cableada con ejecucion real

Si quieres hacer la demo completa desde botones reales, arranca el servidor local:

```powershell
conda activate montecarlo
python scripts/mission_control_server.py
```

Despues abre:

```text
http://127.0.0.1:8765
```

En ese modo la consola deja de ser solo visual:

- carga el payload actual por HTTP
- ejecuta cada etapa contra un backend local
- lanza la simulacion Monte Carlo real desde el boton correspondiente
- monitoriza el progreso live y refresca el panel integrado
- actualiza el informe final cuando termina la simulacion

## Paso a paso funcional del notebook

1. Cargar el dataset.
2. Leer el negocio actual por canal.
3. Ver los contrafactuales estimados desde historico.
4. Lanzar la simulacion Monte Carlo en tiempo real.
5. Consultar el estado del dashboard live.
6. Recargar resultados y leer el ranking ejecutivo.
7. Pedir la recomendacion final al agente.

## Notas operativas

- Si faltan los CSV de `datos/`, `scripts/agente_montecarlo.py` puede regenerarlos automaticamente en una ejecucion corta.
- El dashboard final estilo NASA vive en `dashboards/dashboard_nasa_montecarlo.html`.
- El dashboard live es un artefacto generado; si no existe todavia, aparece en cuanto lances la simulacion.
- La demo mas cinematografica ahora vive en `dashboards/agente_mission_control.html`.
- Para que los botones ejecuten etapas reales, usa `python scripts/mission_control_server.py` y entra por `http://127.0.0.1:8765`.
