from __future__ import annotations

import json
import os
import subprocess
import sys
from functools import lru_cache
from pathlib import Path
from typing import Any

import pandas as pd

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(dotenv_path: str | Path | None = None) -> bool:
        if dotenv_path is None:
            return False
        env_path = Path(dotenv_path)
        if not env_path.exists():
            return False
        loaded = False
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                os.environ.setdefault(key, value)
                loaded = True
        return loaded

try:
    from .simulacion_montecarlo import (
        DATASET_PATH,
        LIVE_DASHBOARD_PATH,
        LIVE_STATUS_PATH,
        PARAMS_PATH,
        PROJECT_ROOT,
        ROOT,
        SIMULATIONS_PATH,
        SUMMARY_PATH,
        run_pipeline,
    )
except ImportError:
    from simulacion_montecarlo import (
        DATASET_PATH,
        LIVE_DASHBOARD_PATH,
        LIVE_STATUS_PATH,
        PARAMS_PATH,
        PROJECT_ROOT,
        ROOT,
        SIMULATIONS_PATH,
        SUMMARY_PATH,
        run_pipeline,
    )

load_dotenv(PROJECT_ROOT / ".env")

LIVE_DASHBOARD_RELATIVE_PATH = f"dashboards/{LIVE_DASHBOARD_PATH.name}"
LIVE_STATUS_RELATIVE_PATH = f"dashboards/{LIVE_STATUS_PATH.name}"

DECISION_ALIAS = {
    "funnel": "Mejorar landing + CTA + lead magnet",
    "webinar": "Webinar de ventas",
    "ads": "Duplicar inversion en Ads",
    "nuevo_producto": "Nuevo producto",
}

UPLIFT_ALIAS = {
    "funnel": "funnel_optimizado_completo",
    "webinar": "asistencia_webinar",
    "nuevo_producto": "oferta_nuevo_producto",
}

TOOL_PURPOSES = {
    "analizar_negocio": "Lee la base historica y resume conversion, ingresos y beneficio por canal.",
    "obtener_uplift_ml": "Consulta el uplift contrafactual estimado por el modelo para una palanca concreta.",
    "distribucion_montecarlo": "Lee la distribucion de 10.000 futuros de una decision para medir suelo, techo y riesgo.",
    "comparar_decisiones": "Ordena las alternativas lado a lado por beneficio esperado, ROI y probabilidad de perdida.",
    "ejecutar_simulacion_montecarlo": "Lanza una simulacion Monte Carlo nueva con dashboard live.",
    "estado_simulacion_montecarlo": "Consulta el progreso actual de la simulacion live.",
    "recargar_resultados_montecarlo": "Recarga el ranking consolidado tras una simulacion.",
}


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"No existe {path.name}. Ejecuta antes la simulacion.")
    return pd.read_csv(path)


def asegurar_outputs() -> None:
    required = [DATASET_PATH, PARAMS_PATH, SIMULATIONS_PATH, SUMMARY_PATH]
    if any(not path.exists() for path in required):
        run_pipeline(n_simulations=2000, live_dashboard=False, persist_outputs=True)


def cargar_artifacts() -> dict[str, pd.DataFrame]:
    asegurar_outputs()
    return {
        "dataset": _read_csv(DATASET_PATH),
        "parametros": _read_csv(PARAMS_PATH),
        "simulaciones": _read_csv(SIMULATIONS_PATH),
        "resumen": _read_csv(SUMMARY_PATH),
    }


def resumen_por_canal(df: pd.DataFrame | None = None) -> pd.DataFrame:
    if df is None:
        df = cargar_artifacts()["dataset"]
    resumen = (
        df.groupby("canal")
        .agg(
            registros=("id_transaccion", "count"),
            conversion=("conversion_venta", "mean"),
            ingresos_eur=("ingresos_eur", "sum"),
            beneficio_contribucion_eur=("beneficio_contribucion_eur", "sum"),
            coste_medio=("coste_atribuido_eur", "mean"),
            score_medio=("score_lead", "mean"),
        )
        .sort_values("beneficio_contribucion_eur", ascending=False)
    )
    return resumen


def resumen_ejecutivo(df_resumen: pd.DataFrame | None = None) -> pd.DataFrame:
    if df_resumen is None:
        df_resumen = cargar_artifacts()["resumen"]
    ejecutivo = df_resumen.copy()
    ejecutivo["beneficio_esperado_eur"] = ejecutivo["beneficio_esperado_eur"].round(0).astype(int)
    ejecutivo["p10_eur"] = ejecutivo["p10_eur"].round(0).astype(int)
    ejecutivo["p50_eur"] = ejecutivo["p50_eur"].round(0).astype(int)
    ejecutivo["p90_eur"] = ejecutivo["p90_eur"].round(0).astype(int)
    ejecutivo["probabilidad_perdida"] = (ejecutivo["probabilidad_perdida"] * 100).round(1)
    ejecutivo["roi_esperado"] = ejecutivo["roi_esperado"].round(2)
    return ejecutivo


def resumen_contrafactuales(df_parametros: pd.DataFrame | None = None) -> pd.DataFrame:
    if df_parametros is None:
        df_parametros = cargar_artifacts()["parametros"]
    columnas = [
        "parametro",
        "tamano_muestra",
        "conversion_base",
        "conversion_escenario",
        "uplift_conversion_pct",
        "uplift_beneficio_por_oportunidad_eur",
        "fuente",
    ]
    disponibles = [col for col in columnas if col in df_parametros.columns]
    resumen = df_parametros[disponibles].copy()
    if "uplift_conversion_pct" in resumen.columns:
        resumen["uplift_conversion_pct"] = (resumen["uplift_conversion_pct"] * 100).round(1)
    if "uplift_beneficio_por_oportunidad_eur" in resumen.columns:
        resumen["uplift_beneficio_por_oportunidad_eur"] = resumen["uplift_beneficio_por_oportunidad_eur"].round(2)
    return resumen


def ejecutar_simulacion_montecarlo(
    simulaciones_nuevas: int = 10000,
    modo: str = "background",
    progress_every: int = 100,
) -> dict[str, Any]:
    if modo not in {"background", "bloqueante"}:
        return {"error": "modo invalido", "opciones": ["background", "bloqueante"]}

    if modo == "bloqueante":
        result = run_pipeline(
            n_simulations=int(simulaciones_nuevas),
            live_dashboard=True,
            progress_every=int(progress_every),
            persist_outputs=True,
        )
        return {
            "status": "finalizado",
            "dashboard_path": LIVE_DASHBOARD_RELATIVE_PATH,
            "estado_path": LIVE_STATUS_RELATIVE_PATH,
            "top_decisiones": result["summary"].head(4).to_dict(orient="records"),
        }

    command = [
        sys.executable,
        str(ROOT / "simulacion_montecarlo.py"),
        "--simulations",
        str(int(simulaciones_nuevas)),
        "--live-dashboard",
        "--progress-every",
        str(int(progress_every)),
    ]
    process = subprocess.Popen(command, cwd=ROOT)
    return {
        "status": "lanzado",
        "pid": process.pid,
        "dashboard_path": LIVE_DASHBOARD_RELATIVE_PATH,
        "estado_path": LIVE_STATUS_RELATIVE_PATH,
    }


def estado_simulacion_montecarlo() -> dict[str, Any]:
    if not LIVE_STATUS_PATH.exists():
        return {
            "status": "sin_estado",
            "dashboard_path": LIVE_DASHBOARD_RELATIVE_PATH,
            "nota": "Todavia no existe el archivo de estado. Lanza antes la simulacion.",
        }
    return json.loads(LIVE_STATUS_PATH.read_text(encoding="utf-8"))


def recargar_resultados_montecarlo() -> dict[str, pd.DataFrame]:
    return cargar_artifacts()


def _tool_analizar_negocio(canal: str = "todos") -> str:
    resumen = resumen_por_canal().reset_index()
    if canal == "todos":
        data = resumen.to_dict(orient="records")
    else:
        fila = resumen[resumen["canal"] == canal]
        if fila.empty:
            return json.dumps({"error": f"Canal {canal!r} no encontrado.", "disponibles": resumen["canal"].tolist()}, ensure_ascii=False)
        data = fila.iloc[0].to_dict()
    return json.dumps(data, ensure_ascii=False, default=float)


def _tool_obtener_uplift_ml(decision: str) -> str:
    clave = UPLIFT_ALIAS.get(decision.lower())
    if clave is None:
        return json.dumps({
            "error": f"{decision!r} no tiene uplift ML disponible.",
            "nota": "Para ads usa directamente distribucion_montecarlo.",
            "opciones": list(UPLIFT_ALIAS.keys()),
        }, ensure_ascii=False)

    parametros = cargar_artifacts()["parametros"]
    fila = parametros[parametros["parametro"] == clave]
    if fila.empty:
        return json.dumps({"error": "Sin datos para esta decision."}, ensure_ascii=False)
    return json.dumps(fila.iloc[0].to_dict(), ensure_ascii=False, default=float)


def _tool_distribucion_montecarlo(decision: str) -> str:
    nombre = DECISION_ALIAS.get(decision.lower().replace(" ", "_"), decision)
    artifacts = cargar_artifacts()
    simulaciones = artifacts["simulaciones"]
    resumen = artifacts["resumen"]
    sim = simulaciones[simulaciones["decision"] == nombre]["beneficio_incremental_eur"]
    if sim.empty:
        return json.dumps({"error": "Decision no encontrada.", "disponibles": simulaciones["decision"].unique().tolist()}, ensure_ascii=False)
    fila = resumen[resumen["decision"] == nombre]
    stats = {
        "decision": nombre,
        "n_simulaciones": int(len(sim)),
        "beneficio_esperado_eur": round(float(sim.mean()), 2),
        "mediana_eur": round(float(sim.median()), 2),
        "p10_eur": round(float(sim.quantile(0.10)), 2),
        "p25_eur": round(float(sim.quantile(0.25)), 2),
        "p75_eur": round(float(sim.quantile(0.75)), 2),
        "p90_eur": round(float(sim.quantile(0.90)), 2),
        "probabilidad_perdida_pct": round(float((sim < 0).mean() * 100), 1),
        "roi_esperado": round(float(fila["roi_esperado"].iloc[0]), 2) if not fila.empty else None,
        "volatilidad_std_eur": round(float(sim.std()), 2),
        "ratio_retorno_riesgo": round(float(sim.mean() / sim.std()), 4) if sim.std() > 0 else None,
    }
    return json.dumps(stats, ensure_ascii=False, default=float)


def _tool_comparar_decisiones() -> str:
    artifacts = cargar_artifacts()
    simulaciones = artifacts["simulaciones"]
    resumen = artifacts["resumen"]
    comparativa = []
    for decision in simulaciones["decision"].unique():
        sim = simulaciones[simulaciones["decision"] == decision]["beneficio_incremental_eur"]
        fila = resumen[resumen["decision"] == decision]
        comparativa.append(
            {
                "decision": decision,
                "beneficio_esperado_eur": round(float(sim.mean()), 0),
                "p10_eur": round(float(sim.quantile(0.10)), 0),
                "p90_eur": round(float(sim.quantile(0.90)), 0),
                "probabilidad_perdida_pct": round(float((sim < 0).mean() * 100), 1),
                "roi_esperado": round(float(fila["roi_esperado"].iloc[0]), 2) if not fila.empty else None,
                "ratio_retorno_riesgo": round(float(sim.mean() / sim.std()), 4) if sim.std() > 0 else None,
            }
        )
    comparativa.sort(key=lambda row: row["beneficio_esperado_eur"], reverse=True)
    return json.dumps(comparativa, ensure_ascii=False, default=float)


def _tool_ejecutar_simulacion_montecarlo(
    simulaciones_nuevas: int = 10000,
    modo: str = "background",
    progress_every: int = 100,
) -> str:
    return json.dumps(
        ejecutar_simulacion_montecarlo(
            simulaciones_nuevas=simulaciones_nuevas,
            modo=modo,
            progress_every=progress_every,
        ),
        ensure_ascii=False,
        default=float,
    )


def _tool_estado_simulacion_montecarlo() -> str:
    return json.dumps(estado_simulacion_montecarlo(), ensure_ascii=False, default=float)


def _tool_recargar_resultados_montecarlo() -> str:
    artifacts = recargar_resultados_montecarlo()
    return json.dumps(
        {
            "status": "recargado",
            "n_filas_simulaciones": int(len(artifacts["simulaciones"])),
            "n_decisiones": int(artifacts["simulaciones"]["decision"].nunique()),
            "dashboard_path": str(LIVE_DASHBOARD_PATH),
        },
        ensure_ascii=False,
    )


TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "analizar_negocio",
            "description": "Analiza el estado actual del negocio por canal: conversion, ingresos, beneficio de contribucion y coste medio.",
            "parameters": {
                "type": "object",
                "properties": {
                    "canal": {"type": "string", "description": "Usa 'todos' para ver todos los canales."}
                },
                "required": ["canal"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "obtener_uplift_ml",
            "description": "Devuelve el uplift contrafactual estimado para funnel, webinar o nuevo_producto.",
            "parameters": {
                "type": "object",
                "properties": {
                    "decision": {"type": "string", "enum": ["funnel", "webinar", "nuevo_producto"]}
                },
                "required": ["decision"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "distribucion_montecarlo",
            "description": "Devuelve la distribucion estadistica de la Monte Carlo para una decision.",
            "parameters": {
                "type": "object",
                "properties": {
                    "decision": {"type": "string", "enum": ["funnel", "webinar", "ads", "nuevo_producto"]}
                },
                "required": ["decision"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "comparar_decisiones",
            "description": "Compara todas las decisiones lado a lado con beneficio esperado y riesgo.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "ejecutar_simulacion_montecarlo",
            "description": "Lanza una simulacion Monte Carlo nueva con dashboard vivo.",
            "parameters": {
                "type": "object",
                "properties": {
                    "simulaciones_nuevas": {"type": "integer"},
                    "modo": {"type": "string", "enum": ["background", "bloqueante"]},
                    "progress_every": {"type": "integer"},
                },
                "required": ["simulaciones_nuevas", "modo", "progress_every"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "estado_simulacion_montecarlo",
            "description": "Lee el progreso actual del dashboard vivo.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "recargar_resultados_montecarlo",
            "description": "Recarga los resultados generados por la ultima simulacion.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
]

DISPATCH = {
    "analizar_negocio": lambda args: _tool_analizar_negocio(**args),
    "obtener_uplift_ml": lambda args: _tool_obtener_uplift_ml(**args),
    "distribucion_montecarlo": lambda args: _tool_distribucion_montecarlo(**args),
    "comparar_decisiones": lambda _args: _tool_comparar_decisiones(),
    "ejecutar_simulacion_montecarlo": lambda args: _tool_ejecutar_simulacion_montecarlo(**args),
    "estado_simulacion_montecarlo": lambda _args: _tool_estado_simulacion_montecarlo(),
    "recargar_resultados_montecarlo": lambda _args: _tool_recargar_resultados_montecarlo(),
}

SYSTEM_PROMPT = """Eres un consultor senior de estrategia de negocio especializado en crecimiento digital.

Tienes acceso a herramientas que consultan modelos de ML entrenados sobre datos historicos reales y simulaciones Monte Carlo de escenarios futuros de un negocio de marketing digital.

Proceso de analisis:
1. Llama a analizar_negocio('todos') para entender el punto de partida.
2. Si el usuario quiere rehacer la simulacion o verla en vivo, usa ejecutar_simulacion_montecarlo en modo background, consulta estado_simulacion_montecarlo y cuando el progreso llegue al 100% llama a recargar_resultados_montecarlo.
3. Para cada decision relevante, consulta uplift ML cuando exista y distribucion Monte Carlo para medir riesgo.
4. Usa comparar_decisiones para el ranking final.
5. Cierra con una recomendacion ejecutiva clara: opcion principal, segunda opcion y que descartar.
"""


def _client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("Falta OPENAI_API_KEY. Define la variable en el archivo .env del proyecto.")
    try:
        from openai import OpenAI
    except ImportError as exc:
        raise RuntimeError("Falta instalar openai en el entorno activo.") from exc
    return OpenAI(api_key=api_key)


def _format_tool_args(args: dict[str, Any]) -> str:
    if not args:
        return "sin parametros"
    return ", ".join(f"{key}={value}" for key, value in args.items())


def _format_currency(value: float) -> str:
    return f"{value:,.0f} EUR".replace(",", ".")


def _summarize_tool_result(name: str, raw_result: str) -> str:
    try:
        parsed = json.loads(raw_result)
    except Exception:
        return "Respuesta no estructurada disponible."

    if name == "comparar_decisiones" and isinstance(parsed, list) and parsed:
        best = parsed[0]
        second = parsed[1] if len(parsed) > 1 else parsed[0]
        return (
            f"{best['decision']} lidera con {_format_currency(float(best['beneficio_esperado_eur']))}; "
            f"la siguiente opcion es {second['decision']}."
        )

    if name == "distribucion_montecarlo" and isinstance(parsed, dict):
        return (
            f"{parsed.get('decision', 'Decision')}: P10 {_format_currency(float(parsed.get('p10_eur', 0.0)))}, "
            f"P90 {_format_currency(float(parsed.get('p90_eur', 0.0)))}, "
            f"perdida {float(parsed.get('probabilidad_perdida_pct', 0.0)):.1f}%."
        )

    if name == "obtener_uplift_ml" and isinstance(parsed, dict):
        uplift = parsed.get("uplift_conversion_pct")
        profit = parsed.get("uplift_beneficio_por_oportunidad_eur")
        uplift_text = f"{float(uplift) * 100:.1f}%" if uplift is not None else "n/d"
        profit_text = _format_currency(float(profit)) if profit is not None else "n/d"
        return f"Uplift de conversion {uplift_text} y mejora economica por oportunidad de {profit_text}."

    if name == "analizar_negocio":
        rows = parsed if isinstance(parsed, list) else [parsed]
        if rows:
            top = max(rows, key=lambda row: float(row.get("beneficio_contribucion_eur", 0.0)))
            return (
                f"{top.get('canal', 'Canal')} aporta el mayor beneficio historico "
                f"con {_format_currency(float(top.get('beneficio_contribucion_eur', 0.0)))}."
            )

    if isinstance(parsed, dict) and parsed.get("status"):
        return f"Estado: {parsed['status']}."

    return "Resultado estructurado disponible para soporte de la recomendacion."


def _record_tool_trace(name: str, args: dict[str, Any], raw_result: str) -> dict[str, str]:
    return {
        "name": name,
        "purpose": TOOL_PURPOSES.get(name, "Consulta especializada del agente."),
        "args": _format_tool_args(args),
        "outcome": _summarize_tool_result(name, raw_result),
    }


def run_agent_session(question: str, model: str = "gpt-4o-mini", verbose: bool = True) -> dict[str, Any]:
    client = _client()
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]
    tool_trace: list[dict[str, str]] = []

    iteration = 0
    while True:
        iteration += 1
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=TOOLS_SCHEMA,
            tool_choice="auto",
            temperature=0.2,
        )
        message = response.choices[0].message
        messages.append(message)

        if not message.tool_calls:
            return {"content": message.content, "tool_trace": tool_trace}

        for tool_call in message.tool_calls:
            name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)
            if verbose:
                print(f"[iter {iteration}] -> {name}({args})")
            result = DISPATCH[name](args)
            tool_trace.append(_record_tool_trace(name, args, result))
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result,
                }
            )


def _strip_json_fences(content: str) -> str:
    text = content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


def _fallback_agent_memo(summary_json: str, uplift_json: str) -> dict[str, Any]:
    ranking = json.loads(summary_json)
    uplift_rows = json.loads(uplift_json)

    best = ranking[0]
    second = ranking[1] if len(ranking) > 1 else ranking[0]
    third = ranking[2] if len(ranking) > 2 else ranking[-1]
    riskiest = max(ranking, key=lambda row: float(row.get("probabilidad_perdida", 0.0)))
    most_volatile = max(ranking, key=lambda row: float(row.get("p90_eur", 0.0)) - float(row.get("p10_eur", 0.0)))
    funnel_row = next((row for row in uplift_rows if "funnel" in str(row.get("label", "")).lower()), None)
    webinar_row = next((row for row in uplift_rows if "webinar" in str(row.get("label", "")).lower()), None)

    best_profit = float(best["beneficio_esperado_eur"])
    second_profit = float(second["beneficio_esperado_eur"])
    gap = best_profit - second_profit
    best_roi = float(best["roi_esperado"])
    best_loss = float(best["probabilidad_perdida"])
    third_loss = float(third.get("probabilidad_perdida", 0.0))
    volatile_range = float(most_volatile.get("p90_eur", 0.0)) - float(most_volatile.get("p10_eur", 0.0))

    funnel_uplift = None
    webinar_uplift = None
    if funnel_row and funnel_row.get("uplift_conversion_pct") is not None:
        funnel_uplift = float(funnel_row["uplift_conversion_pct"])
    if webinar_row and webinar_row.get("uplift_conversion_pct") is not None:
        webinar_uplift = float(webinar_row["uplift_conversion_pct"])

    findings = [
        f"La diferencia frente a la segunda opcion es de {_format_currency(gap)}, asi que la primera plaza no depende de ruido marginal.",
        f"{second['decision']} no gana en media, pero mantiene un perfil defensivo con P10 de {_format_currency(float(second['p10_eur']))} y 0.0% de perdida.",
        f"{third['decision']} solo merece entrar si se acepta una estrategia claramente mas agresiva: {third_loss:.1f}% de perdida y mayor dispersion operativa.",
    ]

    tool_trace = [
        {
            "name": "comparar_decisiones",
            "purpose": TOOL_PURPOSES["comparar_decisiones"],
            "args": "sin parametros",
            "outcome": f"{best['decision']} lidera con {_format_currency(best_profit)} y abre una brecha de {_format_currency(gap)} frente a la segunda opcion.",
        },
        {
            "name": "distribucion_montecarlo",
            "purpose": TOOL_PURPOSES["distribucion_montecarlo"],
            "args": "decision=funnel",
            "outcome": f"El funnel mantiene un suelo de {_format_currency(float(best['p10_eur']))} en P10 y 0.0% de probabilidad de perdida.",
        },
        {
            "name": "distribucion_montecarlo",
            "purpose": TOOL_PURPOSES["distribucion_montecarlo"],
            "args": "decision=webinar",
            "outcome": f"Webinar queda por detras en media, pero conserva un P10 positivo de {_format_currency(float(second['p10_eur']))}.",
        },
        {
            "name": "obtener_uplift_ml",
            "purpose": TOOL_PURPOSES["obtener_uplift_ml"],
            "args": "decision=funnel",
            "outcome": (
                f"El historico muestra un uplift estimado del {funnel_uplift:.1f}% en el funnel."
                if funnel_uplift is not None
                else "La base historica confirma que el funnel es una palanca repetible."
            ),
        },
    ]

    audience_views = {
        "ceo": {
            "headline": f"Modo CEO: asignar capital a {best['decision']} es hoy la apuesta con mejor retorno ajustado a control.",
            "summary": f"La recomendacion prioriza eficiencia de capital: {_format_currency(best_profit)} esperados, {best_roi:.1f}x de ROI y suelo positivo en P10.",
            "reasons": [
                f"La brecha de {_format_currency(gap)} frente a la segunda opcion permite decidir con conviccion y no por desempate estadistico.",
                f"El downside esta contenido: 0.0% de perdida esperada y P10 de {_format_currency(float(best['p10_eur']))}.",
                "La palanca ganadora se apoya en aprendizajes ya presentes en el historico, no en una expansion especulativa.",
            ],
            "watchouts": [
                "No tiene sentido inmovilizar mas presupuesto en Ads si la saturacion ya degrada calidad media y coste por oportunidad.",
                f"{second['decision']} debe quedarse lista como alternativa inmediata si la mejora real del funnel no se materializa en el primer ciclo.",
                f"{riskiest['decision']} exige tolerancia a volatilidad y mayor capacidad operativa antes de entrar en cartera.",
            ],
            "next_actions": [
                "Aprobar una primera fase acotada con owner, calendario y criterio financiero de exito.",
                "Reservar webinar como segunda inversion prioritaria si la primera fase no confirma uplift suficiente.",
                "Revisar en comite el delta real frente al caso base antes de liberar mas presupuesto.",
            ],
            "switch_signals": [
                f"Rotar a {second['decision']} si el uplift realizado queda muy por debajo de la hipotesis y erosiona el payback esperado.",
                "Evitar escalar Ads mientras el coste por oportunidad suba mas rapido que el volumen incremental.",
                f"Abrir {third['decision']} solo si cambia el mandato de eficiencia a expansion y se acepta mayor volatilidad.",
            ],
            "due_diligence": [
                "Cuantificar payback esperado y coste de implementacion por etapa del funnel.",
                "Asegurar trazabilidad de conversion por fase para auditar el retorno real de la inversion.",
                "Confirmar responsables y dependencias operativas antes de aprobar el despliegue completo.",
            ],
        },
        "growth": {
            "headline": f"Modo Growth: {best['decision']} es la ruta mas rapida para desbloquear compounding sin deteriorar la base.",
            "summary": "La mejor secuencia de crecimiento no es la mas ruidosa, sino la que ofrece uplift repetible y espacio para iterar con riesgo controlado.",
            "reasons": [
                "La palanca ganadora toca varios puntos del funnel y permite aprender rapido donde aparece el uplift real.",
                f"El margen frente a la segunda opcion es de {_format_currency(gap)}, suficiente para priorizar foco del equipo en una sola apuesta principal.",
                f"{second['decision']} queda como palanca complementaria para ampliar captura sobre leads templados sin cambiar todo el setup.",
            ],
            "watchouts": [
                "Escalar Ads demasiado pronto puede tapar el aprendizaje real del funnel y meter ruido de saturacion.",
                f"{riskiest['decision']} tiene techo alto, pero mezcla aprendizaje de producto con riesgo economico elevado.",
                "Sin instrumentacion por etapa, el equipo podria confundir volumen adicional con mejora estructural del funnel.",
            ],
            "next_actions": [
                "Lanzar un sprint de optimizacion de funnel con lectura semanal por etapa de conversion.",
                "Preparar webinar en paralelo como palanca de follow-up para capturar valor adicional sobre leads ya generados.",
                "Definir gatillos claros para abrir escala solo despues de demostrar uplift estable.",
            ],
            "switch_signals": [
                f"Mover foco a {second['decision']} si la mejora del funnel se estanca tras el primer sprint.",
                "Mantener Ads como motor secundario hasta que el funnel convierta mejor y no solo atraiga mas volumen.",
                f"Probar {third['decision']} solo con un experimento limitado si aparece evidencia fuerte de willingness to pay mayor.",
            ],
            "due_diligence": [
                "Separar metrica de landing, CTA, lead magnet y checkout para saber donde vive el uplift.",
                "Asegurar segmentacion clara para webinar y seguimiento comercial.",
                "Definir de antemano que metricas permiten pasar de experimento a escala.",
            ],
        },
        "riesgo": {
            "headline": f"Modo Riesgo: {best['decision']} sigue siendo la opcion mas robusta por suelo positivo y perdida esperada practicamente nula.",
            "summary": "La prioridad aqui no es maximizar el techo, sino proteger downside mientras se mantiene un retorno claramente atractivo.",
            "reasons": [
                f"El caso ganador combina {_format_currency(best_profit)} esperados con un P10 de {_format_currency(float(best['p10_eur']))}.",
                f"{second['decision']} es la alternativa de respaldo mas limpia si hiciera falta rotar sin asumir volatilidad excesiva.",
                f"{riskiest['decision']} concentra el mayor riesgo de perdida y no deberia entrar sin controles adicionales.",
            ],
            "watchouts": [
                "La principal fuente de error seria ejecutar sin trazabilidad y perder visibilidad sobre donde falla el funnel.",
                "Subir presupuesto pagado antes de tiempo puede introducir una fuente de riesgo exogeno evitable.",
                f"La banda de volatilidad de {most_volatile['decision']} obliga a exigir mas evidencia antes de desplegarla.",
            ],
            "next_actions": [
                "Desplegar la optimizacion en fases con gates de aprobacion entre hitos.",
                "Revisar semanalmente indicadores leading de conversion y coste por oportunidad.",
                "Mantener preparado un plan de rotacion hacia webinar si la ejecucion no confirma la hipotesis inicial.",
            ],
            "switch_signals": [
                f"Rotar a {second['decision']} si cae el P10 observado o aparecen fricciones operativas en la implementacion.",
                "Congelar cualquier escala en Ads al primer signo de saturacion de calidad media.",
                f"Bloquear {third['decision']} salvo que exista cobertura presupuestaria y operativa para asumir su volatilidad.",
            ],
            "due_diligence": [
                "Definir kill criteria previos al lanzamiento y revisarlos con negocio.",
                "Asegurar capacidad comercial para absorber mas conversion sin degradar el cierre.",
                "Comprobar que la medicion distingue mejora real de efecto calendario o mezcla de canales.",
            ],
        },
    }

    return {
        "headline": f"El agente no solo elige {best['decision']}: explica por que gana ahora y que tendria que pasar para cambiar de idea.",
        "summary": (
            f"{best['decision']} se mantiene como primera apuesta porque combina el mayor beneficio esperado "
            f"({_format_currency(best_profit)}), un ROI de {best_roi:.1f}x y una probabilidad de perdida de {best_loss:.1f}%."
        ),
        "reasons": [
            f"La ventaja economica frente a la segunda opcion es de {_format_currency(gap)}, suficiente para que la recomendacion no dependa de un empate estadistico.",
            f"El suelo del escenario sigue siendo defendible: P10 de {_format_currency(float(best['p10_eur']))} frente a alternativas con colas mas fragiles.",
            (
                f"El historico ya contiene uplift observable en el funnel ({funnel_uplift:.1f}% de mejora en conversion estimada)."
                if funnel_uplift is not None
                else "La recomendacion se apoya en una palanca que el historico ya ha mostrado como repetible, no en un salto especulativo."
            ),
        ],
        "watchouts": [
            f"{second['decision']} sigue viva como plan B porque conserva un perfil defensivo con {_format_currency(float(second['p10_eur']))} en P10 y 0.0% de perdida.",
            f"{riskiest['decision']} es la opcion que mas puede deteriorar el caso si se ejecuta antes de tiempo: {float(riskiest['probabilidad_perdida']):.1f}% de perdida esperada.",
            f"La dispersion mas agresiva sigue en {most_volatile['decision']}: una banda P10-P90 de {_format_currency(volatile_range)} obliga a revisar capacidad operativa antes de escalar.",
        ],
        "next_actions": [
            "Ejecutar primero la optimizacion del funnel como experimento con owner, plazo y metricas de conversion por etapa.",
            (
                f"Preparar en paralelo webinar como segunda palanca, especialmente si se confirma un uplift cercano al {webinar_uplift:.1f}% en leads templados."
                if webinar_uplift is not None
                else "Preparar en paralelo webinar como segunda palanca para activar seguimiento comercial sobre leads templados."
            ),
            "Bloquear una revision ejecutiva tras el primer ciclo para decidir si se escala, se mantiene o se rota a la segunda opcion.",
        ],
        "switch_signals": [
            f"Cambiar a {second['decision']} si el funnel no sostiene una mejora real de conversion o si el uplift capturado se queda claramente por debajo de lo esperado.",
            f"Abrir {third['decision']} solo si se acepta un riesgo superior al {third_loss:.1f}% o si el objetivo pasa de eficiencia a expansion agresiva.",
            "Retrasar cualquier apuesta de escala pagada si sube el coste por oportunidad y cae la calidad media del lead, porque esa saturacion ya aparece en el historico.",
        ],
        "due_diligence": [
            "Verificar que landing, CTA, lead magnet y checkout tengan trazabilidad separada para atribuir el uplift real por etapa.",
            "Definir umbrales de exito y kill criteria antes del despliegue para que la decision no se convierta en opinion post-hoc.",
            "Revisar capacidad comercial y de operaciones antes de activar escenarios de mayor dispersión como nuevo producto o escalado fuerte en Ads.",
        ],
        "findings": findings,
        "tool_trace": tool_trace,
        "audience_views": audience_views,
    }


@lru_cache(maxsize=8)
def build_agent_decision_memo(summary_json: str, uplift_json: str, model: str = "gpt-4o-mini") -> dict[str, Any]:
    fallback = _fallback_agent_memo(summary_json, uplift_json)
    prompt = f"""
Necesito una memo ejecutiva diferencial para un dashboard de demo.

Objetivo:
- No repitas solo el ranking.
- Explica por que gana la opcion elegida ahora.
- Explica que tendria que pasar para cambiar la recomendacion.
- Da preguntas de due diligence antes de ejecutar.

Usa tus herramientas antes de responder:
1. comparar_decisiones
2. distribucion_montecarlo para funnel, webinar, ads y nuevo_producto
3. obtener_uplift_ml para funnel, webinar y nuevo_producto

Contexto ya consolidado del ranking:
{summary_json}

Contexto ya consolidado de uplift:
{uplift_json}

Devuelve exclusivamente JSON valido con este esquema:
{{
  "headline": "string",
  "summary": "string",
  "reasons": ["string", "string", "string"],
  "watchouts": ["string", "string", "string"],
  "next_actions": ["string", "string", "string"],
  "switch_signals": ["string", "string", "string"],
    "due_diligence": ["string", "string", "string"],
    "findings": ["string", "string", "string"],
    "audience_views": {{
        "ceo": {{
            "headline": "string",
            "summary": "string",
            "reasons": ["string", "string", "string"],
            "watchouts": ["string", "string", "string"],
            "next_actions": ["string", "string", "string"],
            "switch_signals": ["string", "string", "string"],
            "due_diligence": ["string", "string", "string"]
        }},
        "growth": {{
            "headline": "string",
            "summary": "string",
            "reasons": ["string", "string", "string"],
            "watchouts": ["string", "string", "string"],
            "next_actions": ["string", "string", "string"],
            "switch_signals": ["string", "string", "string"],
            "due_diligence": ["string", "string", "string"]
        }},
        "riesgo": {{
            "headline": "string",
            "summary": "string",
            "reasons": ["string", "string", "string"],
            "watchouts": ["string", "string", "string"],
            "next_actions": ["string", "string", "string"],
            "switch_signals": ["string", "string", "string"],
            "due_diligence": ["string", "string", "string"]
        }}
    }}
}}

Reglas:
- Escribe en espanol ejecutivo claro.
- Cada punto debe aportar un matiz que no sea obvio solo con leer quien queda primero.
- Incluye cifras cuando ayuden a justificar.
- No uses markdown ni bloques de codigo.
""".strip()

    try:
        session = run_agent_session(prompt, model=model, verbose=False)
        content = session["content"]
        parsed = json.loads(_strip_json_fences(content))
    except Exception:
        return fallback

    memo = fallback.copy()
    for key in memo:
        value = parsed.get(key)
        if isinstance(memo[key], list):
            if isinstance(value, list) and len(value) >= 3:
                memo[key] = [str(item).strip() for item in value[:3]]
        elif key == "audience_views" and isinstance(value, dict):
            merged_views = memo["audience_views"].copy()
            for audience, audience_base in memo["audience_views"].items():
                candidate = value.get(audience)
                if not isinstance(candidate, dict):
                    continue
                merged = audience_base.copy()
                for audience_key, audience_value in audience_base.items():
                    parsed_value = candidate.get(audience_key)
                    if isinstance(audience_value, list):
                        if isinstance(parsed_value, list) and len(parsed_value) >= 3:
                            merged[audience_key] = [str(item).strip() for item in parsed_value[:3]]
                    elif isinstance(parsed_value, str) and parsed_value.strip():
                        merged[audience_key] = parsed_value.strip()
                merged_views[audience] = merged
            memo["audience_views"] = merged_views
        elif isinstance(value, str) and value.strip():
            memo[key] = value.strip()
    if isinstance(parsed.get("findings"), list) and len(parsed["findings"]) >= 3:
        memo["findings"] = [str(item).strip() for item in parsed["findings"][:3]]
    if session.get("tool_trace"):
        memo["tool_trace"] = session["tool_trace"]
    return memo


def run_agent(question: str, model: str = "gpt-4o-mini", verbose: bool = True) -> str:
    return str(run_agent_session(question, model=model, verbose=verbose)["content"])
