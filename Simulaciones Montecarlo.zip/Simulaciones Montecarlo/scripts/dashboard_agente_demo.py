from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split

try:
    from .agente_montecarlo import build_agent_decision_memo
    from .simulacion_montecarlo import (
      FEATURES,
        DATASET_PATH,
        DASHBOARDS_DIR,
        LIVE_DASHBOARD_PATH,
        PARAMS_PATH,
        REPORT_PATH,
      SEED,
        SIMULATIONS_PATH,
        SUMMARY_PATH,
      build_aov_model,
      build_conversion_model,
        write_live_dashboard,
    )
except ImportError:
    from agente_montecarlo import build_agent_decision_memo
    from simulacion_montecarlo import (
      FEATURES,
        DATASET_PATH,
        DASHBOARDS_DIR,
        LIVE_DASHBOARD_PATH,
        PARAMS_PATH,
        REPORT_PATH,
      SEED,
        SIMULATIONS_PATH,
        SUMMARY_PATH,
      build_aov_model,
      build_conversion_model,
        write_live_dashboard,
    )


MISSION_DASHBOARD_PATH = DASHBOARDS_DIR / "agente_mission_control.html"

UPLIFT_LABELS = {
  "funnel_full_optimized": "Optimizacion integral del funnel",
  "webinar_attendance": "Secuencia de webinar comercial",
  "new_product_offer": "Lanzamiento de nuevo producto",
}

ADS_LABELS = {
  "paid_budget_low": "Inversion contenida",
  "paid_budget_medium": "Inversion equilibrada",
  "paid_budget_high": "Inversion intensiva",
  "paid_budget_saturated": "Saturacion del canal",
}

UPLIFT_EXPLANATIONS = {
  "funnel_full_optimized": "Escenario que combina mejoras de landing, CTA, lead magnet y checkout para elevar la conversion sin aumentar el coste fijo.",
  "webinar_attendance": "Escenario que activa una secuencia comercial basada en webinar para leads con mayor probabilidad de cierre.",
  "new_product_offer": "Escenario que abre una oferta de mayor ticket para segmentos elegibles, asumiendo más variabilidad operativa.",
}

STAGES = [
    {
        "key": "briefing",
    "title": "Introduccion",
    "eyebrow": "Fase 01",
    "tagline": "Presenta el objetivo del caso, las capacidades disponibles y el itinerario completo del analisis.",
    "command": "AGENTE.INICIAR_PRESENTACION()",
        "duration_ms": 1100,
    },
    {
        "key": "ingesta",
        "title": "Carga de datos",
    "eyebrow": "Fase 02",
    "tagline": "Carga la base historica, valida su cobertura y resume la estructura del caso antes de modelizar.",
    "command": "AGENTE.CARGAR_Y_VALIDAR_DATOS()",
        "duration_ms": 1400,
    },
    {
        "key": "uplift",
    "title": "Modelos y uplift",
    "eyebrow": "Fase 03",
    "tagline": "Expone como se estima la probabilidad de exito, el valor esperado y el impacto de cada palanca de negocio.",
    "command": "AGENTE.EVALUAR_MODELOS_Y_PALANCAS()",
        "duration_ms": 1500,
    },
    {
        "key": "montecarlo",
        "title": "10000 futuros",
    "eyebrow": "Fase 04",
    "tagline": "Ejecuta la simulacion Monte Carlo en directo y ordena las alternativas por retorno y riesgo.",
    "command": "AGENTE.SIMULAR_10000_FUTUROS()",
        "duration_ms": 1600,
    },
    {
        "key": "reporte",
        "title": "Informe final",
    "eyebrow": "Fase 05",
    "tagline": "Resume el hallazgo principal, los riesgos a vigilar y la recomendacion ejecutiva final.",
    "command": "AGENTE.EMITIR_RECOMENDACION()",
        "duration_ms": 1500,
    },
]


def _read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"No existe {path.name}. Ejecuta antes scripts/simulacion_montecarlo.py.")
    return pd.read_csv(path)


def _currency(value: float) -> str:
    return f"{value:,.0f} EUR".replace(",", ".")


def _percent(value: float) -> str:
    return f"{value * 100:.1f}%"


def _records(df: pd.DataFrame) -> list[dict[str, object]]:
  return df.astype(object).where(pd.notna(df), None).to_dict(orient="records")


def _build_gain_chart(actual: pd.Series, predicted: np.ndarray) -> list[dict[str, float]]:
  ranked = pd.DataFrame({"actual": actual.to_numpy(), "predicted": predicted})
  ranked = ranked.sort_values("predicted", ascending=False).reset_index(drop=True)
  ranked["decile"] = np.minimum(9, (np.arange(len(ranked)) * 10 // max(1, len(ranked)))).astype(int) + 1
  total_conversions = max(1, int(ranked["actual"].sum()))
  total_rows = max(1, len(ranked))
  rows = []
  cumulative = 0
  for decile in range(1, 11):
    bucket = ranked[ranked["decile"] == decile]
    conversions = int(bucket["actual"].sum())
    cumulative += conversions
    rows.append(
      {
        "decile": decile,
        "avg_score": float(bucket["predicted"].mean()) if len(bucket) else 0.0,
        "conversion_rate": float(bucket["actual"].mean()) if len(bucket) else 0.0,
        "capture_pct": cumulative / total_conversions,
        "population_pct": min(1.0, (decile * len(bucket)) / total_rows if len(bucket) else decile / 10),
      }
    )
  return rows


def _build_residual_bands(residuals: np.ndarray) -> list[dict[str, object]]:
  bands = [
    ("Sobreestima > 300 EUR", residuals < -300),
    ("Sobreestima 100-300 EUR", (residuals >= -300) & (residuals < -100)),
    ("Ajuste fino +/- 100 EUR", (residuals >= -100) & (residuals <= 100)),
    ("Infraestima 100-300 EUR", (residuals > 100) & (residuals <= 300)),
    ("Infraestima > 300 EUR", residuals > 300),
  ]
  return [{"label": label, "count": int(mask.sum())} for label, mask in bands]


def _build_payload() -> dict:
    dataset = _read_csv(DATASET_PATH)
    params = _read_csv(PARAMS_PATH)
    summary = _read_csv(SUMMARY_PATH)
    simulations = _read_csv(SIMULATIONS_PATH)

    if not LIVE_DASHBOARD_PATH.exists():
        max_simulation = int(simulations["simulation"].max())
        write_live_dashboard(max_simulation, max_simulation, simulations.to_dict(orient="records"))

    report_text = REPORT_PATH.read_text(encoding="utf-8") if REPORT_PATH.exists() else ""
    report_lines = [line.strip() for line in report_text.splitlines() if line.strip()]

    period_start = str(dataset["date"].min())
    period_end = str(dataset["date"].max())
    converted = dataset[dataset["converted_to_sale"] == 1]
    conversion_model, auc = build_conversion_model(dataset)

    conversion_train, conversion_test = train_test_split(
      dataset,
      test_size=0.25,
      random_state=SEED,
      stratify=dataset["converted_to_sale"],
    )
    conversion_scores = conversion_model.predict_proba(conversion_test[FEATURES])[:, 1]
    gain_chart = _build_gain_chart(conversion_test["converted_to_sale"], conversion_scores)

    sold_train, sold_test = train_test_split(
      converted,
      test_size=0.25,
      random_state=SEED,
    )
    aov_model = build_aov_model(sold_train)
    aov_pred = np.expm1(aov_model.predict(sold_test[FEATURES]))
    residuals = sold_test["aov_eur"].to_numpy() - aov_pred
    abs_residuals = np.abs(residuals)

    dataset_summary = {
        "rows": int(len(dataset)),
        "period_start": period_start,
        "period_end": period_end,
        "conversion_rate": float(dataset["converted_to_sale"].mean()),
        "revenue_eur": float(dataset["revenue_eur"].sum()),
        "contribution_profit_eur": float(dataset["contribution_profit_eur"].sum()),
        "avg_ticket_eur": float(converted["aov_eur"].mean()),
        "avg_lead_score": float(dataset["lead_score"].mean()),
        "campaign_count": int(dataset[["channel", "campaign_objective"]].drop_duplicates().shape[0]),
        "variable_count": int(len(dataset.columns)),
        "channel_count": int(dataset["channel"].nunique()),
        "segment_count": int(dataset["customer_segment"].nunique()),
        "geography_count": int(dataset["geo_region"].nunique()),
        "objective_count": int(dataset["campaign_objective"].nunique()),
        "time_windows": int(dataset["month"].nunique()),
    }

    monthly_summary = (
        dataset.groupby("month")
        .agg(
            revenue_eur=("revenue_eur", "sum"),
            contribution_profit_eur=("contribution_profit_eur", "sum"),
            conversion_rate=("converted_to_sale", "mean"),
        )
        .reset_index()
    )

    important_uplift = params[params["parameter"].isin(UPLIFT_LABELS)].copy()
    important_uplift["label"] = important_uplift["parameter"].map(UPLIFT_LABELS)
    important_uplift["description"] = important_uplift["parameter"].map(UPLIFT_EXPLANATIONS)
    important_uplift["conversion_lift_pct"] = important_uplift["conversion_lift_pct"].fillna(0.0)

    ads_regimes = params[params["parameter"].isin(ADS_LABELS)].copy()
    ads_regimes["label"] = ads_regimes["parameter"].map(ADS_LABELS)

    top_summary = summary.sort_values("ranking").reset_index(drop=True)
    best = top_summary.iloc[0]
    second = top_summary.iloc[1]
    gap_vs_second = float(best["expected_profit_eur"] - second["expected_profit_eur"])
    summary_snapshot = (
      top_summary.rename(
        columns={
          "expected_profit_eur": "beneficio_esperado_eur",
          "probability_loss": "probabilidad_perdida",
          "expected_roi": "roi_esperado",
        }
      )[
        [
          "ranking",
          "decision",
          "beneficio_esperado_eur",
          "p10_eur",
          "p50_eur",
          "p90_eur",
          "probabilidad_perdida",
          "roi_esperado",
        ]
      ]
      .to_json(orient="records", force_ascii=False)
    )
    uplift_snapshot = (
      important_uplift.rename(columns={"conversion_lift_pct": "uplift_conversion_pct"})[
        ["label", "description", "uplift_conversion_pct"]
      ]
      .to_json(orient="records", force_ascii=False)
    )
    agent_memo = build_agent_decision_memo(summary_snapshot, uplift_snapshot)

    executive_notes = []
    capture = False
    for line in report_lines:
        if line.lower().startswith("## lectura ejecutiva"):
            capture = True
            continue
        if capture and line.startswith("## "):
            break
        if capture and line.startswith("-"):
            executive_notes.append(line[1:].strip())

    report_checks = [line[1:].strip() for line in report_lines if line.startswith("- dataset") or line.startswith("- parametros") or line.startswith("- conclusion")]

    recommendation = {
      "headline": agent_memo["headline"],
        "decision": best["decision"],
        "expected_profit_eur": float(best["expected_profit_eur"]),
        "expected_roi": float(best["expected_roi"]),
        "probability_loss": float(best["probability_loss"]),
        "gap_vs_second_eur": gap_vs_second,
      "agent_summary": agent_memo["summary"],
      "reasons": agent_memo["reasons"],
      "watchouts": agent_memo["watchouts"],
      "next_actions": agent_memo["next_actions"],
      "switch_signals": agent_memo["switch_signals"],
      "due_diligence": agent_memo["due_diligence"],
      "findings": agent_memo["findings"],
      "tool_trace": agent_memo["tool_trace"],
      "audience_views": agent_memo["audience_views"],
    }

    sample_columns = [
        "date",
        "channel",
        "customer_segment",
        "campaign_objective",
        "lead_score",
        "converted_to_sale",
        "revenue_eur",
        "contribution_profit_eur",
    ]
    sample_rows = dataset[sample_columns].head(10).to_dict(orient="records")

    mission_tools = [
        {
            "name": "Tool 01 · Carga de datos",
        "purpose": "Carga la base historica y valida que el caso tenga cobertura suficiente antes de analizar decisiones.",
        },
        {
        "name": "Tool 02 · Modelo de propension",
        "purpose": "Estima la probabilidad de exito de cada oportunidad para priorizar mejor las palancas de crecimiento.",
        },
        {
        "name": "Tool 03 · Modelo de valor esperado",
        "purpose": "Estima el ticket esperado de las oportunidades que convierten para traducir conversion en impacto economico.",
        },
        {
        "name": "Tool 04 · Uplift de negocio",
        "purpose": "Compara escenarios como optimizacion del funnel, webinar comercial o nuevo producto sobre la base historica.",
        },
        {
            "name": "Tool 05 · Monte Carlo",
        "purpose": "Simula 10.000 futuros para ordenar decisiones por retorno esperado, dispersion y riesgo de perdida.",
        },
    ]

    return {
      "title": "Agente de Decision Comercial",
      "subtitle": "Una consola unica para analizar los datos, estimar el uplift de cada iniciativa y simular 10.000 futuros antes de decidir.",
        "stages": STAGES,
        "tools": mission_tools,
        "dataset": {
            "summary": dataset_summary,
        "monthly": _records(monthly_summary),
            "sample": sample_rows,
        },
      "models": {
        "classification": {
          "name": "Regresion logistica",
          "purpose": "Calcula la probabilidad de exito de cada oportunidad a partir de canal, segmento, contexto comercial y señales de calidad.",
          "auc": float(auc),
          "positive_rate": float(conversion_test["converted_to_sale"].mean()),
          "avg_predicted_prob": float(conversion_scores.mean()),
          "gain_chart": gain_chart,
        },
        "regression": {
          "name": "Gradient Boosting Regressor",
          "purpose": "Estima el valor esperado de las oportunidades convertidas para traducir conversion en euros potenciales.",
          "mae_eur": float(mean_absolute_error(sold_test["aov_eur"], aov_pred)),
          "r2": float(r2_score(sold_test["aov_eur"], aov_pred)),
          "mean_residual_eur": float(residuals.mean()),
          "p90_abs_error_eur": float(np.percentile(abs_residuals, 90)),
          "residual_bands": _build_residual_bands(residuals),
        },
      },
        "uplift": {
        "main": _records(important_uplift),
        "ads": _records(ads_regimes),
        },
        "simulation": {
        "summary": _records(top_summary),
          "total_simulations": int(simulations["simulation"].max()),
          "live_dashboard": f"dashboards/{LIVE_DASHBOARD_PATH.name}",
        "recent": _records(simulations.sort_values("simulation").tail(24)),
        },
        "recommendation": recommendation,
        "report": {
            "checks": report_checks,
            "executive_notes": executive_notes,
        },
    }


HTML_TEMPLATE = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agente de Decision Comercial</title>
  <style>
    :root {
      --bg: #04111b;
      --bg-deep: #02070d;
      --bg-soft: #071a29;
      --panel: rgba(7, 24, 38, 0.84);
      --panel-strong: rgba(7, 26, 44, 0.92);
      --line: rgba(124, 201, 227, 0.18);
      --text: #e8fbff;
      --muted: #88b6c7;
      --cyan: #25e6ff;
      --green: #27f5c6;
      --amber: #ffd166;
      --pink: #ff6f91;
      --red: #ff6b6b;
      --blue: #58a6ff;
      --shadow: 0 24px 80px rgba(0, 0, 0, 0.35);
      --glow: 0 0 32px rgba(37, 230, 255, 0.18);
    }
    * { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      color: var(--text);
      background:
        radial-gradient(circle at 20% 0%, rgba(37, 230, 255, 0.13), transparent 35%),
        radial-gradient(circle at 80% 10%, rgba(255, 209, 102, 0.10), transparent 28%),
        radial-gradient(circle at 50% 120%, rgba(88, 166, 255, 0.12), transparent 35%),
        linear-gradient(180deg, #04111b 0%, #02070d 100%);
      font-family: "Segoe UI Variable Text", Bahnschrift, "Segoe UI", Arial, sans-serif;
      min-height: 100vh;
    }
    body::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      background: repeating-linear-gradient(180deg, rgba(255,255,255,0.03) 0 1px, transparent 1px 4px);
      opacity: 0.18;
      mix-blend-mode: screen;
      animation: scan 10s linear infinite;
    }
    body::after {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      background: radial-gradient(circle at 50% 0%, rgba(37, 230, 255, 0.07), transparent 42%);
    }
    .shell {
      width: min(1660px, calc(100vw - 32px));
      margin: 0 auto;
      padding: 24px 0 48px;
      position: relative;
    }
    .hero, .panel, .metric, .tool-card, .stage-button, .console, .table-wrap {
      border: 1px solid var(--line);
      background: var(--panel);
      box-shadow: var(--shadow), var(--glow);
      backdrop-filter: blur(12px);
      border-radius: 24px;
    }
    .hero {
      padding: 28px;
      position: relative;
      overflow: hidden;
      display: grid;
      grid-template-columns: 1.15fr 0.85fr;
      gap: 18px;
    }
    .hero::before {
      content: "";
      position: absolute;
      inset: -20% auto auto -10%;
      width: 60%;
      height: 200%;
      background: conic-gradient(from 90deg, transparent, rgba(37, 230, 255, 0.12), transparent 30%);
      animation: rotate 10s linear infinite;
    }
    .hero::after {
      content: "";
      position: absolute;
      inset: auto -10% -55% 45%;
      width: 52%;
      aspect-ratio: 1;
      border-radius: 50%;
      border: 1px solid rgba(124, 201, 227, 0.12);
      box-shadow: inset 0 0 80px rgba(37, 230, 255, 0.06);
      opacity: 0.65;
    }
    .hero-copy, .hero-status { position: relative; z-index: 1; }
    h1, .verdict, .panel-title, .stage-title, .metric-value, .status-big {
      font-family: "Bahnschrift SemiCondensed", "Arial Narrow", Bahnschrift, sans-serif;
    }
    .eyebrow {
      text-transform: uppercase;
      letter-spacing: 0.22em;
      color: var(--muted);
      font-size: 12px;
    }
    h1 {
      margin: 10px 0 12px;
      font-size: clamp(34px, 4vw, 56px);
      line-height: 0.95;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .hero p {
      max-width: 760px;
      color: #b6d9e4;
      font-size: 16px;
      line-height: 1.6;
      margin: 0;
    }
    .hero-grid {
      margin-top: 22px;
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 12px;
    }
    .metric {
      padding: 16px;
      min-height: 110px;
      position: relative;
      overflow: hidden;
    }
    .metric::after {
      content: "";
      position: absolute;
      inset: auto 0 0 0;
      height: 3px;
      background: linear-gradient(90deg, var(--cyan), var(--green));
      box-shadow: 0 0 20px rgba(37, 230, 255, 0.45);
    }
    .metric-label {
      text-transform: uppercase;
      letter-spacing: 0.16em;
      font-size: 11px;
      color: var(--muted);
    }
    .metric-value {
      margin-top: 10px;
      font-size: 28px;
      font-weight: 700;
      color: white;
    }
    .hero-status {
      display: grid;
      gap: 16px;
      align-content: stretch;
    }
    .mission-hud {
      border: 1px solid var(--line);
      background: var(--panel-strong);
      border-radius: 24px;
      box-shadow: var(--shadow), var(--glow);
      padding: 18px;
      display: grid;
      grid-template-columns: 180px 1fr;
      gap: 18px;
      position: relative;
      overflow: hidden;
    }
    .mission-hud::before {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.02), transparent 28%, transparent 72%, rgba(37,230,255,0.05));
      pointer-events: none;
    }
    .status-orbit {
      display: grid;
      place-items: center;
    }
    .status-ring {
      width: 164px;
      height: 164px;
      border-radius: 50%;
      position: relative;
      display: grid;
      place-items: center;
      background: conic-gradient(from 0deg, rgba(37,230,255,0.75), rgba(39,245,198,0.18), rgba(255,255,255,0.04) 72%, rgba(37,230,255,0.75));
      box-shadow: 0 0 44px rgba(37,230,255,0.18);
    }
    .status-ring::before {
      content: "";
      position: absolute;
      inset: 16px;
      border-radius: 50%;
      background: radial-gradient(circle at 50% 35%, #0c2034, #04101a 68%);
      border: 1px solid rgba(120,201,227,0.18);
    }
    .status-ring::after {
      content: "";
      position: absolute;
      inset: 30px;
      border-radius: 50%;
      border: 1px dashed rgba(120,201,227,0.16);
      animation: rotate 18s linear infinite;
    }
    .status-core {
      position: relative;
      z-index: 1;
      text-align: center;
      padding: 0 12px;
    }
    .status-big {
      font-size: 30px;
      line-height: 1;
      margin-top: 8px;
      color: white;
      letter-spacing: 0.05em;
      text-transform: uppercase;
    }
    .status-sub {
      margin-top: 8px;
      font-size: 13px;
      color: #a9cfdb;
      line-height: 1.45;
    }
    .status-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 12px;
      align-content: center;
    }
    .hud-chip {
      border: 1px solid rgba(124, 201, 227, 0.16);
      border-radius: 18px;
      background: rgba(4, 17, 27, 0.72);
      padding: 14px 16px;
      min-height: 88px;
    }
    .hud-chip-label {
      font-size: 11px;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .hud-chip-value {
      margin-top: 10px;
      font-size: 21px;
      line-height: 1.1;
      color: white;
    }
    .hud-chip-copy {
      margin-top: 8px;
      color: #a7c9d5;
      font-size: 12px;
      line-height: 1.45;
    }
    .console {
      padding: 18px;
      min-height: 220px;
      position: relative;
      overflow: hidden;
    }
    .console::before {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.02), transparent 35%, transparent 70%, rgba(37,230,255,0.05));
      pointer-events: none;
    }
    .console-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 14px;
      font-size: 12px;
      letter-spacing: 0.16em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .console-head-right {
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
      justify-content: flex-end;
    }
    .console-command {
      color: var(--cyan);
      font-family: Consolas, "Courier New", monospace;
      font-size: 13px;
    }
    .console-log {
      display: grid;
      gap: 10px;
      font-family: Consolas, "Courier New", monospace;
      font-size: 13px;
      color: #d9f6ff;
    }
    .progress-shell {
      margin-top: 18px;
      height: 12px;
      border-radius: 999px;
      background: rgba(255,255,255,0.04);
      border: 1px solid var(--line);
      overflow: hidden;
    }
    .progress-fill {
      width: 0%;
      height: 100%;
      background: linear-gradient(90deg, var(--cyan), var(--green), var(--amber));
      box-shadow: 0 0 24px rgba(37,230,255,0.35);
      transition: width 0.18s linear;
    }
    .toolbar {
      margin-top: 18px;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }
    .action {
      border: 1px solid rgba(124, 201, 227, 0.25);
      background: rgba(4, 17, 27, 0.8);
      color: var(--text);
      border-radius: 999px;
      padding: 12px 16px;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      font-size: 11px;
      cursor: pointer;
      transition: transform 0.2s ease, border-color 0.2s ease, opacity 0.2s ease;
    }
    .action:hover:not(:disabled) {
      transform: translateY(-1px);
      border-color: rgba(37, 230, 255, 0.35);
    }
    .action:disabled {
      opacity: 0.45;
      cursor: wait;
    }
    .layout {
      margin-top: 22px;
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 22px;
    }
    .rail {
      display: grid;
      gap: 22px;
      align-content: start;
      position: sticky;
      top: 20px;
      height: max-content;
    }
    #stage-buttons {
      display: grid;
      gap: 18px;
    }
    .stage-button, .tool-card, .panel, .table-wrap {
      padding: 18px;
    }
    .stage-button {
      cursor: pointer;
      transition: transform 0.22s ease, border-color 0.22s ease, box-shadow 0.22s ease;
      position: relative;
      overflow: hidden;
      min-height: 148px;
    }
    .stage-button::before {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(115deg, transparent, rgba(255,255,255,0.08), transparent);
      transform: translateX(-120%);
      animation: sheen 3.6s linear infinite;
      pointer-events: none;
    }
    .stage-button::after {
      content: "";
      position: absolute;
      inset: auto 0 0 0;
      height: 3px;
      background: transparent;
      transition: background 0.22s ease;
    }
    .stage-button:hover, .stage-button.active {
      transform: translateY(-3px);
      border-color: rgba(37, 230, 255, 0.45);
      box-shadow: 0 0 0 1px rgba(37,230,255,0.15), 0 24px 80px rgba(0,0,0,0.35);
    }
    .stage-button.active::after {
      background: linear-gradient(90deg, var(--cyan), var(--green));
      box-shadow: 0 0 24px rgba(37,230,255,0.4);
    }
    .stage-button.running::after {
      background: linear-gradient(90deg, var(--amber), var(--cyan));
      box-shadow: 0 0 24px rgba(255,209,102,0.35);
    }
    .stage-button.done::after {
      background: linear-gradient(90deg, var(--green), var(--cyan));
      box-shadow: 0 0 24px rgba(39,245,198,0.30);
    }
    .stage-title {
      margin-top: 8px;
      font-size: 20px;
      color: white;
    }
    .stage-copy {
      margin-top: 8px;
      color: #a9cfdb;
      line-height: 1.5;
      font-size: 14px;
    }
    .main {
      display: grid;
      gap: 22px;
    }
    .stage-pane {
      display: none;
      gap: 22px;
    }
    .stage-pane.active {
      display: grid;
      animation: fadeIn 0.35s ease;
    }
    .briefing-grid {
      display: grid;
      grid-template-columns: minmax(0, 0.95fr) minmax(0, 1.05fr);
      gap: 22px;
      align-items: start;
      min-height: 100%;
    }
    .briefing-stack {
      display: grid;
      gap: 22px;
      align-content: start;
    }
    .cta-panel {
      min-height: 100%;
      display: grid;
      gap: 18px;
      align-content: start;
      background: linear-gradient(180deg, rgba(7,26,44,.94), rgba(4,17,27,.88));
    }
    .cta-link {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 46px;
      padding: 0 18px;
      border-radius: 999px;
      border: 1px solid rgba(124, 201, 227, 0.24);
      color: var(--text);
      text-decoration: none;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      font-size: 12px;
      background: rgba(4,17,27,0.7);
      width: fit-content;
      box-shadow: 0 0 24px rgba(37,230,255,0.10);
    }
    .cta-image-shell {
      border-radius: 20px;
      overflow: hidden;
      border: 1px solid rgba(124, 201, 227, 0.16);
      background: rgba(4,17,27,0.72);
      min-height: 300px;
      display: grid;
      place-items: center;
    }
    .cta-image {
      display: block;
      width: 100%;
      height: auto;
    }
    .panel-title {
      margin: 0 0 6px;
      font-size: 20px;
      color: white;
    }
    .panel-copy {
      margin: 0;
      color: #a7c9d5;
      line-height: 1.6;
    }
    .kpi-grid, .insight-grid, .summary-grid, .report-grid, .model-grid, .tech-grid, .montecarlo-grid {
      display: grid;
      gap: 14px;
    }
    .kpi-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .summary-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .insight-grid, .report-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .model-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .tech-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
    .montecarlo-grid { grid-template-columns: 1fr; }
    .tool-name {
      font-size: 16px;
      color: white;
      margin: 8px 0;
    }
    .tool-card {
      position: relative;
      overflow: hidden;
    }
    .tool-card::before {
      content: "";
      position: absolute;
      inset: -20% -35%;
      background: linear-gradient(115deg, transparent, rgba(255,255,255,0.06), transparent);
      transform: translateX(-120%);
      animation: sheen 4s linear infinite;
      pointer-events: none;
    }
    .tool-purpose {
      color: #a8cfdb;
      line-height: 1.55;
      font-size: 14px;
    }
    .bars, .uplift-cards, .summary-cards {
      display: grid;
      gap: 12px;
    }
    .bar-row {
      display: grid;
      grid-template-columns: 220px 1fr 110px;
      gap: 12px;
      align-items: center;
    }
    .bar-track {
      height: 18px;
      border-radius: 999px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(124, 201, 227, 0.12);
      overflow: hidden;
    }
    .bar-fill {
      height: 100%;
      border-radius: 999px;
      background: linear-gradient(90deg, var(--cyan), var(--green));
      position: relative;
    }
    .bar-fill.red { background: linear-gradient(90deg, var(--red), #ff9c7a); }
    .bar-fill.amber { background: linear-gradient(90deg, var(--amber), #ffef99); }
    .line-shell {
      height: 280px;
      position: relative;
      border-radius: 18px;
      background: rgba(4,17,27,0.72);
      border: 1px solid rgba(124, 201, 227, 0.14);
      overflow: hidden;
    }
    .line-shell svg { width: 100%; height: 100%; display: block; }
    .mini-chart {
      height: 240px;
      border-radius: 18px;
      background: rgba(4,17,27,0.72);
      border: 1px solid rgba(124, 201, 227, 0.14);
      overflow: hidden;
    }
    .mini-chart svg { width: 100%; height: 100%; display: block; }
    .table-wrap {
      overflow: auto;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 720px;
    }
    th, td {
      padding: 12px 10px;
      text-align: left;
      border-bottom: 1px solid rgba(124, 201, 227, 0.10);
      font-size: 13px;
    }
    th {
      text-transform: uppercase;
      letter-spacing: 0.15em;
      font-size: 11px;
      color: var(--muted);
      position: sticky;
      top: 0;
      background: rgba(7,24,38,0.95);
    }
    .iframe-shell {
      position: relative;
      border-radius: 22px;
      overflow: hidden;
      border: 1px solid rgba(124, 201, 227, 0.16);
      background: #02070d;
      min-height: 1040px;
      box-shadow: inset 0 0 80px rgba(37,230,255,0.08);
    }
    .montecarlo-placeholder {
      position: absolute;
      inset: 18px;
      z-index: 3;
      display: none;
      place-items: center;
      border-radius: 18px;
      border: 1px solid rgba(124, 201, 227, 0.18);
      background: radial-gradient(circle at 50% 0%, rgba(37,230,255,0.10), rgba(4,17,27,0.92) 55%);
      padding: 28px;
      text-align: center;
    }
    .montecarlo-placeholder.is-visible {
      display: grid;
    }
    .placeholder-ring {
      width: 124px;
      height: 124px;
      border-radius: 50%;
      border: 2px solid rgba(124, 201, 227, 0.16);
      border-top-color: var(--cyan);
      box-shadow: 0 0 32px rgba(37,230,255,0.16);
      animation: rotate 1.2s linear infinite;
      margin: 0 auto 18px;
    }
    .placeholder-title {
      font-size: 24px;
      color: white;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .placeholder-copy {
      margin-top: 10px;
      max-width: 520px;
      color: #b6d9e4;
      line-height: 1.7;
    }
    .iframe-shell::before {
      content: "";
      position: absolute;
      inset: 0;
      background:
        radial-gradient(circle, rgba(25,230,255,.06) 0 1px, transparent 1px),
        linear-gradient(90deg, rgba(25,230,255,.05) 1px, transparent 1px),
        linear-gradient(180deg, rgba(25,230,255,.05) 1px, transparent 1px);
      background-size: 28px 28px, 28px 28px, 28px 28px;
      mask-image: radial-gradient(circle at center, black 30%, transparent 86%);
      opacity: 0.85;
      pointer-events: none;
      z-index: 1;
    }
    .iframe-shell::after {
      content: "";
      position: absolute;
      inset: 22px;
      border-radius: 50%;
      background: conic-gradient(from 0deg, rgba(39,245,198,.18), transparent 52deg, transparent 360deg);
      filter: blur(2px);
      mix-blend-mode: screen;
      animation: rotate 6s linear infinite;
      opacity: 0.55;
      pointer-events: none;
      z-index: 1;
    }
    iframe {
      position: relative;
      z-index: 2;
      width: 100%;
      min-height: 1040px;
      border: 0;
      background: #02070d;
      overflow: hidden;
    }
    .panel-radar {
      background: linear-gradient(180deg, rgba(7,26,44,.94), rgba(4,17,27,.88));
    }
    .panel-hud {
      background: linear-gradient(180deg, rgba(7,24,38,.9), rgba(4,17,27,.82));
    }
    .bullet-list {
      margin: 14px 0 0;
      padding-left: 18px;
      color: #cfeaf2;
      line-height: 1.7;
    }
    .audience-switch {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin: 18px 0 10px;
    }
    .audience-chip {
      min-width: 132px;
      border: 1px solid rgba(124, 201, 227, 0.22);
      background: linear-gradient(180deg, rgba(9, 28, 47, 0.96), rgba(5, 18, 31, 0.96));
      color: #d7edf5;
      padding: 12px 16px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      cursor: pointer;
      transition: transform 0.2s ease, border-color 0.2s ease, color 0.2s ease, box-shadow 0.2s ease;
    }
    .audience-chip.active {
      color: #06111b;
      background: linear-gradient(135deg, #27f5c6, #7cc9e3);
      border-color: transparent;
      box-shadow: 0 12px 30px rgba(39, 245, 198, 0.24);
    }
    .audience-chip:hover {
      transform: translateY(-1px);
    }
    .audience-caption {
      color: #7cc9e3;
      font-size: 11px;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      margin-top: 4px;
    }
    .audience-summary {
      color: #9fc4d1;
      margin-top: 4px;
      line-height: 1.6;
    }
    .trace-list {
      display: grid;
      gap: 12px;
      margin-top: 18px;
    }
    .trace-item {
      padding: 14px 16px;
      border-radius: 16px;
      border: 1px solid rgba(124, 201, 227, 0.12);
      background: linear-gradient(180deg, rgba(10, 28, 47, 0.96), rgba(6, 18, 31, 0.96));
    }
    .trace-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 6px;
    }
    .trace-name {
      font-size: 14px;
      font-weight: 700;
      color: #eff8fb;
      letter-spacing: 0.04em;
    }
    .trace-args {
      color: #7cc9e3;
      font-size: 11px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    .trace-purpose {
      color: #9fc4d1;
      font-size: 13px;
      margin-bottom: 6px;
    }
    .trace-outcome {
      color: #dcecf2;
      line-height: 1.6;
      font-size: 14px;
    }
    .tag-row {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 12px;
    }
    .tag {
      border: 1px solid rgba(124, 201, 227, 0.18);
      border-radius: 999px;
      padding: 8px 12px;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: var(--muted);
      background: rgba(4,17,27,0.7);
    }
    .status-chip {
      border: 1px solid rgba(124, 201, 227, 0.24);
      border-radius: 999px;
      padding: 8px 12px;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: #dff8ff;
      background: rgba(4,17,27,0.82);
    }
    .status-chip.ready {
      border-color: rgba(39,245,198,0.30);
      color: #b9fff0;
    }
    .status-chip.running {
      border-color: rgba(255,209,102,0.35);
      color: #fff3c0;
      box-shadow: 0 0 24px rgba(255,209,102,0.10);
    }
    .status-chip.alert {
      border-color: rgba(255,107,107,0.38);
      color: #ffd1d1;
    }
    .verdict {
      font-size: clamp(28px, 3vw, 42px);
      line-height: 1.05;
      margin: 6px 0 12px;
      text-transform: uppercase;
      color: white;
    }
    .flash {
      animation: flash 0.4s ease;
    }
    @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    @keyframes sheen { from { transform: translateX(-120%); } to { transform: translateX(120%); } }
    @keyframes scan { from { transform: translateY(-4px); } to { transform: translateY(4px); } }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes flash {
      0% { box-shadow: 0 0 0 1px rgba(37,230,255,0.15), 0 24px 80px rgba(0,0,0,0.35); }
      50% { box-shadow: 0 0 0 1px rgba(37,230,255,0.35), 0 0 40px rgba(37,230,255,0.20), 0 24px 80px rgba(0,0,0,0.35); }
      100% { box-shadow: 0 0 0 1px rgba(37,230,255,0.15), 0 24px 80px rgba(0,0,0,0.35); }
    }
    @media (max-width: 1200px) {
      .hero, .layout, .insight-grid, .report-grid, .model-grid, .mission-hud, .briefing-grid { grid-template-columns: 1fr; }
      .kpi-grid, .summary-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .tech-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .rail { position: static; }
    }
    @media (max-width: 760px) {
      .shell { width: min(100vw - 16px, 100%); padding-top: 16px; }
      .hero-grid, .kpi-grid, .summary-grid, .tech-grid { grid-template-columns: 1fr; }
      .bar-row { grid-template-columns: 1fr; }
      .status-grid { grid-template-columns: 1fr; }
      .stage-button, .tool-card, .panel, .table-wrap, .console { padding: 16px; }
    }
  </style>
</head>
<body>
  <div class="shell">
    <section class="hero">
      <div class="hero-copy">
        <div class="eyebrow">Consola ejecutiva</div>
        <h1 id="hero-title"></h1>
        <p id="hero-subtitle"></p>
        <div class="hero-grid" id="hero-kpis"></div>
      </div>
      <div class="hero-status">
        <section class="mission-hud">
          <div class="status-orbit">
            <div class="status-ring">
              <div class="status-core">
                <div class="eyebrow" id="hud-active-stage">Fase 01</div>
                <div class="status-big" id="hud-active-title">Introduccion</div>
                <div class="status-sub" id="hud-active-copy">Consola lista para recorrer el caso completo.</div>
              </div>
            </div>
          </div>
          <div class="status-grid">
            <article class="hud-chip">
              <div class="hud-chip-label">Runtime</div>
              <div class="hud-chip-value" id="hud-runtime">Modo local</div>
              <div class="hud-chip-copy">Estado del backend y de la sincronizacion de etapas.</div>
            </article>
            <article class="hud-chip">
              <div class="hud-chip-label">Estado live</div>
              <div class="hud-chip-value" id="hud-live">Sin backend</div>
              <div class="hud-chip-copy">Situacion actual del panel Monte Carlo en tiempo real.</div>
            </article>
            <article class="hud-chip">
              <div class="hud-chip-label">Cobertura</div>
              <div class="hud-chip-value">5 fases</div>
              <div class="hud-chip-copy">De exploracion inicial a recomendacion priorizada.</div>
            </article>
            <article class="hud-chip">
              <div class="hud-chip-label">Simulacion</div>
              <div class="hud-chip-value">10.000 futuros</div>
              <div class="hud-chip-copy">Exploracion de retorno esperado, dispersion y riesgo de perdida.</div>
            </article>
          </div>
        </section>
      </div>
    </section>

    <section class="layout">
      <aside class="rail">
        <div id="stage-buttons"></div>
      </aside>

      <main class="main">
        <section class="stage-pane" id="pane-briefing">
          <div class="briefing-grid">
            <div class="briefing-stack">
              <section class="panel">
                <div class="eyebrow">Vision general</div>
                <h2 class="panel-title">Una sola interfaz para recorrer todo el caso</h2>
                <p class="panel-copy">La aplicacion articula un flujo completo para analizar la base historica, estimar el comportamiento esperado, cuantificar el uplift de cada palanca, simular miles de escenarios y cerrar con una recomendacion priorizada.</p>
                <div class="tag-row" id="briefing-tags"></div>
              </section>
              <section class="console" id="console-panel">
              <div class="console-head">
                <span>Estado operativo</span>
                <div class="console-head-right">
                  <span class="status-chip" id="console-runtime-badge">Modo local</span>
                  <span class="status-chip" id="console-live-badge">Sin backend</span>
                  <span id="console-stage-label"></span>
                </div>
              </div>
              <div class="console-command" id="console-command"></div>
              <div class="console-log" id="console-log"></div>
              <div class="progress-shell"><div class="progress-fill" id="progress-fill"></div></div>
              <div class="toolbar">
                <button class="action" id="autoplay-btn">Secuencia automatica</button>
                <button class="action" id="reset-btn">Volver al briefing</button>
              </div>
              </section>
            </div>
            <section class="panel cta-panel">
              <div class="eyebrow">Empieza desde cero</div>
              <h2 class="panel-title">Empieza en IA Data Science Gratis en www.tuprimerasemana.com</h2>
              <p class="panel-copy">El proyecto que estás viendo es avanzado. Si estás empezando apúntante a Tu Primera Semana y allí crearás gratis un proyecto completo de IA Data Science más sencillo e ideal para empezar.</p>
              <a class="cta-link" href="https://www.tuprimerasemana.com" target="_blank" rel="noreferrer">Ir a tuprimerasemana.com</a>
              <div class="cta-image-shell">
                <img class="cta-image" src="tps.png" alt="Tu Primera Semana">
              </div>
            </section>
          </div>
        </section>

        <section class="stage-pane" id="pane-ingesta">
          <div class="kpi-grid" id="dataset-kpis"></div>
          <div class="insight-grid">
            <section class="panel">
              <div class="eyebrow">Cobertura del caso</div>
              <h2 class="panel-title">Que informacion tiene disponible el agente</h2>
              <p class="panel-copy">Antes de modelizar conviene comprobar que el caso tiene suficiente diversidad comercial: campañas, variables, segmentos, geografias y ventana temporal.</p>
              <div class="kpi-grid" id="dataset-structure-cards"></div>
            </section>
            <section class="panel">
              <div class="eyebrow">Serie temporal</div>
              <h2 class="panel-title">Evolucion mensual del negocio</h2>
              <p class="panel-copy">La serie de revenue y beneficio de contribucion da contexto sobre la estabilidad del negocio antes de evaluar nuevas palancas.</p>
              <div class="line-shell"><svg id="monthly-chart" viewBox="0 0 680 280" preserveAspectRatio="none"></svg></div>
            </section>
          </div>
          <section class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Canal</th>
                  <th>Segmento</th>
                  <th>Objetivo</th>
                  <th>Lead score</th>
                  <th>Conversion</th>
                  <th>Revenue</th>
                  <th>Beneficio contribucion</th>
                </tr>
              </thead>
              <tbody id="sample-table"></tbody>
            </table>
          </section>
        </section>

        <section class="stage-pane" id="pane-uplift">
          <div class="model-grid">
            <section class="panel">
              <div class="eyebrow">Modelo 01</div>
              <h2 class="panel-title">Regresion logistica para probabilidad de exito</h2>
              <p class="panel-copy">Este modelo estima la probabilidad de cierre de cada oportunidad usando señales de canal, segmento, calidad del lead y contexto comercial.</p>
              <div class="tech-grid" id="classification-kpis"></div>
              <div class="mini-chart" style="margin-top:14px"><svg id="gain-chart" viewBox="0 0 680 240" preserveAspectRatio="none"></svg></div>
            </section>
            <section class="panel">
              <div class="eyebrow">Modelo 02</div>
              <h2 class="panel-title">Gradient boosting para valor esperado</h2>
              <p class="panel-copy">Este modelo estima el valor economico de las oportunidades que convierten y ayuda a traducir propension en impacto monetario.</p>
              <div class="tech-grid" id="regression-kpis"></div>
              <div class="bars" id="residual-bars" style="margin-top:14px"></div>
            </section>
          </div>
          <section class="panel">
            <div class="eyebrow">Palancas de negocio</div>
            <h2 class="panel-title">Escenarios con mayor uplift esperado</h2>
            <p class="panel-copy">Aqui se muestran las iniciativas mejor posicionadas segun el analisis contrafactual: cuanto mejoran la conversion y cuanto valor añaden por oportunidad.</p>
            <div class="uplift-cards" id="uplift-cards"></div>
          </section>
        </section>

        <section class="stage-pane" id="pane-montecarlo">
          <div class="montecarlo-grid">
            <section class="panel">
              <div class="eyebrow">Simulacion en directo</div>
              <h2 class="panel-title">Panel live de Monte Carlo</h2>
              <p class="panel-copy">El radar, la telemetria y el ranking evolucionan en tiempo real mientras el agente recorre 10.000 escenarios posibles para cada decision.</p>
              <div class="iframe-shell">
                <div class="montecarlo-placeholder" id="montecarlo-placeholder">
                  <div>
                    <div class="placeholder-ring"></div>
                    <div class="placeholder-title" id="montecarlo-placeholder-title">Precalculando simulacion</div>
                    <div class="placeholder-copy" id="montecarlo-placeholder-copy">El backend está preparando los elementos previos al lanzamiento. El dashboard live se mostrará en cuanto arranque la simulación real.</div>
                  </div>
                </div>
                <iframe id="live-frame" title="Monte Carlo live"></iframe>
              </div>
            </section>
          </div>
          <section class="panel panel-radar">
            <div class="eyebrow">Lectura consolidada</div>
            <h2 class="panel-title">Ranking final de alternativas</h2>
            <p class="panel-copy">La comparativa final resume retorno esperado, dispersión y riesgo de perdida para que la conclusion sea inmediata.</p>
            <div class="summary-cards" id="summary-cards"></div>
          </section>
        </section>

        <section class="stage-pane" id="pane-reporte">
          <div class="report-grid">
            <section class="panel">
              <div class="eyebrow">Recomendacion final</div>
              <div class="audience-caption">Selecciona enfoque de lectura</div>
              <div class="audience-switch" id="audience-switch">
                <button class="audience-chip active" data-audience="ceo">CEO</button>
                <button class="audience-chip" data-audience="growth">Growth</button>
                <button class="audience-chip" data-audience="riesgo">Riesgo</button>
              </div>
              <div class="audience-summary" id="audience-summary"></div>
              <div class="verdict" id="verdict-headline"></div>
              <p class="panel-copy" id="verdict-copy"></p>
              <ul class="bullet-list" id="reason-list"></ul>
            </section>
            <section class="panel">
              <div class="eyebrow">Riesgos y siguientes pasos</div>
              <h2 class="panel-title">Puntos de control para la decision</h2>
              <ul class="bullet-list" id="watchouts-list"></ul>
              <div class="tag-row" id="report-checks"></div>
            </section>
          </div>
          <div class="report-grid">
            <section class="panel">
              <div class="eyebrow">Consultas realizadas</div>
              <h2 class="panel-title">Huella de herramientas</h2>
              <div class="trace-list" id="tool-trace"></div>
            </section>
            <section class="panel">
              <div class="eyebrow">Hallazgos adicionales</div>
              <h2 class="panel-title">Lecturas complementarias</h2>
              <ul class="bullet-list" id="agent-findings"></ul>
            </section>
          </div>
          <div class="report-grid">
            <section class="panel">
              <div class="eyebrow">Cuando cambiaria la recomendacion</div>
              <h2 class="panel-title">Senales para rotar la apuesta</h2>
              <ul class="bullet-list" id="switch-signals"></ul>
            </section>
            <section class="panel">
              <div class="eyebrow">Ejecucion y due diligence</div>
              <h2 class="panel-title">Plan recomendado</h2>
              <ul class="bullet-list" id="next-actions"></ul>
              <h2 class="panel-title" style="margin-top:20px;">Preguntas antes de ejecutar</h2>
              <ul class="bullet-list" id="due-diligence"></ul>
            </section>
          </div>
        </section>
      </main>
    </section>
  </div>

  <script>
    const PAYLOAD = __PAYLOAD__;
    const AUDIENCE_META = {
      ceo: 'Prioriza asignacion de capital, payback y claridad de decision ejecutiva.',
      growth: 'Prioriza velocidad de aprendizaje, iteracion y escalado de palancas.',
      riesgo: 'Prioriza control del downside, robustez del suelo y criterios de contencion.',
    };
    const API_BASE = window.location.protocol.startsWith('http') ? window.location.origin : '';
    const BACKEND_ENABLED = Boolean(API_BASE);
    const PRECOMPUTED_STAGE_KEYS = new Set(['briefing', 'ingesta', 'uplift']);
    const state = {
      activeStage: 'briefing',
      audience: 'ceo',
      autoTimer: null,
      progressTimer: null,
      autoplay: false,
      montecarloPollHandle: null,
      stageStatus: {},
      backendReady: false,
    };

    function replacePayload(nextPayload) {
      Object.keys(PAYLOAD).forEach((key) => delete PAYLOAD[key]);
      Object.assign(PAYLOAD, nextPayload);
    }

    async function fetchJson(url, options = {}) {
      const response = await fetch(url, options);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      return response.json();
    }

    function setConsoleBadges(runtimeText, runtimeMode, liveText, liveMode) {
      const runtime = document.getElementById('console-runtime-badge');
      const live = document.getElementById('console-live-badge');
      runtime.className = `status-chip ${runtimeMode || ''}`.trim();
      runtime.textContent = runtimeText;
      live.className = `status-chip ${liveMode || ''}`.trim();
      live.textContent = liveText;
      const hudRuntime = document.getElementById('hud-runtime');
      const hudLive = document.getElementById('hud-live');
      if (hudRuntime) hudRuntime.textContent = runtimeText;
      if (hudLive) hudLive.textContent = liveText;
    }

    function setConsoleOutput(stage, lines) {
      if (!stage) return;
      document.getElementById('console-stage-label').textContent = `${stage.eyebrow} · ${stage.title}`;
      document.getElementById('console-command').textContent = stage.command;
      document.getElementById('console-log').innerHTML = lines.map((line) => `<div>${line}</div>`).join('');
      const hudStage = document.getElementById('hud-active-stage');
      const hudTitle = document.getElementById('hud-active-title');
      const hudCopy = document.getElementById('hud-active-copy');
      if (hudStage) hudStage.textContent = stage.eyebrow;
      if (hudTitle) hudTitle.textContent = stage.title;
      if (hudCopy) hudCopy.textContent = stage.tagline;
    }

    function updateStageDecorators() {
      document.querySelectorAll('.stage-button').forEach((button) => {
        const status = state.stageStatus[button.dataset.stage] || {};
        button.classList.toggle('running', Boolean(status.running));
        button.classList.toggle('done', Boolean(status.done));
        button.classList.toggle('active', button.dataset.stage === state.activeStage);
      });
    }

    function fmtCurrency(value) {
      return Number(value || 0).toLocaleString('es-ES', { maximumFractionDigits: 0 }) + ' EUR';
    }

    function fmtPct(value) {
      return (Number(value || 0) * 100).toFixed(1) + '%';
    }

    function fmtPctNumber(value) {
      return Number(value || 0).toFixed(1) + '%';
    }

    function asArray(value) {
      return Array.isArray(value) ? value : [];
    }

    function asObject(value) {
      return value && typeof value === 'object' ? value : {};
    }

    function createMetric(label, value, sub) {
      return `<article class="metric"><div class="metric-label">${label}</div><div class="metric-value">${value}</div><div class="stage-copy">${sub}</div></article>`;
    }

    function renderHero() {
      document.getElementById('hero-title').textContent = PAYLOAD.title;
      document.getElementById('hero-subtitle').textContent = PAYLOAD.subtitle;
      const ds = asObject(asObject(PAYLOAD.dataset).summary);
      const simulation = asObject(PAYLOAD.simulation);
      const totalSimulations = Number(simulation.total_simulations || 0);
      const metrics = [
        createMetric('Campañas analizadas', ds.rows.toLocaleString('es-ES'), `${ds.period_start} -> ${ds.period_end}`),
        createMetric('Futuros a evaluar', totalSimulations.toLocaleString('es-ES'), 'Escenarios preparados para visualizar la toma de decision'),
        createMetric('Variables disponibles', ds.variable_count.toLocaleString('es-ES'), `${ds.segment_count} segmentos · ${ds.geography_count} geografias`),
        createMetric('Ventanas temporales', ds.time_windows.toLocaleString('es-ES'), 'Meses historicos disponibles para la decision'),
      ];
      document.getElementById('hero-kpis').innerHTML = metrics.join('');
    }

    function renderBriefing() {
      document.getElementById('briefing-tags').innerHTML = asArray(PAYLOAD.stages).map((stage) => `<span class="tag">${stage.eyebrow} · ${stage.title}</span>`).join('');
    }

    function renderStageButtons() {
      const root = document.getElementById('stage-buttons');
      root.innerHTML = asArray(PAYLOAD.stages).map((stage) => `
        <button class="stage-button" data-stage="${stage.key}">
          <div class="eyebrow">${stage.eyebrow}</div>
          <div class="stage-title">${stage.title}</div>
          <div class="stage-copy">${stage.tagline}</div>
        </button>
      `).join('');
      root.querySelectorAll('.stage-button').forEach((button) => {
        button.addEventListener('click', () => runStage(button.dataset.stage));
      });
      updateStageDecorators();
    }

    function renderDataset() {
      const dataset = asObject(PAYLOAD.dataset);
      const ds = asObject(dataset.summary);
      document.getElementById('dataset-kpis').innerHTML = [
        createMetric('Periodo cubierto', `${ds.period_start} -> ${ds.period_end}`, 'Ventana historica utilizada en el analisis'),
        createMetric('Conversion observada', fmtPct(ds.conversion_rate), 'Tasa media de exito del historico'),
        createMetric('Ticket medio', fmtCurrency(ds.avg_ticket_eur), 'Valor medio de las operaciones convertidas'),
        createMetric('Beneficio acumulado', fmtCurrency(ds.contribution_profit_eur), 'Beneficio de contribucion total del historico'),
      ].join('');

      document.getElementById('dataset-structure-cards').innerHTML = [
        createMetric('Campañas únicas', ds.campaign_count.toLocaleString('es-ES'), 'Combinaciones distintas de canal y objetivo comercial'),
        createMetric('Variables', ds.variable_count.toLocaleString('es-ES'), 'Campos disponibles para explicar comportamiento y resultado'),
        createMetric('Segmentos', ds.segment_count.toLocaleString('es-ES'), 'Perfiles de cliente incluidos en el caso'),
        createMetric('Geografías', ds.geography_count.toLocaleString('es-ES'), 'Mercados presentes en la base historica'),
      ].join('');

      document.getElementById('sample-table').innerHTML = asArray(dataset.sample).map((row) => `
        <tr>
          <td>${row.date}</td>
          <td>${row.channel}</td>
          <td>${row.customer_segment}</td>
          <td>${row.campaign_objective}</td>
          <td>${row.lead_score}</td>
          <td>${row.converted_to_sale ? 'Si' : 'No'}</td>
          <td>${fmtCurrency(row.revenue_eur)}</td>
          <td>${fmtCurrency(row.contribution_profit_eur)}</td>
        </tr>
      `).join('');

      renderMonthlyChart();
    }

    function renderMonthlyChart() {
      const svg = document.getElementById('monthly-chart');
      const data = asArray(asObject(PAYLOAD.dataset).monthly);
      if (!data.length) {
        svg.innerHTML = '';
        return;
      }
      const width = 680;
      const height = 280;
      const left = 42;
      const right = 22;
      const top = 24;
      const bottom = 28;
      const revenueValues = data.map((row) => Number(row.revenue_eur));
      const profitValues = data.map((row) => Number(row.contribution_profit_eur));
      const maxValue = Math.max(...revenueValues, ...profitValues, 1);
      const x = (index) => left + (index / Math.max(1, data.length - 1)) * (width - left - right);
      const y = (value) => height - bottom - (value / maxValue) * (height - top - bottom);
      const revenuePath = data.map((row, index) => `${index === 0 ? 'M' : 'L'} ${x(index)} ${y(Number(row.revenue_eur))}`).join(' ');
      const profitPath = data.map((row, index) => `${index === 0 ? 'M' : 'L'} ${x(index)} ${y(Number(row.contribution_profit_eur))}`).join(' ');
      const ticks = [0, 0.33, 0.66, 1].map((ratio) => {
        const tickY = y(maxValue * ratio);
        return `<line x1="${left}" y1="${tickY}" x2="${width - right}" y2="${tickY}" stroke="rgba(124, 201, 227, 0.10)" />`;
      }).join('');
      const labels = [data[0], data[Math.floor(data.length / 2)], data[data.length - 1]].map((row, idx) => {
        const positions = [left, width / 2, width - right];
        return `<text x="${positions[idx]}" y="${height - 8}" fill="#88b6c7" font-size="11" text-anchor="middle">${row.month}</text>`;
      }).join('');
      svg.innerHTML = `
        <defs>
          <linearGradient id="rev-gradient" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stop-color="#25e6ff"></stop>
            <stop offset="100%" stop-color="#58a6ff"></stop>
          </linearGradient>
          <linearGradient id="profit-gradient" x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stop-color="#27f5c6"></stop>
            <stop offset="100%" stop-color="#ffd166"></stop>
          </linearGradient>
        </defs>
        ${ticks}
        <path d="${revenuePath}" fill="none" stroke="url(#rev-gradient)" stroke-width="4" stroke-linecap="round"></path>
        <path d="${profitPath}" fill="none" stroke="url(#profit-gradient)" stroke-width="4" stroke-linecap="round" stroke-dasharray="8 8"></path>
        ${labels}
      `;
    }

    function renderUplift() {
      const models = asObject(PAYLOAD.models);
      const classification = asObject(models.classification);
      const regression = asObject(models.regression);
      const gainChart = asArray(classification.gain_chart);
      const residualBands = asArray(regression.residual_bands);
      const uplift = asObject(PAYLOAD.uplift);
      const mainUplift = asArray(uplift.main);
      const adsUplift = asArray(uplift.ads);
      document.getElementById('classification-kpis').innerHTML = [
        createMetric('AUC', Number(classification.auc).toFixed(3), 'Capacidad de separar oportunidades con mayor y menor probabilidad de exito'),
        createMetric('Base de conversion', fmtPct(classification.positive_rate), 'Frecuencia observada de cierres en el conjunto de validacion'),
        createMetric('Probabilidad media', fmtPct(classification.avg_predicted_prob), 'Propension media estimada por el modelo'),
        createMetric('Top decil', fmtPct(gainChart[0] ? gainChart[0].conversion_rate : 0), 'Tasa de conversion del 10% de casos con mayor puntuacion'),
      ].join('');

      document.getElementById('regression-kpis').innerHTML = [
        createMetric('MAE', fmtCurrency(regression.mae_eur), 'Error absoluto medio sobre el valor estimado'),
        createMetric('R²', Number(regression.r2).toFixed(3), 'Capacidad del modelo para explicar variacion del ticket'),
        createMetric('Sesgo medio', fmtCurrency(regression.mean_residual_eur), 'Diferencia media entre valor real y valor estimado'),
        createMetric('P90 error', fmtCurrency(regression.p90_abs_error_eur), 'Error absoluto en el percentil 90'),
      ].join('');

      renderGainChart();
      const maxResidualCount = Math.max(...residualBands.map((row) => Number(row.count)), 1);
      document.getElementById('residual-bars').innerHTML = residualBands.map((row) => `
        <div class="bar-row">
          <div>
            <div class="stage-title" style="font-size:15px">${row.label}</div>
            <div class="stage-copy">Numero de observaciones dentro de esta banda de error</div>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:${Math.max(8, Number(row.count) / maxResidualCount * 100)}%"></div></div>
          <div style="text-align:right">${Number(row.count).toLocaleString('es-ES')}</div>
        </div>
      `).join('');

      const upliftRoot = document.getElementById('uplift-cards');
      upliftRoot.innerHTML = mainUplift.map((row) => `
        <article class="tool-card flash">
          <div class="eyebrow">${row.label}</div>
          <div class="tool-name">${fmtPct(row.baseline_conversion)} → ${fmtPct(row.scenario_conversion)} de conversion esperada</div>
          <div class="tool-purpose">${row.description} Uplift estimado: ${fmtPctNumber(Number(row.conversion_lift_pct) * 100)} · Impacto incremental por oportunidad: ${fmtCurrency(row.profit_lift_per_opportunity_eur)}</div>
        </article>
      `).join('');

    }

    function renderGainChart() {
      const svg = document.getElementById('gain-chart');
      const data = asArray(asObject(asObject(PAYLOAD.models).classification).gain_chart);
      if (!data.length) {
        svg.innerHTML = '';
        return;
      }
      const width = 680;
      const height = 240;
      const left = 42;
      const right = 18;
      const top = 20;
      const bottom = 28;
      const x = (index) => left + (index / Math.max(1, data.length - 1)) * (width - left - right);
      const y = (value) => height - bottom - value * (height - top - bottom);
      const gainPath = data.map((row, index) => `${index === 0 ? 'M' : 'L'} ${x(index)} ${y(Number(row.capture_pct))}`).join(' ');
      const basePath = `M ${left} ${y(0.1)} ${data.map((row, index) => `L ${x(index)} ${y((index + 1) / 10)}`).join(' ')}`;
      const points = data.map((row, index) => `<circle cx="${x(index)}" cy="${y(Number(row.capture_pct))}" r="4" fill="#25e6ff"></circle>`).join('');
      svg.innerHTML = `
        <line x1="${left}" y1="${y(0)}" x2="${width - right}" y2="${y(0)}" stroke="rgba(124, 201, 227, 0.12)" />
        <line x1="${left}" y1="${y(0.5)}" x2="${width - right}" y2="${y(0.5)}" stroke="rgba(124, 201, 227, 0.12)" />
        <line x1="${left}" y1="${y(1)}" x2="${width - right}" y2="${y(1)}" stroke="rgba(124, 201, 227, 0.12)" />
        <path d="${basePath}" fill="none" stroke="#ffd166" stroke-width="2" stroke-dasharray="8 8"></path>
        <path d="${gainPath}" fill="none" stroke="#25e6ff" stroke-width="4" stroke-linecap="round"></path>
        ${points}
        <text x="${left}" y="18" fill="#88b6c7" font-size="11">Captura acumulada de conversiones</text>
        <text x="${width - right}" y="18" text-anchor="end" fill="#88b6c7" font-size="11">Gain chart</text>
      `;
    }

    function renderSimulation() {
      const simulation = asObject(PAYLOAD.simulation);
      const summary = asArray(simulation.summary);
      document.getElementById('summary-cards').innerHTML = summary.map((row) => `
        <article class="tool-card">
          <div class="eyebrow">Ranking ${row.ranking}</div>
          <div class="tool-name">${row.decision}</div>
          <div class="tool-purpose">Beneficio esperado: ${fmtCurrency(row.expected_profit_eur)} · P10: ${fmtCurrency(row.p10_eur)} · P90: ${fmtCurrency(row.p90_eur)} · ROI: ${Number(row.expected_roi).toFixed(1)}x</div>
        </article>
      `).join('');
      refreshLiveFrame(false);
    }

    function renderReport() {
      const recommendation = asObject(PAYLOAD.recommendation);
      const report = asObject(PAYLOAD.report);
      const audienceViews = asObject(recommendation.audience_views);
      const selectedView = asObject(audienceViews[state.audience]);
      const activeView = Object.keys(selectedView).length ? selectedView : recommendation;
      document.getElementById('audience-summary').textContent = AUDIENCE_META[state.audience] || '';
      document.getElementById('verdict-headline').textContent = activeView.headline || recommendation.headline;
      document.getElementById('verdict-copy').textContent = activeView.summary || recommendation.agent_summary || `${recommendation.decision} lidera la simulacion con ${fmtCurrency(recommendation.expected_profit_eur)}, ROI esperado de ${Number(recommendation.expected_roi).toFixed(1)}x y probabilidad de perdida de ${fmtPct(recommendation.probability_loss)}.`;
      document.getElementById('reason-list').innerHTML = asArray(activeView.reasons || recommendation.reasons).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('watchouts-list').innerHTML = asArray(activeView.watchouts || recommendation.watchouts).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('next-actions').innerHTML = asArray(activeView.next_actions || recommendation.next_actions).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('switch-signals').innerHTML = asArray(activeView.switch_signals || recommendation.switch_signals).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('due-diligence').innerHTML = asArray(activeView.due_diligence || recommendation.due_diligence).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('agent-findings').innerHTML = asArray(recommendation.findings).map((item) => `<li>${item}</li>`).join('');
      document.getElementById('tool-trace').innerHTML = asArray(recommendation.tool_trace).map((item) => `
        <article class="trace-item">
          <div class="trace-top">
            <div class="trace-name">${item.name}</div>
            <div class="trace-args">${item.args}</div>
          </div>
          <div class="trace-purpose">${item.purpose}</div>
          <div class="trace-outcome">${item.outcome}</div>
        </article>
      `).join('');
      document.querySelectorAll('[data-audience]').forEach((button) => {
        button.classList.toggle('active', button.dataset.audience === state.audience);
      });
      document.getElementById('report-checks').innerHTML = asArray(report.checks).map((item) => `<span class="tag">${item}</span>`).join('');
    }

    function consoleLines(stage) {
      const base = [
        `> ${stage.command}`,
        '> preparando la vista ejecutiva',
        '> actualizando la consola con informacion del caso',
      ];
      if (stage.key === 'ingesta') return base.concat(['> cargando base historica', '> validando cobertura y estructura de variables']);
      if (stage.key === 'uplift') return base.concat(['> calculando metricas tecnicas de los modelos', '> traduciendo resultados a escenarios de negocio']);
      if (stage.key === 'montecarlo') return base.concat(['> iniciando simulacion de escenarios', '> sincronizando radar y telemetria en directo']);
      if (stage.key === 'reporte') return base.concat(['> consolidando conclusiones', '> preparando recomendacion ejecutiva']);
      return base.concat(['> consola lista para iniciar la presentacion']);
    }

    function showPane(stageKey) {
      document.querySelectorAll('.stage-pane').forEach((pane) => pane.classList.remove('active'));
      document.getElementById(`pane-${stageKey}`).classList.add('active');
      state.activeStage = stageKey;
      updateStageDecorators();
    }

    function runProgress(stage, durationMs, onDone) {
      clearInterval(state.progressTimer);
      const fill = document.getElementById('progress-fill');
      const start = performance.now();
      fill.style.width = '0%';
      state.progressTimer = setInterval(() => {
        const elapsed = performance.now() - start;
        const pct = Math.min(100, elapsed / Math.max(1, durationMs) * 100);
        fill.style.width = pct + '%';
        if (pct >= 100) {
          clearInterval(state.progressTimer);
          showPane(stage.key);
          if (onDone) onDone();
        }
      }, 32);
    }

    function refreshLiveFrame(withTimestamp = true) {
      const frame = document.getElementById('live-frame');
      const base = asObject(PAYLOAD.simulation).live_dashboard || 'dashboards/dashboard_live_montecarlo.html';
      frame.src = withTimestamp ? `${base}?ts=${Date.now()}` : base;
    }

    function setMontecarloPlaceholder(visible, title = '', copy = '') {
      const root = document.getElementById('montecarlo-placeholder');
      if (!root) return;
      root.classList.toggle('is-visible', Boolean(visible));
      if (title) document.getElementById('montecarlo-placeholder-title').textContent = title;
      if (copy) document.getElementById('montecarlo-placeholder-copy').textContent = copy;
    }

    function syncLiveFrameHeight() {
      const frame = document.getElementById('live-frame');
      if (!frame) return;
      try {
        const doc = frame.contentDocument || frame.contentWindow?.document;
        if (!doc) return;
        const shell = doc.querySelector('.shell');
        const measuredHeight = shell
          ? shell.scrollHeight + 32
          : Math.max(doc.documentElement.scrollHeight || 0, doc.body ? doc.body.scrollHeight : 0);
        const nextHeight = Math.min(1800, Math.max(1040, measuredHeight));
        frame.style.height = `${nextHeight}px`;
      } catch (error) {
        // same-origin in local mode, but keep this resilient if the source changes.
      }
    }

    function renderAll() {
      renderHero();
      renderBriefing();
      renderDataset();
      renderUplift();
      renderSimulation();
      renderReport();
      updateStageDecorators();
    }

    function activateStage(stageKey, instant = false) {
      const stage = asArray(PAYLOAD.stages).find((item) => item.key === stageKey);
      if (!stage) return;
      setConsoleOutput(stage, consoleLines(stage));
      if (instant) {
        document.getElementById('progress-fill').style.width = '100%';
        showPane(stage.key);
        return;
      }
      runProgress(stage, stage.duration_ms);
    }

    async function hydratePayload() {
      if (!BACKEND_ENABLED) {
        setConsoleBadges('Modo local', 'ready', 'Sin backend', '');
        return;
      }
      try {
        const response = await fetchJson(`${API_BASE}/api/payload`);
        replacePayload(response.payload);
        state.backendReady = true;
        renderAll();
        setConsoleBadges('Backend online', 'ready', 'Aplicacion sincronizada', 'ready');
        const live = await fetchJson(`${API_BASE}/api/montecarlo-status`);
          if (live.preparing) {
            setMontecarloPlaceholder(true, 'Precalculando simulacion', live.status_message || 'Preparando dataset y modelos antes de arrancar la simulacion real.');
            beginMontecarloPolling();
          } else if (live.running || live.is_running) {
            setMontecarloPlaceholder(false);
          state.stageStatus.montecarlo = { running: true, done: false };
          beginMontecarloPolling();
        }
      } catch (error) {
        setConsoleBadges('Modo local', 'alert', 'Backend no accesible', 'alert');
      }
    }

    async function runStage(stageKey, options = {}) {
      const stage = asArray(PAYLOAD.stages).find((item) => item.key === stageKey);
      if (!stage) return;

      if (!options.keepAutoplay) {
        state.autoplay = false;
        clearTimeout(state.autoTimer);
      }

      if (!BACKEND_ENABLED) {
        activateStage(stageKey, options.instant === true);
        return;
      }

      if (state.backendReady && PRECOMPUTED_STAGE_KEYS.has(stageKey)) {
        state.stageStatus[stageKey] = { running: false, done: true };
        updateStageDecorators();
        showPane(stage.key);
        setConsoleBadges('Backend online', 'ready', `${stage.title} preparada`, 'ready');
        setConsoleOutput(stage, consoleLines(stage));
        document.getElementById('progress-fill').style.width = '100%';
        return;
      }

      const autoplayButton = document.getElementById('autoplay-btn');
      autoplayButton.disabled = true;
      state.stageStatus[stageKey] = { running: true, done: false };
      updateStageDecorators();
      setConsoleOutput(stage, ['> contactando backend local', '> preparando ejecucion real de la etapa']);
      if (stageKey === 'montecarlo') {
        showPane(stage.key);
        document.getElementById('progress-fill').style.width = '0%';
      }

      try {
        const response = await fetchJson(`${API_BASE}/api/stage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ stage: stageKey }),
        });
        if (response.payload) {
          replacePayload(response.payload);
          renderAll();
        }
        setConsoleOutput(stage, response.logs || consoleLines(stage));
        const liveLabel = stageKey === 'montecarlo'
          ? 'Simulacion en directo'
          : `${stage.title} completada`;
        if (stageKey === 'montecarlo' && response.status === 'preparing') {
          setConsoleBadges('Backend online', 'ready', 'Precalculando simulacion', 'running');
          setMontecarloPlaceholder(true, 'Precalculando simulacion', 'El backend está preparando dataset y modelos. El dashboard live aparecerá cuando arranque la simulación real.');
          beginMontecarloPolling();
          return;
        }
        setConsoleBadges('Backend online', 'ready', liveLabel, stageKey === 'montecarlo' ? 'running' : 'ready');
        if (stageKey === 'montecarlo') {
          state.stageStatus[stageKey] = {
            running: Boolean(response.montecarlo && response.montecarlo.running),
            done: false,
          };
          updateStageDecorators();
          setMontecarloPlaceholder(false);
          refreshLiveFrame(true);
          beginMontecarloPolling();
          return;
        }
        const delayMs = options.instant ? 1 : Number(response.delay_ms || stage.duration_ms || 900);
        runProgress(stage, delayMs, () => {
          state.stageStatus[stageKey] = {
            running: stageKey === 'montecarlo' && response.montecarlo && response.montecarlo.running,
            done: stageKey !== 'montecarlo',
          };
          updateStageDecorators();
          if (stageKey === 'montecarlo') {
            refreshLiveFrame(true);
            beginMontecarloPolling();
          }
        });
      } catch (error) {
        state.stageStatus[stageKey] = { running: false, done: false };
        updateStageDecorators();
        setConsoleBadges('Backend error', 'alert', 'Etapa no ejecutada', 'alert');
        setConsoleOutput(stage, [`> error al ejecutar la etapa`, `> ${error.message}`]);
      } finally {
        autoplayButton.disabled = false;
      }
    }

    async function pollMontecarloStatus() {
      try {
        const status = await fetchJson(`${API_BASE}/api/montecarlo-status`);
        const pct = Number(status.progress_pct || 0);
        document.getElementById('progress-fill').style.width = `${pct}%`;
        if (status.preparing && !status.running && !status.is_running) {
          const montecarloStage = asArray(PAYLOAD.stages).find((item) => item.key === 'montecarlo');
          setConsoleBadges('Backend online', 'ready', 'Precalculando simulacion', 'running');
          setConsoleOutput(
            montecarloStage,
            [
              '> precalculando dataset y modelos',
              '> preparando el punto de partida de la simulacion real',
              `> estado: ${status.status_message || 'esperando activos de simulacion'}`,
            ],
          );
          setMontecarloPlaceholder(true, 'Precalculando simulacion', status.status_message || 'Preparando dataset y modelos antes de arrancar la simulación real.');
          return;
        }
        if (status.running || status.is_running) {
          const leaderText = status.leader ? status.leader.decision : 'calculando ranking';
          const montecarloStage = asArray(PAYLOAD.stages).find((item) => item.key === 'montecarlo');
          setConsoleBadges('Backend online', 'ready', `Monte Carlo ${pct.toFixed(1)}%`, 'running');
          setMontecarloPlaceholder(false);
          setConsoleOutput(
            montecarloStage,
            [
              '> simulacion Monte Carlo en curso',
              `> iteracion ${Number(status.current_simulation || 0).toLocaleString('es-ES')} de ${Number(status.total_simulations || 0).toLocaleString('es-ES')}`,
              `> avance visible: ${pct.toFixed(1)}%`,
              `> mejor alternativa provisional: ${leaderText}`,
            ],
          );
          if (state.activeStage === 'montecarlo') {
            refreshLiveFrame(true);
            syncLiveFrameHeight();
          }
          return;
        }

        clearInterval(state.montecarloPollHandle);
        state.montecarloPollHandle = null;
        state.stageStatus.montecarlo = { running: false, done: true };
        if (status.payload) {
          replacePayload(status.payload);
          renderAll();
        }
        document.getElementById('progress-fill').style.width = '100%';
        const montecarloStage = asArray(PAYLOAD.stages).find((item) => item.key === 'montecarlo');
        setConsoleBadges('Backend online', 'ready', 'Monte Carlo completada', 'ready');
        setMontecarloPlaceholder(false);
        setConsoleOutput(
          montecarloStage,
          [
            '> simulacion finalizada',
            `> iteraciones finales: ${Number(status.total_simulations || 0).toLocaleString('es-ES')}`,
            `> mejor alternativa: ${status.leader ? status.leader.decision : 'sin ranking'}`,
            '> resultados consolidados listos para la recomendacion final',
          ],
        );
        updateStageDecorators();
        refreshLiveFrame(true);
        syncLiveFrameHeight();
      } catch (error) {
        clearInterval(state.montecarloPollHandle);
        state.montecarloPollHandle = null;
        setConsoleBadges('Backend online', 'ready', 'Error monitorizando live', 'alert');
      }
    }

    function beginMontecarloPolling() {
      clearInterval(state.montecarloPollHandle);
      state.montecarloPollHandle = setInterval(pollMontecarloStatus, 1200);
      pollMontecarloStatus();
    }

    function autoplaySequence() {
      clearTimeout(state.autoTimer);
      const order = asArray(PAYLOAD.stages).map((stage) => stage.key);
      let index = 0;
      state.autoplay = true;
      async function next() {
        await runStage(order[index], { keepAutoplay: true });
        index += 1;
        if (index < order.length && state.autoplay) {
          const previous = order[index - 1];
          const waitMs = previous === 'montecarlo' ? 42000 : 4800;
          state.autoTimer = setTimeout(next, waitMs);
        }
      }
      next();
    }

    function bindActions() {
      document.getElementById('autoplay-btn').addEventListener('click', autoplaySequence);
      document.querySelectorAll('[data-audience]').forEach((button) => {
        button.addEventListener('click', () => {
          state.audience = button.dataset.audience || 'ceo';
          renderReport();
        });
      });
      document.getElementById('reset-btn').addEventListener('click', () => {
        state.autoplay = false;
        state.audience = 'ceo';
        clearTimeout(state.autoTimer);
        clearInterval(state.montecarloPollHandle);
        state.montecarloPollHandle = null;
        activateStage('briefing', true);
        setConsoleBadges(BACKEND_ENABLED ? 'Backend online' : 'Modo local', 'ready', BACKEND_ENABLED ? 'Consola lista' : 'Sin backend', BACKEND_ENABLED ? 'ready' : '');
      });
      const liveFrame = document.getElementById('live-frame');
      if (liveFrame) {
        liveFrame.addEventListener('load', syncLiveFrameHeight);
      }
    }

    async function init() {
      renderAll();
      renderStageButtons();
      bindActions();
      activateStage('briefing', true);
      await hydratePayload();
    }

    init();
  </script>
</body>
</html>
"""


def generate_mission_dashboard(output_path: Path = MISSION_DASHBOARD_PATH) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    payload = _build_payload()
    payload_json = json.dumps(payload, ensure_ascii=False, allow_nan=False).replace("</", "<\\/")
    html = HTML_TEMPLATE.replace("__PAYLOAD__", payload_json)
    output_path.write_text(html, encoding="utf-8")
    return output_path


def main() -> None:
    path = generate_mission_dashboard()
    print(path)


if __name__ == "__main__":
    main()