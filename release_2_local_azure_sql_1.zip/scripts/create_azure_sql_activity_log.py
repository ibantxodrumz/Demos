# scripts/create_azure_sql_activity_log.py
"""
Utility script to connect to Azure SQL Database and execute DDL
to ensure the [dbo].[ACTIVITY_LOG] table and indexes exist.
"""

import sys
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config.constants import SQL_DATABASE, SQL_SERVER
from src.repositories.azure_connection import get_azure_connection

DDL_SCRIPT = """
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ACTIVITY_LOG]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ACTIVITY_LOG] (
        [ACTIVITY_LOG_ID]    VARCHAR(255) NOT NULL PRIMARY KEY,
        [ALERT_UNIQUE_ID]    VARCHAR(255) NOT NULL,
        [BMU_ID]             VARCHAR(100) NULL,
        [PARTY_NAME]         VARCHAR(255) NULL,
        [PARAMETER_BREACHED] VARCHAR(255) NULL,
        [RAISE_DATE]         VARCHAR(50) NULL,
        [START_DATE]         VARCHAR(50) NULL,
        [END_DATE]           VARCHAR(50) NULL,
        [PERSON_RAISING]     VARCHAR(255) NULL,
        [NOTIFICATION_SOURCE] VARCHAR(255) NULL,
        [ACTION_TAKEN]       VARCHAR(255) NULL,
        [ANALYSIS_STATUS]    VARCHAR(50) NULL,
        [INFO_FOR_ANALYST]   NVARCHAR(MAX) NULL,
        [REVIEW_COMMENTS]    NVARCHAR(MAX) NULL,
        [CREATED_DATETIME]   VARCHAR(50) NULL,
        [UPDATED_DATETIME]   VARCHAR(50) NULL,
        CONSTRAINT [UQ_ACTIVITY_LOG_ALERT_UNIQUE_ID] UNIQUE ([ALERT_UNIQUE_ID])
    );

    CREATE INDEX [IX_ACTIVITY_LOG_ANALYSIS_STATUS] ON [dbo].[ACTIVITY_LOG] ([ANALYSIS_STATUS]);
    CREATE INDEX [IX_ACTIVITY_LOG_PARTY_NAME] ON [dbo].[ACTIVITY_LOG] ([PARTY_NAME]);
END
"""


def create_activity_log_table():
    print(f"Connecting to Azure SQL Server: {SQL_SERVER}, Database: {SQL_DATABASE}...")
    try:
        conn = get_azure_connection()
        conn.execute(DDL_SCRIPT)
        conn.commit()
        conn.close()
        print("Successfully verified / created [dbo].[ACTIVITY_LOG] table in Azure SQL!")
    except Exception as e:
        print(f"Failed to create [dbo].[ACTIVITY_LOG] table in Azure SQL: {e}")
        sys.exit(1)


if __name__ == "__main__":
    create_activity_log_table()
