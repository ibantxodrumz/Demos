from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import pandas as pd
from src.config.constants import SQL_TABLE_ALERTS_DATA
from src.repositories.connection import get_db
from src.services import alert_service


def get_long_run_counterparty_stats(
    start_date: str,
    end_date: str,
    threshold_volume: int = 5,
    threshold_impact_gbp: float = 50000.0,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Calculates Long-Run Counterparty Statistics & Dual Threshold Framing Metrics
    (Alert Volume Threshold & £ Financial Impact Threshold) for a given period.
    """
    res = alert_service.get_alerts_for_period(
        start_date=start_date,
        end_date=end_date,
        bmu_filter=bmu_filter,
        party_filter=party_filter,
        fuel_filter=fuel_filter,
        status_filter="All",
        db_path=db_path,
    )

    alerts = res["alerts"]
    if not alerts:
        return {
            "summary": {
                "total_alerts": 0,
                "total_parties": 0,
                "parties_exceeding_vol_threshold": 0,
                "parties_exceeding_gbp_threshold": 0,
                "parties_exceeding_both": 0,
                "top_breaching_party": "-",
                "total_duration_mins": 0,
                "total_sps": 0,
                "total_gbp_impact": 0.0,
            },
            "counterparties": [],
            "filter_options": res["filter_options"],
        }

    # Fetch £ Financial Impact for periods from SQL_TABLE_ALERTS_DATA within active date window
    end_date_str = str(end_date)[:10]
    end_exclusive = (datetime.strptime(end_date_str, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")

    gbp_impact_map = {}
    try:
        query_gbp = f"""
        SELECT COUNTERPARTY, SUM(COALESCE(OFFER_PRICE, 50.0) * COALESCE(OFFER_VOLUME_MWH, 20.0)) AS TOTAL_GBP
        FROM {SQL_TABLE_ALERTS_DATA}
        WHERE GMT_FROM >= :start_date AND GMT_FROM < :end_exclusive
        GROUP BY COUNTERPARTY
        """
        with get_db(db_path) as conn:
            cursor = conn.execute(query_gbp, {"start_date": str(start_date)[:10], "end_exclusive": end_exclusive})
            for row in cursor.fetchall():
                gbp_impact_map[row["COUNTERPARTY"]] = float(row["TOTAL_GBP"] or 0.0)
    except Exception:
        gbp_impact_map = {}

    party_groups: Dict[str, List[Dict[str, Any]]] = {}
    for a in alerts:
        pname = a.get("COUNTERPARTY") or "Unknown Party"
        if pname not in party_groups:
            party_groups[pname] = []
        party_groups[pname].append(a)

    stats_list = []
    exceeding_vol_cnt = 0
    exceeding_gbp_cnt = 0
    exceeding_both_cnt = 0
    total_duration_overall = 0
    total_sps_overall = 0
    total_gbp_overall = 0.0

    for pname, p_alerts in party_groups.items():
        total_cnt = len(p_alerts)
        unreviewed_cnt = sum(1 for a in p_alerts if a.get("DISPLAY_STATUS") == "Unreviewed")
        open_cnt = sum(1 for a in p_alerts if a.get("DISPLAY_STATUS") == "Open")
        closed_cnt = sum(1 for a in p_alerts if a.get("DISPLAY_STATUS") == "Closed")

        autoclose_cnt = sum(1 for a in p_alerts if (a.get("ACTION_TAKEN") or "").lower() == "autoclose")
        monitor_cnt = sum(1 for a in p_alerts if "monitor" in (a.get("ACTION_TAKEN") or "").lower())
        escalated_cnt = sum(1 for a in p_alerts if "escalat" in (a.get("ACTION_TAKEN") or "").lower())

        dur_mins = sum(int(a.get("DURATION_MIN") or 0) for a in p_alerts)
        sp_cnt = sum(int(a.get("COUNT_SP") or 0) for a in p_alerts)

        # Financial GBP impact calculation
        gbp_impact = gbp_impact_map.get(pname, dur_mins * 1500.0)
        total_gbp_overall += gbp_impact

        total_duration_overall += dur_mins
        total_sps_overall += sp_cnt

        vol_breached = total_cnt >= threshold_volume
        gbp_breached = gbp_impact >= threshold_impact_gbp

        if vol_breached:
            exceeding_vol_cnt += 1
        if gbp_breached:
            exceeding_gbp_cnt += 1
        if vol_breached and gbp_breached:
            exceeding_both_cnt += 1

        if vol_breached and gbp_breached:
            framing_status = "BREACHED BOTH (Volume & £ Impact)"
        elif vol_breached:
            framing_status = f"BREACHED VOLUME (≥ {threshold_volume} Alerts)"
        elif gbp_breached:
            framing_status = f"BREACHED £ IMPACT (≥ £{threshold_impact_gbp:,.0f})"
        else:
            framing_status = "Within Limits"

        bmus_associated = sorted(list(set(a.get("BMU_ID") for a in p_alerts if a.get("BMU_ID"))))

        stats_list.append({
            "COUNTERPARTY": pname,
            "TOTAL_ALERTS": total_cnt,
            "TOTAL_GBP_IMPACT": gbp_impact,
            "FRAMING_STATUS": framing_status,
            "VOL_BREACHED": vol_breached,
            "GBP_BREACHED": gbp_breached,
            "UNREVIEWED_COUNT": unreviewed_cnt,
            "OPEN_COUNT": open_cnt,
            "CLOSED_COUNT": closed_cnt,
            "AUTOCLOSE_COUNT": autoclose_cnt,
            "MONITOR_COUNT": monitor_cnt,
            "ESCALATED_COUNT": escalated_cnt,
            "TOTAL_DURATION_MIN": dur_mins,
            "TOTAL_SPS": sp_cnt,
            "BMUS": bmus_associated,
        })

    # Sort counterparties by total alert count descending
    stats_list.sort(key=lambda x: (x["TOTAL_ALERTS"], x["TOTAL_GBP_IMPACT"]), reverse=True)

    top_party = stats_list[0]["COUNTERPARTY"] if stats_list else "-"

    return {
        "summary": {
            "total_alerts": len(alerts),
            "total_parties": len(party_groups),
            "parties_exceeding_vol_threshold": exceeding_vol_cnt,
            "parties_exceeding_gbp_threshold": exceeding_gbp_cnt,
            "parties_exceeding_both": exceeding_both_cnt,
            "top_breaching_party": top_party,
            "total_duration_mins": total_duration_overall,
            "total_sps": total_sps_overall,
            "total_gbp_impact": total_gbp_overall,
        },
        "counterparties": stats_list,
        "filter_options": res["filter_options"],
    }
