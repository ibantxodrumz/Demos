from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.config.constants import SQL_TABLE_ACTIVITY_LOG
from src.repositories.connection import get_db


def ensure_activity_log_table_exists(db_path: Optional[Union[Path, str]] = None) -> None:
    """Ensures the ACTIVITY_LOG table exists in Azure SQL or local database prior to read/write operations."""
    ddl = f"""
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'{SQL_TABLE_ACTIVITY_LOG}') AND type in (N'U'))
    BEGIN
        CREATE TABLE {SQL_TABLE_ACTIVITY_LOG} (
            [ACTIVITY_LOG_ID]    VARCHAR(255) NOT NULL PRIMARY KEY,
            [ALERT_UNIQUE_ID]    VARCHAR(255) NOT NULL,
            [BMU_ID]             VARCHAR(100) NULL,
            [PARTY_NAME]         VARCHAR(255) NULL,
            [PARAMETER_BREACHED] VARCHAR(255) NULL,
            [RAISE_DATE]         VARCHAR(50) NULL,
            [START_DATE]         VARCHAR(50) NULL,
            [END_DATE]           VARCHAR(50) NULL,
            [PERSON_RAISING]     VARCHAR(255) NULL,
            [NOTIFICATION_SOURCE] VARCHAR(255) NULL,
            [ACTION_TAKEN]       VARCHAR(255) NULL,
            [ANALYSIS_STATUS]    VARCHAR(50) NULL,
            [INFO_FOR_ANALYST]   NVARCHAR(MAX) NULL,
            [REVIEW_COMMENTS]    NVARCHAR(MAX) NULL,
            [CREATED_DATETIME]   VARCHAR(50) NULL,
            [UPDATED_DATETIME]   VARCHAR(50) NULL,
            CONSTRAINT [UQ_ACTIVITY_LOG_ALERT_UNIQUE_ID] UNIQUE ([ALERT_UNIQUE_ID])
        );

        CREATE INDEX [IX_ACTIVITY_LOG_ANALYSIS_STATUS] ON {SQL_TABLE_ACTIVITY_LOG} ([ANALYSIS_STATUS]);
        CREATE INDEX [IX_ACTIVITY_LOG_PARTY_NAME] ON {SQL_TABLE_ACTIVITY_LOG} ([PARTY_NAME]);
    END
    """
    try:
        with get_db(db_path) as conn:
            conn.execute(ddl)
    except Exception:
        pass


def get_activity_log_by_alert_id(
    alert_unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    query = f"SELECT * FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :alert_unique_id"
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query, {"alert_unique_id": alert_unique_id})
            row = cursor.fetchone()
            return dict(row) if row else None
    except Exception:
        return None


def save_activity_log(
    record: Dict[str, Any],
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Inserts a new ACTIVITY_LOG record or updates an existing record linked to ALERT_UNIQUE_ID.
    Preserves CREATED_DATETIME on update, updates UPDATED_DATETIME.
    Uses transaction management via get_db context manager.
    """
    ensure_activity_log_table_exists(db_path)
    alert_unique_id = record["ALERT_UNIQUE_ID"]

    with get_db(db_path) as conn:
        cursor = conn.execute(
            f"SELECT ACTIVITY_LOG_ID, CREATED_DATETIME FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :id",
            {"id": alert_unique_id},
        )
        existing = cursor.fetchone()

        if existing:
            # Update existing record
            activity_log_id = existing["ACTIVITY_LOG_ID"]
            update_query = f"""
            UPDATE {SQL_TABLE_ACTIVITY_LOG}
            SET PARTY_NAME = :PARTY_NAME,
                PARAMETER_BREACHED = :PARAMETER_BREACHED,
                RAISE_DATE = :RAISE_DATE,
                START_DATE = :START_DATE,
                END_DATE = :END_DATE,
                PERSON_RAISING = :PERSON_RAISING,
                NOTIFICATION_SOURCE = :NOTIFICATION_SOURCE,
                ACTION_TAKEN = :ACTION_TAKEN,
                ANALYSIS_STATUS = :ANALYSIS_STATUS,
                INFO_FOR_ANALYST = :INFO_FOR_ANALYST,
                REVIEW_COMMENTS = :REVIEW_COMMENTS,
                UPDATED_DATETIME = :UPDATED_DATETIME
            WHERE ALERT_UNIQUE_ID = :ALERT_UNIQUE_ID
            """
            params = {
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": record["RAISE_DATE"],
                "START_DATE": record["START_DATE"],
                "END_DATE": record["END_DATE"],
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "UPDATED_DATETIME": record["UPDATED_DATETIME"],
                "ALERT_UNIQUE_ID": alert_unique_id,
            }
            conn.execute(update_query, params)
            record["ACTIVITY_LOG_ID"] = activity_log_id
            record["CREATED_DATETIME"] = existing["CREATED_DATETIME"]
        else:
            # Insert new record
            insert_query = f"""
            INSERT INTO {SQL_TABLE_ACTIVITY_LOG} (
                ACTIVITY_LOG_ID,
                ALERT_UNIQUE_ID,
                BMU_ID,
                PARTY_NAME,
                PARAMETER_BREACHED,
                RAISE_DATE,
                START_DATE,
                END_DATE,
                PERSON_RAISING,
                NOTIFICATION_SOURCE,
                ACTION_TAKEN,
                ANALYSIS_STATUS,
                INFO_FOR_ANALYST,
                REVIEW_COMMENTS,
                CREATED_DATETIME,
                UPDATED_DATETIME
            ) VALUES (
                :ACTIVITY_LOG_ID,
                :ALERT_UNIQUE_ID,
                :BMU_ID,
                :PARTY_NAME,
                :PARAMETER_BREACHED,
                :RAISE_DATE,
                :START_DATE,
                :END_DATE,
                :PERSON_RAISING,
                :NOTIFICATION_SOURCE,
                :ACTION_TAKEN,
                :ANALYSIS_STATUS,
                :INFO_FOR_ANALYST,
                :REVIEW_COMMENTS,
                :CREATED_DATETIME,
                :UPDATED_DATETIME
            )
            """
            params = {
                "ACTIVITY_LOG_ID": record["ACTIVITY_LOG_ID"],
                "ALERT_UNIQUE_ID": record["ALERT_UNIQUE_ID"],
                "BMU_ID": record["BMU_ID"],
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": record["RAISE_DATE"],
                "START_DATE": record["START_DATE"],
                "END_DATE": record["END_DATE"],
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "CREATED_DATETIME": record["CREATED_DATETIME"],
                "UPDATED_DATETIME": record.get("UPDATED_DATETIME"),
            }
            conn.execute(insert_query, params)

    return record


def get_all_saved_reviews(
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    query = f"""
    SELECT *
    FROM {SQL_TABLE_ACTIVITY_LOG}
    ORDER BY START_DATE DESC, BMU_ID ASC
    """
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query)
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except Exception:
        return []
