import unittest
import pandas as pd
from datetime import datetime
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))

from utilities import classify_v2

class TestLogicFixes(unittest.TestCase):
    def test_untraded_small_move(self):
        """1MW move with no trade should be INFO/Balanced."""
        row = pd.Series({
            "Net_PN_Change_MW": 1.0,
            "Total_Volume": 0.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 2, 12, 0),
            "Countertrade_on_same_IC": False,
            "CP Code": "BKW"
        })
        now = datetime(2023, 4, 2, 13, 0) # window passed
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "INFO")
        self.assertIn("Balanced", action)

    def test_untraded_large_move(self):
        """60MW move with no trade should be YES3 (Market Move)."""
        row = pd.Series({
            "Net_PN_Change_MW": 60.0,
            "Total_Volume": 0.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 2, 13, 0),
            "Countertrade_on_same_IC": False,
            "CP Code": "BKW"
        })
        now = datetime(2023, 4, 2, 14, 0) # window passed
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "YES3")
        self.assertIn("Market Move", action)

    def test_traded_breach(self):
        """1MW move when 10MW was traded should still be a NO/Breach."""
        row = pd.Series({
            "Net_PN_Change_MW": 1.0,
            "Total_Volume": 10.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 2, 14, 0),
            "Countertrade_on_same_IC": False,
            "CP Code": "BKW"
        })
        now = datetime(2023, 4, 2, 15, 0) # window passed
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "NO")
        self.assertIn("Compliance", action)

    def test_hplus1_shortfall(self):
        """A shortfall at H+1 should trigger RED ALERT."""
        row = pd.Series({
            "Net_PN_Change_MW": 1.0,
            "Total_Volume": 100.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 2, 14, 0),
            "Countertrade_on_same_IC": False,
            "CP Code": "BKW"
        })
        now = datetime(2023, 4, 2, 14, 0) # Exactly H+1
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "NO")
        self.assertIn("RED ALERT H+1", action)

    def test_hplus1_untraded_large_move(self):
        """A large un-traded move at H+1 should be YES3 (Market Move)."""
        row = pd.Series({
            "Net_PN_Change_MW": 60.0,
            "Total_Volume": 0.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 2, 14, 0),
            "Countertrade_on_same_IC": False,
            "CP Code": "BKW"
        })
        now = datetime(2023, 4, 2, 14, 0) # Simultaneously H+1
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "YES3")
        self.assertIn("RED ALERT H+1", action)

if __name__ == "__main__":
    unittest.main()
