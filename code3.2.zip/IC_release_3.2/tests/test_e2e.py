import os
import sys
import shutil
import unittest
import pandas as pd
from pathlib import Path
from unittest.mock import patch

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))

import click_2
import utilities
import constants

SCENARIOS_DIR = Path(__file__).parent / "scenarios"

class TestClick2E2E(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not SCENARIOS_DIR.exists():
            raise RuntimeError("Scenarios not found. Run generate_scenarios.py first.")

    def run_click2_for_scenario(self, scenario_path):
        """
        Run click_2 main() with patched paths and mocked API.
        """
        # Prepare outputs
        outputs_dir = scenario_path / "outputs"
        logs_dir = scenario_path / "logs"
        if outputs_dir.exists():
            shutil.rmtree(outputs_dir)
        outputs_dir.mkdir(exist_ok=True)
        if logs_dir.exists():
            shutil.rmtree(logs_dir)
        logs_dir.mkdir(exist_ok=True)
        
        # Copy trades CSVs to outputs for 'replay' logic
        for f in scenario_path.glob("trades_*.csv"):
            shutil.copy(f, outputs_dir / f.name)
            
        # Set Env
        os.environ["IC"] = "IFA"
        os.environ["FORWARD_ONLY"] = "true"
        os.environ["ADHOC_PAIRWISE_ONLY"] = "false"
        
        # Patch constants
        # Note: click_2 imports IC_PATHS etc.
        # We patch where they are used.
        # click_2 does NOT import OUTPUTS_DIR or LOGS_DIR, so we don't patch them there.
        with patch("click_2.IC_PATHS", {"IFA": scenario_path}), \
             patch("click_2.CP_CODES_FILE", scenario_path / "CP_codes.csv"), \
             patch("utilities.OUTPUTS_DIR", outputs_dir), \
             patch("utilities.LOGS_DIR", logs_dir), \
             patch("utilities.CP_CODES_FILE", scenario_path / "CP_codes.csv"), \
             patch("click_2.fetch_trades") as mock_fetch:
             
            # Wrapper to force replay mode
            def fetch_wrapper(*args, **kwargs):
                kwargs["mode"] = "replay"
                return utilities.fetch_trades(*args, **kwargs)
                
            mock_fetch.side_effect = fetch_wrapper
            
            # Run
            try:
                click_2.main()
            except SystemExit as e:
                pass # click_2 might exit on error, but main() usually returns
            except Exception as e:
                raise e
            
        return outputs_dir

    def test_s01_early_stop(self):
        """Scenario 1: No changes. Expect Early Stop (NO_CHANGES)."""
        scen_path = SCENARIOS_DIR / "S01_Early_stop"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        # Validations
        files = list(out_dir.glob("Comparison1_no_changes_summary_*.csv"))
        self.assertTrue(len(files) > 0, "Expected Comparison1 no changes summary")
        # [UAT] Run summaries are now log-only

    def test_s02_h_plus_1_changed(self):
        """Scenario 2: H+1 Change. Proceed to Trades."""
        scen_path = SCENARIOS_DIR / "S02_H_plus_1_changed"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        results = list(out_dir.glob("Comparison2_trade_results_*.csv"))
        self.assertTrue(len(results) > 0)
        df = pd.read_csv(results[0])
        self.assertFalse(df.empty)
        
        # Check Local Time columns
        self.assertIn("Local_time", df.columns)
        self.assertNotIn("HourLocal", df.columns)
        self.assertNotIn("HourUTC", df.columns)
        self.assertIn("INFO", df["Decision"].values)
        
    def test_s06_countertrade(self):
        """Scenario 6: Countertrade override."""
        scen_path = SCENARIOS_DIR / "S06_Countertrade"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        results = list(out_dir.glob("Comparison2_trade_results_*.csv"))
        self.assertTrue(len(results) > 0)
        df = pd.read_csv(results[0])
        
        self.assertIn("YES3", df["Decision"].values)
        if "Countertrade_on_same_IC" in df.columns:
            self.assertTrue(df["Countertrade_on_same_IC"].astype(bool).any())

    def test_s03_forward_changes(self):
        """Scenario 3: Forward changes only."""
        scen_path = SCENARIOS_DIR / "S03_Forward_changes_only"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        adv = list(out_dir.glob("Forward_Trade_Advisory_*.csv"))
        self.assertTrue(len(adv) > 0)
        # [UAT] JSON summary check removed as file generation is disabled

    def test_s04_on_ic_met(self):
        """Scenario 4: On-IC Met."""
        scen_path = SCENARIOS_DIR / "S04_On_IC_met"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        results = list(out_dir.glob("Comparison2_trade_results_*.csv"))
        self.assertTrue(len(results) > 0)
        df = pd.read_csv(results[0])
        self.assertIn("INFO", df["Decision"].values)

    def test_s05_across_ic_met(self):
        """Scenario 5: Across-IC Met."""
        scen_path = SCENARIOS_DIR / "S05_Across_IC_met"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        results = list(out_dir.glob("Comparison2_trade_results_*.csv"))
        self.assertTrue(len(results) > 0)
        df = pd.read_csv(results[0])
        self.assertIn("YES2", df["Decision"].values)

    def test_s07_no_trades(self):
        """Scenario 7: No trades found for PN delta."""
        scen_path = SCENARIOS_DIR / "S07_No_trades"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        # We don't get Comparison 2 results if there are NO trades to join with
        # because click_2.py:340 match_pn_to_trades uses inner join.
        # But it should produce an Advisory.
        adv = list(out_dir.glob("Forward_Trade_Advisory_*.csv"))
        self.assertTrue(len(adv) > 0)

    def test_s08_awareness_extremes(self):
        """Scenario 8: Negative awareness lag."""
        scen_path = SCENARIOS_DIR / "S08_Awareness_extremes"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        # Trade created AFTER PN update should be filtered out from Comparison 2
        # results if they are strict.
        # In this scenario, we expect YES3 because the PN delta is not covered by an "Aware" trade.
        adv = list(out_dir.glob("Forward_Trade_Advisory_*.csv"))
        self.assertTrue(len(adv) > 0)

    def test_s09_mapping_gaps(self):
        """Scenario 9: Mapping gaps."""
        scen_path = SCENARIOS_DIR / "S09_Mapping_gaps"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        adv = list(out_dir.glob("Forward_Trade_Advisory_*.csv"))
        self.assertTrue(len(adv) > 0)

    def test_s10_dst_boundary(self):
        """Scenario 10: DST boundary (Early Exit expected)."""
        scen_path = SCENARIOS_DIR / "S10_DST_boundary"
        out_dir = self.run_click2_for_scenario(scen_path)
        
        summary = list(out_dir.glob("Comparison1_no_changes_summary_*.csv"))
        self.assertTrue(len(summary) > 0)

if __name__ == "__main__":
    unittest.main()
