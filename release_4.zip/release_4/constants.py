# constants.py
# Define shared constants for SQL and Local Data Sources

# SQL Azure Configuration
SQL_SERVER = "ivansanz-db.database.windows.net" # Placeholder - update as needed
SQL_DATABASE = "IMPORT_ALERTS_DATABASE"        # Placeholder
SQL_TABLE = "[dbo].[IMPORT_ALERTS_DATA]"
SQL_QUERY = f"SELECT * FROM {SQL_TABLE}"

# Local Data Configuration
LOCAL_INPUT_DIR = "inputs"
DEFAULT_ALERTS_FILENAME = "alerts_data.csv"
