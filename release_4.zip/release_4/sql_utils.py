# sql_utils.py
import pyodbc
import pandas as pd
import struct
import streamlit as st
from azure.identity import DefaultAzureCredential
from constants import SQL_SERVER, SQL_DATABASE, SQL_QUERY

# --- SQL Azure Token-based Authentication Logic ---

def get_access_token():
    """Fetches an access token for Azure SQL Database using current Azure credentials (e.g. az login)."""
    try:
        credential = DefaultAzureCredential()
        token = credential.get_token("https://database.windows.net/.default")
        return token.token
    except Exception as e:
        raise ConnectionError(f"Azure Identity error: {e}. Please ensure you are logged in via 'az login'.")

def get_sql_connection():
    """Creates a pyodbc connection to Azure SQL using a Managed Identity/AccessToken."""
    driver = "{ODBC Driver 18 for SQL Server}"
    connection_string = f"Driver={driver};Server=tcp:{SQL_SERVER},1433;Database={SQL_DATABASE};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30"

    token = get_access_token()
    
    # Token-based auth requires struct packaging for the SQL_COPT_SS_ACCESS_TOKEN attribute (1256)
    token_bytes = token.encode("UTF-16-LE")
    token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)
    # The value 1256 is the constant for SQL_COPT_SS_ACCESS_TOKEN
    SQL_COPT_SS_ACCESS_TOKEN = 1256
    
    try:
        conn = pyodbc.connect(connection_string, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: token_struct})
        return conn
    except pyodbc.Error as e:
        # Check for common "Driver 18" installation issues or Firewall/Access errors
        error_msg = str(e)
        if "Can't open lib 'ODBC Driver 18 for SQL Server'" in error_msg:
            raise EnvironmentError("ODBC Driver 18 for SQL Server is not installed or configured correctly on this system.")
        elif "Firewall" in error_msg:
            raise ConnectionError("Connection blocked by Azure SQL Firewall. Ensure your client IP is allowed.")
        else:
            raise ConnectionError(f"SQL Connection failed: {error_msg}")

@st.cache_data(ttl=3600)
def fetch_sql_data():
    """Fetched data from Azure SQL and returns as a DataFrame."""
    try:
        conn = get_sql_connection()
        df = pd.read_sql(SQL_QUERY, conn)
        conn.close()
        return df
    except Exception as e:
        # Pass the error back to st.error handled in app.py
        raise e
