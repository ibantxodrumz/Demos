# local_utils.py
import pandas as pd
import streamlit as st
from pathlib import Path
from constants import LOCAL_INPUT_DIR

def scan_local_inputs():
    """Returns a list of CSV files in the LOCAL_INPUT_DIR for selectbox navigation."""
    input_dir = Path(LOCAL_INPUT_DIR)
    if input_dir.exists() and input_dir.is_dir():
        # Specifically look for alert files matching prompts
        csv_files = list(input_dir.glob("alerts_*.csv"))
        if not csv_files:
            csv_files = list(input_dir.glob("alerts_cleaned.csv"))
        return sorted(csv_files, key=lambda x: x.name)
    return []

def load_local_csv(file_path):
    """Loads a CSV as a dataframe."""
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        raise IOError(f"Failed to load local CSV: {e}")
