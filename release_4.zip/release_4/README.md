# Release 4: Hybrid SQL & CSV Architecture

## Overview
Release 4 upgrades the dashboard from a purely static CSV file system into a **Hybrid Production Architecture**. The app now supports live feeds from an **Azure SQL Database** while maintaining a local CSV fallback for offline analysis or firewall-restricted environments.

## New Features

### 1. Unified Authentication
*   **DefaultAzureCredential**: The app uses token-based authentication via `azure.identity`, allowing seamless login through your local `az login` context or Managed Identity in the cloud.
*   **Token Injection**: SQL connections are established using the `SQL_COPT_SS_ACCESS_TOKEN` attribute in `pyodbc`, eliminating the need for hardcoded passwords or client secrets in the codebase.

### 2. Hybrid Data Controller (Sidebar)
*   **Live Mode**: Fetches data from `[dbo].[IMPORT_ALERTS_DATA]` with a 1-hour cache TTL (configurable in `constants.py`).
*   **Local mode**: Scans the `./inputs/` directory for legacy CSV backups.
*   **Manual Override**: Allows for ad-hoc CSV uploads even when in database mode.

### 3. Modular Architecture
The codebase has been decoupled into specialized modules:
*   **`sql_utils.py`**: Handles token acquisition, connection retry logic, and SQL error handling (including ODBC Driver 18 verification).
*   **`logic_utils.py`**: Contains the core "Intelligence Layer" logic (Behavioral Taxonomy, Impact Metrics, Episode Windows) to ensure consistent analysis across all data sources.
*   **`local_utils.py`**: Manages the local file system scanning and fallback loading.
*   **`constants.py`**: Centralized configuration for SQL Server, Database, and Table names.

## Deployment & Setup

### Prerequisites
1.  **ODBC Driver 18**: Ensure the driver is installed on your machine.
2.  **Azure Authentication**: Run `az login` in your terminal to provide a security context for the `DefaultAzureCredential`.
3.  **Dependencies**: `pip install -r requirements.txt`

### Launching
Navigate to the `release_4` directory and run:
```bash
streamlit run app.py
```

---
**Released on: 2026-03-30**
**Version: 4.0.0 (Hybrid Cloud Ready)**
