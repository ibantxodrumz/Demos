# Participant Monitoring Dashboard — Release 5 (Portable)

## Overview
This is a self-contained, low-footprint version of the **Import Constraints Monitoring Dashboard**. It allows you to run deep-dive behavioral analytics on participant portfolios with minimal setup.

## Quick Start (macOS/Linux)
1. **Unzip** the folder.
2. **Open Terminal** in this folder.
3. **Run the launcher**:
   ```bash
   chmod +x run_dashboard.sh
   ./run_dashboard.sh
   ```

## Requirements
- **Python 3.9+** installed on your system.
- **ODBC Driver 18** (only if you want to use the "Live Azure SQL" feed).

## Data Sources
- **Local CSV Fallback**: The app starts in local mode using the included `inputs/alerts_data.csv`.
- **Live Azure SQL**: Toggle this in the sidebar if you have an active `az login` context and appropriate permissions.

---
**Version: 5.0.0 (Colleague Edition)**
**Total Package Size: < 1.0 MB**
