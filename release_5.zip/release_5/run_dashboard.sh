#!/bin/bash
# run_dashboard.sh - Automated launcher for Participant Monitoring Dashboard (R5)

echo "⚡ Initializing Monitoring Dashboard (Release 5)..."

# 1. Check for Python
if ! command -v python3 &> /dev/null
then
    echo "❌ Error: python3 could not be found. Please install Python 3.9+."
    exit 1
fi

# 2. Setup isolated environment
echo "📁 Setting up local environment..."
python3 -m venv .venv
source .venv/bin/activate

# 3. Handle dependencies
echo "📦 Installing requirements (this may take a minute)..."
pip install --upgrade pip &> /dev/null
pip install -r requirements.txt

# 4. Launch app
echo "🚀 Launching dashboard..."
streamlit run app.py --server.headless false
