import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

# --- Configuration ---
st.set_page_config(
    page_title="Import Constraints Dashboard",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

import plotly.io as pio
pio.templates.default = "plotly"

# Custom CSS for a more premium look
st.markdown("""
<style>
    div[data-testid="stMetricValue"] {
        font-size: 2rem;
    }
    .stApp {
        background-color: white !important;
    }
    /* Increase font size for tab headers */
    button[data-baseweb="tab"] div[data-testid="stMarkdownContainer"] p {
        font-size: 20px !important;
        font-weight: 500 !important;
    }
</style>
""", unsafe_allow_html=True)

# --- Custom Utilities ---
from utils.constants import SQL_SERVER, SQL_DATABASE, LOCAL_INPUT_DIR
from utils.sql_utils import fetch_sql_data
from utils.local_utils import scan_local_inputs, load_local_csv
from utils.logic_utils import (
    preprocess_data, 
    enrich_alerts_with_impact, 
    infer_alerts_windows, 
    parse_why
)

# ----------------- DATA ORCHESTRATION -----------------

def get_hybrid_data():
    """Manages the hybrid data source selection logic and caching."""
    st.sidebar.header("🔌 Data Architecture")
    source_mode = st.sidebar.radio(
        "Select Data Source:",
        options=["Live Azure SQL", "Local CSV Fallback"],
        help="Switch between production Azure Cloud data and local testing files."
    )
    
    raw_df = pd.DataFrame()
    
    if source_mode == "Live Azure SQL":
        st.sidebar.info(f"Connected to: {SQL_SERVER}/{SQL_DATABASE}")
        
        # Cache management
        if st.sidebar.button("🔄 Refresh Live Data"):
            st.cache_data.clear()
            st.rerun()
            
        try:
            raw_df = fetch_sql_data()
            st.sidebar.success("SQL Instance: Connected")
        except Exception as e:
            st.sidebar.error(f"SQL Connection Failed: {e}")
            st.sidebar.warning("Try running 'az login' locally or check Firewall permissions.")
            st.error(f"Cannot fetch live data. Error details: {e}")
            st.info("💡 Suggestion: Switch to 'Local CSV Fallback' mode in the sidebar.")
            st.stop()
            
    else:
        # Local Mode
        st.sidebar.info(f"Scanning folder: ./{LOCAL_INPUT_DIR}")
        
        # Option A: Manual Upload
        uploaded_file = st.sidebar.file_uploader("Upload Manual CSV", type=['csv'])
        if uploaded_file:
            raw_df = pd.read_csv(uploaded_file)
            st.sidebar.success(f"File: {uploaded_file.name}")
        else:
            # Option B: Pick from inputs folder
            local_files = scan_local_inputs()
            if local_files:
                selected_local = st.sidebar.selectbox("Choose local file:", options=local_files, format_func=lambda x: x.name)
                raw_df = load_local_csv(selected_local)
                st.sidebar.success(f"Using local file: {selected_local.name}")
            else:
                st.sidebar.warning("No CSVs found in /inputs directory.")
                st.stop()

    # Domain Preprocessing (Common across all sources)
    if not raw_df.empty:
        with st.spinner("Processing behavioural taxonomy..."):
            df = preprocess_data(raw_df)
            return df
    return pd.DataFrame()

# --- Main App Execution ---

df = get_hybrid_data()

if df.empty:
    st.info("Please provide a data source to begin.")
    st.stop()

def apply_time_drilldown(df, view_mode, selected_date=None, selected_week=None, selected_month=None):
    if view_mode == "Specific Day" and selected_date:
        mask = df['SETTLEMENT_DATE'].dt.date == selected_date
        return df[mask].copy(), 'LOCAL_DATETIME'
    elif view_mode == "Specific Week" and selected_week:
        mask = df['SETTLEMENT_DATE'].dt.strftime('%G-W%V') == selected_week
        return df[mask].copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D')
    elif view_mode == "Specific Month" and selected_month:
        mask = df['SETTLEMENT_DATE'].dt.strftime('%Y-%m') == selected_month
        return df[mask].copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D')
    else: 
        return df.copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D')

def render_time_drilldown_ui(df, key_prefix):
    view_mode = st.radio(
        "Select Time View:",
        options=["Entire Period", "Specific Month", "Specific Week", "Specific Day"],
        horizontal=True,
        key=f"view_mode_{key_prefix}"
    )
    
    selected_date = None
    selected_week = None
    selected_month = None
    
    if view_mode == "Specific Day":
        min_d = df['SETTLEMENT_DATE'].min().date()
        max_d = df['SETTLEMENT_DATE'].max().date()
        selected_date = st.date_input("Select Day to Drill Down", value=min_d, min_value=min_d, max_value=max_d, key=f"day_{key_prefix}")
    elif view_mode == "Specific Month":
        available_months = sorted(df['SETTLEMENT_DATE'].dt.strftime('%Y-%m').unique().tolist())
        selected_month = st.selectbox("Select Month to Drill Down", options=available_months, key=f"month_{key_prefix}")
    elif view_mode == "Specific Week":
        available_weeks = sorted(df['SETTLEMENT_DATE'].dt.strftime('%G-W%V').unique().tolist())
        selected_week = st.selectbox("Select Week to Drill Down", options=available_weeks, key=f"week_{key_prefix}")
        
    return view_mode, selected_date, selected_week, selected_month

# --- Sidebar Navigation & Filters ---
st.sidebar.title("⚡ Import Constraints Dashboard")
st.sidebar.markdown("Easily toggle timelines & load data.")

st.sidebar.markdown("### 📅 Time Period Selection")
min_date = df['SETTLEMENT_DATE'].min().date()
max_date = df['SETTLEMENT_DATE'].max().date()

start_date = st.sidebar.date_input("Start Date", value=min_date, min_value=min_date, max_value=max_date)
end_date = st.sidebar.date_input("End Date", value=max_date, min_value=min_date, max_value=max_date)

st.sidebar.markdown("---")

mask = (df['SETTLEMENT_DATE'].dt.date >= start_date) & (df['SETTLEMENT_DATE'].dt.date <= end_date)
filtered_df = df[mask].copy()

if filtered_df.empty:
    st.warning("No data in the selected date range.")
    st.stop()

# Basic pre-processing enrichment for ensemble data
ensemble_df_raw = filtered_df[filtered_df['BEHAVIOUR_CLASS'] == 'Constrained - ensemble'].copy()
alerts_df = enrich_alerts_with_impact(ensemble_df_raw)
alerts_sql_df = infer_alerts_windows(alerts_df)

# --- Main Dashboard Content ---

# Top level tabs
tab0, tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "Info & Context",
    "System Overview", 
    "Constrained-Ensemble SP Intelligence",
    "Constrained-Ensemble Windows",
    "BMU Deep Dive",
    "Spread Analysis",
    "Counterparty Intelligence"
])



# ----------------- TAB 0: Info & Context -----------------
with tab0:
    st.header("ℹ️ Import Constraints Monitoring — Context & Definitions")
    
    st.markdown("""
    ### Purpose of this Dashboard
    This dashboard supports Market Monitoring analysts in understanding and investigating the pricing behaviour of Balancing Mechanism Units (BMUs) behind import constraints.
    - **Context:** Import constraints are operationally necessary, creating situations where certain BMUs are more likely to be selected.
    - **Objective:** Identify when pricing behaviour under these conditions departs from the norm, and whether that departure is isolated, emerging, or persistent.
    - **Note:** This is an *intelligence tool*. It provides structured evidence to support analyst judgment, **not** to determine compliance or wrongdoing.

    ---
    ### What Data is Shown
    - All data shown relates **ONLY** to settlement periods where a BMU was behind an import constraint. 

    ---
    ### Key Behavioural Definitions
    Each constrained settlement period is classified into one of three categories:

    1. **Constrained – normal behaviour** (Baseline)
       - Pricing is similar to typical unconstrained behaviour.
       - *No* detection conditions fired.
       - Serves as an internal control group showing constraints don't inherently imply abnormal pricing.
       
    2. **Constrained – elevated signal** (Directional Change)
       - *Exactly one* detection condition fired (C1, C2, or C3).
       - These are early signals, not conclusions, indicating partial departures from baseline behaviour.
       
    3. **Constrained – ensemble** (Corroborated Signal)
       - *Two or more* detection conditions fired, satisfying the ensemble rule.
       - Represents stronger evidence and serves as the entry point for deeper investigation and window construction.

    ---
    ### Detection Conditions (C1, C2, C3)
    These conditions act as complementary, explainable checks:
    - **C1 (Self-comparison):** Is the BMU pricing significantly higher than its own typical behaviour?
    - **C2 (Absolute / Market-context):** Is the price extreme relative to market conditions and fuel-specific thresholds?
    - **C3 (Constrained vs Unconstrained):** Is the BMU pricing materially higher when constrained than when not?
    
    *A single condition firing is a signal; multiple firing indicates stronger evidence.*

    ---
    ### ⚠️ Important Notes
    - High prices alone do **not** automatically classify behaviour as ensemble.
    - Normal behaviour while constrained is explicitly expected and visible.
    - Impact metrics are severity indicators, not conclusions.
    """)
    
    with st.expander("📅 Calendar Reference: ISO Week Mapping"):
        st.markdown("Use this table to quickly check which calendar days belong to each ISO Week (e.g., `2026-W11`) shown in the dropdown filters.")
        
        # Ensure 2026 is always fully mapped, plus any other years present in the dataset
        years = {2026}
        if 'LOCAL_DATETIME' in filtered_df.columns and not filtered_df.empty:
            years.update(filtered_df['LOCAL_DATETIME'].dt.isocalendar().year.unique())
            
        all_weeks = []
        for y in sorted(list(years)):
            # Generate every single day of the year
            dts = pd.date_range(start=f'{y}-01-01', end=f'{y}-12-31', freq='D')
            week_start = dts - pd.to_timedelta(dts.weekday, unit='D')
            week_end = week_start + pd.Timedelta(days=6)
            
            y_weeks = pd.DataFrame({
                'ISO Week': dts.strftime('%G-W%V'),
                'Starts On (Monday)': week_start.strftime('%b %d, %Y'),
                'Ends On (Sunday)': week_end.strftime('%b %d, %Y')
            }).drop_duplicates()
            all_weeks.append(y_weeks)
            
        # Combine, sort explicitly so it reads intuitively
        summary_weeks = pd.concat(all_weeks).drop_duplicates('ISO Week').sort_values('ISO Week', ascending=True).reset_index(drop=True)
        st.dataframe(summary_weeks, hide_index=True, use_container_width=True)

# ----------------- TAB 1: System Overview -----------------
with tab1:
    st.header("Constrained Landscape: System Overview")
    st.markdown("Provides confidence in calibration and shows how constrained behaviour is distributed across the system.")
    
    view_mode_t1, sel_date_t1, sel_week_t1, sel_month_t1 = render_time_drilldown_ui(filtered_df, "tab1")
    t1_df, _ = apply_time_drilldown(filtered_df, view_mode_t1, sel_date_t1, sel_week_t1, sel_month_t1)
    
    if not t1_df.empty:
        st.markdown("### Top-Level Metrics")
        total_sps = len(t1_df)
        normal_count = len(t1_df[t1_df['BEHAVIOUR_CLASS'] == "Constrained - normal behaviour"])
        elevated_count = len(t1_df[t1_df['BEHAVIOUR_CLASS'] == "Constrained - elevated signal"])
        ensemble_count = len(t1_df[t1_df['BEHAVIOUR_CLASS'] == "Constrained - ensemble"])
        
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Constrained SPs", f"{total_sps:,}")
        c2.metric("Normal Behaviour", f"{normal_count:,} ({normal_count/total_sps:.1%})")
        c3.metric("Elevated Signal (1 condition fired)", f"{elevated_count:,} ({elevated_count/total_sps:.1%})")
        c4.metric("Ensemble Behaviour (2 conditions fire -> flagged)", f"{ensemble_count:,} ({ensemble_count/total_sps:.1%})")
        
        st.markdown("---")
        st.markdown("### Materiality Extension: Extreme Pricing")
        high_price_mask = (t1_df['BEHAVIOUR_CLASS'] == 'Constrained - ensemble') & (t1_df['OFFER_PRICE'] > 200)
        high_price_count = high_price_mask.sum()
        max_extreme = t1_df[high_price_mask]['OFFER_PRICE'].max() if high_price_count > 0 else 0
        avg_extreme = t1_df[high_price_mask]['OFFER_PRICE'].mean() if high_price_count > 0 else 0
        
        cm1, cm2, cm3 = st.columns(3)
        cm1.metric("Ensemble SPs > £200", f"{high_price_count:,}")
        cm2.metric("Max Extreme Price (£)", f"£{max_extreme:,.2f}" if max_extreme > 0 else "N/A")
        cm3.metric("Avg Extreme Price (£)", f"£{avg_extreme:,.2f}" if avg_extreme > 0 else "N/A")
        
        st.markdown("#### Extreme Pricing Events by BMU")
        extreme_df = t1_df[high_price_mask]
        if not extreme_df.empty:
            bmus_ex = sorted(extreme_df['BMU_ID'].unique().tolist())
            target_bmu_ex = st.selectbox("Select a BMU to view its extreme pricing events:", options=bmus_ex, key="t1_ex_bmu_select")
            bmu_ex_df = extreme_df[extreme_df['BMU_ID'] == target_bmu_ex].copy()
            
            if 'WHY' in bmu_ex_df.columns:
                parsed = bmu_ex_df['WHY'].apply(parse_why)
                bmu_ex_df['WHY_CONDITIONS'] = parsed.apply(lambda x: x[0])
                bmu_ex_df['WHY_DETAILS'] = parsed.apply(lambda x: x[1])
            else:
                bmu_ex_df['WHY_CONDITIONS'] = ''
                bmu_ex_df['WHY_DETAILS'] = ''
            
            st.dataframe(
                bmu_ex_df[['LOCAL_DATETIME', 'OFFER_PRICE', 'SPREAD', 'WHY_CONDITIONS', 'WHY_DETAILS']].sort_values(by="LOCAL_DATETIME", ascending=False),
                use_container_width=True, hide_index=True,
                column_config={
                    "LOCAL_DATETIME": st.column_config.DatetimeColumn("Date & Time", format="YYYY-MM-DD HH:mm"),
                    "OFFER_PRICE": st.column_config.NumberColumn("Offer Price (£)", format="£%.2f"),
                    "SPREAD": st.column_config.NumberColumn("Spread (£)", format="£%.2f"),
                    "WHY_CONDITIONS": "Conditions Fired",
                    "WHY_DETAILS": "Expanded Explanation"
                }
            )
        else:
            st.info("No extreme pricing events > £200 detected in this period.")
            
        st.markdown("---")
        st.markdown("### Component Profiles")
        
        st.markdown("**Condition Diagnostics (Flagged Combinations):**")
        t1_ens = t1_df[t1_df['BEHAVIOUR_CLASS'] == 'Constrained - ensemble']
        if not t1_ens.empty and 'WHY' in t1_ens.columns:
            combos = t1_ens['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else '')
            combo_counts = combos.value_counts()
        else:
            combo_counts = pd.Series(dtype=int)
            
        c_combo1, c_combo2, c_combo3 = st.columns(3)
        c_combo1.metric("C3 + C1 Fired", int(combo_counts.get('C1,C3') or combo_counts.get('C3,C1') or 0))
        c_combo2.metric("C3 + C2 Fired", int(combo_counts.get('C2,C3') or combo_counts.get('C3,C2') or 0))
        c_combo3.metric("C1 + C2 Fired", int(combo_counts.get('C1,C2') or combo_counts.get('C2,C1') or 0))
        
        if not combo_counts.empty:
            df_combo = combo_counts.reset_index()
            df_combo.columns = ['Combination', 'Count']
            fig_overlap = px.bar(df_combo, x='Combination', y='Count', title="Overlap View: Why are they flagged?", text_auto=True, color='Combination')
            fig_overlap.update_traces(textposition='outside', cliponaxis=False)
            fig_overlap.update_layout(margin=dict(t=80))
            st.plotly_chart(fig_overlap, use_container_width=True)

        
        st.markdown("**Distributions for Flagged Combinations:**")
        if not t1_ens.empty:
            t1_ens_plot = t1_ens.copy()
            t1_ens_plot['FLAGGED_COMB'] = t1_ens_plot['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else 'Unknown')
            
            col_b3, col_b4 = st.columns(2)
            with col_b3:
                fuel_dist_comb = t1_ens_plot.groupby(['FUEL_TYPE', 'FLAGGED_COMB']).size().reset_index(name='Count')
                fig_fuel_comb = px.bar(
                    fuel_dist_comb, x='FUEL_TYPE', y='Count', color='FLAGGED_COMB', 
                    title='Ensemble Combinations by Fuel Type', barmode='group',
                    text_auto=True
                )
                fig_fuel_comb.update_traces(textposition='outside', cliponaxis=False)
                fig_fuel_comb.update_layout(margin=dict(t=80))
                st.plotly_chart(fig_fuel_comb, use_container_width=True)

                
            with col_b4:
                time_dist_comb = t1_ens_plot.groupby([pd.Grouper(key='LOCAL_DATETIME', freq='W'), 'FLAGGED_COMB']).size().reset_index(name='Count')
                fig_time_comb = px.area(
                    time_dist_comb, x='LOCAL_DATETIME', y='Count', color='FLAGGED_COMB', 
                    title='Ensemble Combinations over Time'
                )
                st.plotly_chart(fig_time_comb, use_container_width=True)
        else:
            st.info("No ensemble combinations detected to plot.")

        st.markdown("**Condition Diagnostics (Individual Counts):**")
        cd_col1, cd_col2, cd_col3 = st.columns(3)
        cd_col1.metric("C1 Fired (Historical Behavior)", int(t1_df["COND_1"].sum()))
        cd_col2.metric("C2 Fired (Fuel Threshold)", int(t1_df["COND_2"].sum()))
        cd_col3.metric("C3 Fired (Constrained vs Uncon)", int(t1_df["COND_3"].sum()))
        
        # Supporting breakdowns
        st.markdown("**Distributions by Behaviour Class:**")
        col_b1, col_b2 = st.columns(2)
        with col_b1:
            fuel_dist = t1_df.groupby(['FUEL_TYPE', 'BEHAVIOUR_CLASS']).size().reset_index(name='Count')
            fig_fuel = px.bar(
                fuel_dist, x='FUEL_TYPE', y='Count', color='BEHAVIOUR_CLASS', 
                title='Distribution by Fuel Type', barmode='group',
                text_auto=True,
                color_discrete_map={
                    "Constrained - normal behaviour": "grey", 
                    "Constrained - elevated signal": "orange",
                    "Constrained - ensemble": "red"
                }
            )
            fig_fuel.update_traces(textposition='outside')
            st.plotly_chart(fig_fuel, use_container_width=True)
            
        with col_b2:
            time_dist = t1_df.groupby([pd.Grouper(key='LOCAL_DATETIME', freq='W'), 'BEHAVIOUR_CLASS']).size().reset_index(name='Count')
            fig_time = px.area(
                time_dist, x='LOCAL_DATETIME', y='Count', color='BEHAVIOUR_CLASS', 
                title='Distribution over Time',
                color_discrete_map={
                    "Constrained - normal behaviour": "grey", 
                    "Constrained - elevated signal": "orange",
                    "Constrained - ensemble": "red"
                }
            )
            st.plotly_chart(fig_time, use_container_width=True)

        if 'CONSTRAINT_GROUP' in t1_df.columns:
            st.markdown("**Concentration by Constraint Group:**")
            cg_dist = t1_df.groupby(['CONSTRAINT_GROUP', 'BEHAVIOUR_CLASS']).size().reset_index(name='Count')
            fig_cg = px.bar(
                cg_dist, x='CONSTRAINT_GROUP', y='Count', color='BEHAVIOUR_CLASS',
                title='System Concentration by Constraint Group', barmode='group', text_auto=True,
                color_discrete_map={
                    "Constrained - normal behaviour": "grey", 
                    "Constrained - elevated signal": "orange", 
                    "Constrained - ensemble": "red"
                }
            )
            fig_cg.update_traces(textposition='outside', cliponaxis=False)
            fig_cg.update_layout(margin=dict(t=80))
            st.plotly_chart(fig_cg, use_container_width=True)


        st.markdown("---")
        st.markdown("### BMU Summary Profiling")


        bmus_t1 = sorted(t1_df['BMU_ID'].dropna().unique().tolist())
        target_bmu_t1 = st.selectbox("Select a BMU for Profiling:", options=bmus_t1, key="t1_bmu_select")
        
        bmu_t1_df = t1_df[t1_df['BMU_ID'] == target_bmu_t1]
        if not bmu_t1_df.empty:
            bmu_total_sps = len(bmu_t1_df)
            bmu_normal = (bmu_t1_df['BEHAVIOUR_CLASS'] == "Constrained - normal behaviour").sum()
            bmu_elevated = (bmu_t1_df['BEHAVIOUR_CLASS'] == "Constrained - elevated signal").sum()
            bmu_ensemble = (bmu_t1_df['BEHAVIOUR_CLASS'] == "Constrained - ensemble").sum()
            bmu_ens_gt_200 = ((bmu_t1_df['BEHAVIOUR_CLASS'] == 'Constrained - ensemble') & (bmu_t1_df['OFFER_PRICE'] > 200)).sum()
            
            bmu_summary = pd.DataFrame([{
                'BMU_ID': target_bmu_t1,
                'Total_Constrained_SPs': bmu_total_sps,
                '% Normal': f"{(bmu_normal / bmu_total_sps * 100):.1f}%",
                '% Elevated': f"{(bmu_elevated / bmu_total_sps * 100):.1f}%",
                '% Ensemble': f"{(bmu_ensemble / bmu_total_sps * 100):.1f}%",
                'Ensemble_SPs': bmu_ensemble,
                'Ensemble_GT_200': bmu_ens_gt_200,
            }])
            
            st.dataframe(bmu_summary, use_container_width=True, hide_index=True)
        else:
            st.info("No data for the selected BMU.")
    else:
        st.info("No data available for the selected time period.")

# ----------------- TAB 2: Constrained-Ensemble SP Intelligence -----------------
with tab2:
    st.header("Constrained-Ensemble SP Intelligence")
    st.markdown("Explains why individual settlement periods were flagged and how severe they are.")
    
    view_mode_t2, sel_date_t2, sel_week_t2, sel_month_t2 = render_time_drilldown_ui(filtered_df, "tab2")
    t2_df_raw, _ = apply_time_drilldown(alerts_df, view_mode_t2, sel_date_t2, sel_week_t2, sel_month_t2)

    st.markdown("These are the alerts derived from the canonical dataset that have passed the `ENSEMBLE` by satisfying at least 2 conditions.")
    ORIGINAL_ALERT_COLS = [
        'SETTLEMENT_DATE', 'SETTLEMENT_PERIOD', 'GMT_FROM', 'LOCAL_DATETIME',
        'COUNTERPARTY', 'BMU_ID', 'FUEL_TYPE', 'OFFER_PRICE', 'OFFER_VOLUME_MWH',
        'SPREAD', 'COND_1', 'COND_2', 'COND_3', 'N_CONDITIONS_TRUE', 'ENSEMBLE', 'WHY'
    ]
    orig_display_cols = [c for c in ORIGINAL_ALERT_COLS if c in t2_df_raw.columns]
    raw_alerts = t2_df_raw[t2_df_raw['WHY'].notna()]
    
    st.metric("Total Constrained-Ensemble Alerts (filtered)", len(raw_alerts))
    if not raw_alerts.empty:
        st.dataframe(
            raw_alerts[orig_display_cols].sort_values(by="LOCAL_DATETIME", ascending=False),
            use_container_width=True,
            hide_index=True
        )

    st.markdown("---")
    st.subheader("🔍 Analyst Intelligence")
    
    # Allow filtering by BMU or Fuel Type
    fcol1, fcol2 = st.columns(2)
    with fcol1:
        fuels_t2 = sorted(t2_df_raw['FUEL_TYPE'].dropna().unique().tolist()) if not t2_df_raw.empty else []
        sel_fuels_t2 = st.multiselect("Filter by Fuel Type:", options=fuels_t2, default=fuels_t2, key="t2_fuel")
    with fcol2:
        bmus_t2 = sorted(t2_df_raw['BMU_ID'].dropna().unique().tolist()) if not t2_df_raw.empty else []
        sel_bmus_t2 = st.multiselect("Filter by BMU (leave blank for all):", options=bmus_t2, default=[], key="t2_bmu")
        
    t2_df = t2_df_raw.copy()
    if sel_fuels_t2:
        t2_df = t2_df[t2_df['FUEL_TYPE'].isin(sel_fuels_t2)]
    if sel_bmus_t2:
        t2_df = t2_df[t2_df['BMU_ID'].isin(sel_bmus_t2)]
        
    if not t2_df.empty:
        st.markdown("### BMU-Level Aggregation")
        if 'WHY' in t2_df.columns:
            t2_df['Conditions_Parsed'] = t2_df['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else '')
        else:
            t2_df['Conditions_Parsed'] = ''

        bmu_agg = t2_df.groupby('BMU_ID').apply(lambda x: pd.Series({
            'Ensemble_SPs': len(x),
            'C1_Fired': x['COND_1'].sum(),
            'C2_Fired': x['COND_2'].sum(),
            'C3_Fired': x['COND_3'].sum(),
            'GT_150': (x['OFFER_PRICE'] > 150).sum(),
            'GT_200': (x['OFFER_PRICE'] > 200).sum(),
            'GT_300': (x['OFFER_PRICE'] > 300).sum()
        })).reset_index()
        
        # Pairwise condition pivot
        pair_counts = pd.crosstab(t2_df['BMU_ID'], t2_df['Conditions_Parsed']).reset_index()
        bmu_agg_merged = pd.merge(bmu_agg, pair_counts, on='BMU_ID', how='left').fillna(0)
        
        st.dataframe(bmu_agg_merged.sort_values(by="Ensemble_SPs", ascending=False), use_container_width=True, hide_index=True)
        
        st.markdown("### SP-Level Detail")
        sp_cols = ['LOCAL_DATETIME', 'BMU_ID', 'OFFER_PRICE', 'REFERENCE_PRICE', 'WHY_CONDITIONS', 'IMPACT_SP']
        available_cols = [c for c in sp_cols if c in t2_df.columns]
        
        st.dataframe(
            t2_df[available_cols].sort_values(by="LOCAL_DATETIME", ascending=False),
            use_container_width=True,
            hide_index=True,
            column_config={
                "LOCAL_DATETIME": st.column_config.DatetimeColumn("Date & Time", format="YYYY-MM-DD HH:mm"),
                "OFFER_PRICE": st.column_config.NumberColumn("Offer (£)", format="£%.2f"),
                "REFERENCE_PRICE": st.column_config.NumberColumn("Ref (£)", format="£%.2f"),
                "WHY_CONDITIONS": "Conditions Fired",
                "IMPACT_SP": st.column_config.NumberColumn("Impact per SP (£)", format="£%.0f")
            }
        )
        
    else:
        st.info("No ensemble SPs match the current filters.")

# ----------------- TAB 3: Constrained-Ensemble Windows -----------------
with tab3:
    st.header("Constrained-Ensemble Windows (Episodes)")
    st.markdown("Determines whether ensemble behaviour is sporadic or persistent and assesses significance.")
    
    view_mode_t3, sel_date_t3, sel_week_t3, sel_month_t3 = render_time_drilldown_ui(filtered_df, "tab3")
    t3_df = alerts_sql_df.copy()
    if not t3_df.empty:
        if view_mode_t3 == "Specific Day" and sel_date_t3:
            t3_df = t3_df[t3_df['START_LOCAL'].dt.date == sel_date_t3]
        elif view_mode_t3 == "Specific Month" and sel_month_t3:
            t3_df = t3_df[t3_df['START_LOCAL'].dt.strftime('%Y-%m') == sel_month_t3]
        elif view_mode_t3 == "Specific Week" and sel_week_t3:
            t3_df = t3_df[t3_df['START_LOCAL'].dt.strftime('%G-W%V') == sel_week_t3]

    if not t3_df.empty:
        st.markdown("### High-Level Summary")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Constraint Windows", len(t3_df))
        col2.metric("Unique BMUs Involved", t3_df['BMU_ID'].nunique())
        col3.metric("Total Estimated Impact", f"£{t3_df['IMPACT_WINDOW'].sum():,.0f}")
        
        bmu_summary = t3_df.groupby('BMU_ID').agg(
            Episodes=('DURATION_MIN', 'count'),
            Cumm_Duration=('DURATION_MIN', 'sum'),
            Max_Duration=('DURATION_MIN', 'max'),
            Total_Impact=('IMPACT_WINDOW', 'sum')
        ).reset_index().sort_values('Total_Impact', ascending=False)
        
        st.dataframe(
            bmu_summary,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Episodes": "Window Count",
                "Cumm_Duration": "Total Duration (min)",
                "Max_Duration": "Max Duration (min)",
                "Total_Impact": st.column_config.NumberColumn("Aggregated Impact (£)", format="£%.0f")
            }
        )
                
        st.markdown("### Supporting Views (Overall Summary)")
        c_v1, c_v2, c_v3 = st.columns(3)
        with c_v1:
            dur_counts = t3_df['DURATION_MIN'].value_counts().reset_index()
            dur_counts.columns = ['DURATION_MIN', 'Count']
            max_dur = int(dur_counts['DURATION_MIN'].max())
            all_durs = pd.DataFrame({'DURATION_MIN': range(30, max_dur + 30, 30)})
            dur_counts = all_durs.merge(dur_counts, on='DURATION_MIN', how='left').fillna(0)
            
            fig_dur = px.bar(dur_counts, x="DURATION_MIN", y="Count", title="Distribution of Window Durations", text_auto=True, color_discrete_sequence=['#00B4D8'])
            fig_dur.update_traces(textposition='outside', texttemplate='%{y}', cliponaxis=False)
            fig_dur.update_layout(margin=dict(t=80), xaxis_title="Duration (min)", yaxis_title="Count")
            fig_dur.update_xaxes(tickmode='array', tickvals=dur_counts['DURATION_MIN'])
            st.plotly_chart(fig_dur, use_container_width=True)

            
        with c_v2:
            repeat_w = t3_df.groupby('BMU_ID').size().reset_index(name='Window_Count').sort_values('Window_Count', ascending=False)
            fig_rep = px.bar(repeat_w.head(10), x='BMU_ID', y='Window_Count', title="Top 10 Repeat Windows by BMU", text_auto=True, color_discrete_sequence=['#00B4D8'])
            fig_rep.update_traces(textposition='outside', cliponaxis=False)
            fig_rep.update_layout(margin=dict(t=80))
            st.plotly_chart(fig_rep, use_container_width=True)

            
        with c_v3:
            fuel_w = t3_df.groupby('FUEL_TYPE').size().reset_index(name='Window_Count').sort_values('Window_Count', ascending=False)
            figs_fuel = px.bar(fuel_w, x='FUEL_TYPE', y='Window_Count', title="Concentration by Fuel", text_auto=True, color_discrete_sequence=['#00B4D8'])
            figs_fuel.update_traces(textposition='outside', cliponaxis=False)
            figs_fuel.update_layout(margin=dict(t=80))
            st.plotly_chart(figs_fuel, use_container_width=True)

            
        st.markdown("**Window Priority Quadrant (Persistence vs Significance):**")
        q_bmus = sorted(t3_df['BMU_ID'].unique().tolist())
        target_q_bmu = st.selectbox("Select BMU to isolate in Quadrant:", options=["All"] + q_bmus, key="t3_quad_bmu")
        
        plot_t3 = t3_df.copy()
        if target_q_bmu != "All":
            plot_t3 = plot_t3[plot_t3['BMU_ID'] == target_q_bmu]

        fig_quad = px.scatter(
            plot_t3, x='DURATION_MIN', y='IMPACT_WINDOW', color='BMU_ID', size='COUNT_SP',
            title=f"Episode Priority (Persistence vs Impact) - {target_q_bmu}",
            labels={'DURATION_MIN': 'Duration (min)', 'IMPACT_WINDOW': 'Total Window Impact (£)', 'COUNT_SP': 'SP Count'},
            hover_data=['BMU_ID', 'START_LOCAL']
        )
        st.plotly_chart(fig_quad, use_container_width=True)
            
        st.markdown("### Window-Level Metrics & Impact")
        
        # Display Window Table
        disp_cols = [
            'BMU_ID', 'START_LOCAL', 'END_LOCAL', 'DURATION_MIN', 'COUNT_SP', 
            'AVG_SPREAD', 'MAX_SPREAD', 'IMPACT_WINDOW'
        ]
        if 'CONSTRAINT_GROUP' in t3_df.columns:
            disp_cols.insert(1, 'CONSTRAINT_GROUP')
            
        disp_df = t3_df[disp_cols].sort_values('IMPACT_WINDOW', ascending=False).reset_index(drop=True)
        win_selection = st.dataframe(
            disp_df,
            use_container_width=True,
            hide_index=True,
            on_select="rerun",
            selection_mode="single-row",
            column_config={
                "START_LOCAL": st.column_config.DatetimeColumn("Start", format="YYYY-MM-DD HH:mm"),
                "END_LOCAL": st.column_config.DatetimeColumn("End", format="YYYY-MM-DD HH:mm"),
                "DURATION_MIN": "Duration (min)",
                "COUNT_SP": "SP Count",
                "AVG_SPREAD": st.column_config.NumberColumn("Mean Spread (£)", format="£%.2f"),
                "MAX_SPREAD": st.column_config.NumberColumn("Max Spread (£)", format="£%.2f"),
            }
        )
        
        with st.expander("ℹ️ How is Window Impact Calculated?"):
            st.info("""
            **Impact Calculation Logic:**
            The potential extra cost of a window is dynamically calculated against the specific thresholds breached by each condition during its settlement periods:
            - **C1 (Spread Outlier):** $(Spread - Unconstrained\\_Median\\_Spread) \\times Volume$
            - **C2 (Fuel Value):** $(Offer\\_Price - Fuel\\_Threshold) \\times Volume$
            - **C3 (Materiality):** $(Spread - (Unconstrained\\_Median\\_Spread + 30)) \\times Volume$
            
            - **SP Impact:** The average excess value among the breached conditions for that SP.
            - **Total Window Impact:** $\\sum IMPACT\\_SP$
            
            This measures realistic estimated impact by scaling the cost against the baseline thresholds and taking the mean across the specific conditions that fired.
            """)
        
        selected_rows = win_selection.selection.rows
        if len(selected_rows) > 0:
            selected_idx = selected_rows[0]
            selected_row = disp_df.iloc[selected_idx]
            selected_bmu = selected_row['BMU_ID']
            start_time = selected_row['START_LOCAL']
            end_time = selected_row['END_LOCAL']
            
            st.markdown(f"### Specific Info: Window for {selected_bmu}")
            st.info(f"**Period:** {start_time.strftime('%Y-%m-%d %H:%M')} to {end_time.strftime('%Y-%m-%d %H:%M')}  |  **Duration:** {selected_row['DURATION_MIN']} mins  |  **Impact:** £{selected_row['IMPACT_WINDOW']:,.0f}")
            
            # Show underlying SPs for this window
            if 'alerts_df' in globals() or 'alerts_df' in locals():
                window_sps = alerts_df[(alerts_df['BMU_ID'] == selected_bmu) & (alerts_df['LOCAL_DATETIME'] >= start_time) & (alerts_df['LOCAL_DATETIME'] < end_time)]
                if not window_sps.empty:
                    st.markdown(f"#### Settlement Periods in this Window")
                    st_cols = ['LOCAL_DATETIME', 'OFFER_PRICE', 'REFERENCE_PRICE', 'SPREAD', 'WHY_CONDITIONS', 'IMPACT_SP']
                    avail_cols = [c for c in st_cols if c in window_sps.columns]
                    st.dataframe(
                        window_sps[avail_cols].sort_values("LOCAL_DATETIME"), 
                        hide_index=True, 
                        use_container_width=True,
                        column_config={
                            "LOCAL_DATETIME": st.column_config.DatetimeColumn("Date & Time", format="YYYY-MM-DD HH:mm"),
                            "OFFER_PRICE": st.column_config.NumberColumn("Offer (£)", format="£%.2f"),
                            "REFERENCE_PRICE": st.column_config.NumberColumn("Ref (£)", format="£%.2f"),
                            "SPREAD": st.column_config.NumberColumn("Spread (£)", format="£%.2f"),
                            "IMPACT_SP": st.column_config.NumberColumn("Estimated Impact (£)", format="£%.0f")
                        }
                    )
                else:
                    st.warning("Could not find underlying settlement periods for this window.")
            
    else:
        st.info("No ensemble windows detected for this time range.")

# ----------------- TAB 4: BMU Deep Dive -----------------
with tab4:
    st.header("BMU Deep Dive")
    st.markdown("Full behavioural narrative for a single BMU behind constraints.")
    
    # 1. Selection & Time Filters
    bmus_t4 = sorted(filtered_df['BMU_ID'].unique().tolist())
    target_bmu = st.selectbox("Select a BMU to Track:", options=bmus_t4, key="t4_bmu_select")
    
    view_mode_t4, sel_date_t4, sel_week_t4, sel_month_t4 = render_time_drilldown_ui(filtered_df, "tab4")
    
    # Apply filters
    bmu_all_raw, _ = apply_time_drilldown(filtered_df, view_mode_t4, sel_date_t4, sel_week_t4, sel_month_t4)
    bmu_all = bmu_all_raw[bmu_all_raw['BMU_ID'] == target_bmu].copy()
    
    bmu_ens_raw, _ = apply_time_drilldown(alerts_df, view_mode_t4, sel_date_t4, sel_week_t4, sel_month_t4)
    bmu_ens = bmu_ens_raw[bmu_ens_raw['BMU_ID'] == target_bmu].copy()
    
    bmu_win = alerts_sql_df[alerts_sql_df['BMU_ID'] == target_bmu].copy()
    if not bmu_win.empty:
        if view_mode_t4 == "Specific Day" and sel_date_t4:
            bmu_win = bmu_win[bmu_win['START_LOCAL'].dt.date == sel_date_t4]
        elif view_mode_t4 == "Specific Month" and sel_month_t4:
            bmu_win = bmu_win[bmu_win['START_LOCAL'].dt.strftime('%Y-%m') == sel_month_t4]
        elif view_mode_t4 == "Specific Week" and sel_week_t4:
            bmu_win = bmu_win[bmu_win['START_LOCAL'].dt.strftime('%G-W%V') == sel_week_t4]

    if not bmu_all.empty:
        st.markdown("### Top-Level Metrics")
        total_sps = len(bmu_all)
        normal_count = len(bmu_all[bmu_all['BEHAVIOUR_CLASS'] == "Constrained - normal behaviour"])
        elevated_count = len(bmu_all[bmu_all['BEHAVIOUR_CLASS'] == "Constrained - elevated signal"])
        ensemble_count = len(bmu_all[bmu_all['BEHAVIOUR_CLASS'] == "Constrained - ensemble"])
        
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Total Constrained SPs", f"{total_sps:,}")
        c2.metric("Normal Behaviour", f"{normal_count:,} ({normal_count/total_sps:.1%})" if total_sps>0 else "0 (0%)")
        c3.metric("Elevated Signal (1 condition fired)", f"{elevated_count:,} ({elevated_count/total_sps:.1%})" if total_sps>0 else "0 (0%)")
        c4.metric("Ensemble Behaviour (2 conditions fire -> flagged)", f"{ensemble_count:,} ({ensemble_count/total_sps:.1%})" if total_sps>0 else "0 (0%)")
        
        total_impact = bmu_ens['IMPACT_SP'].sum() if not bmu_ens.empty and 'IMPACT_SP' in bmu_ens.columns else 0
        c5.metric("Total Aggregated Impact (£)", f"£{total_impact:,.0f}")
        
        # New: Intensity Metric
        impact_density = total_impact / ensemble_count if ensemble_count > 0 else 0
        st.markdown(f"**Impact Intensity:** On average, each flagged ensemble period for this BMU represents an estimated cost of **£{impact_density:,.0f}**.")
        
        st.markdown("---")
        st.markdown("### Materiality Extension: Extreme Pricing")
        high_price_mask = (bmu_all['BEHAVIOUR_CLASS'] == 'Constrained - ensemble') & (bmu_all['OFFER_PRICE'] > 200)
        high_price_count = high_price_mask.sum()
        max_extreme = bmu_all[high_price_mask]['OFFER_PRICE'].max() if high_price_count > 0 else 0
        avg_extreme = bmu_all[high_price_mask]['OFFER_PRICE'].mean() if high_price_count > 0 else 0
        
        cm1, cm2, cm3 = st.columns(3)
        cm1.metric("Ensemble SPs > £200", f"{high_price_count:,}")
        cm2.metric("Max Extreme Price (£)", f"£{max_extreme:,.2f}" if max_extreme > 0 else "N/A")
        cm3.metric("Avg Extreme Price (£)", f"£{avg_extreme:,.2f}" if avg_extreme > 0 else "N/A")
        
        st.markdown("---")
        st.markdown("### Component Profiles")
        
        st.markdown("**1. Behaviour Mix:**")
        mix_counts = bmu_all['BEHAVIOUR_CLASS'].value_counts().reset_index()
        mix_counts.columns = ['Behaviour', 'Count']
        total_mix = mix_counts['Count'].sum()
        mix_counts['Percent'] = (mix_counts['Count'] / total_mix * 100).round(1).astype(str) + '%' if total_mix > 0 else '0%'
        
        fig_mix = px.bar(
            mix_counts, x='Behaviour', y='Count', color='Behaviour', text='Percent',
            title=f"Behaviour Mix for {target_bmu}",
            color_discrete_map={
                "Constrained - normal behaviour": "grey", 
                "Constrained - elevated signal": "orange",
                "Constrained - ensemble": "red"
            }
        )
        fig_mix.update_traces(textposition='outside', cliponaxis=False)
        fig_mix.update_layout(margin=dict(t=80))
        st.plotly_chart(fig_mix, use_container_width=True)


        st.markdown("**2. Condition Firing Mix:**")
        col_m1, col_m2 = st.columns(2)
        with col_m1:
            if not bmu_ens.empty and 'WHY' in bmu_ens.columns:
                combos = bmu_ens['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else '')
                combo_counts = combos.value_counts().reset_index()
                combo_counts.columns = ['Combination', 'Count']
                tot_c = combo_counts['Count'].sum()
                combo_counts['Percent'] = (combo_counts['Count'] / tot_c * 100).round(1).astype(str) + '%' if tot_c > 0 else '0%'
                
                fig_combo = px.bar(combo_counts, x='Combination', y='Count', color='Combination', text='Percent', title="Flagged Combinations (Tuples)")
                fig_combo.update_traces(textposition='outside', cliponaxis=False)
                fig_combo.update_layout(margin=dict(t=80))
                st.plotly_chart(fig_combo, use_container_width=True)

            else:
                st.info("No ensemble flagging to plot combinations.")

        with col_m2:
            indiv_counts = pd.DataFrame({
                'Condition': ['C1 (Historical)', 'C2 (Threshold)', 'C3 (vs Uncon)'],
                'Count': [bmu_all['COND_1'].sum(), bmu_all['COND_2'].sum(), bmu_all['COND_3'].sum()]
            })
            tot_i = indiv_counts['Count'].sum()
            indiv_counts['Percent'] = (indiv_counts['Count'] / tot_i * 100).round(1).astype(str) + '%' if tot_i > 0 else '0%'
            
            fig_indiv = px.bar(indiv_counts, x='Condition', y='Count', color='Condition', text='Percent', title="Individual Condition Firing", color_discrete_sequence=['#00B4D8', '#FFB703', '#E5383B'])
            fig_indiv.update_traces(textposition='outside', cliponaxis=False)
            fig_indiv.update_layout(margin=dict(t=80))
            st.plotly_chart(fig_indiv, use_container_width=True)


        st.markdown("---")
        st.subheader("Constrained-Ensemble SP Intelligence")
        if not bmu_ens.empty:
            st.dataframe(
                bmu_ens[['LOCAL_DATETIME', 'OFFER_PRICE', 'SPREAD', 'WHY_CONDITIONS', 'WHY_DETAILS', 'IMPACT_SP']].sort_values('LOCAL_DATETIME', ascending=False),
                use_container_width=True, hide_index=True,
                column_config={
                    "IMPACT_SP": st.column_config.NumberColumn("Estimated Impact (£)", format="£%.0f")
                }
            )
            with st.expander("ℹ️ How is Impact Calculated?"):
                st.info("""
                **Impact Calculation Logic:**
                The potential extra cost to the system is calculated against the specific threshold of the condition that fired:
                - **C1 (Spread Outlier):** $(Spread - Unconstrained\\_Median\\_Spread) \\times Volume$
                - **C2 (Fuel Value):** $(Offer\\_Price - Fuel\\_Threshold) \\times Volume$
                - **C3 (Materiality):** $(Spread - (Unconstrained\\_Median\\_Spread + 30)) \\times Volume$
                
                The dashboard takes the average excess value among all actively breached conditions. High impact means prices deviated severely on average from the thresholds that triggered the investigation.
                """)
        else:
            st.info("No ensemble events for this BMU.")
            
        st.markdown("---")
        st.subheader("Constrained-Ensemble Windows")
        if not bmu_win.empty:
            w_cols = ['START_LOCAL', 'END_LOCAL', 'DURATION_MIN', 'COUNT_SP', 'AVG_SPREAD', 'IMPACT_WINDOW']
            st.dataframe(
                bmu_win[w_cols].sort_values('START_LOCAL', ascending=False),
                use_container_width=True, hide_index=True,
                column_config={
                    "IMPACT_WINDOW": st.column_config.NumberColumn("Window Impact (£)", format="£%.0f")
                }
            )
            st.metric("Total Cumulative Window Impact", f"£{bmu_win['IMPACT_WINDOW'].sum():,.0f}")
        else:
            st.info("No ensemble windows for this BMU.")
            
    else:
        st.info("No data available for this BMU.")

# ----------------- TAB 5: Spread Analysis -----------------
with tab5:
    st.header("💡 Spread Analysis")
    st.markdown("Distribution of spreads across different fuel types and temporal spread patterns.")

    view_mode_t8, sel_date_t8, sel_week_t8, sel_month_t8 = render_time_drilldown_ui(filtered_df, "tab8")
    drill_df, global_grouper = apply_time_drilldown(filtered_df, view_mode_t8, sel_date_t8, sel_week_t8, sel_month_t8)
    
    st.markdown("---")
    # Added Behavior filter for context comparison
    behav_options = sorted(drill_df['BEHAVIOUR_CLASS'].unique().tolist()) if not drill_df.empty else []
    sel_behav = st.multiselect("Filter by Behavior Class:", options=behav_options, default=behav_options, key="t8_behav")
    if sel_behav:
        drill_df = drill_df[drill_df['BEHAVIOUR_CLASS'].isin(sel_behav)]
    
    st.subheader("Median Spread by Weekday × Hour (GMT)")
    if not drill_df.empty and 'GMT_FROM' in drill_df.columns and 'SPREAD' in drill_df.columns:
        hm_df = drill_df[["GMT_FROM", "SPREAD"]].dropna().copy()
        if not hm_df.empty:
            hm_df["weekday"] = hm_df["GMT_FROM"].dt.day_name()
            hm_df["hour"] = hm_df["GMT_FROM"].dt.hour
            
            weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            
            pivot_med = hm_df.pivot_table(
                index="weekday", columns="hour", values="SPREAD", aggfunc="median"
            ).reindex(index=weekday_order)
            
            fig_hm = px.imshow(
                pivot_med,
                labels=dict(x="Hour (GMT)", y="Weekday", color="Median Spread (£/MWh)"),
                x=pivot_med.columns,
                y=pivot_med.index,
                color_continuous_scale="viridis_r",
                aspect="auto"
            )
            fig_hm.update_layout(
                paper_bgcolor="#F0F2F6",
                plot_bgcolor="#F0F2F6",
                margin=dict(t=20, b=20)
            )
            st.plotly_chart(fig_hm, use_container_width=True)
        else:
            st.info("No valid GMT_FROM and SPREAD data available.")
    else:
        st.info("GMT_FROM or SPREAD column is missing.")

    st.markdown("---")

    st.subheader("Spread Distributions by Fuel Type & Behavior")
    if not drill_df.empty and 'SPREAD' in drill_df.columns and 'FUEL_TYPE' in drill_df.columns:
        ridge_df = drill_df[["FUEL_TYPE", "SPREAD", "BEHAVIOUR_CLASS"]].dropna()
        if not ridge_df.empty:
            # Sort fuels by median spread
            fuel_order = ridge_df.groupby("FUEL_TYPE")["SPREAD"].median().sort_values(ascending=False).index.tolist()
            
            fig_ridge = px.violin(
                ridge_df, x='SPREAD', y='FUEL_TYPE', color='BEHAVIOUR_CLASS',
                orientation='h', points=False, box=True,
                color_discrete_map={
                    "Constrained - normal behaviour": "grey", 
                    "Constrained - elevated signal": "orange", 
                    "Constrained - ensemble": "red"
                },
                category_orders={"FUEL_TYPE": fuel_order},
                title="Spread Distribution Segregated by Behavior"
            )
            
            fig_ridge.update_layout(
                paper_bgcolor="#F0F2F6", 
                plot_bgcolor="#F0F2F6",
                xaxis_title="Spread (£/MWh)",
                xaxis=dict(range=[0, min(300, ridge_df["SPREAD"].max() + 20)]),
                legend_title="Behavior Class"
            )
            st.plotly_chart(fig_ridge, use_container_width=True)
        else:
            st.info("No valid SPREAD and FUEL_TYPE data available.")
    else:
        st.info("SPREAD or FUEL_TYPE column is missing.")

    st.subheader("C3: Spread by Fuel Type (Constrained vs Unconstrained)")
    if not drill_df.empty and 'FUEL_TYPE' in drill_df.columns:
        # Mini Filters for this chart
        mc1, mc2 = st.columns(2)
        with mc1:
            all_fuels_t5 = sorted(drill_df['FUEL_TYPE'].unique().tolist())
            sel_fuels_t5 = st.multiselect("Filter Fuel Types for this chart:", options=all_fuels_t5, default=all_fuels_t5, key="t5_fuel_sub")
        with mc2:
            display_modes = ["Both (Comparison)", "Constrained Only", "Unconstrained Only"]
            sel_mode = st.radio("Display Mode:", options=display_modes, horizontal=True, key="t5_mode_sub")

        chart_df = drill_df[drill_df['FUEL_TYPE'].isin(sel_fuels_t5)].copy()
        
        fuel_spread_comp = chart_df.groupby('FUEL_TYPE').agg({
            'SPREAD': 'median',
            'MED_SPREAD_UNCON': 'median'
        }).reset_index()
        
        fuel_spread_comp = fuel_spread_comp.melt(id_vars='FUEL_TYPE', var_name='Context', value_name='Median Spread')
        fuel_spread_comp['Context'] = fuel_spread_comp['Context'].map({
            'SPREAD': 'Constrained (Actual)',
            'MED_SPREAD_UNCON': 'Unconstrained (Typical)'
        })
        
        # Filter based on mode
        if sel_mode == "Constrained Only":
            fuel_spread_comp = fuel_spread_comp[fuel_spread_comp['Context'] == 'Constrained (Actual)']
        elif sel_mode == "Unconstrained Only":
            fuel_spread_comp = fuel_spread_comp[fuel_spread_comp['Context'] == 'Unconstrained (Typical)']

        fig_fuel_comp = px.bar(
            fuel_spread_comp, x='FUEL_TYPE', y='Median Spread', color='Context',
            title="C3 Comparison: Median Spreads by Fuel Type",
            barmode='group',
            color_discrete_map={
                'Constrained (Actual)': '#E5383B',
                'Unconstrained (Typical)': '#A8A8A8'
            },
            height=500
        )
        fig_fuel_comp.update_layout(
            paper_bgcolor="#F0F2F6",
            plot_bgcolor="#F0F2F6",
            xaxis_title="Fuel Type",
            yaxis_title="Median Spread (£/MWh)",
            margin=dict(t=80)
        )
        fig_fuel_comp.update_traces(cliponaxis=False)
        st.plotly_chart(fig_fuel_comp, use_container_width=True)

        st.markdown("---")
        st.subheader("C3: Individual BMU Drill-down by Fuel")
        # Mini Filters for drill-down
        mb1, mb2 = st.columns(2)
        with mb1:
            all_fuels_break = sorted(drill_df['FUEL_TYPE'].unique().tolist())
            sel_fuel_break = st.selectbox("Select Fuel Type to see all units:", options=all_fuels_break, key="t5_fuel_drill")
        with mb2:
            display_modes_bmu = ["Both (Comparison)", "Constrained Only", "Unconstrained Only"]
            sel_mode_bmu = st.radio("Display Mode (Units):", options=display_modes_bmu, horizontal=True, key="t5_mode_bmu")

        bmu_chart_df = drill_df[drill_df['FUEL_TYPE'] == sel_fuel_break].copy()
        
        if not bmu_chart_df.empty:
            bmu_comp_df = bmu_chart_df.groupby('BMU_ID').agg({
                'SPREAD': 'median',
                'MED_SPREAD_UNCON': 'median'
            }).reset_index()
            
            bmu_comp_df = bmu_comp_df.melt(id_vars='BMU_ID', var_name='Context', value_name='Median Spread')
            bmu_comp_df['Context'] = bmu_comp_df['Context'].map({
                'SPREAD': 'Constrained (Actual)',
                'MED_SPREAD_UNCON': 'Unconstrained (Typical)'
            })
            
            if sel_mode_bmu == "Constrained Only":
                bmu_comp_df = bmu_comp_df[bmu_comp_df['Context'] == 'Constrained (Actual)']
            elif sel_mode_bmu == "Unconstrained Only":
                bmu_comp_df = bmu_comp_df[bmu_comp_df['Context'] == 'Unconstrained (Typical)']

            fig_bmu_drill = px.bar(
                bmu_comp_df, x='BMU_ID', y='Median Spread', color='Context',
                title=f"C3 Comparison for {sel_fuel_break} Unit Portfolio",
                barmode='group',
                color_discrete_map={
                    'Constrained (Actual)': '#E5383B',
                    'Unconstrained (Typical)': '#A8A8A8'
                },
                height=500
            )
            fig_bmu_drill.update_layout(
                paper_bgcolor="#F0F2F6",
                plot_bgcolor="#F0F2F6",
                xaxis_title="BMU ID",
                yaxis_title="Median Spread (£/MWh)",
                margin=dict(t=80)
            )
            fig_bmu_drill.update_traces(cliponaxis=False)
            st.plotly_chart(fig_bmu_drill, use_container_width=True)
        else:
            st.info(f"No units found for fuel type: {sel_fuel_break}")
    else:
        st.info("No data available for Fuel Type spread comparison.")





# ----------------- TAB 6: Counterparty Intelligence -----------------
with tab6:
    st.header("🏢 Counterparty Intelligence")
    st.markdown("Provides participant-level insights and detailed behavioural breakdowns across their unit portfolios.")

    view_mode_t6, sel_date_t6, sel_week_t6, sel_month_t6 = render_time_drilldown_ui(filtered_df, "tab6")
    t6_df, _ = apply_time_drilldown(filtered_df, view_mode_t6, sel_date_t6, sel_week_t6, sel_month_t6)

    if not t6_df.empty:
        st.subheader("Market Participant Portfolio Concentration")
        ens_t6 = t6_df[t6_df['BEHAVIOUR_CLASS'] == 'Constrained - ensemble']
        
        if not ens_t6.empty:
            cp_dist = ens_t6.groupby('COUNTERPARTY').size().reset_index(name='Ensemble_SPs').sort_values('Ensemble_SPs', ascending=False)
            fig_cp = px.bar(
                cp_dist.head(10), x='COUNTERPARTY', y='Ensemble_SPs',
                title="Top 10 Counterparties by Ensemble SPs",
                text_auto=True,
                color_discrete_sequence=['#E5383B'],
                height=600 # Making it taller
            )
            fig_cp.update_traces(textposition='outside', cliponaxis=False)
            fig_cp.update_layout(margin=dict(t=80))
            st.plotly_chart(fig_cp, use_container_width=True)
        else:
            st.info("No ensemble SPs detected for the selected period.")

        st.markdown("---")
        st.subheader("Individual Counterparty Deep Dive")
        
        available_cps = sorted(t6_df['COUNTERPARTY'].dropna().unique().tolist())
        target_cp = st.selectbox("Select Counterparty to Investigate:", options=available_cps, key="t6_cp_select")
        
        cp_data = t6_df[t6_df['COUNTERPARTY'] == target_cp].copy()
        
        if not cp_data.empty:
            st.markdown(f"### Portfolio Summary: {target_cp}")
            
            # Metrics
            cp_total_sps = len(cp_data)
            cp_ens_sps = (cp_data['BEHAVIOUR_CLASS'] == 'Constrained - ensemble').sum()
            cp_extreme_sps = ((cp_data['BEHAVIOUR_CLASS'] == 'Constrained - ensemble') & (cp_data['OFFER_PRICE'] > 200)).sum()
            
            mc1, mc2, mc3 = st.columns(3)
            mc1.metric("Total Portfolio SPs", f"{cp_total_sps:,}")
            mc2.metric("Ensemble Events", f"{cp_ens_sps:,}")
            mc3.metric("Extreme Prices (>£200)", f"{cp_extreme_sps:,}")
            
            st.markdown("#### BMU Breakdown")
            # BMU, total ensemble, max price, extreme counts
            bmu_breakdown = cp_data.groupby('BMU_ID').apply(lambda x: pd.Series({
                'Total_SPs': len(x),
                'Ensemble_SPs': (x['BEHAVIOUR_CLASS'] == 'Constrained - ensemble').sum(),
                'Elevated_SPs': (x['BEHAVIOUR_CLASS'] == 'Constrained - elevated signal').sum(),
                'Max_Offer': x['OFFER_PRICE'].max(),
                'Extreme_Events': ((x['BEHAVIOUR_CLASS'] == 'Constrained - ensemble') & (x['OFFER_PRICE'] > 200)).sum()
            })).reset_index().sort_values('Ensemble_SPs', ascending=False)
            
            st.dataframe(
                bmu_breakdown,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "BMU_ID": "BMU ID",
                    "Total_SPs": "Total Periods",
                    "Ensemble_SPs": "Flagged Ensemble",
                    "Elevated_SPs": "Elevated Signals",
                    "Max_Offer": st.column_config.NumberColumn("Max Offer (£)", format="£%.2f"),
                    "Extreme_Events": "Price > £200"
                }
            )
            
            # Additional visual for the counterparty
            if cp_ens_sps > 0:
                st.markdown("#### Ensemble Distribution by BMU")
                fig_cp_bmu = px.bar(
                    bmu_breakdown[bmu_breakdown['Ensemble_SPs'] > 0], 
                    x='BMU_ID', y='Ensemble_SPs',
                    title=f"Ensemble Event Concentration for {target_cp}",
                    text_auto=True,
                    color='Ensemble_SPs',
                    color_continuous_scale='Reds',
                    height=300
                )

                fig_cp_bmu.update_traces(textposition='outside', cliponaxis=False)
                fig_cp_bmu.update_layout(margin=dict(t=50))
                st.plotly_chart(fig_cp_bmu, use_container_width=True)
        else:
            st.info(f"No data available for {target_cp}.")
            
    else:
        st.info("No data available for the selected period.")

