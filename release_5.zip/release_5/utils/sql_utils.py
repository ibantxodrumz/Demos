# utils/sql_utils.py
import struct
import pandas as pd
import streamlit as st

try:
    import pyodbc
    from azure.identity import AzureCliCredential, DefaultAzureCredential
    from azure.core.exceptions import ClientAuthenticationError
    HAS_SQL_LIBS = True
except ImportError:
    HAS_SQL_LIBS = False

from utils.constants import SQL_SERVER, SQL_DATABASE, SQL_QUERY


# --- SQL Azure Token-based Authentication Logic ---


@st.cache_resource(ttl=3300)
def get_access_token():
    """
    Fetch an access token for Azure SQL.
    """
    if not HAS_SQL_LIBS:
        raise ImportError("SQL dependencies (pyodbc, azure-identity) are not installed.")

    scope = "https://database.windows.net/.default"

    # 1) Most reliable for local dev on corporate laptops
    try:
        token = AzureCliCredential().get_token(scope)
        return token.token
    except Exception:
        pass

    # 2) Fallback chain
    try:
        cred = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        token = cred.get_token(scope)
        return token.token
    except ClientAuthenticationError as e:
        raise ConnectionError(
            "Azure authentication failed. Run 'az login' in the same environment. "
            f"Details: {e}"
        )
    except Exception as e:
        raise ConnectionError(f"Azure authentication error: {e}")


def _pick_odbc_driver():
    """
    Prefer Driver 18, fallback to Driver 17 if present.
    """
    if not HAS_SQL_LIBS:
        return None
    installed = pyodbc.drivers()
    for d in ["ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"]:
        if d in installed:
            return "{" + d + "}"
    return "{ODBC Driver 18 for SQL Server}"


def get_sql_connection():
    """
    Creates a pyodbc connection to Azure SQL using an AAD access token.
    """
    if not HAS_SQL_LIBS:
        raise ImportError("SQL dependencies are missing.")
    
    driver = _pick_odbc_driver()

    connection_string = (
        f"Driver={driver};"
        f"Server=tcp:{SQL_SERVER},1433;"
        f"Database={SQL_DATABASE};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        "Connection Timeout=30;"
    )

    token = get_access_token()
    token_bytes = token.encode("UTF-16-LE")
    token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

    try:
        conn = pyodbc.connect(connection_string, attrs_before={1256: token_struct})
        return conn
    except pyodbc.Error as e:
        raise ConnectionError(f"SQL connection failed: {e}")


@st.cache_data(ttl=3600)
def fetch_sql_data():
    """Fetched data from Azure SQL and returns as a DataFrame."""
    if not HAS_SQL_LIBS:
        raise ImportError("SQL dependencies (pyodbc/azure-identity) are not installed or cannot be loaded.")
    try:
        conn = get_sql_connection()
        df = pd.read_sql(SQL_QUERY, conn)
        conn.close()
        return df
    except Exception as e:
        raise e
