# utils/logic_utils.py
import pandas as pd
import streamlit as st

def get_behaviour_class(r):
    """Classifies a constrained settlement period based on the ensemble rule."""
    if r['N_CONDITIONS_TRUE'] == 0:
        return "Constrained - normal behaviour"
    elif r['N_CONDITIONS_TRUE'] == 1:
        return "Constrained - elevated signal"
    else:
        return "Constrained - ensemble"

def preprocess_data(df):
    """Standardizes columns and calculates behavioral classes across all data sources."""
    if df.empty:
        return df
        
    # Preprocessing
    df['LOCAL_DATETIME'] = pd.to_datetime(df['LOCAL_DATETIME'])
    df['SETTLEMENT_DATE'] = pd.to_datetime(df['SETTLEMENT_DATE'])
    if 'GMT_FROM' in df.columns:
        df['GMT_FROM'] = pd.to_datetime(df['GMT_FROM'])
        
    # Standardize or infer behavioral columns
    for col in ['COND_1', 'COND_2', 'COND_3']:
        if col not in df.columns:
            df[col] = False
            
    if 'N_CONDITIONS_TRUE' not in df.columns:
        df['N_CONDITIONS_TRUE'] = df[['COND_1', 'COND_2', 'COND_3']].sum(axis=1)
        
    if 'ENSEMBLE' not in df.columns:
        df['ENSEMBLE'] = df['N_CONDITIONS_TRUE'] >= 2
        
    # Define BEHAVIOUR_CLASS taxonomy
    df['BEHAVIOUR_CLASS'] = df.apply(get_behaviour_class, axis=1)

    # Sort chronologically
    df = df.sort_values('LOCAL_DATETIME')
    return df

def parse_why(why_str):
    """Splits the detect-reason string into summary conditions and expanded details."""
    if pd.isna(why_str) or str(why_str).strip() == '':
        return '', ''
    parts = str(why_str).split('|')
    conditions = parts[0].strip()
    details = ' | '.join(p.strip() for p in parts[1:]) if len(parts) > 1 else ''
    return conditions, details

def enrich_alerts_with_impact(alerts_df):
    """Calculates granular estimated impact (£) per flag based on threshold deviations."""
    if alerts_df.empty:
        return alerts_df
    df = alerts_df.copy()
    MATERIALITY = 30

    parsed = df['WHY'].apply(parse_why)
    df['WHY_CONDITIONS'] = parsed.apply(lambda x: x[0])
    df['WHY_DETAILS'] = parsed.apply(lambda x: x[1])

    # Realistic estimated impact using the specific thresholds from each condition
    df['IMPACT_C1'] = df.apply(
        lambda r: max(r.get('SPREAD', 0) - r.get('MED_SPREAD_UNCON', 0), 0) * r.get('OFFER_VOLUME_MWH', 0)
        if r.get('COND_1', False) and pd.notna(r.get('MED_SPREAD_UNCON')) else float('nan'), axis=1
    )
    df['IMPACT_C2'] = df.apply(
        lambda r: max(r.get('OFFER_PRICE', 0) - r.get('THR_FUEL', 0), 0) * r.get('OFFER_VOLUME_MWH', 0)
        if r.get('COND_2', False) and pd.notna(r.get('THR_FUEL')) else float('nan'), axis=1
    )
    df['IMPACT_C3'] = df.apply(
        lambda r: max(r.get('SPREAD', 0) - (r.get('MED_SPREAD_UNCON', 0) + MATERIALITY), 0) * r.get('OFFER_VOLUME_MWH', 0)
        if r.get('COND_3', False) and pd.notna(r.get('MED_SPREAD_UNCON')) else float('nan'), axis=1
    )
    
    c_cols = [c for c in ['IMPACT_C1', 'IMPACT_C2', 'IMPACT_C3'] if c in df.columns]
    df['IMPACT_SP'] = df[c_cols].mean(axis=1).fillna(0).round(0) if c_cols else 0
    return df

@st.cache_data
def infer_alerts_windows(alerts_df):
    """Groups individual ensemble alerts into continuous temporal episodes/windows."""
    if alerts_df.empty:
        return pd.DataFrame()
        
    df_window = alerts_df.copy()
    df_window = df_window.sort_values(['BMU_ID', 'GMT_FROM'])
    
    df_window['prev_gmt'] = df_window.groupby('BMU_ID')['GMT_FROM'].shift(1)
    df_window['is_new_window'] = (df_window['GMT_FROM'] - df_window['prev_gmt']) > pd.Timedelta(minutes=30)
    df_window['is_new_window'] = df_window['is_new_window'].fillna(True)
    df_window['window_id'] = df_window['is_new_window'].cumsum()
    
    has_impact = 'IMPACT_SP' in df_window.columns
    agg_dict = dict(
        FUEL_TYPE=('FUEL_TYPE', 'first'),
        COUNTERPARTY=('COUNTERPARTY', 'first'),
        START_GMT=('GMT_FROM', 'min'),
        END_GMT=('GMT_FROM', lambda x: x.max() + pd.Timedelta(minutes=30)),
        START_LOCAL=('LOCAL_DATETIME', 'min'),
        END_LOCAL=('LOCAL_DATETIME', lambda x: x.max() + pd.Timedelta(minutes=30)),
        COUNT_SP=('SETTLEMENT_PERIOD', 'count'),
        C1_PRESENT=('COND_1', 'any'),
        C2_PRESENT=('COND_2', 'any'),
        C3_PRESENT=('COND_3', 'any'),
        AVG_SPREAD=('SPREAD', 'mean'),
        MAX_SPREAD=('SPREAD', 'max'),
        AVG_OFFER_PRICE=('OFFER_PRICE', 'mean'),
        SUM_VOLUME=('OFFER_VOLUME_MWH', 'sum'),
    )
    if 'CONSTRAINT_GROUP' in df_window.columns:
        agg_dict['CONSTRAINT_GROUP'] = ('CONSTRAINT_GROUP', 'first')
        
    if has_impact:
        agg_dict['TOTAL_IMPACT_SP'] = ('IMPACT_SP', 'sum')

    grouped = df_window.groupby(['window_id', 'BMU_ID']).agg(**agg_dict).reset_index()
    
    grouped['DURATION_MIN'] = grouped['COUNT_SP'] * 30
    grouped['IMPACT_WINDOW'] = grouped['TOTAL_IMPACT_SP'] if has_impact else (grouped['AVG_SPREAD'] * grouped['SUM_VOLUME'])
    grouped['UNIQUE_ID'] = grouped['START_LOCAL'].dt.strftime('%Y%m%d%H%M') + grouped['window_id'].astype(str)
    
    for col in ['AVG_SPREAD', 'MAX_SPREAD', 'AVG_OFFER_PRICE']:
        grouped[col] = grouped[col].round(2)
    grouped['IMPACT_WINDOW'] = grouped['IMPACT_WINDOW'].round(0)

    base_cols = ['BMU_ID']
    if 'CONSTRAINT_GROUP' in grouped.columns:
        base_cols.append('CONSTRAINT_GROUP')
    base_cols.extend(['FUEL_TYPE', 'COUNTERPARTY', 'START_GMT', 'END_GMT',
                 'START_LOCAL', 'END_LOCAL', 'DURATION_MIN', 'COUNT_SP',
                 'C1_PRESENT', 'C2_PRESENT', 'C3_PRESENT',
                 'AVG_SPREAD', 'MAX_SPREAD', 'AVG_OFFER_PRICE', 'SUM_VOLUME',
                 'IMPACT_WINDOW', 'UNIQUE_ID'])
    if has_impact:
        base_cols.append('TOTAL_IMPACT_SP')
    return grouped[base_cols]
