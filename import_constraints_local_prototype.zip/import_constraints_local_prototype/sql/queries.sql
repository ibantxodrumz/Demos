-- Weekly alert retrieval for the local prototype.
SELECT w.*, s.WHY AS INFO_FOR_ANALYST
FROM IMPORT_ALERTS AS w
LEFT JOIN (
    SELECT GMT_FROM, MAX(WHY) AS WHY
    FROM IMPORT_ALERTS_DATA
    GROUP BY GMT_FROM
) AS s
    ON w.START_GMT = s.GMT_FROM
WHERE w.START_GMT >= :start_datetime
  AND w.START_GMT < :end_datetime
ORDER BY w.START_GMT, w.BMU_ID;

-- SP-level analytical support for a selected alert window.
SELECT *
FROM IMPORT_ALERTS_DATA
WHERE BMU_ID = :bmu_id
  AND GMT_FROM >= :start_gmt
  AND GMT_FROM < :end_gmt
ORDER BY GMT_FROM;

-- Saved analyst reviews.
SELECT *
FROM ACTIVITY_LOG
ORDER BY START_DATE, BMU_ID;
