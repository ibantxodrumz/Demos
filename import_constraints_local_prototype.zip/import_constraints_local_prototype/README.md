# Import Constraints Local Prototype

This package is the local database starting point for reproducing the Excel workflow in Dash.

## Database

`data/prototype.db` contains three tables:

- `IMPORT_ALERTS_DATA`: six months of static synthetic SP-level processed data.
- `IMPORT_ALERTS`: static alert windows collapsed from consecutive `ENSEMBLE = 1` rows.
- `ACTIVITY_LOG`: initially empty and ready for Dash write-back.

`INFO_FOR_ANALYST` stores system-generated analytical information such as `WHY`.
`REVIEW_COMMENTS` stores human-entered review text.

## Demonstration weeks

- 2 to 8 February 2026
- 4 to 10 May 2026

These weeks deliberately contain repeated alerts for selected BMUs.

## Rebuild

From the package root:

    python scripts/initialise_database.py

This rebuilds `prototype.db` from the CSV files and leaves `ACTIVITY_LOG` empty.
