# Fixes for later

1. Preserve null `WHY` values in `_sanitize_why`; do not convert them to the literal string `nan`.
2. Review the compatibility join on `START_GMT = GMT_FROM`; another BMU may share the same timestamp.
3. Future evidence retrieval should use `BMU_ID` plus the half-open alert window.
4. Decide how multiple SP-level `WHY` values should be presented in Dash.
5. Keep system-generated `INFO_FOR_ANALYST` separate from human-entered `REVIEW_COMMENTS`.
6. Investigate duplicate output rows from the current production query/export.
