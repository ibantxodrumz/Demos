from pathlib import Path
import sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "prototype.db"
SCHEMA_PATH = ROOT / "sql" / "schema.sql"


def initialise_database() -> None:
    DB_PATH.unlink(missing_ok=True)
    alerts_data = pd.read_csv(DATA_DIR / "IMPORT_ALERTS_DATA.csv")
    alerts = pd.read_csv(DATA_DIR / "IMPORT_ALERTS.csv")

    with sqlite3.connect(DB_PATH) as connection:
        connection.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        alerts_data.to_sql("IMPORT_ALERTS_DATA", connection, if_exists="append", index=False)
        alerts.to_sql("IMPORT_ALERTS", connection, if_exists="append", index=False)


if __name__ == "__main__":
    initialise_database()
