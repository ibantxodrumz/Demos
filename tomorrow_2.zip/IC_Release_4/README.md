
# Interconnector Position Reconciliation Tool (Release 4)

A Python-based tool for reconciling Day-Ahead positions, Physical Notifications (PNs), Market Trades, and Internal Trades for electricity interconnectors.

## Key Features

1.  **Automated Data Ingestion**:
    *   **PNs**: Melts wide-format Excel files (e.g., `MCNN...xls`).
    *   **Market Trades**: Fetches trade data via API (EnTrader) or falls back to local CSV snapshots.
    *   **Internal Trades (New in R4)**: Ingests internal trade records from Excel/CSV for 3-way reconciliation.

2.  **Comparison Logic**:
    *   **Comparison 1**: Checks for PN changes between H+1 and H+8.
    *   **Comparison 2**: Reconciles PN changes against Market and Internal trades.
    *   **Countertrade Detection**: Identifies "True" countertrades vs. system balancing actions.
    *   **Internal Mismatch (New in R4)**: Flags discrepancies between Market Trades and Internal Records (> 5 MW tolerance).

3.  **Reporting**:
    *   Generates CSV reports: `Comparison2_trade_results`, `Advisory`, `Summary`.
    *   Console output for operators with clear "Action" directives.

## Installation

1.  **Prerequisites**: Python 3.9+
2.  **Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
3.  **Environment Variables**:
    *   `IC`: Target Interconnector (e.g., `IFA`, `IFA2`, `ELECLINK`).
    *   `ENTRADER_API_KEY`: Required for live market trade fetching.

## Usage

Run the tool for a specific Interconnector:

```bash
IC=IFA python3 click_2.py
```

### Data Directory Structure

Ensure your `data/` directory is structured as follows:

```
data/
├── April_IFA/              # PN Excel files (MCNN...)
├── internal_trades/        # Internal Trade files (internal_trades_YYYY-MM-DD.xlsx)
├── trades_master/          # Market Trade snapshots
└── CP_codes.csv            # Counterparty mapping file
```

## Internal Trades Functionality (Release 4)

Release 4 introduces a layer to verify market trades against internal records.

1.  **Input**: Place daily internal trade files in `data/internal_trades/`.
    *   Format: Excel (`.xlsx`) or CSV.
    *   Naming: `internal_trades_YYYY-MM-DD.xlsx`
    *   Required Columns: `Counterparty`, `Volume`, `IC`, `Start Time`, `End Time`.
    *   *Note*: The tool automatically detects header rows even if offset (e.g., Row 2).

2.  **Logic**:
    *   The tool aggregates Internal Trades by Counterparty and Hour.
    *   It compares the **Internal Volume** against the **Market Trade Volume**.
    *   If the difference exceeds **5 MW**, the row is flagged with `Internal_Mismatch = True`.

3.  **Output**:
    *   Check `outputs/Comparison2_trade_results_{IC}.csv`.
    *   Columns `Internal_Volume_MW` and `Internal_Mismatch` provide audit trails.
