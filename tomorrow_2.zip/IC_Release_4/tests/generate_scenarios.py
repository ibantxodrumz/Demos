"""
Generate Synthetic Data for Click 2 QA Scenarios.
Produces:
    - PN Files (.xls) in Europe/London time
    - Trades Files (.csv) in UTC
    - CP Codes (.csv)
    - Scenario Bundles
"""

import os
import shutil
import random
from pathlib import Path
from datetime import datetime, timedelta
import pandas as pd
import numpy as np

# Config
DATA_ROOT = Path(__file__).parent / "scenarios"
CP_CODES_FILE_NAME = "CP_codes.csv"

# Scenarios to generate
SCENARIOS = [
    "S01_Early_stop",
    "S02_H_plus_1_changed",
    "S03_Forward_changes_only",
    "S04_On_IC_met",
    "S05_Across_IC_met",
    "S06_Countertrade",
    "S07_No_trades",
    "S08_Awareness_extremes",
    "S09_Mapping_gaps",
    "S10_DST_boundary",
]

# Common BMUs
BMUS = {
    "IC_A": ["IFA-BMU-1", "IFA-BMU-2", "IFA-BMU-3", "IFA-BMU-4"],
    "IC_B": ["NEM-BMU-1", "NEM-BMU-2"],
    "Other": ["OTHER-BMU-1"],
}
ALL_BMUS = BMUS["IC_A"] + BMUS["IC_B"] + BMUS["Other"]

def ensure_dir(path: Path):
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)

def generate_cp_codes(path: Path):
    """Generate a CP mapping file covering most BMUs but leaving some for mapping gaps."""
    # Mapping structure: CP Code | IFA1 - Buy | IFA1 - Sell | ...
    # We will just map most BMUs to a few CP codes
    
    data = []
    
    # CP1: Maps to IFA-BMU-1 (Buy) and IFA-BMU-2 (Sell)
    data.append({
        "CP Code": "CP001",
        "IFA1 - Buy": "IFA-BMU-1",
        "IFA1 - Sell": "IFA-BMU-2",
        "BN - Buy": "NEM-BMU-1",
        "BN - Sell": "NEM-BMU-2" 
    })
    
    # CP2: Maps to IFA-BMU-3 (Buy)
    data.append({
        "CP Code": "CP002",
        "IFA1 - Buy": "IFA-BMU-3",
        "IFA1 - Sell": "IFA-BMU-4",
    })

    # Note: OTHER-BMU-1 is intentionally left unmapped for "S09_Mapping_gaps"
    
    df = pd.DataFrame(data)
    # Fill missing columns with blank
    cols = [
        "CP Code", 
        "IFA1 - Buy", "IFA1 - Sell", 
        "BN - Buy", "BN - Sell",
        "NEMO - Buy", "NEMO - Sell",
        "IFA2 - Buy", "IFA2 - Sell",
        "EL - Buy", "EL - Sell",
        "VKL - Buy", "VKL - Sell"
    ]
    for c in cols:
        if c not in df.columns:
            df[c] = ""
            
    df.to_csv(path, index=False)
    return df

def generate_pn_file(
    directory: Path, 
    date_str: str, 
    hh_token: str = "DA", 
    bmu_changes: dict = None,
    base_mw: float = 100.0
):
    """
    Generate a PN .xls file.
    date_str: YYYYMMDD
    hh_token: 'DA' or '14' etc.
    bmu_changes: dict { 'BMU_ID': { hour_int: new_mw } } 
    """
    
    # Setup time range in Local Time (Europe/London)
    # Simplification: We will just create 48 half-hours for the day
    # In a real rigorous test we'd handle DST, but here we can mock the timestamps as strings or datetimes
    
    cols = ["UNIT"]
    # Generate 48 columns for HH blocks
    # MCNN format implies Columns B.. are timestamps.
    # Let's generate timestamps for the specific day 00:00 to 23:30
    
    day_dt = datetime.strptime(date_str, "%Y%m%d")
    timestamps = []
    for h in range(24):
        for m in [0, 30]:
            ts = day_dt + timedelta(hours=h, minutes=m)
            timestamps.append(ts)
            cols.append(ts) # As datetime objects, pandas will format them
            
    rows = []
    
    # TOTAL PNS row
    total_row = ["TOTAL PNS"] + [0.0] * 48
    rows.append(total_row)
    
    for bmu in ALL_BMUS:
        row = [bmu]
        vals = []
        for i, ts in enumerate(timestamps):
            mw = base_mw
            # Apply overrides
            if bmu_changes and bmu in bmu_changes:
                hour = ts.hour
                if hour in bmu_changes[bmu]:
                    mw = bmu_changes[bmu][hour]
            vals.append(mw)
        row.extend(vals)
        rows.append(row)
        
    df = pd.DataFrame(rows, columns=cols)
    
    filename = f"MCNN {date_str}.xlsx" if hh_token == "DA" else f"MCNN {date_str}_{hh_token}.xlsx"
    path = directory / filename
    
    # Write as excel
    # Note: Using default engine (openpyxl) for xlsx
    try:
        df.to_excel(path, index=False) 
    except Exception as e:
        print(f"Warning: Could not write excel directly: {e}")
        # Fallback to csv for debugging if needed, but the tool expects excel.
        pass
        
    return path

def generate_trades_file(
    directory: Path,
    start_date: str, # YYYY-MM-DD
    end_date: str,   # YYYY-MM-DD
    trades_data: list = None
):
    """
    Generate trades CSV with columns expected by fetch_trades.
    """
    filename = f"trades_{start_date}_{end_date}.csv"
    path = directory / filename
    
    columns = [
        "Id", "Trade_Id", "NGC_BM_Unit_Name", "Unit_Volume", "Agreement_Type",
        "Delivery_Area", "Note", "CP_Name", "Price", "Total_Volume", "Total_Value",
        "SO_Flag", "Trade_Constraint", "Trade_Reason", 
        "Start_Time_UTC", "End_Time_UTC", "Trade_Created", "Last_Updated", "Traded_Date"
    ]
    
    if not trades_data:
        trades_data = [] # Empty df
        
    df = pd.DataFrame(trades_data, columns=columns)
    df.to_csv(path, index=False)
    return path

def build_scenario_data(scenario_name: str, base_dir: Path):
    scen_dir = base_dir / scenario_name
    ensure_dir(scen_dir)
    
    # 1. CP Codes
    cp_map_path = scen_dir / CP_CODES_FILE_NAME
    generate_cp_codes(cp_map_path)
    
    # 2. Files
    # Base configuration: Day T (today)
    today = datetime(2025, 6, 1) # Arbitrary non-DST date for stability unless S10
    if scenario_name == "S10_DST_boundary":
         today = datetime(2025, 3, 30) # DST start in UK 2025? (Last sunday March)
         
    ymd = today.strftime("%Y%m%d")
    ymd_dash = today.strftime("%Y-%m-%d")

    # Click 2 requests D-1 to D+2
    trade_start = (today - timedelta(days=1)).strftime("%Y-%m-%d")
    trade_end = (today + timedelta(days=2)).strftime("%Y-%m-%d")
    
    # Default Files: DA full day + Update at 10:00
    
    # Scenario Specific Logic
    
    if scenario_name == "S01_Early_stop":
        # H+1 has NO change. Forward NO change.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        # Update file same as DA (no delta)
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0)
        # Trades file (empty or irrelevant as it stops early)
        generate_trades_file(scen_dir, trade_start, trade_end) # MATCH WINDOW
        
    elif scenario_name == "S02_H_plus_1_changed":
        # Update at 10:00. H+1 (11:00) has change.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        # Change at 11:00 Local (10:00 UTC) - this is H+1
        # Change at 12:00 Local (11:00 UTC) - extra buffer
        changes = {"IFA-BMU-1": {11: 150.0, 12: 150.0}} 
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "IFA-BMU-1",
            "Start_Time_UTC": f"{ymd_dash}T10:00:00Z", # Matches 11:00 Local (H+1)
            "End_Time_UTC": f"{ymd_dash}T11:00:00Z",
            "Unit_Volume": 50.0,
            "Total_Volume": 50.0,
            "Traded_Date": f"{today.strftime('%Y-%m-%d')}T08:00:00Z", # Awareness clearly before 10:00 receipt (09:00 UTC)
            "Trade_Created": f"{today.strftime('%Y-%m-%d')}T07:00:00Z",
            "Agreement_Type": "Normal",
            "SO_Flag": "F"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)

    elif scenario_name == "S03_Forward_changes_only":
        # Update at 10:00. H+1 (11:00) Clean. Change at 15:00.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {15: 150.0}} 
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "IFA-BMU-1",
            "Start_Time_UTC": f"{ymd_dash}T15:00:00Z",
            "End_Time_UTC": f"{ymd_dash}T16:00:00Z",
            "Unit_Volume": 50.0,
            "Total_Volume": 50.0, # Matches Delta
            "Traded_Date": f"{today.strftime('%Y-%m-%d')}T09:00:00Z",
            "Trade_Created": f"{today.strftime('%Y-%m-%d')}T08:00:00Z",
            "Agreement_Type": "Normal",
            "SO_Flag": "F"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)
        
    elif scenario_name == "S04_On_IC_met":
        # Standard MET scenario
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {12: 200.0}} # Delta +100
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "IFA-BMU-1", # Same BMU
            "Start_Time_UTC": f"{ymd_dash}T12:00:00Z",
            "End_Time_UTC": f"{ymd_dash}T13:00:00Z",
            "Unit_Volume": 100.0,
            "Total_Volume": 100.0,
            "Traded_Date": f"{ymd_dash}T09:00:00Z",
            "Trade_Created": f"{ymd_dash}T08:00:00Z",
            "Agreement_Type": "Normal",
            "SO_Flag": "F"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)
        
    elif scenario_name == "S05_Across_IC_met":
        # Delta on IFA-BMU-1. Trade on NEM-BMU-1 (same CP).
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {14: 200.0}} # Delta +100 at 14:00 Local
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "NEM-BMU-1", # Same CP (CP001)
            "Start_Time_UTC": f"{ymd_dash}T13:00:00Z",
            "End_Time_UTC": f"{ymd_dash}T14:00:00Z",
            "Unit_Volume": 100.0,
            "Total_Volume": 100.0,
            "Traded_Date": f"{ymd_dash}T09:00:00Z",
            "Trade_Created": f"{ymd_dash}T08:00:00Z",
            "Agreement_Type": "Normal",
            "SO_Flag": "F"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)
        
    elif scenario_name == "S06_Countertrade":
        # YES3 override.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        # Trade at 13:00 UTC = 14:00 Local (BST)
        # So PN change should be at 14:00 Local to match.
        changes = {"IFA-BMU-2": {14: 0.0}} # Delta -100 at 14:00 Local
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "IFA-BMU-1", 
            "Start_Time_UTC": f"{ymd_dash}T13:00:00Z", # 14:00 Local
            "End_Time_UTC": f"{ymd_dash}T14:00:00Z",
            "Unit_Volume": 100.0,
            "Total_Volume": 100.0,
            "Traded_Date": f"{ymd_dash}T09:00:00Z",
            "Trade_Created": f"{ymd_dash}T08:00:00Z",
            "Agreement_Type": "Normal",
            "SO_Flag": "F"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)

    elif scenario_name == "S07_No_trades":
        # Delta PN exists, NO trades. Expect YES3.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {12: 150.0}}
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        generate_trades_file(scen_dir, trade_start, trade_end) # Empty

    elif scenario_name == "S08_Awareness_extremes":
        # Trade created AFTER the PN update (Negative awareness lag)
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {12: 150.0}}
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "IFA-BMU-1",
            "Start_Time_UTC": f"{ymd_dash}T12:00:00Z",
            "End_Time_UTC": f"{ymd_dash}T13:00:00Z",
            "Unit_Volume": 50.0,
            "Total_Volume": 50.0,
            "Traded_Date": f"{ymd_dash}T11:00:00Z", # After 09:00 UTC receipt
            "Trade_Created": f"{ymd_dash}T10:30:00Z",
            "Agreement_Type": "Normal"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)

    elif scenario_name == "S09_Mapping_gaps":
        # Delta on BMU not in CP_codes (OTHER-BMU-1)
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"OTHER-BMU-1": {12: 150.0}} 
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        
        trades = [{
            "NGC_BM_Unit_Name": "OTHER-BMU-1",
            "Start_Time_UTC": f"{ymd_dash}T12:00:00Z",
            "End_Time_UTC": f"{ymd_dash}T13:00:00Z",
            "Unit_Volume": 50.0,
            "Total_Volume": 50.0,
            "Traded_Date": f"{ymd_dash}T08:00:00Z",
            "Trade_Created": f"{ymd_dash}T07:00:00Z",
            "Agreement_Type": "Normal"
        }]
        generate_trades_file(scen_dir, trade_start, trade_end, trades)

    elif scenario_name == "S10_DST_boundary":
        # DST start (March 30 2025). 01:00 local skips to 02:00?
        # UK DST 2025: March 30 (Sunday), clock goes fwd 1h at 01:00.
        # So hours are: 00:00, 00:30, 02:00...
        # My generate_pn_file uses range(24), so it might need adjustment for DST.
        # For now, let's just use it to check if utilities handle it without crashing.
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        changes = {"IFA-BMU-1": {5: 150.0}} # Hour 5 (Safe post-DST)
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0, bmu_changes=changes)
        generate_trades_file(scen_dir, trade_start, trade_end)

    else:
        # Generic defaults
        generate_pn_file(scen_dir, ymd, "DA", base_mw=100.0)
        generate_pn_file(scen_dir, ymd, "10", base_mw=100.0)
        generate_trades_file(scen_dir, trade_start, trade_end)

if __name__ == "__main__":
    ensure_dir(DATA_ROOT)
    for sc in SCENARIOS:
        print(f"Generating {sc}...")
        build_scenario_data(sc, DATA_ROOT)
    print("Done.")
