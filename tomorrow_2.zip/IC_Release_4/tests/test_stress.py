import unittest
import pandas as pd
import numpy as np
from datetime import datetime
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))

from utilities import classify_v2

class TestStressLogic(unittest.TestCase):
    def test_extreme_pn_move(self):
        """PN move over 2000MW should be a DATA_ERROR."""
        row = pd.Series({
            "Net_PN_Change_MW": 5000.0,
            "Total_Volume": 100.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 3, 15, 0),
            "CP Code": "BKW",
            "Duplicate_Trade_Error": False
        })
        now = datetime(2023, 4, 3, 16, 0)
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "DATA_ERROR")
        self.assertIn("Extreme PN Move", action)

    def test_extreme_trade_volume(self):
        """Trade volume over 2000MW should be a DATA_ERROR."""
        row = pd.Series({
            "Net_PN_Change_MW": 100.0,
            "Total_Volume": 5000.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 3, 15, 0),
            "CP Code": "BKW",
            "Duplicate_Trade_Error": False
        })
        now = datetime(2023, 4, 3, 16, 0)
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "DATA_ERROR")
        self.assertIn("Extreme Trade Volume", action)

    def test_missing_mapping_is_external(self):
        """BMU with no mapping is an external party (YES3 if movement)."""
        row = pd.Series({
            "BMU_ID": "MYSTERIOUS_UNIT",
            "Net_PN_Change_MW": 10.0,
            "Total_Volume": 0.0,
            "HourUTC": datetime(2023, 4, 3, 15, 0),
            "CP Code": np.nan,
            "Duplicate_Trade_Error": False
        })
        now = datetime(2023, 4, 3, 16, 0)
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "YES3")
        self.assertIn("System has moved", action)

    def test_duplicate_trade(self):
        """Flag set in click_2 should trigger DATA_ERROR in classify_v2."""
        row = pd.Series({
            "Net_PN_Change_MW": 10.0,
            "Total_Volume": 10.0,
            "HourUTC": datetime(2023, 4, 3, 15, 0),
            "CP Code": "BKW",
            "Duplicate_Trade_Error": True # Marked by orchestrator
        })
        now = datetime(2023, 4, 3, 16, 0)
        decision, action = classify_v2(row, now)
        self.assertEqual(decision, "DATA_ERROR")
        self.assertIn("Duplicate Trade ID", action)

if __name__ == "__main__":
    unittest.main()
