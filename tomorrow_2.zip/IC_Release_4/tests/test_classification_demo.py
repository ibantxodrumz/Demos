import unittest
import pandas as pd
from datetime import datetime
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))

from utilities import classify_v2

class TestClassificationDemos(unittest.TestCase):
    def test_yes1_wait(self):
        """YES1: Trade exists for the future, window not reached."""
        row = pd.Series({
            "Net_PN_Change_MW": 0.0,
            "Total_Volume": 100.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": datetime(2023, 4, 3, 15, 0), # Delivery is 15:00
            "CP Code": "BKW",
            "Duplicate_Trade_Error": False
        })
        now = datetime(2023, 4, 3, 13, 0) # Running at 13:00 (2 hours before - Forward)
        decision, action = classify_v2(row, now)
        print(f"\n[DEMO YES1] Decision: {decision} | Action: {action}")
        self.assertEqual(decision, "YES1")
        self.assertIn("WAIT", action)

    def test_yes2_across(self):
        """YES2: Trade not met on this IC, but covered across portfolio."""
        row = pd.Series({
            "Net_PN_Change_MW": 0.0,
            "Total_Volume": 100.0,
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": True, # Covered elsewhere!
            "HourUTC": datetime(2023, 4, 3, 15, 0),
            "CP Code": "BKW",
            "Duplicate_Trade_Error": False
        })
        now = datetime(2023, 4, 3, 16, 0) # window passed
        decision, action = classify_v2(row, now)
        print(f"\n[DEMO YES2] Decision: {decision} | Action: {action}")
        self.assertEqual(decision, "YES2")
        self.assertIn("Across", action)

if __name__ == "__main__":
    unittest.main()
