
import pytest
import pandas as pd
from pathlib import Path
import tempfile
import os
import shutil
from unittest.mock import MagicMock

# Import utility functions to test
from utilities import fetch_internal_trades, match_pn_to_trades

@pytest.fixture
def sample_internal_trades_df():
    data = {
        "Counterparty": ["CP1", "CP2"],
        "Buy/Sell": ["Buy", "Sell"],
        "Volume": [100, 50],
        "IC": ["IFA1", "IFA1"],
        "Start Time": ["2025-01-01 10:00", "2025-01-01 10:00"],
        "End Time": ["2025-01-01 11:00", "2025-01-01 11:00"],
        "Price": [50.0, 60.0],
        "Reason": ["R1", "R2"],
        "Default Price": [10, 10]
    }
    return pd.DataFrame(data)

def test_fetch_internal_trades_standard_header(sample_internal_trades_df):
    """Test fetching with standard row 0 header."""
    with tempfile.NamedTemporaryFile(suffix=".xlsx") as tmp:
        sample_internal_trades_df.to_excel(tmp.name, index=False)
        df = fetch_internal_trades(Path(tmp.name))
        assert not df.empty
        assert "Internal_CP" in df.columns  # Renamed from Counterparty
        assert len(df) == 2
        assert df.iloc[0]["Unit_Volume_MW"] == 100
        assert df.iloc[1]["Unit_Volume_MW"] == -50 # Sell logic

def test_fetch_internal_trades_offset_header(sample_internal_trades_df):
    """Test fetching with header on row 1 (offset by 1 row)."""
    with tempfile.NamedTemporaryFile(suffix=".xlsx") as tmp:
        # Create DF with garbage first row
        garbage = pd.DataFrame([["Obs", "X", "Y", "Z", "A", "B", "C", "D", "E"]], columns=sample_internal_trades_df.columns)
        final = pd.concat([garbage, sample_internal_trades_df], ignore_index=True)
        # Write without header, so 'Counterparty' is in data (row 1)
        final.to_excel(tmp.name, index=False, header=True) # Row 0 is header (which is garbage keys), Row 1 has data (Obs...), wait.
        # Let's do it manually using valid excel write
        # Row 0: Garbage
        # Row 1: Header (Counterparty...)
        # Row 2+: Data
        
        # Use pandas integer index to simulate "no header read" initially
        # Actually easier: Write with header=False, prepend a list
        data_vals = [sample_internal_trades_df.columns.tolist()] + sample_internal_trades_df.values.tolist()
        final_vals = [["SomeInfo"]] + data_vals
        df_out = pd.DataFrame(final_vals)
        df_out.to_excel(tmp.name, index=False, header=False)
        
        # Now test
        df = fetch_internal_trades(Path(tmp.name))
        assert not df.empty
        assert "Internal_CP" in df.columns
        assert len(df) == 2

def test_fetch_internal_trades_empty_file():
    key = "generate_internal_trades.py" # Just use a non-excel file or empty one
    with tempfile.NamedTemporaryFile(suffix=".xlsx") as tmp:
        df = fetch_internal_trades(Path(tmp.name))
        assert df.empty

def test_match_pn_to_trades_logic():
    """Test the 3-way reconciliation match logic."""
    # Mock data
    pn_df = pd.DataFrame({
        "BMU_ID": ["BMU1"],
        "HourUTC": [pd.Timestamp("2025-01-01 10:00")],
        "DeltaPN": [100.0],
        "DatetimeUTC": [pd.Timestamp("2025-01-01 10:00")],
        "ReceiptUTC": [pd.Timestamp("2025-01-01 09:35")], # After awareness (09:30)
    })
    
    trades_df = pd.DataFrame({
        "BMU_ID": ["BMU1"],
        "HourUTC": [pd.Timestamp("2025-01-01 10:00")],
        "Total_Volume": [100.0],
        "Awareness_Start": [pd.Timestamp("2025-01-01 09:30")],
        "Internal_Volume_MW": [100.0], # Matches
        "Agreement_Type": ["GTMA"],
        "DATETIME_FROM": [pd.Timestamp("2025-01-01 10:00")],
        "DATETIME_TO": [pd.Timestamp("2025-01-01 11:00")],
        "Traded_Date": [pd.Timestamp("2025-01-01 09:00")],
        "Trade_Created": [pd.Timestamp("2025-01-01 09:00")],
    })
    
    # 1. Match Case
    res = match_pn_to_trades(pn_df, trades_df)
    assert not res.empty
    val = res.iloc[0]
    assert val["Total_Volume"] == 100.0
    # Note: internal volume and mismatch flag logic is in click_2.py OR utilities.py?
    # Checking utilities.py, match_pn_to_trades returns agg df.
    # The Mismatch Logic (Comparison vs Internal) is in click_2.py (Orchestrator).
    # utilities.py only helps load/prep data.
    # So here we verify `match_pn_to_trades` handles the merge correctly.
    # Does it return "Internal_Volume_MW"?
    # Checking source: match_pn_to_trades in utilities.py primarily aggregates deltaPN and Market Trades.
    # The INTERNAL comparison happens in click_2.py after calling this function.
    # So specific internal verification logic is in the main script.
    # We should focus testing `fetch_internal_trades` heavily.
    pass

