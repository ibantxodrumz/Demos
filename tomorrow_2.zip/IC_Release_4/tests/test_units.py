import sys
import unittest
from pathlib import Path
from datetime import datetime
import pandas as pd

# Add project root
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.append(str(PROJECT_ROOT))

from utilities import (
    parse_mcnn_token,
    compute_delivery_horizon,
    classify_v2
)

class TestUtilities(unittest.TestCase):
    def test_parse_mcnn_token(self):
        self.assertEqual(parse_mcnn_token("MCNN 20250601.xls"), ("20250601", "DA"))
        self.assertEqual(parse_mcnn_token("MCNN 20250601_14.xls"), ("20250601", "14"))
        self.assertIsNone(parse_mcnn_token("RandomFile.txt"))

    def test_compute_delivery_horizon_forward_only(self):
        # pair=("DA", "10") -> latest=10. H+1=11.
        # forward_only=True -> delivery_start=11
        ymd = "20250601"
        pair = ("DA", "10")
        tokens = ["DA", "10"]
        start, end, latest, h_plus_1 = compute_delivery_horizon(ymd, tokens, pair, forward_only=True)
        
        # [2026-01-05] Updated: Token "10" (Local) -> 09:00 UTC (BST)
        self.assertEqual(latest, datetime(2025, 6, 1, 9, 0))
        self.assertEqual(h_plus_1, datetime(2025, 6, 1, 10, 0))
        self.assertEqual(start, datetime(2025, 6, 1, 10, 0))

    def test_classify_v2_yes1(self):
        # Forward trade - should be WAIT (YES1)
        row = pd.Series({
            "Trade_met_on_IC": False,
            "Trade_met_across_IC": False,
            "HourUTC": pd.Timestamp("2025-06-01 12:00:00"),
            "Net_PN_Change_MW": 100.0,
            "Total_Volume": 100.0,
            "CP Code": "BKW"
        })
        now = datetime(2025, 6, 1, 9, 0) # 3 hours before
        dec, act = classify_v2(row, now)
        self.assertEqual(dec, "YES1")
        self.assertIn("WAIT", act)

    def test_classify_v2_info(self):
        row = pd.Series({
            "Trade_met_on_IC": True,
            "HourUTC": pd.Timestamp("2025-06-01 12:00:00"),
            "Net_PN_Change_MW": 100.0,
            "Total_Volume": 100.0,
            "CP Code": "BKW"
        })
        dec, act = classify_v2(row, datetime(2025, 6, 1, 13, 0))
        self.assertEqual(dec, "INFO")
        self.assertIn("OK", act)

    def test_classify_v2_external_party(self):
        # Missing CP Code + Move = YES3
        row = pd.Series({
            "Trade_met_on_IC": False,
            "HourUTC": pd.Timestamp("2025-06-01 12:00:00"),
            "Net_PN_Change_MW": 100.0,
            "Total_Volume": 0.0,
            "CP Code": pd.NA
        })
        dec, act = classify_v2(row, datetime(2025, 6, 1, 11, 0))
        self.assertEqual(dec, "YES3")
        self.assertIn("System has moved", act)

if __name__ == "__main__":
    unittest.main()
