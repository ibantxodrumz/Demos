# PN Accuracy Dashboard Guide (External)

## 🎯 Purpose
The **PN Accuracy Dashboard** is a tool designed to monitor and analyze the forecasting accuracy of power generation assets. It compares what units *said* they would generate (**Physical Notifications** or **PN**) against what they *actually* generated (**Metered Volume**).

**Why this matters:**
*   **System Stability**: accurate PNs are crucial for Grid stability.
*   **Performance Monitoring**: helps identify under-performing assets.
*   **Compliance**: monitors adherence to grid code requirements.

---

## 📖 Glossary & Key Concepts

| Term | Meaning |
| :--- | :--- |
| **BMU** | **Balancing Mechanism Unit**. A single power generation asset (or a collection of small ones) registered with the Grid. |
| **PN** | **Physical Notification**. The expected generation schedule submitted by the operator. |
| **Metered** | The actual electricity generation measured at the meter. |
| **Error** | The difference between Expected (PN) and Actual (Metered) generation. |

---

## 📏 Core Metrics Explained

| Metric | What it measures | Why it's useful |
| :--- | :--- | :--- |
| **Annual Absolute Net Error %** | **Efficiency**. The error percentage **normalized by the unit's capacity**. | Allows fair comparison between huge power plants and small wind farms. *Lower is better.* |
| **Net Error (GWh)** | **Directional Bias**. Net difference in Gigawatt-hours (`Expected - Metered`). | Tells you if a unit consistently **Over-forecasts** (Positive) or **Under-forecasts** (Negative). |
| **Total ABS Error (GWh)** | **System Impact**. The total volume of mismatch in GWh. | Shows which units cause the biggest headache for the System Operator, regardless of their percentage efficiency. |
| **P90 Error %** | **Uncertainty/Risk**. The "worst case" error rate (90th percentile). | Identifies units that are unpredictable or "risky". |
| **Needs Attention** | **Compliance Flags**. | Highlights units breaching the 25% error threshold. |

---

## 🧭 How to Use This Dashboard (Tab-by-Tab)

### 1. 🚀 Executive Summary
**Goal:** Get a high-level view of the entire portfolio.
*   **Key Indicator:** Look at **Fleet Median Error %** to see how the fleet is doing on average.
*   **Action:** Check the **Fuel Performance Summary** table (bottom right) to see which technology (Gas, Wind, etc.) is the most accurate.

### 2. 📊 Fleet Overview
**Goal:** Analyze the fleet's composition and error drivers.

#### Tab 2.1: Fleet: Distribution
*   **Question:** *"Do we have many poor performers?"*
*   **Chart:** **Error Band Composition**. See how many units fall into the ">10%" error bucket.
*   **Question:** *"Are small units less accurate?"*
*   **Chart:** **Size Category Analysis**. Compare the error spread of Small (<50MW), Medium, and Large units.

#### Tab 2.2: Fleet: Capacity
*   **Question:** *"Which units are hurting the system the most?"*
*   **Chart:** Top **Capacity vs. Error** Bubble Chart.
    *   Set **Y-Axis** to **Total Error (GWh)**.
    *   Look for bubbles high on the Y-axis. These are your high-impact assets.

### 3. ⚡ By Technology
**Goal:** Deep dive into a specific fuel type (e.g., Wind).
*   **Action:** Select a Fuel from the dropdown.
*   **Charts (Tabbed View):**
    *   **Efficiency (Annual %)**: View the distribution of normalized error.
    *   **Bias (Net GWh)**: Switch to this tab to check for **Directional Bias** (Over vs. Under forecasting).
*   **Review:** Check the **Top & Bottom 10** tables to praise the best teams and support the strugglers.

### 4. 🔍 BMU Explorer
**Goal:** Investigate a specific unit (e.g., after an alert).
*   **Action:** Search for a BMU ID (e.g., `T_UNIT-1`).
*   **Insight:** Check the **Monthly Trend** sparkline. Did accuracy degrade recently, or has it always been poor?

### 5. 🚩 Attention Needed
**Goal:** Exception Management.
*   **Action:** This tab lists ONLY the units that have breached the **25% error threshold**.
*   **Download:** Use the export button to generate a "Hit List" for the operational teams to review.

### 6. 📥 Exports
**Goal:** detailed offline analysis.
*   **Annual Summary**: One row per unit (Summary stats).
*   **Monthly Summary**: One row per unit per month (Granular data).
