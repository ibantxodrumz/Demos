
import pandas as pd
import numpy as np

def load_data():
    df = pd.read_csv('inputs/annual_summary_2025.csv')
    # Standardize columns
    df["BMU"] = df["nationalGridBmUnit"].astype(str)
    df["Fuel"] = df["FUEL_I"].astype(str)
    
    # Coerce numerics
    numeric_cols = [
        "PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", 
        "Metered", "ExpectOT", "CapacityCalibrated", "NetError", 
        "ABSError", "max_M_ABS_NetError%", "installedCapacity_mwh", 
        "A_NetError%", "A_ABS_NetError%"
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
            
    # Calculate GWh
    if "ABSError" in df.columns:
        df["ABSError_GWh"] = df["ABSError"] / 1000
    if "NetError" in df.columns:
        df["NetError_GWh"] = df["NetError"] / 1000
        
    return df

def analyze_batteries(df):
    print("\n--- BATTERIES ANALYSIS ---")
    bat = df[df["Fuel"] == "BATTERY"]
    if bat.empty:
        print("No Battery data found.")
        return

    total_abs_error = bat["ABSError_GWh"].sum()
    total_net_error = bat["NetError_GWh"].sum()
    median_error = bat["A_ABS_NetError%"].median()
    count = len(bat)
    
    print(f"Count: {count}")
    print(f"Total ABS Error: {total_abs_error:.2f} GWh")
    print(f"Net Bias: {total_net_error:.2f} GWh (Positive = Over-forecast if PN>Metered)")
    print(f"Median Error %: {median_error:.2f}%")
    
    # Worst offenders (>5% error)
    worst = bat[bat["A_ABS_NetError%"] > 5].sort_values("A_ABS_NetError%", ascending=False)
    print(f"\nWorst Offenders (>5% Error): {len(worst)}")
    if not worst.empty:
        print(worst[["BMU", "A_ABS_NetError%", "ABSError_GWh"]].head(10).to_string(index=False))
        
    # Correlation with capacity?
    # Determine size
    bat["Size"] = bat["installedCapacity_mwh"].replace(0, np.nan).fillna(bat["CapacityCalibrated"])
    # Split into Small (<50) and Large (>50)
    small = bat[bat["Size"] < 50]
    large = bat[bat["Size"] >= 50]
    print(f"\nSmall (<50MW) Median Error: {small['A_ABS_NetError%'].median():.2f}% (Count: {len(small)})")
    print(f"Large (>=50MW) Median Error: {large['A_ABS_NetError%'].median():.2f}% (Count: {len(large)})")


def analyze_wind(df):
    print("\n--- WIND ANALYSIS ---")
    wind = df[df["Fuel"] == "WIND"]
    
    total_abs_error = wind["ABSError_GWh"].sum()
    total_net_error = wind["NetError_GWh"].sum()
    median_error = wind["A_ABS_NetError%"].median()
    
    print(f"Total ABS Error: {total_abs_error:.2f} GWh")
    print(f"Net Bias: {total_net_error:.2f} GWh")
    print(f"Median Error %: {median_error:.2f}%")
    
    # Check for "Optimism Bias"
    # If NetError is consistent positive?
    positive_bias_count = len(wind[wind["NetError"] > 0])
    negative_bias_count = len(wind[wind["NetError"] < 0])
    print(f"Units with Positive Bias (Over-forecast): {positive_bias_count}")
    print(f"Units with Negative Bias (Under-forecast): {negative_bias_count}")
    
    # Outliers
    worst = wind.sort_values("ABSError_GWh", ascending=False).head(5)
    print("\nTop 5 Contributors to Total Error (GWh):")
    print(worst[["BMU", "ABSError_GWh", "A_ABS_NetError%", "NetError_GWh"]].to_string(index=False))

def check_outliers(df, fuels, label):
    print(f"\n--- {label} OUTLIERS ---")
    subset = df[df["Fuel"].isin(fuels)]
    
    if subset.empty:
        print(f"No data for {fuels}")
        return

    # IQR for Error %
    q1 = subset["A_ABS_NetError%"].quantile(0.25)
    q3 = subset["A_ABS_NetError%"].quantile(0.75)
    iqr = q3 - q1
    upper_bound = q3 + 1.5 * iqr
    
    outliers = subset[subset["A_ABS_NetError%"] > upper_bound].sort_values("A_ABS_NetError%", ascending=False)
    print(f"Median Error %: {subset['A_ABS_NetError%'].median():.2f}%")
    print(f"Outlier Threshold (>1.5*IQR): {upper_bound:.2f}%")
    print(f"Number of Outliers: {len(outliers)}")
    
    if not outliers.empty:
        print("Top 10 Outliers by Error %:")
        print(outliers[["BMU", "Fuel", "A_ABS_NetError%", "ABSError_GWh"]].head(10).to_string(index=False))
        
    # Also check high GWh outliers even if % is low?
    # High GWh error
    high_gwh = subset.sort_values("ABSError_GWh", ascending=False).head(5)
    print("\nTop 5 Contributors to Total Error (GWh):")
    print(high_gwh[["BMU", "Fuel", "ABSError_GWh", "A_ABS_NetError%"]].to_string(index=False))

def analyze_others(df):
    print("\n--- OTHERS ANALYSIS ---")
    # "Others" as in the 'Other' category or just everything else?
    # User said "Others ---- these needs to be looked up as it is a mix bag"
    # Likely referring to Fuel="OTHER"
    
    other = df[df["Fuel"] == "OTHER"]
    if other.empty:
        print("No OTHER fuel data.")
        return
        
    total_abs = other["ABSError_GWh"].sum()
    print(f"Total ABS Error: {total_abs:.2f} GWh")
    
    # Try to identify what they are from BMU names?
    # Common prefixes?
    other["Prefix"] = other["BMU"].str.extract(r'^([A-Z0-9_]+?)')
    # Just list top contributors
    worst = other.sort_values("ABSError_GWh", ascending=False).head(10)
    print("Top 10 OTHER Contributors:")
    print(worst[["BMU", "ABSError_GWh", "A_ABS_NetError%"]].to_string(index=False))

def main():
    df = load_data()
    
    # 1. Batteries
    analyze_batteries(df)
    
    # 2. Wind
    analyze_wind(df)
    
    # 3. CCGT, OCGT, BIOMASS, GAS
    thermal_fuels = ["CCGT", "OCGT", "BIOMASS", "GAS"]
    check_outliers(df, thermal_fuels, "THERMAL (CCGT/OCGT/BIO/GAS)")
    
    # 4. Interconnectors
    check_outliers(df, ["INTERCONNECTOR"], "INTERCONNECTORS")
    
    # 5. Others
    analyze_others(df)

if __name__ == "__main__":
    main()
