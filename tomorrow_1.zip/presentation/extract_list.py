
import pandas as pd
import numpy as np

def load_data():
    df = pd.read_csv('inputs/annual_summary_2025.csv')
    df["BMU"] = df["nationalGridBmUnit"].astype(str)
    df["Fuel"] = df["FUEL_I"].astype(str)
    
    # Coerce numerics
    numeric_cols = ["A_ABS_NetError%", "ABSError", "NetError", "installedCapacity_mwh"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
            
    df["ABSError_GWh"] = df["ABSError"] / 1000
    df["NetError_GWh"] = df["NetError"] / 1000
    
    return df

def extract_needs_attention(df):
    results = []
    
    # 1. Batteries > 5% Error
    bat = df[(df["Fuel"] == "BATTERY") & (df["A_ABS_NetError%"] > 5)]
    for _, row in bat.iterrows():
        results.append({
            "BMU": row["BMU"],
            "Fuel": row["Fuel"],
            "Error_Pct": row["A_ABS_NetError%"],
            "Error_GWh": row["ABSError_GWh"],
            "Reason": "Battery with >5% Error"
        })
        
    # 2. Thermal Outliers (IQR Method per Fuel)
    thermal_fuels = ["CCGT", "OCGT", "BIOMASS", "GAS"]
    for fuel in thermal_fuels:
        subset = df[df["Fuel"] == fuel]
        q1 = subset["A_ABS_NetError%"].quantile(0.25)
        q3 = subset["A_ABS_NetError%"].quantile(0.75)
        iqr = q3 - q1
        upper_bound = q3 + 1.5 * iqr
        
        # Filter strictly above threshold AND influential (>1 GWh error) to avoid noise
        outliers = subset[(subset["A_ABS_NetError%"] > upper_bound) & (subset["ABSError_GWh"] > 1.0)]
        for _, row in outliers.iterrows():
            results.append({
                "BMU": row["BMU"],
                "Fuel": row["Fuel"],
                "Error_Pct": row["A_ABS_NetError%"],
                "Error_GWh": row["ABSError_GWh"],
                "Reason": f"{fuel} Statistical Outlier"
            })

    # 3. Interconnector Outliers
    ic = df[df["Fuel"] == "INTERCONNECTOR"]
    q1 = ic["A_ABS_NetError%"].quantile(0.25)
    q3 = ic["A_ABS_NetError%"].quantile(0.75)
    iqr = q3 - q1
    upper_bound = q3 + 1.5 * iqr
    ic_outliers = ic[(ic["A_ABS_NetError%"] > upper_bound) & (ic["ABSError_GWh"] > 1.0)]
    for _, row in ic_outliers.iterrows():
        results.append({
            "BMU": row["BMU"],
            "Fuel": row["Fuel"],
            "Error_Pct": row["A_ABS_NetError%"],
            "Error_GWh": row["ABSError_GWh"],
            "Reason": "Interconnector Outlier"
        })

    # 4. "BGS" / Other Aggregators
    # Logic: Fuel='OTHER' and high error (>20%)
    other = df[(df["Fuel"] == "OTHER") & (df["A_ABS_NetError%"] > 20)]
    for _, row in other.iterrows():
        results.append({
            "BMU": row["BMU"],
            "Fuel": row["Fuel"],
            "Error_Pct": row["A_ABS_NetError%"],
            "Error_GWh": row["ABSError_GWh"],
            "Reason": "Critical 'Other' Category Error"
        })
        
    # 5. Wind Top Error Contributors (Top 20 by GWh volume)
    wind = df[df["Fuel"] == "WIND"].sort_values("ABSError_GWh", ascending=False).head(20)
    for _, row in wind.iterrows():
        results.append({
            "BMU": row["BMU"],
            "Fuel": row["Fuel"],
            "Error_Pct": row["A_ABS_NetError%"],
            "Error_GWh": row["ABSError_GWh"],
            "Reason": "Top Wind Error Contributor"
        })
        
    # Create DataFrame
    res_df = pd.DataFrame(results)
    
    # Remove duplicates (some might trigger multiple rules, unlikely but good practice)
    res_df = res_df.drop_duplicates(subset=["BMU"])
    
    # Sort by Error GWh desc
    res_df = res_df.sort_values("Error_GWh", ascending=False)
    
    # Save
    output_path = '/Users/ivansanz/Desktop/presentation/needs_attention_bmus_2025.csv'
    res_df.to_csv(output_path, index=False)
    print(f"Exported {len(res_df)} BMUs to {output_path}")
    print(res_df.head(10).to_string(index=False))

if __name__ == "__main__":
    extract_needs_attention(load_data())
