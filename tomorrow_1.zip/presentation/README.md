# PN Accuracy Dashboard 2025

## 🎯 Overview
This application analyzes the forecasting accuracy of power generation assets (PN vs Metered) for the year 2025. It is designed to identify "Volume Risk", "Directional Bias", and exceptional performers across the fleet.

## 🚀 Quick Start
This folder is self-contained. To run the dashboard:

1.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

2.  **Run Application**:
    ```bash
    streamlit run pn_accuracy_dashboard.py
    ```

## 📂 Project Structure
*   **`pn_accuracy_dashboard.py`**: The main application code.
*   **`inputs/`**: Contains the Annual and Monthly summary CSVs.
*   **`documentation/`**:
    *   `PN_external.md`: Guide for stakeholders/ops.
    *   `PN_internal.md`: Technical guide for data teams.
    *   `brief.md`: Compliance matrix against the original brief.
    *   `insights.md`: Executive summary of key findings.
    *   `costing_proposal.md`: Proposal for future financial analysis.

## 📊 Key Features
*   **Executive Summary**: High-level KPIs and Fleet Health.
*   **Fleet Overview**: Distribution and Capacity analysis (Bubble Charts).
*   **By Technology**: Deep dive into Fuel types (Efficiency vs Bias).
*   **BMU Explorer**: Detailed monthly trends for specific units.
*   **Attention Needed**: Automated flagging of non-compliant units (>25% error).

