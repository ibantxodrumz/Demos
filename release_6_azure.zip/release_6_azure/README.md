# Physical Notification (PN) Accuracy Dashboard — Release 6

## 🎯 Overview
This enterprise analytical dashboard monitors and assesses the Physical Notification (PN) accuracy of Balancing Mechanism Units (BMUs) across the GB power generation fleet. It evaluates volume risk, directional bias, and compliance tolerances across multiple calendar years (2025, 2026+), with half-hourly Settlement Period (SP) root-cause investigation powered by DuckDB.

---

## 🌟 What's New in Release 6
- **New Tab: Graph BMU (Settlement Period Investigation)**:
  - Granular half-hourly investigation answering *"Why does a BMU perform poorly?"*
  - Interactive Power BI replica in Plotly: **PNLevel**, **BidVolume** (|MW|), **OfferVolume** (|MW|), **MELLevel**, and **Settlement Metered Output** plotted across `timeFrom`.
  - Secondary investigative visuals: **PN vs Metered** divergence, **Net Error Profile** with prominent zero reference line, and **MEL / MIL Operating Limit Envelope**.
  - Default analytical window set to 1 calendar month (`2025-01-01` to `2025-01-31`).
  - Contextual summary cards linking directly to the BMU's annual metrics and compliance status.
- **DuckDB Direct Query Engine (Multi-GB CSV Support)**:
  - High-performance direct querying on `inputs/sp_summary_{year}.csv` without loading full multi-GB files into Python memory.
  - Sub-second filter execution with standard analytical deduplication on `(nationalGridBmUnit, settlementDate, settlementPeriod)`.
  - Graceful absence handling: if the SP file is not present for a year (e.g. 2026), an informative notice is shown while all other 7 tabs remain fully operational.
- **Enhanced "Require Attention" UX**:
  - Replaced the long scrolling stacked list with an **interactive Fuel Type Selector** displaying unit counts (e.g. `All Fuels (553 units)`, `WIND (184 units)`).
  - Compact summary metric cards (Flagged Units, Median Error, Max Error, Total GWh Error) per fuel group.
- **Refined Styling & Typography**:
  - Clean tab headers without emojis/icons.
  - Light pink tab background (`#fdf2f8` / `#fce7f3`) with solid black borders (`1px solid #000000`).
  - High-contrast, bold **Poppins** font (`font-weight: 700` and `800`) across tab labels and navigation.
  - Harmonized NESO corporate color scheme across all Plotly investigation traces (`#0284c7` Sky Blue, `#cf3e9e` Electric Magenta, `#400732` Deep Plum, `#002060` Navy Blue, `#d97706` Warm Amber).
- **Tab Consolidation**:
  - Retired the redundant "Fleet: Capacity" bubble chart tab.
- **Expanded Guardian Test Suite**:
  - 38 automated unit tests covering business rules, DuckDB SP queries, schema coercion, and baseline invariants.

---

## 💻 Windows 11 Setup Guide (VS Code + Conda)

This package is verified and self-contained to run on **Windows 11** using **Conda** and **Visual Studio Code**.

### 1. Prerequisites on Windows 11
* **Miniconda or Anaconda**: [Install Miniconda for Windows](https://docs.conda.io/en/latest/miniconda.html)
* **Visual Studio Code**: [Install VS Code](https://code.visualstudio.com/)
* **Azure CLI (Required for live Azure mode)**: [Install Azure CLI for Windows](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows)

---

### 2. Environment Setup (Terminal in VS Code)
Open VS Code, press ``Ctrl + ` `` to open the integrated terminal (PowerShell or Command Prompt), and run:

```powershell
# 1. Create a clean Conda environment with Python 3.11
conda create -n dashboard python=3.11 -y

# 2. Activate the environment
conda activate dashboard

# 3. Navigate into the release directory
cd release_6_azure

# 4. Install dependencies (includes duckdb)
pip install -r requirements.txt
```

---

### 3. Corporate Azure Authentication (`az login`)
To connect to live corporate Azure Blob Storage, authenticate once via the Azure CLI:

```powershell
az login
```
*(A browser window will open for corporate Single Sign-On / MFA. Once authenticated, the terminal will confirm your subscription).*

---

### 4. Verification: Run Guardian Test Suite
Before launching the application, verify that your environment passes all analytical and schema invariants:

```powershell
python tests/run_tests.py
```
*(All 38 guardian tests will execute and report `✅ ALL TEST SUITES PASSED` in < 2 seconds).*

---

### 5. Running the Dashboard

#### Option A: Live Azure Mode (Default)
With Azure CLI authenticated, launch the application:
```powershell
streamlit run app.py
```
* The sidebar will display `Azure Blob Storage` as the selected data source.
* You can switch between **2025** and **2026** directly from the **Calendar Year** dropdown.

#### Option B: Offline / Local Mode (Zero Cloud Credentials Required)
If operating on an unconfigured machine or without network access:
```powershell
streamlit run app.py
```
* If Azure credentials are not found, the app **automatically falls back** to bundled local inputs (`inputs/annual_summary_2025.csv`, `monthly_summary_2025.csv`, and `sp_summary_2025.csv`).
* Alternatively, select **Local (inputs/ folder)** or **Manual Upload (CSV)** directly in the sidebar.

---

## 📂 Project Structure
```
release_6_azure/
├── app.py                   # Single application entry point
├── constants.py             # Configuration endpoints & multi-year list
├── azure_blob_helper.py     # Azure Blob Storage connector (AzureCliCredential)
├── requirements.txt         # Pinned production dependencies (including duckdb)
├── README.md                # Windows 11 & VS Code execution guide
├── assets/                  # Corporate branding assets
│   ├── neso_logo.jpg        # Embedded corporate logo
│   └── dashboard_reference.png
├── documentation/           # Stakeholder user guide
│   └── How_to.docx
├── inputs/                  # Bundled offline fallback datasets
│   ├── annual_summary_2025.csv
│   ├── monthly_summary_2025.csv
│   ├── sp_summary_2025.csv  # Settlement Period dataset for DuckDB querying
│   └── clean.ipynb
└── tests/                   # Guardian regression test suite
    ├── run_tests.py         # Single-command test runner (exit 0 on pass)
    ├── test_business_rules.py
    ├── test_data_processing.py
    ├── test_azure_and_fallback.py
    ├── test_baseline_invariants.py
    └── test_sp_duckdb.py    # DuckDB SP querying & deduplication tests
```

---

## 🛡️ Guardian Test Architecture

The regression test suite is split across 5 focused modules:
1. `test_business_rules.py` (13 tests): Wind/Solar thresholds ($\pm3\%$ net, $9.4\%$ ABS), other fuel thresholds ($\pm1\%$ net, $2.6\%$ ABS), reason string formatting, and 5 operational error bands.
2. `test_data_processing.py` (5 tests): Multi-year stamping, schema coercion, NaN handling, monthly date parsing, and attention flagging.
3. `test_azure_and_fallback.py` (6 tests): Dynamic multi-year blob path resolution (`pn-accuracy-{year}`), constants verification, and local fallback locator.
4. `test_baseline_invariants.py` (7 tests): Regression audit against canonical baseline datasets ensuring fleet counts, monthly records, and flagged attention units remain invariant.
5. `test_sp_duckdb.py` (7 tests): DuckDB Settlement Period query filtering, deduplication on `(BMU, settlementDate, settlementPeriod)`, absolute Bid/Offer volumes, missing file handling, and dynamic blob paths.
