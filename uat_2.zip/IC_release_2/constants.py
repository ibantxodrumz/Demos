"""
Constants for IC_ENCC Click 2.
Holds non-secret paths, settings, and parsing tokens used across the tool.
"""

# =========================
# Standard Library Imports
# =========================
from pathlib import Path
from dataclasses import dataclass

# ==========
# Root Paths
# ==========
# ==========
# Root Paths
# ==========
# [Refactor] Use portable path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
TOOL_ROOT = Path(__file__).resolve().parent
DATA_ROOT = TOOL_ROOT / "data"

# =======================
# Interconnector Folders
# =======================
IC_PATHS = {
    "IFA": DATA_ROOT / "IFA_UAT_April15",
    # "BritNed": DATA_ROOT / "April_BritNed",
    # "NEMO": DATA_ROOT / "April_NEMO",
}

# ==========================
# Mapping/Outputs/Logs Paths
# ==========================
CP_CODES_FILE = TOOL_ROOT / "data" / "CP_codes.csv"
OUTPUTS_DIR = TOOL_ROOT / "outputs"
LOGS_DIR = TOOL_ROOT / "logs"
OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# ==================
# Processing Settings
# ==================
CAP_HOURS = 6  # awareness lag cap (hours)
TOLERANCE_MW = 5  # trade-vs-PN tolerance (MW)
TIMEZONE_LOCAL = "Europe/London"

# ===================
# Filename Token Regex
# ===================
# For wide PN files that include a date/hour token somewhere in the name.
FILENAME_TOKEN_REGEX = r"(?P<date>\d{8})(?:_(?P<hour>\d{2}))?"

# =================
# Logging Settings
# =================
LOG_LEVEL = "INFO"  # default log level
LOG_FILE_MAX_BYTES = 2_000_000
LOG_FILE_BACKUP_COUNT = 5  # keep up to 5 rotated files


# ============
# Data Classes
# ============
@dataclass(frozen=True)
class RunWindow:
    """RunWindow boundaries as text; used for optional scheduling metadata."""

    start_utc: str  # "YYYY-MM-DD HH:MM:SS"
