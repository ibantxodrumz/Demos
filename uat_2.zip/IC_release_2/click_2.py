"""
Click 2 – Processor for IC_ENCC.
Orchestrates PN ingest, ΔPN, trades reconciliation, classification, and outputs with structured logging.
"""

# =========================
# Standard Library Imports
# =========================
import os
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import numpy as np

# ===========
# App Imports
# ===========
from constants import (
    PROJECT_ROOT,
    TOOL_ROOT,
    DATA_ROOT,
    IC_PATHS,
    CAP_HOURS,
    TOLERANCE_MW,
    TIMEZONE_LOCAL,
    CP_CODES_FILE,
)
from utilities import (
    # Logging & summaries
    setup_logger,
    log_step,
    write_run_summary_txt,
    write_run_summary_json,
    # Receipts & windows
    infer_latest_day_and_pair,
    get_files_in_window,
    token_to_dt,
    # PN helpers
    read_and_melt_pn,
    compute_delta_pn,
    # Forward horizon
    compute_delivery_horizon,
    filter_forward_horizon,
    format_operator_banner,
    # Trades + mapping + matching
    load_cp_mapping,
    fetch_trades,
    match_pn_to_trades,
    # Countertrade + decisions
    opposite_bmu_id,
    detect_countertrade_on_same_ic,
    classify_v2,
    apply_yes3_countertrade_override,
    # Advisory + writers
    build_forward_advisory,
    tidy_advisory_latest,
    summarise_advisory,
    write_csv,
    write_csv_bom,
)


# =========================
# Console Formatting Helper
# =========================
def console_section(logger, title: str, lines: list[str]) -> None:
    """Print a compact, readable block to console via the logger."""
    sep = "-" * 85
    bar = "-" * len(title)
    logger.info(sep)
    logger.info(title)
    logger.info(bar)
    for line in lines:
        logger.info(line)
    logger.info(sep)


def utc_to_local_str(dt, fmt="%H:%M") -> str:
    """Convert a UTC datetime (naive or aware) to a Local Time string."""
    if dt is None:
        return "n/a"
    # Ensure it's a pandas Timestamp
    ts = pd.to_datetime(dt)
    # If naive, assume UTC
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    # Convert and format
    return ts.tz_convert(TIMEZONE_LOCAL).strftime(fmt)


# ==================
# Orchestrator Entry
# ==================
def main():
    """Run Click 2 end-to-end using env toggles; logs steps, writes CSVs and summaries."""
    # -----------------------
    # 1) Setup & Environment
    # -----------------------
    # [UAT] Allow simulated time override
    sim_time_env = os.environ.get("SIMULATED_TIME", "").strip()
    if sim_time_env:
        try:
            start_utc = pd.to_datetime(sim_time_env).tz_localize(None)
            print(f"[UAT] SIMULATED TIME ACTIVE: {start_utc} UTC")
        except Exception as e:
            print(f"[UAT] Failed to parse SIMULATED_TIME '{sim_time_env}': {e}. Using system time.")
            start_utc = datetime.utcnow()
    else:
        start_utc = datetime.utcnow()

    ic = os.environ.get("IC", "IFA")
    FILTER_TRADES_TO_IC_BMUS = (
        os.environ.get("FILTER_TRADES_TO_IC_BMUS", "true").lower() == "true"
    )
    AGGREGATE_MULTI_TRADES = os.environ.get("AGGREGATE_MULTI_TRADES", "sum")
    PRINT_OPERATOR_BANNER = (
        os.environ.get("PRINT_OPERATOR_BANNER", "true").lower() == "true"
    )
    FORWARD_ONLY = os.environ.get("FORWARD_ONLY", "true").lower() == "true"
    ADHOC_PAIRWISE_ONLY = (
        os.environ.get("ADHOC_PAIRWISE_ONLY", "false").lower() == "true"
    )

    # Infer receipt window first so we can name the log file with the chosen day
    folder = IC_PATHS[ic]
    inferred = infer_latest_day_and_pair(Path(folder))
    if inferred is None:
        raise ValueError(
            f"No PN files found in {folder} (ad hoc latest-day inference)."
        )
    start_dt, end_dt, ymd_chosen, tokens_chosen, pair = inferred

    # Configure logger (file name includes IC + chosen day + timestamp)
    logger, log_path, run_id = setup_logger(ic, ymd_chosen)
    logger.info(
        f"Toggles | FORWARD_ONLY={FORWARD_ONLY} | PAIRWISE_ONLY={ADHOC_PAIRWISE_ONLY} | "
        f"FILTER_TRADES_TO_IC_BMUS={FILTER_TRADES_TO_IC_BMUS} | AGGREGATE_MULTI_TRADES={AGGREGATE_MULTI_TRADES}"
    )
    logger.info(
        f"Processing window: {utc_to_local_str(start_dt)} → {utc_to_local_str(end_dt)} (Local) "
        f"for day {pd.to_datetime(ymd_chosen).strftime('%Y-%m-%d')}. "
        f"Files used: {tokens_chosen}"
    )

    # DA-only edge fix: ensure DA included if only receipt present
    if tokens_chosen == ["DA"] and end_dt == start_dt:
        end_dt = start_dt + timedelta(hours=1)

    files_in_window = get_files_in_window(folder, start_dt, end_dt)
    if not files_in_window:
        logger.error("No PN files found in the inferred window!")
        raise ValueError("No PN files found in the inferred window!")

    # --------------------------
    # 2) Melt PN (No Hour Filter)
    # --------------------------
    log_step(logger, "start", "melt_pn", files=len(files_in_window))
    frames = [read_and_melt_pn(f, ic) for _, f in files_in_window]
    pn_all = pd.concat(frames, ignore_index=True)
    pn_all = pn_all[pn_all["BMU_ID"] != "TOTAL_PNS_AT"].copy()
    log_step(logger, "ok", "melt_pn", rows=len(pn_all))

    # ---------------------------------------
    # 3) Forward Deliveries (H+1 → midnight)
    # ---------------------------------------
    log_step(
        logger,
        "start",
        "delivery_horizon",
        forward_only=FORWARD_ONLY,
        pairwise_only=ADHOC_PAIRWISE_ONLY,
    )
    delivery_start, day_end, latest_receipt_hour, h_plus_1 = compute_delivery_horizon(
        ymd_chosen, tokens_chosen, pair, FORWARD_ONLY
    )
    pn_all = filter_forward_horizon(
        pn_all,
        delivery_start,
        day_end,
        pair=pair,
        pairwise_only=ADHOC_PAIRWISE_ONLY,
        ymd_chosen=ymd_chosen,
    )
    logger.info(
        f"Delivery horizon: {delivery_start} → {day_end} UTC | rows={len(pn_all)}"
    )
    log_step(
        logger,
        "ok",
        "delivery_horizon",
        rows=len(pn_all),
        latest_receipt_utc=latest_receipt_hour,
        h_plus_1_utc=h_plus_1,
    )

    # -----------------------------
    # 4) ΔPN (Comparison 1) & H+1
    # -----------------------------
    log_step(logger, "start", "comparison_1")
    pn_with_delta = compute_delta_pn(pn_all)
    has_changes = (pn_with_delta["DeltaPN"].abs() > 0).any()

    h_plus_1_view = pn_with_delta[
        pn_with_delta["DatetimeUTC"].dt.floor("h") == h_plus_1
    ].copy()
    h_plus_1_changed = (h_plus_1_view["DeltaPN"].abs() > 0).any()
    logger.info(
        f"H+1 ({h_plus_1}) — {'CHANGES DETECTED' if h_plus_1_changed else 'no change'}"
    )

    if PRINT_OPERATOR_BANNER:
        chosen_date = pd.Timestamp(ymd_chosen).date()
        banner = format_operator_banner(chosen_date, pair, pn_with_delta, h_plus_1)
        for line in banner.splitlines():
            logger.info(line)

    # ---- Operator Console: Comparison 1 outcome ----
    fw_tmp = pn_with_delta.assign(HourUTC=pn_with_delta["DatetimeUTC"].dt.floor("h"))
    forward_changed = (
        fw_tmp[(fw_tmp["HourUTC"] > h_plus_1) & (fw_tmp["DeltaPN"].abs() > 0)]
        .groupby("HourUTC", as_index=False)
        .size()
        .rename(columns={"size": "changed_rows"})
        .sort_values("HourUTC")
    )

    # Construct a readable list of forward-change hours
    forward_hours_list = []
    if not forward_changed.empty:
        for _, row in forward_changed.iterrows():
            forward_hours_list.append(utc_to_local_str(row["HourUTC"]))

    # ------------------------
    # 5) Trades (API-first 3d)
    # ------------------------
    log_step(logger, "start", "fetch_trades")
    day_start = datetime.strptime(ymd_chosen, "%Y%m%d")
    window_start = day_start - timedelta(days=1)
    window_end = day_start + timedelta(days=2)
    master_dir = TOOL_ROOT / "data" / "trades_master"

    trades = fetch_trades(
        window_start,
        window_end,
        mode="api_first",
        masterfile_dir=master_dir,
        logger=logger,
    )
    if trades is None or trades.empty:
        trades = pd.DataFrame(columns=["BMU_ID", "HourUTC", "Awareness_Start", "Total_Volume", "Trade_Id", "Duplicate_Trade_Error"])
        logger.warning("Trades frame is empty/None.")
    else:
        if "DATETIME_FROM" in trades.columns:
            trades["HourUTC"] = pd.to_datetime(trades["DATETIME_FROM"]).dt.floor("h").dt.tz_localize(None)
        
        # [Ironclad] Detect Duplicate Trade IDs
        if "Trade_Id" in trades.columns:
            dupes = trades[trades["Trade_Id"].duplicated(keep=False)]["Trade_Id"].unique()
            trades["Duplicate_Trade_Error"] = trades["Trade_Id"].isin(dupes)
            if not trades[trades["Duplicate_Trade_Error"]].empty:
                logger.error(f"🚨 DUPLICATE TRADES DETECTED: {list(dupes)}")
        else:
            trades["Duplicate_Trade_Error"] = False
    log_step(logger, "ok", "fetch_trades", rows=len(trades))

    # Early exit when no changes AND no trades
    if not has_changes and trades.empty:
        c1_lines = [
            f"H+1 ({utc_to_local_str(h_plus_1)} Local): No change.",
            "Forward horizon: No PN changes detected and no active trades.",
            "Action: All good until next run (Comparison 2 not executed).",
        ]
        console_section(logger, "COMPARISON 1 — NO CHANGES", c1_lines)

        summary_c1 = (
            pn_with_delta.assign(HourUTC=pn_with_delta["DatetimeUTC"].dt.floor("h"))
            .groupby("HourUTC", as_index=False)
            .size()
            .rename(columns={"size": "PN_rows"})
            .sort_values("HourUTC")
        )
        out_nochg = write_csv(summary_c1, f"Comparison1_no_changes_summary_{ic}.csv")
        logger.info(
            f"NO CHANGES & NO TRADES — All good until next run. Wrote: {out_nochg}"
        )

        # Run summary + footer
        end_utc = datetime.utcnow()
        summary = {
            "run_id": run_id,
            "start_utc": start_utc,
            "end_utc": end_utc,
            "duration_s": (end_utc - start_utc).total_seconds(),
            "latest_receipt_utc": latest_receipt_hour,
            "h_plus_1_utc": h_plus_1,
            "delivery_start_utc": delivery_start,
            "day_end_utc": day_end,
            "c1_status": "NO_CHANGES",
            "c1_message": "No PN changes and no trades detected. Comparison 2 not executed.",
            "trades_rows": 0,
            "on_ic_met_count": 0,
            "across_ic_met_count": 0,
            "countertrade_count": 0,
            "class_tallies": {"YES1": 0, "YES2": 0, "YES3": 0, "NO": 0, "INFO": 0},
            "advisory_hours": [],
            "output_paths": [str(out_nochg)],
        }
        # [UAT Cleanup] Disabled JSON/TXT summaries to reduce clutter
        # txt_path = write_run_summary_txt(ic, ymd_chosen, summary)
        # json_path = write_run_summary_json(ic, ymd_chosen, summary)
        # logger.info(f"Run summary written: {txt_path} | {json_path}")
        logger.info("RUN END | status=NO_CHANGES")

        # ---- Final Summary (console) ----
        final_header = "Final summary for this run"
        final_lines = [
            f"H+1 ({h_plus_1.strftime('%H:%M')} UTC): No change.",
            "No trades found. Stopping.",
        ]
        console_section(logger, final_header, final_lines)
        return

    # There are changes; tell operator exactly why we continue
    if h_plus_1_changed:
        c1_lines = [
            f"H+1 ({utc_to_local_str(h_plus_1)} Local): Changes detected.",
            f"Forward changes detected at: {', '.join(forward_hours_list) if forward_hours_list else 'none'}.",
            "Action: Proceeding to Comparison 2 (trades).",
        ]
        console_section(logger, "COMPARISON 1 — H+1 CHANGES", c1_lines)
    else:
        c1_lines = [
            f"H+1 ({utc_to_local_str(h_plus_1)} Local): No change.",
            f"Forward changes detected at: {', '.join(forward_hours_list) if forward_hours_list else 'none'}.",
            "Action: Proceeding to Comparison 2 (trades).",
        ]
        console_section(logger, "COMPARISON 1 — FORWARD CHANGES", c1_lines)

    cp_map = load_cp_mapping()
    if FILTER_TRADES_TO_IC_BMUS and not trades.empty:
        ic_bmus = set(cp_map["BMU_ID"].dropna().astype(str).unique())
        trades = trades[trades["BMU_ID"].astype(str).isin(ic_bmus)].copy()
        logger.info(f"Filtered trades to IC BMUs: {len(trades)} rows")
        if trades.empty:
            logger.warning(
                "No interconnector BMUs in trades for the 3-day window; On-IC will be zero."
            )

    # ------------------------------
    # 6) On-IC Match & Across-ICs
    # ------------------------------
    log_step(logger, "start", "comparison_2_match_rollup")
    pn_with_delta["HourUTC"] = pd.to_datetime(pn_with_delta["DatetimeUTC"]).dt.floor(
        "h"
    )
    on_ic = match_pn_to_trades(pn_with_delta, trades)
    logger.info(f"On-IC matched rows: {len(on_ic)}")

    tr = trades.copy()
    # HourUTC is already guaranteed to exist from the fetch_trades block
    # [Fix] Don't filter out PN deltas without trade awareness yet,
    # as we need them for company_pn (Across-IC) calculation.
    pn_aw = pn_with_delta.copy()
    pn_aw["HourUTC"] = pn_aw["DatetimeUTC"].dt.floor("h")
    pn_aw = pn_aw.merge(
        tr[["BMU_ID", "HourUTC", "Awareness_Start"]].drop_duplicates(),
        on=["BMU_ID", "HourUTC"],
        how="left",
    )
    # Mask: (No Trade) OR (Aware)
    aware_mask = pn_aw["Awareness_Start"].isna() | (pn_aw["ReceiptUTC"] >= pn_aw["Awareness_Start"])
    pn_aw = pn_aw[aware_mask].copy()
    pn_aw = pn_aw.merge(cp_map[["CP Code", "BMU_ID"]], how="left", on="BMU_ID")

    # Stage 1: Sum deltas per point (same as utilities.match_pn_across_ics)
    pn_aw_pt = (
        pn_aw.groupby(["CP Code", "BMU_ID", "DatetimeUTC", "HourUTC"], as_index=False)
        .agg(Point_Delta=("DeltaPN", "sum"))
    )
    # Stage 2: Sum across BMUs per point, then mean across hour
    pn_aw_pt_cp = (
        pn_aw_pt.groupby(["CP Code", "DatetimeUTC", "HourUTC"], as_index=False)
        .agg(Cp_Point_Delta=("Point_Delta", "sum"))
    )
    company_pn = (
        pn_aw_pt_cp.groupby(["CP Code", "HourUTC"], as_index=False)
        .agg(Total_PN_change_across_ICs=("Cp_Point_Delta", "mean"))
    )
    company_trades = (
        trades.copy()
        .merge(cp_map[["CP Code", "BMU_ID"]], how="left", on="BMU_ID")
        .groupby(["CP Code", "HourUTC"], as_index=False)
        .agg(
            Total_Vol_Traded_across_allICs=(
                "Total_Volume",
                "sum" if AGGREGATE_MULTI_TRADES == "sum" else "first",
            )
        )
    )
    company_rollup = company_trades.merge(
        company_pn, how="left", on=["CP Code", "HourUTC"]
    )
    company_rollup["Total_PN_change_across_ICs"] = company_rollup[
        "Total_PN_change_across_ICs"
    ].fillna(0.0)
    same_sign_company = (np.sign(company_rollup["Total_Vol_Traded_across_allICs"]) == np.sign(company_rollup["Total_PN_change_across_ICs"]))
    company_rollup["All_Trades_Met_company"] = (
        same_sign_company & (company_rollup["Total_PN_change_across_ICs"].abs()
        >= company_rollup["Total_Vol_Traded_across_allICs"].abs() - TOLERANCE_MW)
    )
    log_step(
        logger,
        "ok",
        "comparison_2_match_rollup",
        on_ic_rows=len(on_ic),
        company_rows=len(company_rollup),
    )

    # ----------------------
    # 7) Base + Shortfall MW
    # ----------------------
    base = on_ic.merge(cp_map[["CP Code", "BMU_ID"]], how="left", on="BMU_ID").merge(
        company_rollup, how="left", on=["CP Code", "HourUTC"]
    )
    base["Total_PN_change_across_ICs"] = base["Total_PN_change_across_ICs"].fillna(0.0)
    base["Total_Vol_Traded_across_allICs"] = base[
        "Total_Vol_Traded_across_allICs"
    ].fillna(0.0)
    base["All_Trades_Met_company"] = base["All_Trades_Met_company"].fillna(False)
    base["Trade_met_on_IC"] = base["Trade_met_on_IC"].fillna(False)
    base["Trade_met_across_IC"] = (
        base["All_Trades_Met_company"] | base["Trade_met_on_IC"]
    )
    # [Fix] Ensure PN deltas and trade volumes are populated for classify_v2
    base["Net_PN_Change_MW"] = base["Net_PN_Change_MW"].fillna(0.0)
    base["Total_PN_change_across_ICs"] = base["Total_PN_change_across_ICs"].fillna(0.0)
    base["Shortfall_MW_on_IC"] = (
        0.0
        if base.empty
        else (base["Net_PN_Change_MW"].abs() - base["Total_Volume"].abs()).clip(
            lower=0.0
        )
    )

    # --------------------------------
    # 8) Countertrade on Same IC Flag
    # --------------------------------
    base["Opposite_BMU_ID"] = base["BMU_ID"].astype(str).map(opposite_bmu_id)
    # [Fix] Countertrade logic is already computed in match_pn_to_trades (via on_ic)
    # base["Countertrade_on_same_IC"] = detect_countertrade_on_same_ic(
    #     base, pn_with_delta, trades
    # )
    ct_count = int(base["Countertrade_on_same_IC"].fillna(False).sum())
    logger.info(f"Countertrade detected in {ct_count} trade-hour(s).")

    # --------------------------
    # 9) Classification (v2)
    # --------------------------
    classified = base.copy()
    decisions = classified.apply(lambda r: classify_v2(r, start_utc), axis=1)
    classified["Decision"] = [d[0] for d in decisions]
    classified["Action"] = [d[1] for d in decisions]
    classified = apply_yes3_countertrade_override(classified)

    # ------------------------
    # 10) Persist Main Outputs
    # ------------------------
    # [Refactor] Convert to Local Time for CSV outputs
    classified_local = classified.copy()
    time_cols_to_convert = [
        "DATETIME_FROM",
        "DATETIME_TO",
        "Traded_Date",
        "Trade_Created",
        "Awareness_Start",
    ]
    for c in time_cols_to_convert:
        if c in classified_local.columns:
            classified_local[c] = (
                pd.to_datetime(classified_local[c], utc=True)
                .dt.tz_convert(TIMEZONE_LOCAL)
                .dt.tz_localize(None)
            )

    if "HourUTC" in classified_local.columns:
        classified_local["HourUTC"] = (
            pd.to_datetime(classified_local["HourUTC"], utc=True)
            .dt.tz_convert(TIMEZONE_LOCAL)
            .dt.tz_localize(None)
        )
        classified_local = classified_local.rename(columns={
            "HourUTC": "Local_time",
        })

    trade_out = write_csv(
        classified_local.sort_values(["Local_time", "CP Code", "BMU_ID"]),
        f"Comparison2_trade_results_{ic}.csv",
    )
    hourly_summary = (
        classified_local.assign(
            Not_met_on_IC=~classified_local["Trade_met_on_IC"].fillna(False)
        )
        .groupby("Local_time", as_index=False)
        .agg(
            Trades_total=("BMU_ID", "count"),
            Met_on_IC=("Trade_met_on_IC", lambda s: int(s.fillna(False).sum())),
            Met_across_IC=("Trade_met_across_IC", lambda s: int(s.fillna(False).sum())),
            Not_met_on_IC=("Not_met_on_IC", lambda s: int(s.sum())),
            Shortfall_MW_on_IC_sum=("Shortfall_MW_on_IC", "sum"),
            Countertrade_count=(
                "Countertrade_on_same_IC",
                lambda s: int(s.fillna(False).sum()),
            ),
        )
    )
    class_breakdown = (
        classified_local.groupby(["Local_time", "Decision"])
        .size()
        .unstack(fill_value=0)
        .reset_index()
    )
    summary_out = write_csv(
        hourly_summary.sort_values("Local_time"), f"Comparison2_hourly_summary_{ic}.csv"
    )
    breakdown_out = write_csv(
        class_breakdown.sort_values("Local_time"),
        f"Comparison2_hourly_classification_{ic}.csv",
    )
    logger.info(f"Wrote: {trade_out} | {summary_out} | {breakdown_out}")

    # --------------------------------
    # 11) Forward Advisory (H+1→midnt)
    # --------------------------------
    advisory = build_forward_advisory(pn_with_delta, trades, h_plus_1)
    adv_paths = []
    adv_hours_list = []
    if advisory is not None and not advisory.empty:
        # Convert Advisory to Local
        advisory_local = advisory.copy()
        if "HourUTC" in advisory_local.columns:
            advisory_local["HourUTC"] = (
                pd.to_datetime(advisory_local["HourUTC"], utc=True)
                .dt.tz_convert(TIMEZONE_LOCAL)
                .dt.tz_localize(None)
            )
            advisory_local = advisory_local.rename(columns={"HourUTC": "Local_time"})
        if "ReceiptUTC" in advisory_local.columns:
            advisory_local["ReceiptUTC"] = (
                pd.to_datetime(advisory_local["ReceiptUTC"], utc=True)
                .dt.tz_convert(TIMEZONE_LOCAL)
                .dt.tz_localize(None)
            )
            advisory_local = advisory_local.rename(columns={"ReceiptUTC": "ReceiptLocal"})

        # Logic for tidy_advisory_latest depends on HourUTC. The prompt implies outputs to be Local.
        # But tidy_advisory_latest dedupes. It should work on Local too if columns renamed.
        # Let's convert AFTER tidying to be safe on logic, OR use local.
        # tidy_advisory_latest sorts by HourUTC. If I pass Local, I must rename col first.
        # Actually simplest is to tidy the UTC one, THEN convert.

        advisory_latest = tidy_advisory_latest(advisory)
        advisory_latest_local = advisory_latest.copy()
        if "HourUTC" in advisory_latest_local.columns:
            advisory_latest_local["HourUTC"] = (
                pd.to_datetime(advisory_latest_local["HourUTC"], utc=True)
                .dt.tz_convert(TIMEZONE_LOCAL)
                .dt.tz_localize(None)
            )
            advisory_latest_local = advisory_latest_local.rename(
                columns={"HourUTC": "Local_time"}
            )
        if "ReceiptUTC" in advisory_latest_local.columns:
            advisory_latest_local["ReceiptUTC"] = (
                pd.to_datetime(advisory_latest_local["ReceiptUTC"], utc=True)
                .dt.tz_convert(TIMEZONE_LOCAL)
                .dt.tz_localize(None)
            )
            advisory_latest_local = advisory_latest_local.rename(
                columns={"ReceiptUTC": "ReceiptLocal"}
            )

        out_adv = write_csv_bom(
            advisory_latest_local, f"Forward_Trade_Advisory_{ic}.csv"
        )
        adv_paths.append(str(out_adv))
        adv_sum = summarise_advisory(advisory_latest)
        for _, row in adv_sum.iterrows():
            logger.info(
                f"ADVISORY {utc_to_local_str(row['HourUTC'])} Local: {int(row['BMUs_affected'])} BMUs | Sum ΔPN {float(row['Total_DeltaPN_MW']):.1f} MW"
            )
            adv_hours_list.append(utc_to_local_str(row["HourUTC"]))
        logger.info(f"Forward Trade Advisory written: {out_adv}")
    else:
        logger.info("No advisory data to write.")

    # ---------------------
    # 12) Run Summary & End
    # ---------------------
    end_utc = datetime.utcnow()
    duration_s = (end_utc - start_utc).total_seconds()

    # Classification tallies (safe fallback to avoid {})
    tallies = (
        classified["Decision"]
        .value_counts()
        .reindex(["YES1", "YES2", "YES3", "NO", "INFO"], fill_value=0)
        .to_dict()
    )

    summary = {
        "run_id": run_id,
        "start_utc": start_utc,
        "end_utc": end_utc,
        "duration_s": duration_s,
        "latest_receipt_utc": latest_receipt_hour,
        "h_plus_1_utc": h_plus_1,
        "delivery_start_utc": delivery_start,
        "day_end_utc": day_end,
        "c1_status": "FORWARD_CHANGES" if not h_plus_1_changed else "H_PLUS_1_CHANGES",
        "c1_message": (
            "H+1 clean; forward changes detected — proceeded to Comparison 2."
            if not h_plus_1_changed
            else "H+1 changes detected — proceeded to Comparison 2."
        ),
        "trades_rows": int(len(trades)),
        "on_ic_met_count": int(base["Trade_met_on_IC"].fillna(False).sum()),
        "across_ic_met_count": int(base["Trade_met_across_IC"].fillna(False).sum()),
        "countertrade_count": ct_count,
        "class_tallies": tallies,
        "advisory_hours": adv_hours_list,
        "output_paths": [
            str(trade_out),
            str(summary_out),
            str(breakdown_out),
            *adv_paths,
        ],
    }
    # [UAT Cleanup] Disabled JSON/TXT summaries to reduce clutter
    # txt_path = write_run_summary_txt(ic, ymd_chosen, summary)
    # json_path = write_run_summary_json(ic, ymd_chosen, summary)
    # logger.info(f"Run summary written: {txt_path} | {json_path}")
    logger.info("RUN END | status=COMPLETED")

    # ---- Final Summary (console) ----
    # Build Run context line
    run_context = (
        f"Run context: IC={ic} | Day={pd.to_datetime(ymd_chosen).strftime('%Y-%m-%d')} | "
        f"Latest receipt={utc_to_local_str(latest_receipt_hour)} Local | H+1={utc_to_local_str(h_plus_1)} Local | "
        f"Delivery={utc_to_local_str(delivery_start)}→{utc_to_local_str(day_end)} Local"
    )

    final_header = "Final summary for this run"
    final_lines = [
        run_context,
        "Comparison 1:",
        f"H+1 ({utc_to_local_str(h_plus_1)} Local): {'Changes detected.' if h_plus_1_changed else 'No change.'}",
        f"Forward changes detected at: {', '.join(forward_hours_list) if forward_hours_list else 'none'}.",
        "Proceeding to Comparison 2 (trades).",  # we only reach here when has_changes=True
    ]

    if classified.empty:
        final_lines += [
            "",
            "Comparison 2 (no matches):",
            "No trade-hour matches found for classification (possible awareness/BMU mapping issue).",
            f"Forward PN Advisory produced for hours: {', '.join(adv_hours_list) if adv_hours_list else 'none'}.",
            "Review advisory and trading coverage.",
        ]
    else:
        final_lines += [
            "",
            "Comparison 2 (results):",
            "Trade-hour matches classified.",
            "Tallies: " + ", ".join(f"{k}={v}" for k, v in tallies.items()),
            f"Countertrades: {ct_count}.",
        ]

    console_section(logger, final_header, final_lines)


if __name__ == "__main__":
    main()
