# Interconnector Position Reconciliation Tool - Release 2

This tool reconciles Interconnector Physical Notifications (PNs) with Traded volumes. It identifies discrepancies, classifies them (YES1, YES2, YES3, NO, INFO, DATA_ERROR), and provides recommended actions for the operator.

## Prerequisites
- **Python 3.9 or higher** (Ensure `python --version` returns 3.9+)
- **Internet Access** (For fetching trades from the enTrader API)

## Installation & Setup

1. **Unzip** the release folder to a permanent location on your computer.
2. **Setup Dependencies**:
   Open a terminal/command prompt in the folder and run:
   ```bash
   pip install -r requirements.txt
   ```
3. **Configure Environment**:
   - Rename `.env.example` to `.env`.
   - Open `.env` in a text editor and provide your `ENTRADER_API_KEY`.
   - If behind a corporate proxy, uncomment and set `HTTPS_PROXY`.

## How to Run
Run the tool using the following command:
```bash
python click_2.py
```

## Outputs
All results are saved in the `outputs/` folder:
- **`Comparison2_trade_results_*.csv`**: Detailed trade-by-trade classification and recommended actions.
- **`Comparison2_hourly_summary_*.csv`**: Hourly aggregate of matches and shortfalls.
- **`Forward_Trade_Advisory_*.csv`**: Early warning for PN changes that don't have trades yet.
- **Logs**: Detailed execution logic is saved in the `logs/` directory.

For a detailed explanation of all columns, see **[OUTPUT_LEGEND.md](OUTPUT_LEGEND.md)**.

## What's new in Release 2 (Ironclad)
- **UK Local Time**: All terminal logs and CSVs now use Local Time.
- **Noise Floor**: Untraded PN moves below 50MW no longer trigger breach alerts.
- **Data Quality**: Explicit flagging for Duplicate Trades, Missing Mappings, and Extreme Volumes (>2000MW).
- **Consolidated Advisory**: A single "Tidy" view showing the latest updates per hour.
- **Schema Guard**: Validates PN files and API responses for expected formats.
