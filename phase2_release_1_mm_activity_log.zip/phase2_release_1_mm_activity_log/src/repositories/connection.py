import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, Optional, Union
from src.config.settings import DATABASE_MODE, DEFAULT_DB_PATH
from src.repositories import azure_connection


def get_connection(db_path: Optional[Union[Path, str]] = None) -> Any:
    # 1. Explicit db_path override (used in unit tests / specific test fixtures)
    if db_path:
        target_path = Path(db_path)
        if target_path.name != ":memory:" and not target_path.exists():
            raise FileNotFoundError(f"SQLite database file not found at '{target_path}'.")
        conn = sqlite3.connect(target_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    # 2. Primary Production Mode: Azure SQL Database connection
    if DATABASE_MODE == "azure":
        return azure_connection.get_azure_connection()

    # 3. Local SQLite Mode
    elif DATABASE_MODE == "sqlite":
        target_path = Path(DEFAULT_DB_PATH)
        if not target_path.exists():
            raise FileNotFoundError(f"SQLite database file not found at '{target_path}'.")
        conn = sqlite3.connect(target_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    else:
        raise ValueError(
            f"Unsupported DATABASE_MODE '{DATABASE_MODE}'. Must be 'azure' or 'sqlite'."
        )


@contextmanager
def get_db(db_path: Optional[Union[Path, str]] = None) -> Generator[Any, None, None]:
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
