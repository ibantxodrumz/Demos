from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator
from src.config.settings import CONTROLLED_ACTIONS, CONTROLLED_STATUSES


class ActivityLogModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    activity_log_id: str = Field(..., alias="ACTIVITY_LOG_ID")
    workstream_name: Optional[str] = Field("IMPORT_CONSTRAINTS", alias="WORKSTREAM_NAME")
    alert_unique_id: str = Field(..., alias="ALERT_UNIQUE_ID")
    bmu_id: str = Field(..., alias="BMU_ID")
    party_name: Optional[str] = Field(None, alias="PARTY_NAME")
    parameter_breached: str = Field(..., alias="PARAMETER_BREACHED")
    raise_date: str = Field(..., alias="RAISE_DATE")
    start_date: str = Field(..., alias="START_DATE")
    end_date: str = Field(..., alias="END_DATE")
    person_raising: Optional[str] = Field(None, alias="PERSON_RAISING")
    notification_source: str = Field(..., alias="NOTIFICATION_SOURCE")
    action_taken: Optional[str] = Field(None, alias="ACTION_TAKEN")
    analysis_status: Optional[str] = Field(None, alias="ANALYSIS_STATUS")
    info_for_analyst: Optional[str] = Field(None, alias="INFO_FOR_ANALYST")
    review_comments: Optional[str] = Field(None, alias="REVIEW_COMMENTS")
    created_datetime: str = Field(..., alias="CREATED_DATETIME")
    updated_datetime: Optional[str] = Field(None, alias="UPDATED_DATETIME")


class SaveReviewRequest(BaseModel):
    alert_unique_id: str
    action_taken: str
    analysis_status: str
    review_comments: Optional[str] = ""

    @field_validator("action_taken")
    @classmethod
    def validate_action(cls, v: str) -> str:
        if v not in CONTROLLED_ACTIONS:
            raise ValueError(f"Invalid action_taken '{v}'. Must be one of: {CONTROLLED_ACTIONS}")
        return v

    @field_validator("analysis_status")
    @classmethod
    def validate_status(cls, v: str) -> str:
        if v not in CONTROLLED_STATUSES:
            raise ValueError(
                f"Invalid analysis_status '{v}'. Must be one of: {CONTROLLED_STATUSES}"
            )
        return v

    @field_validator("review_comments")
    @classmethod
    def validate_comments(cls, v: Optional[str]) -> str:
        comments_str = (v or "").strip()
        if len(comments_str) <= 5:
            raise ValueError(
                "Review comments must be more than 5 characters long (avoid placeholder text like 'ok' or 'djdje')."
            )
        return comments_str

