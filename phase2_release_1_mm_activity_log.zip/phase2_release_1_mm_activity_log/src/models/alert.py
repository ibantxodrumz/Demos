from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class AlertModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    unique_id: str = Field(..., alias="UNIQUE_ID")
    bmu_id: str = Field(..., alias="BMU_ID")
    fuel_type: Optional[str] = Field(None, alias="FUEL_TYPE")
    counterparty: Optional[str] = Field(None, alias="COUNTERPARTY")
    start_gmt: str = Field(..., alias="START_GMT")
    end_gmt: str = Field(..., alias="END_GMT")
    start_local: Optional[str] = Field(None, alias="START_LOCAL")
    end_local: Optional[str] = Field(None, alias="END_LOCAL")
    duration_min: int = Field(..., alias="DURATION_MIN")
    count_sp: int = Field(..., alias="COUNT_SP")

    # Linked activity log fields
    activity_log_id: Optional[str] = Field(None, alias="ACTIVITY_LOG_ID")
    workstream_name: Optional[str] = Field("IMPORT_CONSTRAINTS", alias="WORKSTREAM_NAME")
    parameter_breached: Optional[str] = Field(None, alias="PARAMETER_BREACHED")
    raise_date: Optional[str] = Field(None, alias="RAISE_DATE")
    person_raising: Optional[str] = Field(None, alias="PERSON_RAISING")
    notification_source: Optional[str] = Field(None, alias="NOTIFICATION_SOURCE")
    action_taken: Optional[str] = Field(None, alias="ACTION_TAKEN")
    analysis_status: Optional[str] = Field(None, alias="ANALYSIS_STATUS")
    info_for_analyst: Optional[str] = Field(None, alias="INFO_FOR_ANALYST")
    review_comments: Optional[str] = Field(None, alias="REVIEW_COMMENTS")
    created_datetime: Optional[str] = Field(None, alias="CREATED_DATETIME")
    updated_datetime: Optional[str] = Field(None, alias="UPDATED_DATETIME")
