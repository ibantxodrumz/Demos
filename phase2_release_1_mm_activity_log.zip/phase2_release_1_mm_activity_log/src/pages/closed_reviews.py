import dash
from dash import dash_table, dcc, html, Input, Output, State, callback
import pandas as pd

from src.repositories import activity_log_repository
from src.services import alert_service

dash.register_page(
    __name__, path="/closed-reviews", title="Closed Reviews - Market Monitoring Platform"
)

time_opts = alert_service.get_available_time_options()

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Inter, Segoe UI, sans-serif"},
    children=[
        # Title Banner
        html.Div(
            style={"marginBottom": "20px"},
            children=[
                html.H2(
                    "Closed Reviews — Historical View & Audit Trail",
                    className="neso-page-title",
                ),
                html.P(
                    "Historical audit view of all closed alert reviews, audit trails, and persisted analyst decision remarks.",
                    className="neso-page-subtitle",
                ),
            ],
        ),
        # Controls Card: Workstream Domain & Date Period Selection
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "20px",
            },
            children=[
                # Workstream Domain Selector
                html.Div(
                    style={"marginBottom": "16px"},
                    children=[
                        html.Label(
                            "Active Workstream Domain:",
                            style={
                                "fontWeight": "600",
                                "fontSize": "13px",
                                "marginBottom": "6px",
                                "display": "block",
                            },
                        ),
                        dcc.Dropdown(
                            id="closed-workstream-domain",
                            options=[
                                {
                                    "label": "Import Constraints (Active)",
                                    "value": "import_constraints",
                                },
                                {"label": "TBC (Upcoming)", "value": "tbc_1", "disabled": True},
                                {"label": "TBC (Upcoming)", "value": "tbc_2", "disabled": True},
                            ],
                            value="import_constraints",
                            clearable=False,
                            style={"width": "100%"},
                        ),
                    ],
                ),
                # Quick Presets Bar
                html.Div(
                    style={
                        "display": "flex",
                        "alignItems": "center",
                        "gap": "12px",
                        "marginBottom": "16px",
                        "flexWrap": "wrap",
                    },
                    children=[
                        html.Span(
                            "Quick Time Presets:",
                            style={"fontSize": "13px", "fontWeight": "600", "color": "#475569"},
                        ),
                        html.Button(
                            "All History / Entire Period",
                            id="btn-closed-select-all",
                            n_clicks=0,
                            style={
                                "backgroundColor": "#fdf4fa",
                                "color": "#4e0038",
                                "border": "1px solid #4e0038",
                                "padding": "6px 14px",
                                "borderRadius": "6px",
                                "fontWeight": "600",
                                "fontSize": "12px",
                                "cursor": "pointer",
                            },
                        ),
                    ],
                ),
                # Time Controls Row
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))",
                        "gap": "16px",
                        "marginBottom": "16px",
                    },
                    children=[
                        html.Div(
                            [
                                html.Label(
                                    "Start Date:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="closed-picker-start-date",
                                    min_date_allowed=time_opts["min_date"],
                                    max_date_allowed=time_opts["max_date"],
                                    initial_visible_month="2026-02-02",
                                    date="2026-02-02",
                                    display_format="YYYY-MM-DD",
                                    style={"width": "100%"},
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "End Date:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="closed-picker-end-date",
                                    min_date_allowed=time_opts["min_date"],
                                    max_date_allowed=time_opts["max_date"],
                                    initial_visible_month="2026-02-08",
                                    date="2026-02-08",
                                    display_format="YYYY-MM-DD",
                                    style={"width": "100%"},
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Select Any Single Day:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="closed-picker-single-day",
                                    min_date_allowed=time_opts["min_date"],
                                    max_date_allowed=time_opts["max_date"],
                                    placeholder="Pick a Single Day...",
                                    display_format="YYYY-MM-DD",
                                    style={"width": "100%"},
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Select Whole Week:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-dropdown-select-week",
                                    options=time_opts["weeks"],
                                    placeholder="Select a Week Preset...",
                                    clearable=True,
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Select Whole Month:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-dropdown-select-month",
                                    options=time_opts["months"],
                                    placeholder="Select a Month Preset...",
                                    clearable=True,
                                ),
                            ]
                        ),
                    ],
                ),
                # Active Window Indicator Badge
                html.Div(id="closed-active-window-badge", style={"marginBottom": "16px"}),
                # Secondary Filters Row
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))",
                        "gap": "16px",
                    },
                    children=[
                        html.Div(
                            [
                                html.Label(
                                    "Filter BMU:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-filter-bmu", placeholder="All BMUs", clearable=True
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Filter Party:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-filter-party",
                                    placeholder="All Parties",
                                    clearable=True,
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Filter Fuel Type:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-filter-fuel",
                                    placeholder="All Fuel Types",
                                    clearable=True,
                                ),
                            ]
                        ),
                        html.Div(
                            [
                                html.Label(
                                    "Filter Action Taken:",
                                    style={
                                        "fontSize": "12px",
                                        "fontWeight": "600",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="closed-filter-action",
                                    placeholder="All Actions",
                                    clearable=True,
                                ),
                            ]
                        ),
                    ],
                ),
            ],
        ),
        # KPI Summary Cards Container
        html.Div(
            id="closed-summary-metrics-container",
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(200px, 1fr))",
                "gap": "16px",
                "marginBottom": "20px",
            },
        ),
        # Closed Reviews Table Container
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
            },
            children=[
                html.H3(
                    "Historical Closed Reviews Archive",
                    style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                ),
                html.Div(id="closed-reviews-table-container"),
            ],
        ),
    ],
)


# Preset Handlers
@callback(
    Output("closed-picker-start-date", "date"),
    Output("closed-picker-end-date", "date"),
    Input("btn-closed-select-all", "n_clicks"),
    Input("closed-picker-single-day", "date"),
    Input("closed-dropdown-select-week", "value"),
    Input("closed-dropdown-select-month", "value"),
    State("operational-date-store", "data"),
    prevent_initial_call=False,
)
def handle_closed_review_dates(all_clicks, single_day_val, week_val, month_val, store_data):
    ctx = dash.callback_context
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0] if ctx.triggered else ""
    if triggered_id == "btn-closed-select-all" and all_clicks:
        return "2026-01-01", "2026-06-30"
    elif triggered_id == "closed-picker-single-day" and single_day_val:
        day_str = str(single_day_val)[:10]
        return day_str, day_str
    elif triggered_id == "closed-dropdown-select-week" and week_val and "|" in str(week_val):
        parts = str(week_val).split("|")
        return parts[0], parts[1]
    elif triggered_id == "closed-dropdown-select-month" and month_val and "|" in str(month_val):
        parts = str(month_val).split("|")
        return parts[0], parts[1]
    elif store_data and "start_date" in store_data and "end_date" in store_data:
        return store_data["start_date"], store_data["end_date"]
    return "2026-02-02", "2026-02-08"


@callback(
    Output("operational-date-store", "data", allow_duplicate=True),
    Input("closed-picker-start-date", "date"),
    Input("closed-picker-end-date", "date"),
    prevent_initial_call="initial_duplicate",
)
def update_closed_date_store(start_d, end_d):
    if start_d and end_d:
        return {"start_date": str(start_d)[:10], "end_date": str(end_d)[:10]}
    return dash.no_update


# Main Query Callback
@callback(
    Output("closed-active-window-badge", "children"),
    Output("closed-reviews-table-container", "children"),
    Output("closed-filter-bmu", "options"),
    Output("closed-filter-party", "options"),
    Output("closed-filter-fuel", "options"),
    Output("closed-filter-action", "options"),
    Output("closed-summary-metrics-container", "children"),
    Input("closed-picker-start-date", "date"),
    Input("closed-picker-end-date", "date"),
    Input("closed-filter-bmu", "value"),
    Input("closed-filter-party", "value"),
    Input("closed-filter-fuel", "value"),
    Input("closed-filter-action", "value"),
)
def update_closed_reviews(start_date, end_date, bmu_f, party_f, fuel_f, action_f):
    if not start_date or not end_date:
        return (
            html.Div("Select valid date window."),
            html.Div("No dates selected."),
            [],
            [],
            [],
            [],
            [],
        )

    start_str = str(start_date)[:10]
    end_str = str(end_date)[:10]

    try:
        d1 = pd.to_datetime(start_str)
        d2 = pd.to_datetime(end_str)
        num_days = (d2 - d1).days + 1
    except Exception:
        num_days = 1

    badge = html.Div(
        style={
            "backgroundColor": "#fdf4fa",
            "border": "1px solid #4e0038",
            "borderRadius": "8px",
            "padding": "10px 16px",
            "fontWeight": "600",
            "color": "#4e0038",
            "fontSize": "13px",
            "display": "flex",
            "alignItems": "center",
            "gap": "12px",
            "flexWrap": "wrap",
        },
        children=[
            html.Span("Active Review Window:"),
            html.Div(
                [
                    html.Span("Start Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                    html.Strong(start_str, style={"color": "#4e0038", "fontSize": "14px"}),
                ],
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "4px 10px",
                    "borderRadius": "6px",
                    "border": "1px solid #cbd5e1",
                },
            ),
            html.Span("───▶", style={"color": "#94a3b8"}),
            html.Div(
                [
                    html.Span("End Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                    html.Strong(end_str, style={"color": "#4e0038", "fontSize": "14px"}),
                ],
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "4px 10px",
                    "borderRadius": "6px",
                    "border": "1px solid #cbd5e1",
                },
            ),
            html.Span(
                f"({num_days} Day{'s' if num_days != 1 else ''} selected)",
                style={"color": "#64748b", "fontWeight": "500"},
            ),
        ],
    )

    all_closed_reviews = activity_log_repository.get_closed_reviews(
        start_date=start_str,
        end_date=end_str,
    )

    alerts = [
        alert
        for alert in all_closed_reviews
        if (not bmu_f or alert.get("BMU_ID") == bmu_f)
        and (not party_f or alert.get("COUNTERPARTY") == party_f)
        and (not fuel_f or alert.get("FUEL_TYPE") == fuel_f)
        and (not action_f or alert.get("ACTION_TAKEN") == action_f)
    ]

    for alert in alerts:
        alert["DISPLAY_STATUS"] = "Closed"

    summary = {
        "count": len(alerts),
        "autoclose_count": sum(
            (alert.get("ACTION_TAKEN") or "").lower() == "autoclose" for alert in alerts
        ),
        "monitor_count": sum(
            "monitor" in (alert.get("ACTION_TAKEN") or "").lower() for alert in alerts
        ),
        "escalated_count": sum(
            "escalat" in (alert.get("ACTION_TAKEN") or "").lower() for alert in alerts
        ),
    }

    opts = {
        "bmus": sorted({alert["BMU_ID"] for alert in all_closed_reviews if alert.get("BMU_ID")}),
        "parties": sorted(
            {alert["COUNTERPARTY"] for alert in all_closed_reviews if alert.get("COUNTERPARTY")}
        ),
        "fuels": sorted(
            {alert["FUEL_TYPE"] for alert in all_closed_reviews if alert.get("FUEL_TYPE")}
        ),
        "actions": sorted(
            {alert["ACTION_TAKEN"] for alert in all_closed_reviews if alert.get("ACTION_TAKEN")}
        ),
    }

    cards = [
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #16a34a",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "Total Closed Reviews",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#16a34a"},
                ),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "AutoClose Count",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["autoclose_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"},
                ),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #2563eb",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "Monitor Ongoing",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["monitor_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"},
                ),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #d97706",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "Escalated Count",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["escalated_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"},
                ),
            ],
        ),
    ]

    if not alerts:
        table_el = html.Div(
            "No Closed reviews found for the selected window and filter criteria.",
            style={"color": "#64748b", "fontStyle": "italic", "padding": "20px 0"},
        )
        return badge, table_el, opts["bmus"], opts["parties"], opts["fuels"], opts["actions"], cards

    table_data = []
    for a in alerts:
        uid = a.get("UNIQUE_ID")
        table_data.append(
            {
                "UNIQUE_ID": uid,
                "BMU_ID": a.get("BMU_ID"),
                "COUNTERPARTY": a.get("COUNTERPARTY"),
                "FUEL_TYPE": a.get("FUEL_TYPE"),
                "START_LOCAL": a.get("START_LOCAL"),
                "END_LOCAL": a.get("END_LOCAL"),
                "DURATION_MIN": a.get("DURATION_MIN"),
                "COUNT_SP": a.get("COUNT_SP"),
                "DISPLAY_STATUS": a.get("DISPLAY_STATUS", "Closed"),
                "ACTION_TAKEN": a.get("ACTION_TAKEN"),
                "PERSON_RAISING": a.get("PERSON_RAISING"),
                "REVIEW_COMMENTS": a.get("REVIEW_COMMENTS"),
                "UPDATED_DATETIME": a.get("UPDATED_DATETIME"),
                "EVIDENCE_LINK": f"/analytical-support?unique_id={uid}",
            }
        )

    table_el = dash_table.DataTable(
        columns=[
            {"name": "BMU ID", "id": "BMU_ID"},
            {"name": "Party Name", "id": "COUNTERPARTY"},
            {"name": "Fuel Type", "id": "FUEL_TYPE"},
            {"name": "Start Time (Local)", "id": "START_LOCAL"},
            {"name": "End Time (Local)", "id": "END_LOCAL"},
            {"name": "Duration (min)", "id": "DURATION_MIN"},
            {"name": "SPs", "id": "COUNT_SP"},
            {"name": "Status", "id": "DISPLAY_STATUS"},
            {"name": "Action Taken", "id": "ACTION_TAKEN"},
            {"name": "Person Raising", "id": "PERSON_RAISING"},
            {"name": "Review Comments", "id": "REVIEW_COMMENTS"},
            {"name": "Closed Datetime", "id": "UPDATED_DATETIME"},
        ],
        data=table_data,
        style_table={"overflowX": "auto", "borderRadius": "8px", "border": "1px solid #e2e8f0"},
        style_header={
            "backgroundColor": "#edf1f7",
            "color": "#4e0038",
            "fontWeight": "700",
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "borderBottom": "2px solid #cbd5e1",
        },
        style_cell={
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "fontFamily": "Inter, Segoe UI, sans-serif",
            "whiteSpace": "normal",
            "height": "auto",
            "color": "#1e293b",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#f8fafc"},
            {"if": {"column_id": "DISPLAY_STATUS"}, "color": "#16a34a", "fontWeight": "700"},
        ],
        page_size=15,
    )

    return badge, table_el, opts["bmus"], opts["parties"], opts["fuels"], opts["actions"], cards
