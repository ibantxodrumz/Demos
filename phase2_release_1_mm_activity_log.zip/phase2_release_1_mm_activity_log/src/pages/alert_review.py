import dash
from dash import dcc, html, Input, Output, State, callback, ctx
import pandas as pd
from typing import Optional

from src.components.alert_table import create_alert_table
from src.config.settings import (
    CONTROLLED_ACTIONS,
    CONTROLLED_STATUSES,
    DEFAULT_NOTIFICATION_SOURCE,
    DEFAULT_PARAMETER_BREACHED,
    LOCAL_ANALYST_NAME,
)
from src.services import activity_log_service, alert_service, analytics_service
from src.utils.bmrs_links import get_bmrs_bmu_url, get_bmrs_remit_url

dash.register_page(__name__, path="/", title="Alert Review - Market Monitoring Platform")

TIME_OPTIONS = alert_service.get_available_time_options()

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Segoe UI, sans-serif"},
    children=[
        # Title & Context
        html.Div(
            style={"marginBottom": "24px"},
            children=[
                html.H2(
                    "Operational Alert Queue & Decision Capture",
                    className="neso-page-title",
                ),
                html.P(
                    "Review Market Monitoring alerts by selecting dates, whole weeks or whole months, investigate evidence, and persist decisions to SQL.",
                    className="neso-page-subtitle",
                ),
            ],
        ),
        # Controls & Date Pickers Card
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "20px",
            },
            children=[
                # Top Workstream Selector
                html.Div(
                    style={"marginBottom": "16px"},
                    children=[
                        html.Label(
                            "Active Workstream Domain:",
                            style={
                                "fontWeight": "600",
                                "fontSize": "13px",
                                "marginBottom": "6px",
                                "display": "block",
                                "color": "#4e0038",
                            },
                        ),
                        dcc.Dropdown(
                            id="select-workstream",
                            options=[
                                {
                                    "label": "Import Constraints (Active)",
                                    "value": "IMPORT_CONSTRAINTS",
                                },
                                {
                                    "label": "TBC (Upcoming)",
                                    "value": "WORKSTREAM_2_TBC",
                                    "disabled": True,
                                },
                                {
                                    "label": "TBC (Upcoming)",
                                    "value": "WORKSTREAM_3_TBC",
                                    "disabled": True,
                                },
                                {
                                    "label": "TBC (Upcoming)",
                                    "value": "WORKSTREAM_4_TBC",
                                    "disabled": True,
                                },
                            ],
                            value="IMPORT_CONSTRAINTS",
                            clearable=False,
                            style={"fontSize": "13px"},
                        ),
                    ],
                ),
                # Period Controls Grid: Start Date, End Date, Select Whole Week, Select Whole Month
                html.Div(
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(auto-fit, minmax(210px, 1fr))",
                        "gap": "16px",
                        "alignItems": "flex-end",
                        "marginBottom": "16px",
                    },
                    children=[
                        # 1. Start Date Input
                        html.Div(
                            children=[
                                html.Label(
                                    "Start Date:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#4e0038",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="picker-start-date",
                                    date="2026-02-02",
                                    display_format="YYYY-MM-DD",
                                    min_date_allowed="2026-01-01",
                                    max_date_allowed="2026-06-30",
                                    style={"width": "100%", "fontSize": "13px"},
                                ),
                            ],
                        ),
                        # 2. End Date Input
                        html.Div(
                            children=[
                                html.Label(
                                    "End Date:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#4e0038",
                                    },
                                ),
                                dcc.DatePickerSingle(
                                    id="picker-end-date",
                                    date="2026-02-08",
                                    display_format="YYYY-MM-DD",
                                    min_date_allowed="2026-01-01",
                                    max_date_allowed="2026-06-30",
                                    style={"width": "100%", "fontSize": "13px"},
                                ),
                            ],
                        ),
                        # 3. Select Whole Week Preset Dropdown
                        html.Div(
                            children=[
                                html.Label(
                                    "Select Whole Week:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#64748b",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="dropdown-select-week",
                                    options=[{"label": "Select a Week Preset...", "value": "none"}]
                                    + [
                                        {"label": w["label"], "value": w["value"]}
                                        for w in TIME_OPTIONS["weeks"]
                                    ],
                                    value="none",
                                    clearable=False,
                                ),
                            ],
                        ),
                        # 4. Select Whole Month Preset Dropdown
                        html.Div(
                            children=[
                                html.Label(
                                    "Select Whole Month:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "marginBottom": "6px",
                                        "display": "block",
                                        "color": "#64748b",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="dropdown-select-month",
                                    options=[{"label": "Select a Month Preset...", "value": "none"}]
                                    + [
                                        {"label": m["label"], "value": m["value"]}
                                        for m in TIME_OPTIONS["months"]
                                    ],
                                    value="none",
                                    clearable=False,
                                ),
                            ],
                        ),
                    ],
                ),
                # Prominent Active Window Summary Banner
                html.Div(id="active-window-badge", style={"marginBottom": "16px"}),
                html.Hr(
                    style={"margin": "16px 0", "border": "none", "borderTop": "1px solid #e2e8f0"}
                ),
                # Filter Dropdowns
                html.Div(
                    style={"display": "flex", "flexWrap": "wrap", "gap": "16px"},
                    children=[
                        html.Div(
                            style={"flex": "1", "minWidth": "160px"},
                            children=[
                                html.Label(
                                    "Filter BMU:", style={"fontSize": "12px", "fontWeight": "600"}
                                ),
                                dcc.Dropdown(
                                    id="filter-bmu", placeholder="All BMUs", clearable=True
                                ),
                            ],
                        ),
                        html.Div(
                            style={"flex": "1", "minWidth": "160px"},
                            children=[
                                html.Label(
                                    "Filter Party:", style={"fontSize": "12px", "fontWeight": "600"}
                                ),
                                dcc.Dropdown(
                                    id="filter-party", placeholder="All Parties", clearable=True
                                ),
                            ],
                        ),
                        html.Div(
                            style={"flex": "1", "minWidth": "160px"},
                            children=[
                                html.Label(
                                    "Filter Fuel Type:",
                                    style={"fontSize": "12px", "fontWeight": "600"},
                                ),
                                dcc.Dropdown(
                                    id="filter-fuel", placeholder="All Fuel Types", clearable=True
                                ),
                            ],
                        ),
                        html.Div(
                            style={"flex": "1", "minWidth": "160px"},
                            children=[
                                html.Label(
                                    "Filter Status:",
                                    style={"fontSize": "12px", "fontWeight": "600"},
                                ),
                                dcc.Dropdown(
                                    id="filter-status",
                                    options=["Unreviewed", "Open", "Closed", "All"],
                                    value="Unreviewed",
                                    clearable=False,
                                ),
                            ],
                        ),
                    ],
                ),
            ],
        ),
        # Metrics KPI Cards (Pink / White / Pink / White Alternating Pattern)
        html.Div(
            id="summary-metrics-container",
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(200px, 1fr))",
                "gap": "16px",
                "marginBottom": "20px",
            },
        ),
        # Main Queue Table and Decision Panel Grid
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "20px"},
            children=[
                # Left: Alert Queue Table
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3(
                            "Alert Queue (Select row to review)",
                            style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                        ),
                        html.Div(
                            id="alert-table-container",
                            children=[create_alert_table([])],
                        ),
                    ],
                ),
                # Right: Decision Capture & Investigation Panel
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3(
                            "Analyst Decision & Capture",
                            style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                        ),
                        html.Div(id="selected-alert-details-container"),
                        html.Hr(
                            style={
                                "margin": "16px 0",
                                "border": "none",
                                "borderTop": "1px solid #e2e8f0",
                            }
                        ),
                        # Decision Inputs
                        html.Div(
                            children=[
                                html.Label(
                                    "Action Taken:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="input-action-taken",
                                    options=[{"label": a, "value": a} for a in CONTROLLED_ACTIONS],
                                    placeholder="Select Action Taken...",
                                    style={"marginBottom": "14px"},
                                ),
                                html.Label(
                                    "Analysis Status:",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Dropdown(
                                    id="input-analysis-status",
                                    options=[{"label": s, "value": s} for s in CONTROLLED_STATUSES],
                                    placeholder="Select Status...",
                                    style={"marginBottom": "14px"},
                                ),
                                html.Label(
                                    "Review Comments (Human Input):",
                                    style={
                                        "fontWeight": "600",
                                        "fontSize": "13px",
                                        "display": "block",
                                        "marginBottom": "4px",
                                    },
                                ),
                                dcc.Textarea(
                                    id="input-review-comments",
                                    placeholder="Enter human analyst investigation remarks...",
                                    style={
                                        "width": "100%",
                                        "height": "90px",
                                        "padding": "8px",
                                        "borderRadius": "6px",
                                        "borderColor": "#cbd5e1",
                                        "marginBottom": "14px",
                                    },
                                ),
                                dcc.ConfirmDialogProvider(
                                    id="confirm-save-review",
                                    message=(
                                        "Confirm this decision and persist it to Azure SQL?\n\n"
                                        "Please verify the selected alert, action, status and comments."
                                    ),
                                    children=html.Button(
                                        "Confirm & Save Decision",
                                        id="btn-save-review",
                                        n_clicks=0,
                                        className="btn-neso-primary",
                                        style={"width": "100%", "marginBottom": "12px"},
                                    ),
                                ),
                                html.Div(id="save-feedback-container"),
                                html.Hr(
                                    style={
                                        "margin": "14px 0",
                                        "border": "none",
                                        "borderTop": "1px solid #e2e8f0",
                                    }
                                ),
                                # Action / External Links
                                html.Div(
                                    id="investigation-links-container",
                                    style={
                                        "display": "flex",
                                        "flexDirection": "column",
                                        "gap": "8px",
                                    },
                                ),
                            ]
                        ),
                    ],
                ),
            ],
        ),
        # Hidden Stores for State
        dcc.Store(id="store-selected-alert-id"),
        dcc.Store(id="store-refresh-signal", data=0),
    ],
)


# --- Callbacks ---


@callback(
    Output("picker-start-date", "date"),
    Output("picker-end-date", "date"),
    Input("dropdown-select-week", "value"),
    Input("dropdown-select-month", "value"),
    State("operational-date-store", "data"),
    prevent_initial_call=False,
)
def handle_alert_review_dates(week_val, month_val, store_data):
    ctx = dash.callback_context
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0] if ctx.triggered else ""
    if triggered_id == "dropdown-select-week" and week_val and "|" in str(week_val):
        parts = str(week_val).split("|")
        return parts[0], parts[1]
    elif triggered_id == "dropdown-select-month" and month_val and "|" in str(month_val):
        parts = str(month_val).split("|")
        return parts[0], parts[1]
    elif store_data and "start_date" in store_data and "end_date" in store_data:
        return store_data["start_date"], store_data["end_date"]
    return "2026-02-02", "2026-02-08"


@callback(
    Output("operational-date-store", "data", allow_duplicate=True),
    Input("picker-start-date", "date"),
    Input("picker-end-date", "date"),
    prevent_initial_call="initial_duplicate",
)
def update_operational_date_store_from_alert_review(start_d, end_d):
    if start_d and end_d:
        return {"start_date": str(start_d)[:10], "end_date": str(end_d)[:10]}
    return dash.no_update


@callback(
    Output("active-window-badge", "children"),
    Output("alert-review-table", "data"),
    Output("filter-bmu", "options"),
    Output("filter-party", "options"),
    Output("filter-fuel", "options"),
    Output("summary-metrics-container", "children"),
    Output("alert-review-table", "selected_rows"),
    Input("picker-start-date", "date"),
    Input("picker-end-date", "date"),
    Input("filter-bmu", "value"),
    Input("filter-party", "value"),
    Input("filter-fuel", "value"),
    Input("filter-status", "value"),
    Input("store-refresh-signal", "data"),
)
def fetch_and_filter_alerts(start_date, end_date, bmu_f, party_f, fuel_f, status_f, refresh_signal):
    if not start_date or not end_date:
        empty_badge = html.Div(
            "Please select valid Start Date and End Date.",
            style={"color": "#dc2626", "fontSize": "13px"},
        )
        return empty_badge, [], [], [], [], [], []

    start_str = str(start_date)[:10]
    end_str = str(end_date)[:10]

    try:
        d1 = pd.to_datetime(start_str)
        d2 = pd.to_datetime(end_str)
        num_days = (d2 - d1).days + 1
    except Exception:
        num_days = 1

    badge = html.Div(
        style={
            "backgroundColor": "#fdf4fa",
            "border": "1px solid #4e0038",
            "borderRadius": "8px",
            "padding": "10px 16px",
            "fontWeight": "600",
            "color": "#4e0038",
            "fontSize": "13px",
            "display": "flex",
            "alignItems": "center",
            "gap": "12px",
            "flexWrap": "wrap",
        },
        children=[
            html.Span("Active Review Window:"),
            html.Div(
                children=[
                    html.Span("Start Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                    html.Strong(start_str, style={"color": "#4e0038", "fontSize": "14px"}),
                ],
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "4px 10px",
                    "borderRadius": "6px",
                    "border": "1px solid #cbd5e1",
                },
            ),
            html.Span("───▶", style={"color": "#94a3b8"}),
            html.Div(
                children=[
                    html.Span("End Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                    html.Strong(end_str, style={"color": "#4e0038", "fontSize": "14px"}),
                ],
                style={
                    "backgroundColor": "#ffffff",
                    "padding": "4px 10px",
                    "borderRadius": "6px",
                    "border": "1px solid #cbd5e1",
                },
            ),
            html.Span(
                f"({num_days} Day{'s' if num_days != 1 else ''} selected)",
                style={"color": "#64748b", "fontWeight": "500"},
            ),
        ],
    )

    res = alert_service.get_alerts_for_period(
        start_date=start_str,
        end_date=end_str,
        bmu_filter=bmu_f,
        party_filter=party_f,
        fuel_filter=fuel_f,
        status_filter=status_f,
    )

    alerts = res["alerts"]
    summary = res["summary"]
    opts = res["filter_options"]

    # Build Pink / White / Pink / White Alternating KPI Summary Cards
    cards = [
        # Card 1: Total Alerts (Pink)
        html.Div(
            style={
                "backgroundColor": "#fdf4fa",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #f9a8d4",
                "borderRight": "1px solid #f9a8d4",
                "borderBottom": "1px solid #f9a8d4",
            },
            children=[
                html.Div(
                    "Total Alerts in Window",
                    style={"fontSize": "12px", "color": "#4e0038", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["total_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#4e0038"},
                ),
            ],
        ),
        # Card 2: Unreviewed Alerts (White)
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "Unreviewed Alerts",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["unreviewed_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"},
                ),
            ],
        ),
        # Card 3: Open Alerts (Pink)
        html.Div(
            style={
                "backgroundColor": "#fdf4fa",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #f9a8d4",
                "borderRight": "1px solid #f9a8d4",
                "borderBottom": "1px solid #f9a8d4",
            },
            children=[
                html.Div(
                    "Open Alerts",
                    style={"fontSize": "12px", "color": "#4e0038", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["open_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#4e0038"},
                ),
            ],
        ),
        # Card 4: Closed Alerts (White)
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div(
                    "Closed Alerts",
                    style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"},
                ),
                html.Div(
                    str(summary["closed_count"]),
                    style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"},
                ),
            ],
        ),
    ]

    return badge, alerts, opts["bmus"], opts["parties"], opts["fuels"], cards, []


@callback(
    Output("store-selected-alert-id", "data"),
    Output("selected-alert-details-container", "children"),
    Output("input-action-taken", "value"),
    Output("input-analysis-status", "value"),
    Output("input-review-comments", "value"),
    Output("investigation-links-container", "children"),
    Input("alert-review-table", "selected_rows"),
    State("alert-review-table", "data"),
)
def handle_alert_selection(selected_rows, alerts_data):
    if not selected_rows or not alerts_data:
        no_select = html.Div(
            "Select one or more alert rows from the queue to view details and capture analyst decision.",
            style={"color": "#64748b", "fontStyle": "italic", "fontSize": "13px"},
        )
        return None, no_select, None, None, "", []

    valid_indices = [idx for idx in selected_rows if idx < len(alerts_data)]
    if not valid_indices:
        return None, html.Div("No valid alerts selected."), None, None, "", []

    if len(valid_indices) == 1:
        idx = valid_indices[0]
        alert = alerts_data[idx]
        unique_id = alert["UNIQUE_ID"]
        bmu_id = alert["BMU_ID"]

        # Compute system info
        info_sys = analytics_service.get_aggregated_info_for_analyst(
            bmu_id=bmu_id,
            start_gmt=alert["START_GMT"],
            end_gmt=alert["END_GMT"],
        )

        details_card = html.Div(
            style={"fontSize": "13px", "display": "flex", "flexDirection": "column", "gap": "6px"},
            children=[
                html.Div(
                    [
                        html.Strong("BMU ID: "),
                        html.Span(bmu_id, style={"color": "#4e0038", "fontWeight": "600"}),
                    ]
                ),
                html.Div(
                    [html.Strong("Counterparty: "), html.Span(alert.get("COUNTERPARTY") or "-")]
                ),
                html.Div(
                    [
                        html.Strong("Time Window: "),
                        html.Span(f"{alert.get('START_LOCAL')} to {alert.get('END_LOCAL')}"),
                    ]
                ),
                html.Div(
                    [
                        html.Strong("Duration / SPs: "),
                        html.Span(
                            f"{alert.get('DURATION_MIN')} mins ({alert.get('COUNT_SP')} SPs)"
                        ),
                    ]
                ),
                html.Div(
                    [
                        html.Strong("System Info (INFO_FOR_ANALYST): "),
                        html.P(
                            info_sys or "No breach WHY flags",
                            style={
                                "margin": "2px 0 0 0",
                                "color": "#475569",
                                "backgroundColor": "#f8fafc",
                                "padding": "6px",
                                "borderRadius": "4px",
                                "fontSize": "12px",
                            },
                        ),
                    ]
                ),
            ],
        )

        bmrs_url = get_bmrs_bmu_url(
            bmu_id=bmu_id,
            start_gmt=alert.get("START_GMT"),
        )
        remit_url = get_bmrs_remit_url(bmu_id)
        nav_analytical_url = f"/analytical-support?unique_id={unique_id}"

        links = [
            html.A(
                "Open Detailed Analytical Evidence View",
                href=nav_analytical_url,
                target="_blank",
                className="btn-neso-primary",
                style={
                    "padding": "8px 12px",
                    "textDecoration": "none",
                    "fontSize": "12px",
                    "textAlign": "center",
                },
            ),
            html.A(
                "View BMU on Elexon BMRS",
                href=bmrs_url,
                target="_blank",
                style={
                    "backgroundColor": "#f1f5f9",
                    "color": "#0f172a",
                    "padding": "6px 12px",
                    "borderRadius": "6px",
                    "textDecoration": "none",
                    "fontSize": "12px",
                    "textAlign": "center",
                    "border": "1px solid #cbd5e1",
                },
            ),
            html.A(
                "View REMIT Data",
                href=remit_url,
                target="_blank",
                style={
                    "backgroundColor": "#f1f5f9",
                    "color": "#0f172a",
                    "padding": "6px 12px",
                    "borderRadius": "6px",
                    "textDecoration": "none",
                    "fontSize": "12px",
                    "textAlign": "center",
                    "border": "1px solid #cbd5e1",
                },
            ),
        ]

        action_val = alert.get("ACTION_TAKEN")
        status_val = alert.get("ANALYSIS_STATUS")
        comment_val = alert.get("REVIEW_COMMENTS") or ""

        return [unique_id], details_card, action_val, status_val, comment_val, links

    # Multi-Row Selection Case
    selected_alerts = [alerts_data[idx] for idx in valid_indices]
    unique_ids = [a["UNIQUE_ID"] for a in selected_alerts]
    bmu_ids = sorted(list(set(a["BMU_ID"] for a in selected_alerts)))

    batch_details_card = html.Div(
        style={"fontSize": "13px", "display": "flex", "flexDirection": "column", "gap": "6px"},
        children=[
            html.Div(
                [
                    html.Strong("Batch Mode Active: "),
                    html.Span(
                        f"{len(unique_ids)} alerts selected",
                        style={"color": "#4e0038", "fontWeight": "700"},
                    ),
                ]
            ),
            html.Div([html.Strong("Alert IDs: "), html.Span(", ".join(unique_ids))]),
            html.Div([html.Strong("BMU IDs: "), html.Span(", ".join(bmu_ids))]),
            html.Div(
                "Decisions entered below will be applied to ALL selected alerts.",
                style={
                    "color": "#64748b",
                    "fontStyle": "italic",
                    "fontSize": "12px",
                    "backgroundColor": "#f8fafc",
                    "padding": "6px",
                    "borderRadius": "4px",
                    "marginTop": "4px",
                },
            ),
        ],
    )

    return unique_ids, batch_details_card, None, None, "", []


@callback(
    Output("save-feedback-container", "children"),
    Output("store-refresh-signal", "data"),
    Input("confirm-save-review", "submit_n_clicks"),
    State("store-selected-alert-id", "data"),
    State("input-action-taken", "value"),
    State("input-analysis-status", "value"),
    State("input-review-comments", "value"),
    State("store-refresh-signal", "data"),
    prevent_initial_call=True,
)
def save_review_callback(
    submit_n_clicks,
    alert_ids_data,
    action_taken,
    analysis_status,
    comments,
    current_signal,
):
    if not submit_n_clicks:
        return dash.no_update, current_signal

    if not alert_ids_data:
        return (
            html.Div(
                "Please select at least one alert from the table first.",
                style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"},
            ),
            current_signal,
        )

    if not action_taken or not analysis_status or not comments or len(str(comments).strip()) <= 5:
        return (
            html.Div(
                "All fields are required: Select Action Taken, Analysis Status (Open or Closed), and enter Review Comments (must be more than 5 characters to avoid short placeholder text).",
                style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"},
            ),
            current_signal,
        )

    target_ids = alert_ids_data if isinstance(alert_ids_data, list) else [str(alert_ids_data)]

    try:
        saved_logs = []
        for aid in target_ids:
            saved = activity_log_service.save_analyst_review(
                alert_unique_id=aid,
                action_taken=action_taken,
                analysis_status=analysis_status,
                review_comments=comments.strip(),
                analyst_name=LOCAL_ANALYST_NAME,
            )
            saved_logs.append(saved)

        if len(target_ids) == 1:
            msg_text = f"Review successfully persisted to SQL for alert '{target_ids[0]}'."
        else:
            msg_text = f"Review decision successfully persisted to SQL for all {len(target_ids)} selected alerts ({', '.join(target_ids)})!"

        msg = html.Div(
            msg_text,
            style={"color": "#16a34a", "fontSize": "12px", "fontWeight": "600"},
        )
        return msg, (current_signal or 0) + 1
    except Exception as e:
        msg = html.Div(
            f"Error persisting review: {str(e)}",
            style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"},
        )
        return msg, current_signal
