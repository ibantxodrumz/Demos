from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.repositories import alert_repository
from src.utils.date_utils import generate_available_time_options


def derive_review_status(row: Dict[str, Any]) -> str:
    """
    Derive the logical display status:
    - If no linked ACTIVITY_LOG or ANALYSIS_STATUS is null/empty -> Unreviewed
    - If ANALYSIS_STATUS == 'Open' -> Open
    - If ANALYSIS_STATUS == 'Closed' -> Closed
    """
    status = row.get("ANALYSIS_STATUS")
    if not status or str(status).strip() == "":
        return "Unreviewed"
    return str(status).strip()


def get_alerts_for_period(
    start_date: str,
    end_date: str,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    status_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    raw_alerts = alert_repository.get_alerts_by_date_range(start_date, end_date, db_path=db_path)

    processed_alerts = []
    bmu_options = set()
    party_options = set()
    fuel_options = set()

    for item in raw_alerts:
        item["DISPLAY_STATUS"] = derive_review_status(item)
        if item.get("BMU_ID"):
            bmu_options.add(item["BMU_ID"])
        if item.get("COUNTERPARTY"):
            party_options.add(item["COUNTERPARTY"])
        if item.get("FUEL_TYPE"):
            fuel_options.add(item["FUEL_TYPE"])

        # Apply filters
        if bmu_filter and item.get("BMU_ID") != bmu_filter:
            continue
        if party_filter and item.get("COUNTERPARTY") != party_filter:
            continue
        if fuel_filter and item.get("FUEL_TYPE") != fuel_filter:
            continue
        if status_filter and status_filter != "All":
            if item["DISPLAY_STATUS"] != status_filter:
                continue

        processed_alerts.append(item)

    total_count = len(processed_alerts)
    unreviewed_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Unreviewed")
    open_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Open")
    closed_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Closed")

    return {
        "alerts": processed_alerts,
        "summary": {
            "total_count": total_count,
            "unreviewed_count": unreviewed_count,
            "open_count": open_count,
            "closed_count": closed_count,
        },
        "filter_options": {
            "bmus": sorted(list(bmu_options)),
            "parties": sorted(list(party_options)),
            "fuels": sorted(list(fuel_options)),
            "statuses": ["All", "Unreviewed", "Open", "Closed"],
        },
    }


def get_alert_by_id(
    unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    alert = alert_repository.get_alert_by_unique_id(unique_id, db_path=db_path)
    if alert:
        alert["DISPLAY_STATUS"] = derive_review_status(alert)
    return alert


def get_available_time_options() -> Dict[str, Any]:
    """
    Returns structured options for time period selection:
    Months, ISO weeks, and date bounds dynamically generated from August 2022.
    """
    return generate_available_time_options()


def get_reviews_by_status_for_period(
    target_status: str,
    start_date: str,
    end_date: str,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    action_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Retrieve alerts specifically filtered by target_status ('Open' or 'Closed') for a given period.
    """
    period_res = get_alerts_for_period(
        start_date=start_date,
        end_date=end_date,
        bmu_filter=bmu_filter,
        party_filter=party_filter,
        fuel_filter=fuel_filter,
        status_filter=target_status,
        db_path=db_path,
    )

    alerts = period_res["alerts"]
    if action_filter and action_filter != "All":
        alerts = [a for a in alerts if a.get("ACTION_TAKEN") == action_filter]

    action_options = sorted(list(set(a.get("ACTION_TAKEN") for a in alerts if a.get("ACTION_TAKEN"))))

    return {
        "alerts": alerts,
        "summary": {
            "count": len(alerts),
            "autoclose_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "AutoClose"),
            "monitor_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "Monitor Ongoing"),
            "escalated_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "Escalated to Compliance"),
        },
        "filter_options": {
            "bmus": period_res["filter_options"]["bmus"],
            "parties": period_res["filter_options"]["parties"],
            "fuels": period_res["filter_options"]["fuels"],
            "actions": ["All"] + action_options,
        },
    }
