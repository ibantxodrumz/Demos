"""
Date utility functions for Market Monitoring Platform Phase 2.
Provides dynamic date option generation and formatting helpers.
"""

from datetime import date, datetime, timedelta
import calendar
from typing import Dict, Any, List


def generate_available_time_options(
    min_year: int = 2022,
    min_month: int = 8,
    forward_margin_days: int = 30,
) -> Dict[str, Any]:
    """
    Dynamically generates structured time period options (Months, ISO Weeks, min_date, max_date)
    starting from a historical lower bound (default: August 2022) up to current date + forward margin.
    
    Returns:
        Dict with keys 'months', 'weeks', 'min_date', 'max_date'.
    """
    start_date = date(min_year, min_month, 1)
    today = date.today()
    target_max_date = today + timedelta(days=forward_margin_days)

    # 1. Generate Months (from min_date month to target_max_date month)
    months: List[Dict[str, str]] = []
    curr_year = today.year
    curr_month = today.month

    # Determine latest month/year boundary
    latest_year = target_max_date.year
    latest_month = target_max_date.month

    # Generate months descending (newest first)
    y = latest_year
    m = latest_month
    while (y > min_year) or (y == min_year and m >= min_month):
        month_name = calendar.month_name[m]
        _, last_day = calendar.monthrange(y, m)
        m_start = f"{y:04d}-{m:02d}-01"
        m_end = f"{y:04d}-{m:02d}-{last_day:02d}"
        
        months.append({
            "label": f"{month_name} {y}",
            "value": f"{m_start}|{m_end}",
            "start": m_start,
            "end": m_end,
        })
        
        m -= 1
        if m < 1:
            m = 12
            y -= 1

    # 2. Generate ISO Weeks (from week containing start_date to week containing target_max_date)
    weeks: List[Dict[str, str]] = []

    # Find Monday of week containing start_date
    start_monday = start_date - timedelta(days=start_date.weekday())
    
    # Find Sunday of week containing target_max_date
    max_monday = target_max_date - timedelta(days=target_max_date.weekday())

    w_monday = max_monday
    while w_monday >= start_monday:
        w_sunday = w_monday + timedelta(days=6)
        iso_year, iso_week, _ = w_monday.isocalendar()
        
        start_str = w_monday.strftime("%Y-%m-%d")
        end_str = w_sunday.strftime("%Y-%m-%d")
        
        start_fmt = w_monday.strftime("%b %d")
        end_fmt = w_sunday.strftime("%b %d, %Y")
        
        label = f"Week {iso_week:02d} ({start_fmt} - {end_fmt})"
        value = f"{start_str}|{end_str}"
        
        weeks.append({
            "label": label,
            "value": value,
            "start": start_str,
            "end": end_str,
        })
        
        w_monday -= timedelta(days=7)

    min_date_str = start_date.strftime("%Y-%m-%d")
    _, max_month_last_day = calendar.monthrange(latest_year, latest_month)
    max_date_str = f"{latest_year:04d}-{latest_month:02d}-{max_month_last_day:02d}"

    return {
        "months": months,
        "weeks": weeks,
        "min_date": min_date_str,
        "max_date": max_date_str,
    }
