import os
from pathlib import Path

# Workspace Root
ROOT_DIR = Path(__file__).resolve().parents[2]

from src.config.constants import SQL_DATABASE, SQL_SERVER

# Database Configuration
DATABASE_MODE = os.getenv("DATABASE_MODE", "azure").lower()  # "azure" or "sqlite"
DEFAULT_DB_PATH = os.getenv(
    "DEFAULT_DB_PATH",
    str(ROOT_DIR / "import_constraints_local_prototype" / "data" / "prototype.db"),
)

AZURE_SQL_SERVER = os.getenv("AZURE_SQL_SERVER", SQL_SERVER)
AZURE_SQL_DATABASE = os.getenv("AZURE_SQL_DATABASE", SQL_DATABASE)



# Analyst Configuration
LOCAL_ANALYST_NAME = os.getenv("LOCAL_ANALYST_NAME", "Local Prototype Analyst")

# Domain Configuration
DEFAULT_PARAMETER_BREACHED = "Import Constraints"
DEFAULT_NOTIFICATION_SOURCE = "IMPORT_CONSTRAINTS"

# Controlled Outcome Values
CONTROLLED_ACTIONS = [
    "AutoClose",
    "Monitor Ongoing",
    "Resolved With Provider",
    "Review For Potential STR",
    "Escalated To STR",
    "Escalated To MIR",
    "Bad Data",
    "Closed by Ivan",
    "Close by dkfjdkfjkdjfkj",
    "REMIT email sent",
    "Data improvement",
    "Poor quality remit",
    "Under 100MW REMIT",
]

CONTROLLED_STATUSES = [
    "Open",
    "Closed",
]

# Demonstration Weeks for Testing & Validation
DEMO_WEEK_1 = {
    "label": "Demo Week 1 (Feb 2 - Feb 8, 2026)",
    "start": "2026-02-02",
    "end": "2026-02-08",
}

DEMO_WEEK_2 = {
    "label": "Demo Week 2 (May 4 - May 10, 2026)",
    "start": "2026-05-04",
    "end": "2026-05-10",
}
