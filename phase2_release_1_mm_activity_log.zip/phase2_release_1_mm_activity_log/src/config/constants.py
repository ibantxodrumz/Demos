# src/config/constants.py
import os

# SQL Azure Configuration
# Defaults mirror the SQL Dashboard configuration (SQL_DS) while allowing environment overrides
SQL_SERVER = os.getenv("AZURE_SQL_SERVER", "placeholder")
SQL_DATABASE = os.getenv("AZURE_SQL_DATABASE", "placeholder")

# Table Definitions (Compatible with both Azure SQL Database default schema and unit test SQLite runner)
SQL_TABLE_ALERTS = os.getenv("AZURE_SQL_TABLE_ALERTS", "IMPORT_ALERTS")
SQL_TABLE_ALERTS_DATA = os.getenv("AZURE_SQL_TABLE_ALERTS_DATA", "IMPORT_ALERTS_DATA")
SQL_TABLE_ACTIVITY_LOG = os.getenv("AZURE_SQL_TABLE_ACTIVITY_LOG", "MM_ACTIVITY_LOG")
DEFAULT_WORKSTREAM_NAME = os.getenv("DEFAULT_WORKSTREAM_NAME", "IMPORT_CONSTRAINTS")

# Azure ODBC Connection String Options
ODBC_DRIVER_PREFERENCE = [
    "ODBC Driver 18 for SQL Server",
    "ODBC Driver 17 for SQL Server",
]
