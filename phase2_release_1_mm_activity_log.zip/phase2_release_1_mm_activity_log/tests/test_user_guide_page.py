from pathlib import Path
import dash

PAGES_DIR = str(Path(__file__).resolve().parent.parent / "src" / "pages")
app = dash.Dash(__name__, use_pages=True, pages_folder=PAGES_DIR)
from src.pages import user_guide


def test_user_guide_layout():
    layout = user_guide.layout
    assert layout is not None
    assert hasattr(layout, "children")
    assert len(layout.children) >= 2
