from pathlib import Path
import pytest
from src.config.settings import DEMO_WEEK_1, DEMO_WEEK_2
from src.repositories import alert_repository


def test_demo_week_1_retrieval_and_repeated_bmus(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    assert len(alerts) > 0

    # Verify repeated BMUs exist as distinct alert rows
    bmu_counts = {}
    for a in alerts:
        bmu = a["BMU_ID"]
        bmu_counts[bmu] = bmu_counts.get(bmu, 0) + 1

    # Check for expected repeated BMUs in Demo Week 1
    repeated_found = any(count > 1 for count in bmu_counts.values())
    assert repeated_found, "Demonstration Week 1 should contain repeated BMU alert windows"


def test_demo_week_2_retrieval_and_repeated_bmus(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_2["start"],
        DEMO_WEEK_2["end"],
        db_path=fresh_db,
    )
    assert len(alerts) > 0

    bmu_counts = {}
    for a in alerts:
        bmu = a["BMU_ID"]
        bmu_counts[bmu] = bmu_counts.get(bmu, 0) + 1

    repeated_found = any(count > 1 for count in bmu_counts.values())
    assert repeated_found, "Demonstration Week 2 should contain repeated BMU alert windows"


def test_get_alert_by_unique_id(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    target_id = alerts[0]["UNIQUE_ID"]

    single = alert_repository.get_alert_by_unique_id(target_id, db_path=fresh_db)
    assert single is not None
    assert single["UNIQUE_ID"] == target_id
    assert single["BMU_ID"] == alerts[0]["BMU_ID"]


def test_half_open_upper_boundary_excludes_next_day(fresh_db):
    """
    Spec: SQL query uses the correct half-open boundaries.
    Alerts with START_LOCAL on end_date+1 must NOT appear in results.
    """
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    for a in alerts:
        start_date_str = str(a["START_LOCAL"])[:10]
        assert start_date_str <= DEMO_WEEK_1["end"], (
            f"Alert {a['UNIQUE_ID']} with START_LOCAL={a['START_LOCAL']} "
            f"is outside the requested end date {DEMO_WEEK_1['end']}"
        )


def test_each_alert_retains_unique_identifier(fresh_db):
    """Every row in the result must carry its UNIQUE_ID."""
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=fresh_db,
    )
    for a in alerts:
        assert "UNIQUE_ID" in a, "Alert row missing UNIQUE_ID"
        assert a["UNIQUE_ID"] is not None and str(a["UNIQUE_ID"]).strip() != ""


def test_empty_date_range_returns_empty_list(fresh_db):
    """A date range with no alerts must return [] without raising."""
    alerts = alert_repository.get_alerts_by_date_range(
        "2020-01-01",
        "2020-01-07",
        db_path=fresh_db,
    )
    assert alerts == [], f"Expected empty list, got {len(alerts)} rows"


def test_query_boundary_with_timestamp_end_date(fresh_db):
    """Verify that passing end_date as a full timestamp string correctly includes alerts on that day."""
    alerts_date_only = alert_repository.get_alerts_by_date_range(
        "2026-02-02",
        "2026-02-08",
        db_path=fresh_db,
    )
    alerts_timestamp = alert_repository.get_alerts_by_date_range(
        "2026-02-02",
        "2026-02-08 23:59:59",
        db_path=fresh_db,
    )
    assert len(alerts_date_only) == len(alerts_timestamp)
    assert [a["UNIQUE_ID"] for a in alerts_date_only] == [a["UNIQUE_ID"] for a in alerts_timestamp]


def test_activity_log_priority_over_unlinked_alerts(fresh_db):
    from src.services import activity_log_service, alert_service

    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    target_alert = alerts[0]
    uid = target_alert["UNIQUE_ID"]

    # Initially unreviewed
    open_res = alert_service.get_reviews_by_status_for_period("Open", "2026-02-02", "2026-02-08", db_path=fresh_db)
    open_uids_initial = [a["UNIQUE_ID"] for a in open_res["alerts"]]
    assert uid not in open_uids_initial

    # Save as Open
    activity_log_service.save_analyst_review(
        alert_unique_id=uid,
        action_taken="Monitor Ongoing",
        analysis_status="Open",
        review_comments="Investigating issue...",
        db_path=fresh_db,
    )

    open_res_after_open = alert_service.get_reviews_by_status_for_period("Open", "2026-02-02", "2026-02-08", db_path=fresh_db)
    open_uids_after_open = [a["UNIQUE_ID"] for a in open_res_after_open["alerts"]]
    assert uid in open_uids_after_open

    # Save as Closed
    activity_log_service.save_analyst_review(
        alert_unique_id=uid,
        action_taken="AutoClose",
        analysis_status="Closed",
        review_comments="Closing review as resolved.",
        db_path=fresh_db,
    )

    open_res_after_closed = alert_service.get_reviews_by_status_for_period("Open", "2026-02-02", "2026-02-08", db_path=fresh_db)
    open_uids_after_closed = [a["UNIQUE_ID"] for a in open_res_after_closed["alerts"]]
    assert uid not in open_uids_after_closed
