import pandas as pd
from src.config.settings import DEMO_WEEK_1
from src.services import sp_analytics_service


def test_preprocess_data_empty():
    df = pd.DataFrame()
    res = sp_analytics_service.preprocess_data(df)
    assert res.empty


def test_preprocess_data_taxonomy():
    raw = pd.DataFrame(
        [
            {
                "COND_1": True,
                "COND_2": False,
                "COND_3": False,
                "LOCAL_DATETIME": "2026-02-02 00:00",
            },
            {"COND_1": True, "COND_2": True, "COND_3": False, "LOCAL_DATETIME": "2026-02-02 00:30"},
            {
                "COND_1": False,
                "COND_2": False,
                "COND_3": False,
                "LOCAL_DATETIME": "2026-02-02 01:00",
            },
        ]
    )
    res = sp_analytics_service.preprocess_data(raw)
    assert len(res) == 3
    assert res.iloc[0]["BEHAVIOUR_CLASS"] == "Constrained - elevated signal"
    assert res.iloc[1]["BEHAVIOUR_CLASS"] == "Constrained - ensemble"
    assert res.iloc[2]["BEHAVIOUR_CLASS"] == "Constrained - normal behaviour"


def test_preprocess_data_deduplication():
    raw = pd.DataFrame(
        [
            {
                "BMU_ID": "T_TEST-1",
                "LOCAL_DATETIME": "2026-02-02 00:00",
                "SETTLEMENT_PERIOD": 1,
                "COND_1": True,
                "COND_2": True,
            },
            {
                "BMU_ID": "T_TEST-1",
                "LOCAL_DATETIME": "2026-02-02 00:00",
                "SETTLEMENT_PERIOD": 1,
                "COND_1": True,
                "COND_2": True,
            },
        ]
    )
    res = sp_analytics_service.preprocess_data(raw)
    assert len(res) == 1


def test_get_sp_workspace_data():
    res = sp_analytics_service.get_sp_workspace_data(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    assert "sp_df" in res
    assert "alerts_df" in res
    assert "windows_df" in res
    assert "filter_options" in res

    sp_df = res["sp_df"]
    assert not sp_df.empty
    assert "BEHAVIOUR_CLASS" in sp_df.columns
    assert len(res["filter_options"]["bmus"]) > 0


def test_infer_alerts_windows():
    raw_sp = pd.DataFrame(
        [
            {
                "BMU_ID": "T_TEST-1",
                "LOCAL_DATETIME": pd.to_datetime("2026-02-02 10:00"),
                "GMT_FROM": pd.to_datetime("2026-02-02 10:00"),
                "SETTLEMENT_PERIOD": 21,
                "FUEL_TYPE": "GAS",
                "COUNTERPARTY": "Test Energy",
                "COND_1": True,
                "COND_2": True,
                "COND_3": False,
                "SPREAD": 50.0,
                "OFFER_PRICE": 120.0,
                "OFFER_VOLUME_MWH": 10.0,
                "IMPACT_SP": 100.0,
            },
            {
                "BMU_ID": "T_TEST-1",
                "LOCAL_DATETIME": pd.to_datetime("2026-02-02 10:30"),
                "GMT_FROM": pd.to_datetime("2026-02-02 10:30"),
                "SETTLEMENT_PERIOD": 22,
                "FUEL_TYPE": "GAS",
                "COUNTERPARTY": "Test Energy",
                "COND_1": True,
                "COND_2": True,
                "COND_3": False,
                "SPREAD": 60.0,
                "OFFER_PRICE": 130.0,
                "OFFER_VOLUME_MWH": 10.0,
                "IMPACT_SP": 150.0,
            },
        ]
    )
    windows = sp_analytics_service.infer_alerts_windows(raw_sp)
    assert len(windows) == 1
    w = windows.iloc[0]
    assert w["BMU_ID"] == "T_TEST-1"
    assert w["COUNT_SP"] == 2
    assert w["DURATION_MIN"] == 60
    assert w["AVG_SPREAD"] == 55.0
    assert w["TOTAL_IMPACT_SP"] == 250.0


def test_sync_ic_date_controls_week_and_month_presets(monkeypatch):
    from unittest.mock import MagicMock
    import dash
    from src.pages import import_constraints

    mock_ctx = MagicMock()
    mock_ctx.triggered = [{"prop_id": "ic-dropdown-select-week.value", "value": "2026-02-02|2026-02-08"}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx)

    start, end, badge = import_constraints.sync_ic_date_controls(
        single_day=None,
        start_date="2026-01-01",
        end_date="2026-01-31",
        week_preset="2026-02-02|2026-02-08",
        month_preset=None,
        full_clicks=0,
    )
    assert start == "2026-02-02"
    assert end == "2026-02-08"

    mock_ctx_month = MagicMock()
    mock_ctx_month.triggered = [{"prop_id": "ic-dropdown-select-month.value", "value": "2026-02-01|2026-02-28"}]
    monkeypatch.setattr(dash, "callback_context", mock_ctx_month)

    start, end, badge = import_constraints.sync_ic_date_controls(
        single_day=None,
        start_date="2026-01-01",
        end_date="2026-01-31",
        week_preset=None,
        month_preset="2026-02-01|2026-02-28",
        full_clicks=0,
    )
    assert start == "2026-02-01"
    assert end == "2026-02-28"
