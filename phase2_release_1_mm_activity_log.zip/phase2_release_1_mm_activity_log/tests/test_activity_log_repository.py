import pytest
from src.repositories import activity_log_repository, alert_repository
from src.services import activity_log_service


def test_insert_and_update_activity_log(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    target_alert = alerts[0]
    unique_id = target_alert["UNIQUE_ID"]

    # Initial Save -> INSERT
    saved_1 = activity_log_service.save_analyst_review(
        alert_unique_id=unique_id,
        action_taken="AutoClose",
        analysis_status="Closed",
        review_comments="Initial automated review note",
        analyst_name="Test Analyst",
        db_path=fresh_db,
    )

    assert len(saved_1["ACTIVITY_LOG_ID"]) == 36
    assert saved_1["ACTION_TAKEN"] == "AutoClose"
    assert saved_1["ANALYSIS_STATUS"] == "Closed"
    created_time_1 = saved_1["CREATED_DATETIME"]

    # Verify single row created
    all_reviews_1 = activity_log_service.get_saved_reviews(db_path=fresh_db)
    assert len(all_reviews_1) == 1

    # Second Save -> UPDATE
    saved_2 = activity_log_service.save_analyst_review(
        alert_unique_id=unique_id,
        action_taken="Monitor Ongoing",
        analysis_status="Open",
        review_comments="Updated analyst observation",
        analyst_name="Test Analyst",
        db_path=fresh_db,
    )

    assert saved_2["ACTION_TAKEN"] == "Monitor Ongoing"
    assert saved_2["ANALYSIS_STATUS"] == "Open"
    assert saved_2["REVIEW_COMMENTS"] == "Updated analyst observation"
    assert (
        saved_2["CREATED_DATETIME"] == created_time_1
    ), "CREATED_DATETIME must remain unchanged on update"

    # Verify row count remains 1 (no duplicate record)
    all_reviews_2 = activity_log_service.get_saved_reviews(db_path=fresh_db)
    assert len(all_reviews_2) == 1


def test_invalid_action_or_status_rejected(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    unique_id = alerts[0]["UNIQUE_ID"]

    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id=unique_id,
            action_taken="INVALID_ACTION",
            analysis_status="Closed",
            db_path=fresh_db,
        )

    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id=unique_id,
            action_taken="AutoClose",
            analysis_status="INVALID_STATUS",
            db_path=fresh_db,
        )


def test_non_existent_alert_id_rejected(fresh_db):
    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id="NON_EXISTENT_ID_999999",
            action_taken="AutoClose",
            analysis_status="Closed",
            review_comments="Valid review comment text",
            db_path=fresh_db,
        )


def test_short_comments_rejected(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    unique_id = alerts[0]["UNIQUE_ID"]

    # Comments with <= 5 characters must be rejected
    for short_text in ["k", "ok", "djdje", " 123 ", ""]:
        with pytest.raises(ValueError, match="more than 5 characters"):
            activity_log_service.save_analyst_review(
                alert_unique_id=unique_id,
                action_taken="AutoClose",
                analysis_status="Closed",
                review_comments=short_text,
                db_path=fresh_db,
            )


def test_get_closed_reviews(fresh_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    target_id = alerts[0]["UNIQUE_ID"]

    # Save a review as Closed
    activity_log_service.save_analyst_review(
        alert_unique_id=target_id,
        action_taken="AutoClose",
        analysis_status="Closed",
        review_comments="Valid closed review comments for test",
        analyst_name="Test Analyst",
        db_path=fresh_db,
    )

    closed_list = activity_log_repository.get_closed_reviews("2026-02-02", "2026-02-08", db_path=fresh_db)
    assert len(closed_list) == 1
    assert closed_list[0]["UNIQUE_ID"] == target_id
    assert closed_list[0]["ANALYSIS_STATUS"] == "Closed"


def test_activity_log_uuid_format_for_azure_sql(fresh_db):
    """Verify that generated ACTIVITY_LOG_ID is a valid RFC 4122 UUID string compatible with Azure SQL UNIQUEIDENTIFIER."""
    import uuid

    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    saved = activity_log_service.save_analyst_review(
        alert_unique_id=alerts[0]["UNIQUE_ID"],
        action_taken="Monitor Ongoing",
        analysis_status="Open",
        review_comments="Valid test review comment text for UUID validation",
        db_path=fresh_db,
    )

    act_id = saved["ACTIVITY_LOG_ID"]
    parsed_uuid = uuid.UUID(act_id)
    assert str(parsed_uuid) == act_id
    assert len(act_id) == 36


def test_workstream_name_isolation_and_persistence(fresh_db):
    """Verify that WORKSTREAM_NAME is persisted and filtered in MM_ACTIVITY_LOG."""
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=fresh_db)
    target_id = alerts[0]["UNIQUE_ID"]

    saved = activity_log_service.save_analyst_review(
        alert_unique_id=target_id,
        action_taken="Monitor Ongoing",
        analysis_status="Open",
        review_comments="Valid test review comment for workstream validation",
        workstream_name="IMPORT_CONSTRAINTS",
        db_path=fresh_db,
    )

    assert saved["WORKSTREAM_NAME"] == "IMPORT_CONSTRAINTS"

    log_entry = activity_log_repository.get_activity_log_by_alert_id(
        alert_unique_id=target_id,
        workstream_name="IMPORT_CONSTRAINTS",
        db_path=fresh_db,
    )
    assert log_entry is not None
    assert log_entry["WORKSTREAM_NAME"] == "IMPORT_CONSTRAINTS"

    # Querying with a different workstream should return None
    other_entry = activity_log_repository.get_activity_log_by_alert_id(
        alert_unique_id=target_id,
        workstream_name="TCLC",
        db_path=fresh_db,
    )
    assert other_entry is None



