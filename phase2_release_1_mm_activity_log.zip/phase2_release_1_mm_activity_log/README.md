# Market Monitoring Platform — Phase 2 Release 1

## Release Overview

**Release Identifier**: `phase2_release_1_mm_activity_log`  
**Target Environments**: Windows 11 (VS Code Local Execution) & macOS  
**Database Backend**: Azure SQL Database (`DATABASE_MODE=azure`) with SQLite local fallback (`DATABASE_MODE=sqlite`)

This release establishes the core persistence and date handling foundations for Phase 2 of the Market Monitoring Platform while strictly preserving all existing Import Constraints workflows.

---

## What's New in Phase 2 Release 1

1. **Dedicated Phase 2 Review Persistence (`dbo.MM_ACTIVITY_LOG`)**:
   - All review decisions (Open, Closed, Action Taken, Review Comments) are persisted exclusively to `dbo.MM_ACTIVITY_LOG`.
   - The Phase 1 `dbo.ACTIVITY_LOG` table remains completely untouched and frozen.
   - Includes `WORKSTREAM_NAME` schema partitioning (`'IMPORT_CONSTRAINTS'`).
   - Technical Primary Key: `ACTIVITY_LOG_ID` (`UNIQUEIDENTIFIER` / Python UUID).
   - Logical Uniqueness Constraint: `UNIQUE (WORKSTREAM_NAME, ALERT_UNIQUE_ID)`.

2. **Dynamic Date Option Generator**:
   - Hardcoded 2026 dropdown options have been replaced by a dynamic generator.
   - Dynamic month and ISO week options are generated starting from historical lower bound **August 2022** (`2022-08-01`) up to the current date + forward margin.
   - Eliminates manual annual code updates while preserving callback compatibility across all Dash pages.

3. **Database Schema Setup Script**:
   - SQL DDL script provided in `scripts/create_mm_activity_log.sql` for setting up `dbo.MM_ACTIVITY_LOG` in Azure SQL.

---

## Instructions for Colleagues Testing on Windows 11 (VS Code)

### Step 1: Environment Setup
Open the folder `releases/phase2_release_1_mm_activity_log` in VS Code and install dependencies:

```powershell
pip install -r requirements.txt
```

### Step 2: Database Table Verification (Azure SQL)
Ensure the table `dbo.MM_ACTIVITY_LOG` exists in your Azure SQL database. If creating it manually, execute `scripts/create_mm_activity_log.sql` in Azure Data Studio or SSMS:

```sql
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'MM_ACTIVITY_LOG';
```

### Step 3: Configure Environment Variables
Set your environment variables in your terminal or `.env` file:

```powershell
$env:DATABASE_MODE="azure"
$env:AZURE_SQL_SERVER="your_server.database.windows.net"
$env:AZURE_SQL_DATABASE="your_db_name"
$env:AZURE_SQL_USER="your_username"
$env:AZURE_SQL_PASSWORD="your_password"
```

*(To run locally in SQLite test mode without Azure SQL credentials, set `$env:DATABASE_MODE="sqlite"`)*

### Step 4: Run the Application
Launch the Market Monitoring Platform Dash application:

```powershell
python src/app.py
```

Access the application in your browser at `http://127.0.0.1:8050`.

---

## Regression & Feature Testing Checklist for Validation

- [ ] **Dynamic Date Range**: Verify that dropdowns allow selecting months and weeks back to **August 2022**.
- [ ] **Unreviewed Alert Display**: Load alerts and verify unreviewed alerts display `DISPLAY_STATUS = 'Unreviewed'`.
- [ ] **Save Open Review**: Select an alert, enter comments (> 5 characters), set status to `Open`, and click **Save**. Verify saving succeeds.
- [ ] **Save / Transition Closed Review**: Update status to `Closed` and save. Verify the alert transitions to the **Closed Reviews** page.
- [ ] **Azure SQL Persistence**: Query `SELECT * FROM dbo.MM_ACTIVITY_LOG WHERE WORKSTREAM_NAME = 'IMPORT_CONSTRAINTS'` in Azure SQL to verify rows are created and updated with `WORKSTREAM_NAME` populated.
- [ ] **Phase 1 Baseline Protection**: Query `dbo.ACTIVITY_LOG` to confirm Phase 1 records remain unmodified.

---

## Verification Evidence

- **Unit & Integration Suite**: `51 / 51 tests passed` (100% pass rate).
- **Execution Command**: `uv run python -m pytest tests/` inside release directory.
