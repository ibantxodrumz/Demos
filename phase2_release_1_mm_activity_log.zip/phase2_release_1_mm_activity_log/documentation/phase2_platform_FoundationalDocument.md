# Market Monitoring Platform: Phase 2 Foundation

## 1. Status

Phase 1 is complete and approved.

Authoritative Phase 1 baseline:

`release_2_local_azure_sql_working_final`

The approved baseline is frozen and must remain available for:

- Demonstration
- Regression comparison
- Rollback
- Technical reference

All Phase 2 work must take place in a separate Phase 2 folder.

The Phase 1 baseline must not be modified.

## 2. North Star

Move from:

`Import Constraints application PoC`

to:

`Fully fledged Market Monitoring Platform`

The platform will support multiple Monitoring workstreams through a shared operational application.

Planned workstreams:

- Import Constraints
- IC
- TCLC
- IOLC
- UMM
- Other future workstreams

## 3. Phase 2 Objective

Phase 2 will establish the foundations required to:

- Preserve the approved Import Constraints workflow
- Remove known Phase 1 limitations
- Support multiple workstreams
- Reuse common platform functionality
- Isolate workstream-specific logic
- Store all operational records in Azure SQL
- Prevent records from different workstreams being mixed
- Introduce a platform landing page
- Introduce temporary analyst context
- Move the existing rota into the application
- Define what constitutes a workstream
- Prepare the architecture for a second workstream
- Avoid duplicating the application for every workstream

The key architectural objective is:

`Shared platform capabilities + isolated workstream-specific capabilities`

Each workstream may have its own:

- Azure SQL schema and tables
- Alert fields
- Business rules
- Analytical support
- Statistical support
- Investigation links
- Operational particularities

The platform must support these differences without duplicating all shared functionality.

## 4. Non-Negotiable Architecture Principles

### 4.1 Azure SQL

Azure SQL is the single operational source of truth.

Azure SQL will store:

- Alerts
- Supporting operational data
- Analyst reviews
- Review statuses
- Review comments
- Workstream identifiers
- Analyst reference data
- Rota data
- Future platform configuration
- BMU and counterparty reference data where required

Dash must not use SharePoint Excel workbooks as operational data sources.

The existing BMU and counterparty mapping workbook may later be used as an initial migration or reconciliation source.

Any reference data required during normal application operation should ultimately be available in Azure SQL.

#### Phase Separation

Phase 1 and Phase 2 review persistence must remain separated.

Phase 1:

```text
ACTIVITY_LOG
```

Phase 2:

```text
MM_ACTIVITY_LOG
```

The approved Phase 1 release must continue using `ACTIVITY_LOG`.

Phase 2 must use `MM_ACTIVITY_LOG`.

No Phase 2 implementation may modify or depend on changes to the approved Phase 1 `ACTIVITY_LOG` table.

The two releases must be capable of operating independently.

### 4.2 Dash

Dash is the operational Market Monitoring workspace.

Dash owns:

- Platform navigation
- Landing page
- Analyst context
- Alert review
- Open Reviews
- Closed Reviews
- Analytical support
- Workstream-specific analytical pages
- Weekly rota display
- Rota administration

### 4.3 External Investigation Destinations

External websites support investigations but are not operational sources of truth.

Potential destinations include:

- Elexon
- REMIT
- Enappsys

External investigation destinations will apply differently across workstreams.

The existing Elexon functionality used by Import Constraints may be reusable for other appropriate workstreams.

The active workstream and selected alert context will determine which investigation buttons are available.

A failure or change in an external destination must not prevent an analyst from:

- Reviewing an alert
- Saving a decision
- Updating a review
- Closing a review

External destinations are navigation aids, not persistence dependencies.

### 4.4 Streamlit

KPI and governance reporting will be handled separately in Streamlit by another colleague.

Streamlit development is outside this Phase 2 scope.

The Dash platform roadmap must not include Streamlit implementation tasks.

### 4.5 NED

Historical NED migration is a backlog item.

NED migration is not part of the immediate Phase 2 implementation.

However, current platform changes must not unnecessarily block a future controlled migration.

Future considerations may include:

- Historical export
- Retention requirements
- Record provenance
- Historical reconciliation
- Migration into Azure SQL
- Archival storage

These considerations remain backlog items until separately prioritised.

## 5. Approved Baseline Protection

Phase 2 development must take place separately from the approved Phase 1 release.

The following baseline must not be modified:

`release_2_local_azure_sql_working_final`

Phase 2 must preserve the existing Import Constraints behaviour, including:

- Alert loading
- Alert filtering
- Alert selection
- Analytical evidence
- Review validation
- Saving a review as Open
- Updating an Open review
- Saving a review as Closed
- Updating a review to Closed
- Open Reviews
- Closed Reviews
- Long-run analytics
- Azure SQL persistence

Regression checks must be completed after every material Phase 2 change.

A successful application start is not sufficient regression evidence.

The end-to-end operational workflow must be checked.

The approved Phase 1 release must continue using its existing `ACTIVITY_LOG` table.

Phase 2 must use the new `MM_ACTIVITY_LOG` table.

## 6. Existing Platform Architecture

The existing layer structure remains the preferred architecture:

`Dash Page -> Service -> Repository -> Azure SQL`

### 6.1 Pages

Pages own:

- Layout
- Components
- Callbacks
- User interaction
- Display formatting
- Navigation

Pages must not contain direct SQL queries.

### 6.2 Services

Services own:

- Business rules
- Validation
- Workflow logic
- Data preparation
- Workstream orchestration

### 6.3 Repositories

Repositories own:

- SQL queries
- Database reads
- Database writes
- Database-specific behaviour

### 6.4 Azure SQL

Azure SQL owns the authoritative operational records.

## 7. Definition of a Workstream

A workstream is an operational Monitoring area supported by the platform.

A workstream is not just:

- A navigation button
- A Dash page
- A SQL table
- A dashboard
- A workstream name

A complete workstream may consist of the following elements.

### 7.1 Workstream Identity

Each workstream requires a stable identifier.

Initial planned identifiers:

- `IMPORT_CONSTRAINTS`
- `IC`
- `TCLC`
- `IOLC`
- `UMM`

These identifiers are persistent technical values.

Display names may be more user-friendly, but persistent identifiers should not change casually.

### 7.2 Azure SQL Schema and Tables

Each workstream may have its own:

- Alert table
- Supporting evidence table
- Reference tables
- Statistical tables
- Analytical tables
- Relationships
- SQL schema
- Query requirements

Azure SQL remains the operational source of truth for every workstream.

The platform must not assume that every workstream has the same raw SQL structure.

### 7.3 Alert Output

Each workstream must provide alert information that can be consumed by the platform.

The common platform may require a minimum alert representation containing:

- Workstream identifier
- Alert identifier
- Alert start
- Alert end
- Current review status
- Relevant entity or unit
- Relevant counterparty where applicable

Additional workstream-specific fields may remain outside the common alert representation.

### 7.4 Shared Review Lifecycle

Each workstream must integrate with the shared lifecycle where the common review process applies:

`Alert -> Investigation -> Decision -> Persistence -> History`

Shared review capabilities may include:

- Unreviewed status
- Open status
- Closed status
- Action taken
- Review comments
- Analyst information
- Created timestamp
- Updated timestamp
- Open Reviews
- Closed Reviews

The exact applicability of these capabilities must be validated for each workstream.

### 7.5 Workstream-Specific Business Rules

Each workstream may have different:

- Alert logic
- Filtering rules
- Review fields
- Controlled values
- Calculations
- Status requirements
- Decision criteria
- Validation requirements

These differences must remain explicit.

Raw workstream schemas may differ, but operational review persistence should use the shared `MM_ACTIVITY_LOG` contract where the common review lifecycle applies.

Workstream-specific repositories or adapters should map workstream data into the shared platform contract.

Workstream differences must not be hidden behind abstractions that make the code harder to understand or maintain.


### 7.6 Analytical Support

Each workstream requires its own analytical support.

Examples may include:

- Alert-level evidence
- Settlement-period analysis
- Price analysis
- Volume analysis
- Behavioural classification
- Charts
- Tables
- External context

Import Constraints calculations such as settlement-period processing, ensemble alert-window inference and C1, C2 and C3 calculations must remain Import Constraints-specific.

### 7.7 Statistical and Long-Run Support

A workstream may require:

- Long-run statistics
- Historical comparisons
- Counterparty analysis
- Unit analysis
- Threshold analysis
- Aggregated monitoring views

Statistical support is not automatically a shared capability.

The common platform may provide shared layout or navigation patterns, while the calculations and data remain workstream-specific.

### 7.8 Investigation Links

A workstream may provide contextual links to external investigation destinations.

Potential examples:

- Elexon
- REMIT
- Enappsys

The applicable destinations and URL requirements must be defined separately for each workstream.

### 7.9 Routes and Navigation

Each workstream may provide:

- Operational route
- Alert Review route
- Analytical Support route
- Statistical Support route
- Other workstream-specific routes

The platform landing page and navigation must expose only implemented capabilities.

### 7.10 Platform Integration

A workstream must specify which shared capabilities it supports.

Examples:

- Alert Review
- Open Reviews
- Closed Reviews
- Analytical Support
- Bulk review
- Statistical Support
- Investigation links

A workstream is ready for platform integration only when these responsibilities and interfaces are understood.

## 8. Phase 2 Delivery Plan

### P0: Dynamic Date Options

The existing date preset logic is hardcoded and must be replaced.

Current issue:

`get_available_time_options()` contains a fixed list of weeks and months.

Required historical lower bound:

`August 2022`

Target behaviour:

- Support the required period from August 2022
- Use an appropriate upper date bound
- Include the agreed forward margin required by the review workflow
- Generate month options dynamically
- Generate ISO week options dynamically
- Remain valid as time progresses
- Preserve the current callback return structure
- Preserve current date-selection behaviour
- Avoid annual manual code updates

The lower bound is fixed at August 2022 because the oldest alerts in the current legacy database are from August 2022.

This is a hardening change.

It must not redesign the date-selection interface unnecessarily.

Required checks:

- Month generation
- Week generation
- Year boundaries
- Current dates
- Historical dates
- Forward-margin dates
- Empty-data behaviour
- All pages using the shared date options
- Existing filters and callbacks

### P1: Create the Phase 2 MM_ACTIVITY_LOG

Create a new operational review table for the Market Monitoring Platform:

`MM_ACTIVITY_LOG`

The existing Phase 1 table must remain unchanged:

`ACTIVITY_LOG`

The separation is:

```text
Approved Phase 1 release
    ↓
ACTIVITY_LOG
```

```text
Phase 2 platform
    ↓
MM_ACTIVITY_LOG
```

The approved Phase 1 release must continue using `ACTIVITY_LOG`.

All Phase 2 review functionality must use `MM_ACTIVITY_LOG`.

This provides:

- Complete persistence isolation between Phase 1 and Phase 2
- Independent operation of both releases
- No Phase 1 schema changes
- No Phase 1 data changes
- No historical review migration
- No backfill requirement
- Clear rollback capability
- Clean Phase 2 lifecycle testing

#### Outdated Phase 1 DDL

The existing file:

`create_azure_sql_activity_log.sql`

must be treated as historical and outdated.

The file defines `ACTIVITY_LOG_ID` as `INT IDENTITY`.

However, the working implementation generates UUID values in Python and stores them as string values.

The historical DDL file must not be:

- Used to create `MM_ACTIVITY_LOG`
- Copied and renamed for Phase 2
- Treated as the live Phase 1 schema definition
- Used as evidence of current identifier behaviour

The working repository code and live Azure SQL implementation are authoritative.

##### Verified Identifier Implementation

The current implementation generates ACTIVITY_LOG_ID in Python.

The repository uses:

```python
uuid.uuid4()
```

when no source value is available.

It uses:

```python
uuid.uuid5(uuid.NAMESPACE_DNS, value)
```

when a supplied value is not already a valid UUID.

The generated UUID value is supplied to Azure SQL by the Python application.

The live Azure SQL schema stores:

```sql
ACTIVITY_LOG_ID UNIQUEIDENTIFIER
```

The live SQLite schema stores:

```sql
ACTIVITY_LOG_ID TEXT
```

The historical DDL file defining:

```sql
ACTIVITY_LOG_ID INT IDENTITY
```

is outdated and no longer reflects the working implementation.

MM_ACTIVITY_LOG must preserve the existing identifier strategy.

Python remains responsible for UUID generation.

Azure SQL remains responsible for storing the UUID using the UNIQUEIDENTIFIER datatype.

No UUID redesign is required during Phase 2A.

##### New Phase 2 DDL File

Create a new Phase 2 SQL file:

`create_mm_activity_log.sql`

This file must:

- Create dbo.MM_ACTIVITY_LOG
- Include WORKSTREAM_NAME
- Preserve the proven Import Constraints review fields
- Define ACTIVITY_LOG_ID as UNIQUEIDENTIFIER NOT NULL
- Define ACTIVITY_LOG_ID as the primary key
- Preserve Python-based UUID generation
- Add the correct logical uniqueness constraint
- Add justified indexes
- Remain independent from dbo.ACTIVITY_LOG
- Be safe to execute when MM_ACTIVITY_LOG already exists
- Contain clear comments describing its Phase 2 purpose

The database must not independently generate ACTIVITY_LOG_ID.

The existing Python repository logic remains responsible for generating and validating UUID values.

#### Initial Data Position

`MM_ACTIVITY_LOG` will start empty.

Existing `ACTIVITY_LOG` records will not be copied.

Existing `ACTIVITY_LOG` records will not be modified.

No historical migration or backfill is required during Phase 2A.

Existing Import Constraints alerts remain available and can be reviewed again to test:

- Unreviewed alert behaviour
- Open review creation
- Open review updates
- Open-to-Closed transitions
- Direct Closed review creation where permitted
- Open Reviews
- Closed Reviews
- Bulk review behaviour
- Workstream partitioning
- Analyst attribution
- Azure SQL persistence

#### Initial Schema Contract

The initial `MM_ACTIVITY_LOG` schema must preserve the proven Phase 1 review fields and add `WORKSTREAM_NAME`.

Expected fields:

```text
ACTIVITY_LOG_ID
WORKSTREAM_NAME
ALERT_UNIQUE_ID
BMU_ID
PARTY_NAME
PARAMETER_BREACHED
RAISE_DATE
START_DATE
END_DATE
PERSON_RAISING
NOTIFICATION_SOURCE
ACTION_TAKEN
ANALYSIS_STATUS
INFO_FOR_ANALYST
REVIEW_COMMENTS
CREATED_DATETIME
UPDATED_DATETIME
```

The initial Azure SQL datatypes should remain compatible with the current working repository:

```text
ACTIVITY_LOG_ID       VARCHAR(255)
WORKSTREAM_NAME       VARCHAR(100)
ALERT_UNIQUE_ID       VARCHAR(255)
BMU_ID                VARCHAR(100)
PARTY_NAME            VARCHAR(255)
PARAMETER_BREACHED    VARCHAR(255)
RAISE_DATE            VARCHAR(50)
START_DATE            VARCHAR(50)
END_DATE              VARCHAR(50)
PERSON_RAISING        VARCHAR(255)
NOTIFICATION_SOURCE   VARCHAR(255)
ACTION_TAKEN          VARCHAR(255)
ANALYSIS_STATUS       VARCHAR(50)
INFO_FOR_ANALYST      NVARCHAR(MAX)
REVIEW_COMMENTS       NVARCHAR(MAX)
CREATED_DATETIME      VARCHAR(50)
UPDATED_DATETIME      VARCHAR(50)
```

The final DDL must still be checked against:

- Current INSERT statements
- Current UPDATE statements
- Current review reads
- Open Reviews
- Closed Reviews
- Bulk-save behaviour
- Existing tests

Do not add speculative fields during P1.

#### Workstream Field

The new table must include:

`WORKSTREAM_NAME`

Initial controlled values:

```python
ALLOWED_WORKSTREAMS = {
    "IMPORT_CONSTRAINTS",
    "IC",
    "TCLC",
    "IOLC",
    "UMM",
}
```

Do not build the full workstream registry during P1.

During the initial implementation, all Phase 2 Import Constraints review records must use:

`IMPORT_CONSTRAINTS`

The value must be supplied automatically.

The analyst must not manually enter or select `WORKSTREAM_NAME` on the review form.

Before workstream session context exists, the Phase 2 Import Constraints implementation may supply the controlled value directly.

After workstream session context is implemented, the active session workstream will supply the value.

##### Identifier Strategy

Current live ACTIVITY_LOG records use UUID values generated in Python.

The live Azure SQL schema stores:

```sql
ACTIVITY_LOG_ID UNIQUEIDENTIFIER
```

The historical DDL showing INT IDENTITY is outdated.

MM_ACTIVITY_LOG must preserve:

- Python-generated UUID values
- Azure SQL UNIQUEIDENTIFIER storage

Use:

`ACTIVITY_LOG_ID`

as the technical primary key.

Use:

`WORKSTREAM_NAME + ALERT_UNIQUE_ID`

as the logical identity of a review.

The intended model is:

```text
ACTIVITY_LOG_ID
=
Technical UUID identifier

WORKSTREAM_NAME + ALERT_UNIQUE_ID
=
Logical review identity
```

The current lifecycle updates one existing review row identified by its alert identifier.

For the platform, the lookup and update lifecycle must include both:

```text
WORKSTREAM_NAME
+
ALERT_UNIQUE_ID
```

The platform table should therefore use:

```sql
UNIQUE (
    WORKSTREAM_NAME,
    ALERT_UNIQUE_ID
)
```

rather than:

```sql
UNIQUE (
    ALERT_UNIQUE_ID
)
```

to avoid collisions across future workstreams.

#### Import Constraints Schemas

Phase 2 must continue reading Import Constraints alerts and supporting evidence from the existing Import Constraints schemas.

The initial architecture is:

```text
Import Constraints alerts
    ↓
Existing Import Constraints alert tables

Import Constraints supporting evidence
    ↓
Existing Import Constraints evidence tables

Phase 2 review persistence
    ↓
MM_ACTIVITY_LOG
```

The existing Import Constraints alert and evidence tables do not automatically require a `WORKSTREAM_NAME` column.

The Import Constraints repository or adapter may supply:

`IMPORT_CONSTRAINTS`

when mapping records into the shared platform contract.

This decision must be confirmed by the Platform Versus Workstream Code Review.

Do not modify existing Import Constraints alert or evidence schemas unless the code review identifies a verified requirement.

#### Phase 2 Repointing

Trace every current reference to:

`ACTIVITY_LOG`

Classify each reference as:

- Frozen Phase 1 only
- Required in Phase 2
- Shared configuration requiring separation
- Test-only
- Obsolete

All Phase 2 operations must be repointed to:

`MM_ACTIVITY_LOG`

This includes operations that:

- Create the table
- Insert a review
- Update a review
- Retrieve a review
- Derive Unreviewed, Open or Closed status
- Load all saved reviews
- Load Open Reviews
- Load Closed Reviews
- Join alerts to reviews
- Perform bulk saves
- Filter reviews
- Use review data in analytical or statistical views

Every applicable Phase 2 review operation must include workstream context.

For the initial Import Constraints implementation:

```text
WORKSTREAM_NAME = IMPORT_CONSTRAINTS
```

The Phase 1 code must remain pointed to:

`ACTIVITY_LOG`

The Phase 2 code must be pointed to:

`MM_ACTIVITY_LOG`

Avoid one global table constant shared across both releases if changing that constant could redirect the frozen Phase 1 release.

#### Repository Changes

The Phase 2 repository must update the following verified behaviours:

- SQLite table creation
- Azure SQL table creation
- Review lookup by alert
- Existing-review lookup before save
- INSERT statement
- UPDATE statement
- All-saved-reviews query
- Closed Reviews query
- Alert joins
- Status filters

Functions currently using only `ALERT_UNIQUE_ID` must be changed to use:

```text
WORKSTREAM_NAME
+
ALERT_UNIQUE_ID
```

The repository must preserve:

- Python UUID generation
- Created timestamp preservation during updates
- Updated timestamp replacement during updates
- Existing date formatting behaviour unless separately changed
- Existing transaction handling through `get_db()`

#### Local and Test Environments

Create the corresponding `MM_ACTIVITY_LOG` structure in every Phase 2 environment used for development and testing.

This includes:

- Azure SQL development environment
- Local SQLite test schema where applicable
- Test fixtures
- Repository tests
- Service tests
- End-to-end workflow tests

Phase 1 schemas and fixtures must remain available for frozen-baseline regression testing where required.

The SQLite uniqueness rule must also become:

```text
WORKSTREAM_NAME + ALERT_UNIQUE_ID
```

rather than:

```text
ALERT_UNIQUE_ID only
```

#### Required Documentation Changes

Create and maintain:

`create_mm_activity_log.sql`

Retain the existing file as historical evidence:

`create_azure_sql_activity_log.sql`

Do not modify the historical file where preserving the approved Phase 1 release requires it to remain unchanged.

Document clearly that:

- It belongs to Phase 1 history
- It no longer represents the working `ACTIVITY_LOG` implementation
- It must not be used for Phase 2
- `create_mm_activity_log.sql` is the authoritative Phase 2 DDL
- UUID generation occurs in the Python repository
- UUID values are stored as strings

Record the final schema and repository changes in:

`DEVELOPMENT_LOG.md`

#### Acceptance Criteria

P1 is complete when:

- `ACTIVITY_LOG` remains unchanged
- The approved Phase 1 release still uses `ACTIVITY_LOG`
- The historical Phase 1 DDL is not used for Phase 2
- Python UUID generation is preserved
- `create_mm_activity_log.sql` exists
- `MM_ACTIVITY_LOG` exists
- `MM_ACTIVITY_LOG` starts empty
- `MM_ACTIVITY_LOG` includes `WORKSTREAM_NAME`
- `ACTIVITY_LOG_ID` uses the verified UUID-string approach
- The logical review identity includes workstream and alert
- The composite uniqueness constraint uses workstream and alert
- Phase 2 uses `MM_ACTIVITY_LOG` exclusively for review persistence
- Import Constraints saves include `IMPORT_CONSTRAINTS`
- Import Constraints reads are partitioned by workstream
- Import Constraints updates are partitioned by workstream
- Open Reviews use `MM_ACTIVITY_LOG`
- Closed Reviews use `MM_ACTIVITY_LOG`
- Alert-status derivation uses `MM_ACTIVITY_LOG`
- Bulk-review behaviour uses `MM_ACTIVITY_LOG`
- Phase 1 and Phase 2 can operate independently
- Phase 1 regression checks pass
- Phase 2 review lifecycle tests pass
- All decisions and evidence are recorded in `DEVELOPMENT_LOG.md`

### P2: Platform Versus Workstream Code Review

The Platform Versus Workstream Review is the most important architectural activity in Phase 2A.

No generic workstream abstraction should begin until this review is complete.

Complete the review before building the generic workstream framework.

The review must happen before the workstream registry and before migrating a second workstream.

The landing page and rota may be developed after this review using the agreed platform boundaries.

Classify every file and significant function as:

- Platform-shared
- Workstream-specific
- Mixed responsibility
- Infrastructure
- Dead code

Likely platform-shared capabilities include:

- Landing page
- Analyst session
- Navigation
- Alert review lifecycle
- Open Reviews
- Closed Reviews
- `MM_ACTIVITY_LOG`
- Review status handling
- Review validation
- Rota
- Administration
- Shared components
- Shared formatting

Likely Import Constraints-specific capabilities include:

- Import Constraints SQL tables
- Settlement-period logic
- Ensemble alert-window inference
- Import Constraints behavioural classification
- C1, C2 and C3 calculations
- Import Constraints analytical dashboard
- Import Constraints evidence preparation
- Import Constraints external-link context

The review must identify:

- Hardcoded Import Constraints labels
- Hardcoded table names
- Hardcoded routes
- Hardcoded fields
- Hardcoded investigation links
- Workstream assumptions in callbacks
- Workstream assumptions in services
- Workstream assumptions in models
- Workstream assumptions in repository joins
- Workstream assumptions in activity-log updates
- Shared functions containing workstream-specific logic
- Test fixtures coupled to Import Constraints
- Dead code
- Duplicate logic
- Existing abstractions that should remain unchanged

Required output:

```text
File or Function
Current Classification
Current Responsibility
Target Classification
Required Change
Risk
Regression Coverage
```

Do not generalise code solely because it contains an Import Constraints reference.

Legitimately workstream-specific behaviour should remain explicit and isolated.

### P3: Platform Landing Page

Create a new landing page at:

`/`

The landing page establishes the application as the Market Monitoring Platform.

The page will contain:

- NESO branding where permitted
- Market Monitoring Platform heading
- Optional internal title or approved working name
- Welcome section
- Analyst dropdown
- Workstream buttons
- Rota for This Week button
- Admin Page button

The final branding and title should be agreed before implementation.

Initial workstream buttons:

- Import Constraints
- IC
- TCLC
- IOLC
- UMM

During the initial Phase 2 implementation:

- Import Constraints is operational
- Other workstream names may be displayed as planned
- Planned workstream buttons must be disabled or clearly marked as not operational
- Planned buttons must not navigate to incomplete operational pages

The landing page should contain buttons that open separate pages.

The landing page should not attempt to contain every operational feature directly.

### P4: Temporary Analyst Session

During local Phase 2 development, analyst identity will use placeholder analysts.

Examples:

- Analyst 1
- Analyst 2
- Analyst 3

The analyst selects a name from the landing-page dropdown.

The analyst must be selected before a workstream can be opened.

This is a key operational guardrail.

The selected analyst will be stored in a session-scoped `dcc.Store`.

The initial session context should include:

```python
{
    "analyst": "Analyst 1",
    "workstream": "IMPORT_CONSTRAINTS",
}
```

Analysts are expected to work across all workstreams.

Each Monitoring session may involve the analyst reviewing multiple workstreams.

The session does not require a mapping between analysts and permitted workstreams during the initial implementation.

The session contains:

- The current analyst
- The current workstream

The selected analyst will replace the current `LOCAL_ANALYST_NAME` placeholder when saving reviews.

The value will populate:

`PERSON_RAISING`

The active workstream will populate:

`WORKSTREAM_NAME`

This is temporary application context.

It is not authentication.

Real user identity will be considered later when the deployment and authentication architecture is agreed.

Required guardrails:

- No workstream entry without analyst selection
- No review save without analyst context
- No silent fallback to an unidentified analyst
- Direct operational-page access without context returns to Home
- Browser refresh and navigation behaviour must be tested
- Session data must not leak between browser sessions

### P5: Rota and Administration

The platform will contain the existing Market Monitoring rota.

The rota contains different people on different days.

The existing rota structure and operating process must be understood before finalising the Azure SQL schema.

The rota must:

- Show the current week
- Be accessible from the landing page
- Be editable through Dash
- Use similar validation and persistence principles to the alert workflow
- Support quick changes during or after stand-ups
- Store changes in Azure SQL
- Avoid reliance on the existing Excel workbook as the operational source
- Preserve the actual rota structure
- Support a wider management view through the Admin page

The platform must not replace the current rota with:

- Workstream ownership
- Lead and support roles
- A simplified single-person weekly assignment
- Another scheduling model

unless this is separately agreed.

#### Rota for This Week Page

The landing page will contain:

`Rota for This Week`

This button opens a separate page containing the current weekly rota.

The page should prioritise clear operational visibility.

#### Admin Page

The landing page will contain:

`Admin Page`

The Admin page allows the rota to be managed.

Initial capabilities:

- View current rota entries
- View future rota entries
- Add entries
- Edit entries
- Replace assignments
- Remove entries where allowed
- Make ad-hoc changes
- Select analysts from controlled values
- Validate required fields
- Save changes to Azure SQL
- Display clear success messages
- Display clear validation and database errors

The Admin page should provide a wider rota view than the current-week page.

The first implementation should prioritise:

- Correctness
- Speed of change
- Validation
- Auditability
- Reliable persistence

Advanced calendar presentation is not required initially.

#### Rota SQL Design

The precise Azure SQL schema must be derived from:

- The current rota fields
- The current rota rules
- The required daily assignments
- The required update process
- Any overlapping assignment rules
- Historical requirements
- Audit requirements

Do not finalise the schema from a simplified mock-up.

### P6: Landing-Page Navigation Rules

Navigation rules:

- The analyst dropdown is available immediately
- Workstream buttons remain disabled until an analyst is selected
- Selecting an analyst stores analyst context
- Selecting a workstream stores workstream context
- The application opens the selected workstream area
- Rota for This Week opens the weekly rota page
- Admin Page opens the rota administration page
- Home returns the user to the landing page

Unsaved-change behaviour must be defined and validated before Home navigation is considered complete.

The application must not silently discard unsaved review changes.

If an operational page is opened without the required session context, the application should redirect to the landing page.

Planned workstream buttons must not provide access to incomplete workflows.

### P7: Sidebar and Navigation Review

Once landing-page navigation works:

- Add Home to the sidebar
- Display the active analyst where useful
- Display the active workstream where useful
- Review whether existing workstream dropdowns remain necessary
- Preserve existing page routes where practical
- Test direct navigation
- Test browser refresh behaviour
- Test back and forward navigation
- Test missing session context
- Test changes between workstreams
- Test unsaved-change behaviour

Remove per-page workstream selectors only after the replacement session flow has passed regression testing.

Do not remove working controls before the replacement behaviour is proven.

### P8: Define the Shared Platform Contract

Use the Platform Versus Workstream Code Review as the primary input.

Define the minimum contract required for workstream integration.

Potential shared concepts:

- Workstream
- Alert identifier
- Alert start
- Alert end
- Review status
- Investigation
- Decision
- Action
- Comments
- Analyst
- Created timestamp
- Updated timestamp
- Investigation links

The contract should define:

- Required fields
- Optional fields
- Shared service responsibilities
- Shared repository expectations
- Shared review behaviour
- Workstream-specific extension points
- Error handling
- Empty-data behaviour

Do not assume every workstream has the same raw Azure SQL schema.

Where necessary, repositories or adapters should map workstream-specific records into a common platform representation.

Do not force workstream-specific analytics into a generic model unless genuine common behaviour exists.

Shared functionality is any capability intended to be reused across workstreams without rewriting the complete capability.

Potential shared functionality includes:

- Alert Review
- Open Reviews
- Closed Reviews
- `MM_ACTIVITY_LOG`
- Navigation
- Landing Page
- Analyst Session
- Rota
- Administration

### P9: Workstream Definition or Registry

Implement the workstream configuration mechanism only after:

- The code review is complete
- The shared platform contract is defined
- The variation points are evidenced

A workstream definition may include:

- Workstream ID
- Display name
- Availability status
- Operational route
- Analytical Support route
- Statistical Support route
- Repository or adapter
- Supported platform capabilities
- Applicable investigation links

The configuration must not reduce the architecture to dynamic table-name substitution.

It must represent genuine platform variation without hiding meaningful workstream differences.

The initial controlled identifiers should evolve into this definition only when the required structure is understood.

### P10: Investigation-Link Framework

Create a shared mechanism for displaying contextual investigation buttons.

Potential destinations:

- Elexon
- REMIT
- Enappsys

The active workstream and selected alert context determine which buttons are displayed.

Potential interface:

```python
get_investigation_links(
    workstream_name,
    alert_context,
)
```

URL construction should be isolated from page callbacks.

Pages should request applicable links and render the returned controls.

Requirements:

- Link templates belong in configuration
- URL construction belongs in dedicated utilities or builders
- Pages should not contain repeated URL-building logic
- Existing working Elexon functionality should be preserved
- Existing functionality should be reused where appropriate
- Broken external links must not block the review lifecycle
- Azure SQL remains the operational source of truth

The exact destination mapping must be confirmed per workstream.

### P11: Second Workstream

Add a second workstream only after Phase 2B Platform Integration and Validation is complete.

Prerequisites:

- `MM_ACTIVITY_LOG` is stable
- Python-based UUID generation is proven in Phase 2
- Composite workstream and alert identity is proven
- Import Constraints is fully operational in Phase 2
- Platform-wide regression tests pass
- Shared platform functionality is identified and documented
- The shared platform contract is complete
- The workstream definition mechanism is ready
- Phase 1 and Phase 2 operate independently
- Phase 2B exit criteria have been met

The second workstream must be selected separately.

The migration should validate that:

- Shared review functionality can be reused
- Workstream-specific logic remains isolated
- Each workstream can use its own Azure SQL schema and tables
- `WORKSTREAM_NAME` prevents cross-workstream contamination
- Identical alert identifiers can exist safely across different workstreams
- Landing-page selection works
- Analyst context works
- Open Reviews are correctly partitioned
- Closed Reviews are correctly partitioned
- Investigation links vary correctly
- Analytical Support can remain workstream-specific
- Statistical Support can remain workstream-specific
- Import Constraints behaviour remains unchanged

The second workstream must be treated as a migration into the shared platform.

It must not become a duplicate application.

## 9. Deferred and Backlog Scope

The following items are not part of the immediate Phase 2A implementation.

### 9.1 NED Historical Migration

NED migration remains backlog.

The current architecture must not prevent a future migration, but Phase 2A must not implement it.

### 9.2 Parquet Historical Archive

Historical Parquet archiving remains backlog.

### 9.3 Production Authentication

Entra ID or another real authentication mechanism remains deferred until the deployment design is agreed.

### 9.4 Streamlit KPI Development

Streamlit KPI and governance work is owned separately.

### 9.5 BMU and Counterparty Reference Data

The existing workbook requires separate analysis.

Potential future direction:

- Review required fields
- Remove duplicates
- Define ownership
- Define update process
- Load required reference data into Azure SQL
- Avoid SharePoint runtime dependency

This is not an immediate blocker for Phase 2A.

### 9.6 Additional Workstreams

Full migration of all planned workstreams is outside the initial platform foundation.

### 9.7 Excel Upload

No generic Excel upload capability is approved.

## 10. Documentation Structure

### 10.1 Authoritative Phase 2 Documents

- `README.md`
- `phase2_platform_foundation.md`
- `DEVELOPMENT_LOG.md`
- `create_mm_activity_log.sql`

### 10.2 Authoritative Phase 1 Code Reference

- `release_2_local_azure_sql_working_final`

### 10.3 Baseline Technical Reference Documents

The following Phase 1 SQL file is retained as historical evidence:

- create_azure_sql_activity_log.sql

This SQL file must not be treated as the live Phase 1 schema definition or used as the basis for Phase 2.

The file defines:

```sql
ACTIVITY_LOG_ID INT IDENTITY
```

However, the verified working implementation:

- Generates UUID values in Python
- Stores ACTIVITY_LOG_ID as UNIQUEIDENTIFIER in Azure SQL
- Stores ACTIVITY_LOG_ID as TEXT in SQLite

The working repository code and live Azure SQL schema are authoritative.

The authoritative Phase 2 activity-log DDL will be:

- create_mm_activity_log.sql

### 10.4 Retired Discovery Documents

Documents whose decisions have been superseded should be archived or clearly marked as historical.

Examples:

- `phase2_welcome_and_date_analysis.md`
- Previous versions of `phase2_design_decisions.md`

Retired documents must not compete with the authoritative Phase 2 plan.

## 11. Development Audit Rules

The following P1 evidence must be recorded:

- Live ACTIVITY_LOG schema
- Live schema query results
- Differences from the historical DDL
- Location of UUID generation
- UUID generation method
- Verification that UUID generation occurs in Python
- Verification that Azure SQL stores ACTIVITY_LOG_ID as UNIQUEIDENTIFIER
- Final MM_ACTIVITY_LOG schema
- Final constraints and indexes
- Phase 2 repository repointing
- Phase 1 and Phase 2 independence checks


All Phase 2 work must be recorded in:

`DEVELOPMENT_LOG.md`

For every task, record:

- Task code
- Date
- Objective
- Files changed
- Database changes
- Behaviour changed
- Tests completed
- Regression checks completed
- Known limitations
- Final status

Documentation must describe verified implementation.

Planned behaviour must be clearly labelled as planned.

Assumptions must be clearly labelled as assumptions.

Do not describe proposed behaviour as completed behaviour.

The following P1 evidence must be recorded:

- Live `ACTIVITY_LOG` schema
- Differences from the historical DDL
- Location of UUID generation
- UUID generation method
- Final `MM_ACTIVITY_LOG` schema
- Final constraints and indexes
- Phase 2 repository repointing
- Phase 1 and Phase 2 independence checks

## 12. Execution Plan

### Phase 2A: Build the Platform Foundations

#### Goal

Build the foundational Market Monitoring Platform around the approved Import Constraints implementation.

Phase 2A must produce:

```text
Shared platform infrastructure
+
One fully functioning Import Constraints workstream
```

Phase 2A does not add a second workstream.

The approved Phase 1 release remains independently operational throughout Phase 2A.

#### Success Criteria

Phase 2A is complete when:

- The Phase 1 baseline remains unchanged
- Phase 1 continues to use `ACTIVITY_LOG`
- Phase 2 uses `MM_ACTIVITY_LOG`
- Phase 1 and Phase 2 can operate independently
- Import Constraints remains fully functional in Phase 2
- Dynamic date options are operational
- Workstream-aware review persistence is operational
- Shared platform infrastructure exists
- Platform and workstream responsibilities are understood
- Shared functionality has been identified
- Workstream-specific functionality has been identified
- The landing page is operational
- Analyst session context is operational
- Workstream session context is operational
- Navigation guardrails are operational
- Rota functionality is operational
- Rota administration is operational
- Investigation links use the agreed shared approach
- The shared platform contract is documented
- The platform is ready for integration and validation in Phase 2B

#### Execution Order

##### Baseline and Working Environment

1. Preserve and verify the Phase 1 baseline.
2. Confirm that `release_2_local_azure_sql_working_final` operates correctly.
3. Confirm that Phase 1 uses `ACTIVITY_LOG`.
4. Confirm that `create_azure_sql_activity_log.sql` is outdated and must not be used for Phase 2.
5. Create the separate Phase 2 working folder.
6. Copy only the required approved baseline code into the Phase 2 working folder.
7. Record the Phase 2 starting structure in `DEVELOPMENT_LOG.md`.

##### Dynamic Date Options

8. Review `get_available_time_options()` and all related date logic.
9. Identify every page and callback using shared date options.
10. Remove hardcoded month and week lists.
11. Support the required historical period from August 2022.
12. Include the agreed forward margin required by the review workflow.
13. Preserve the existing callback return structure.
14. Test month generation.
15. Test ISO week generation.
16. Test year boundaries.
17. Test historical dates.
18. Test current and forward-margin dates.
19. Test empty-data behaviour.
20. Run regression checks on all affected pages.

##### Verified Phase 1 Activity-Log Behaviour

21. Document the current Python UUID-generation behaviour.
22. Document the use of `uuid.uuid4()`.
23. Document the fallback use of deterministic `uuid.uuid5()`.
24. Document that Azure SQL stores `ACTIVITY_LOG_ID` as `VARCHAR(255)`.
25. Document that SQLite stores `ACTIVITY_LOG_ID` as `TEXT`.
26. Review every current activity-log read, write, update, filter and join.
27. Document the differences between the working repository and historical DDL.

##### Phase 2 Activity Log

28. Design `MM_ACTIVITY_LOG` using the verified working repository contract.
29. Add `WORKSTREAM_NAME` from the start.
30. Preserve Python-based UUID generation.
31. Preserve UUID-string storage.
32. Define `WORKSTREAM_NAME + ALERT_UNIQUE_ID` as the logical review identity.
33. Add a composite uniqueness constraint for workstream and alert.
34. Create `create_mm_activity_log.sql`.
35. Create `MM_ACTIVITY_LOG` in Azure SQL.
36. Create `MM_ACTIVITY_LOG` in the Phase 2 SQLite test schema.
37. Keep `MM_ACTIVITY_LOG` empty.
38. Do not copy or backfill Phase 1 review data.
39. Record the schema decision in `DEVELOPMENT_LOG.md`.

##### Import Constraints Repointing

40. Identify every Phase 2 reference to `ACTIVITY_LOG`.
41. Separate Phase 1 and Phase 2 table configuration.
42. Repoint Phase 2 review persistence to `MM_ACTIVITY_LOG`.
43. Update the Phase 2 activity-log model.
44. Update Phase 2 review payloads.
45. Add `WORKSTREAM_NAME` to INSERT operations.
46. Add workstream context to existing-review lookups.
47. Add workstream context to UPDATE operations.
48. Add workstream context to review retrieval.
49. Update review-status derivation.
50. Update all-saved-reviews retrieval.
51. Update Open Reviews.
52. Update Closed Reviews.
53. Update alert-to-review joins.
54. Update bulk-save behaviour.
55. Use `WORKSTREAM_NAME = 'IMPORT_CONSTRAINTS'` in all applicable Phase 2 operations.
56. Keep existing Import Constraints alert and evidence schemas unchanged unless the code review proves a change is required.
57. Confirm that Phase 1 still points to `ACTIVITY_LOG`.
58. Confirm that Phase 2 points only to `MM_ACTIVITY_LOG`.

##### Tests and Regression Validation

59. Update Phase 2 test schemas.
60. Update Phase 2 test fixtures.
61. Update repository tests.
62. Update service tests.
63. Test an alert with no `MM_ACTIVITY_LOG` record as Unreviewed.
64. Test saving a new Open review.
65. Test updating an Open review.
66. Test closing an Open review.
67. Test saving directly as Closed where permitted.
68. Test Open Reviews.
69. Test Closed Reviews.
70. Test bulk-review behaviour.
71. Test workstream partitioning.
72. Test duplicate alert identifiers across different workstreams.
73. Test Azure SQL persistence.
74. Run the complete Phase 1 regression checklist against the frozen baseline.
75. Confirm that Phase 1 and Phase 2 can operate independently.
76. Record test evidence and known limitations in `DEVELOPMENT_LOG.md`.

##### Platform Versus Workstream Code Review

77. Complete the Platform Versus Workstream Code Review.
78. Classify every file and significant function as:
    - Platform-shared
    - Workstream-specific
    - Mixed responsibility
    - Infrastructure
    - Dead code
79. Identify all remaining Import Constraints assumptions.
80. Identify genuine shared platform functionality.
81. Identify functionality that must remain Import Constraints-specific.
82. Identify mixed modules requiring later separation.
83. Identify abstractions that should remain unchanged.
84. Create the platform functionality inventory.
85. Document the findings before implementing generic abstractions.

##### Platform Home and Session Context

86. Build the platform landing page.
87. Add placeholder analysts.
88. Add analyst session context.
89. Add workstream session context.
90. Replace `LOCAL_ANALYST_NAME`.
91. Populate `PERSON_RAISING` from analyst session context.
92. Populate `WORKSTREAM_NAME` from workstream session context.
93. Prevent workstream entry without analyst selection.
94. Prevent review saves without analyst context.
95. Add direct-navigation guardrails.
96. Test session isolation.
97. Test browser refresh behaviour.
98. Test back and forward navigation.

##### Rota and Administration

99. Analyse the complete current rota process.
100. Document the actual rota fields and rules.
101. Define rota validation requirements.
102. Define rota audit requirements.
103. Design the Azure SQL rota schema.
104. Create the required analyst reference table.
105. Create the rota table or tables.
106. Build Rota for This Week.
107. Build the Admin Page.
108. Implement rota reads.
109. Implement rota inserts.
110. Implement rota updates.
111. Implement permitted rota removals or replacements.
112. Add validation.
113. Add success and error messages.
114. Test ad-hoc changes.
115. Test current-week display.
116. Test future rota entries.
117. Confirm that the rota no longer depends on Excel during normal operation.

##### Navigation and Shared Platform Contract

118. Add Home to the sidebar.
119. Display the active analyst where useful.
120. Display the active workstream where useful.
121. Review existing workstream selectors.
122. Remove existing selectors only after replacement behaviour is proven.
123. Define unsaved-change navigation behaviour.
124. Test Home navigation with unsaved changes.
125. Finalise the shared platform functionality inventory.
126. Define the shared platform contract.
127. Define required shared fields.
128. Define optional shared fields.
129. Define shared review behaviour.
130. Define repository or adapter expectations.
131. Define workstream-specific extension points.
132. Define error and empty-data behaviour.

##### Investigation Links

133. Review the existing Elexon link implementation.
134. Preserve working Import Constraints behaviour.
135. Identify reusable link-building functionality.
136. Define the shared investigation-link interface.
137. Isolate URL construction from page callbacks.
138. Configure the Import Constraints investigation links.
139. Test broken or unavailable external destinations.
140. Confirm that external-link failure does not block review persistence.

##### Phase 2A Exit Gate

141. Run the complete Phase 2A regression suite.
142. Run the complete frozen Phase 1 regression suite.
143. Confirm independent operation of Phase 1 and Phase 2.
144. Confirm that Import Constraints is fully operational in Phase 2.
145. Confirm that shared platform functionality is documented.
146. Confirm that workstream-specific functionality is documented.
147. Confirm that all material changes are recorded in `DEVELOPMENT_LOG.md`.
148. Confirm readiness to enter Phase 2B Platform Integration and Validation.


### Phase 2B: Platform Integration and Validation

#### Goal

Prove that the platform infrastructure and Import Constraints workstream operate as one integrated system.

Phase 2B validates:

```text
Platform
+
Import Constraints
=
One coherent operational system
```

No second workstream is introduced during Phase 2B.

#### Success Criteria

Phase 2B is complete when:

- Landing page integration is complete
- Analyst session integration is complete
- Workstream session integration is complete
- `MM_ACTIVITY_LOG` integration is complete
- Phase 1 remains independently operational
- Phase 1 continues using `ACTIVITY_LOG`
- Phase 2 exclusively uses `MM_ACTIVITY_LOG`
- Open Reviews operate correctly
- Closed Reviews operate correctly
- Review-status derivation operates correctly
- Navigation is stable
- Unsaved-change behaviour is controlled
- Rota integration is complete
- Admin functionality is operational
- Investigation links behave correctly
- No remaining critical Import Constraints assumptions exist in shared platform functionality
- Shared platform functionality is isolated where appropriate
- Import Constraints remains fully operational
- The platform is ready for multi-workstream enablement

#### Execution Order

1. Complete platform-wide integration testing.
2. Complete platform-wide regression testing.
3. Verify independent operation of Phase 1 and Phase 2.
4. Verify that Phase 1 uses `ACTIVITY_LOG`.
5. Verify that Phase 2 uses `MM_ACTIVITY_LOG`.
6. Verify that Python-based UUID generation remains correct.
7. Verify that the logical review identity includes workstream and alert.
8. Validate analyst session behaviour.
9. Validate workstream session behaviour.
10. Validate navigation guardrails.
11. Validate browser refresh behaviour.
12. Validate back and forward navigation.
13. Validate unsaved-change behaviour.
14. Validate review persistence.
15. Validate Unreviewed status.
16. Validate Open Reviews.
17. Validate Closed Reviews.
18. Validate Open-to-Closed transitions.
19. Validate bulk-review behaviour.
20. Validate workstream partitioning.
21. Validate rota functionality.
22. Validate administration functionality.
23. Validate investigation-link behaviour.
24. Validate external-link failure handling.
25. Review remaining platform-workstream coupling.
26. Resolve critical shared-functionality coupling.
27. Finalise the shared platform functionality inventory.
28. Finalise the workstream-specific functionality inventory.
29. Finalise the shared platform contract.
30. Finalise platform architecture documentation.
31. Record all findings and limitations in `DEVELOPMENT_LOG.md`.
32. Confirm readiness for Phase 2C Multi-Workstream Enablement.

### Phase 2C: Multi-Workstream Enablement

#### Goal

Extend the validated platform to support additional Monitoring workstreams.

#### Success Criteria

- Shared platform functionality is reusable
- Workstream-specific functionality remains isolated
- Additional workstreams can be added without duplicating the application
- Review data remains partitioned by workstream
- Platform architecture scales correctly
- Import Constraints continues to operate correctly

#### Execution Order

1. Implement the workstream definition mechanism.
2. Create the first version of the workstream registry.
3. Select the second workstream.
4. Map the second workstream against the shared platform contract.
5. Implement required repository or service adapters.
6. Implement workstream-specific analytical support.
7. Implement workstream-specific statistical support where required.
8. Implement workstream-specific investigation links.
9. Validate workstream isolation.
10. Validate review persistence.
11. Validate Open Reviews.
12. Validate Closed Reviews.
13. Run full Import Constraints regression testing.
14. Refine the platform contract where required.
15. Refine the workstream registry where required.
16. Document lessons learned.
17. Confirm readiness for additional workstreams.

### Future Phases

Potential future scope:

- Additional workstreams
- Production authentication
- Reference data management
- BMU and counterparty reference tables
- Historical data strategy
- NED migration
- Production hardening
- Operational governance support
- Additional analytical modules

Final objective:

A fully operational Market Monitoring Platform supporting multiple Monitoring workstreams through a shared architecture.