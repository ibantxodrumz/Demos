# Layer Connections

## Connection mechanism: Python `import`

```
app.py
  imports → navbar.py (components)
  imports → dash (framework)

alert_review.py (page)
  imports → alert_service, activity_log_service, analytics_service  (services)
  imports → alert_table (component)
  imports → bmrs_links (utils)
  imports → settings (config)

analytical_support.py (page)
  imports → alert_service, analytics_service  (services)

import_constraints.py (page)
  imports → alert_service, sp_analytics_service  (services)
  imports → formatting (utils)

open_reviews.py (page)
  imports → alert_service, activity_log_service, analytics_service  (services)
  imports → alert_table (component)
  imports → bmrs_links (utils)

closed_reviews.py (page)
  imports → alert_service  (services)

long_run_analytics.py (page)
  imports → long_run_service, alert_service  (services)

alert_service.py (service)
  imports → alert_repository  (repository)

activity_log_service.py (service)
  imports → activity_log_repository  (repository)
  imports → alert_repository         (repository — looks up alert before saving)
  imports → analytics_service        (service — generates INFO_FOR_ANALYST at save time)
  imports → SaveReviewRequest model  (models)
  imports → settings                 (config)

analytics_service.py (service)
  imports → analytics_repository  (repository)

sp_analytics_service.py (service)
  imports → sp_analytics_repository  (repository)

long_run_service.py (service)
  imports → alert_service        (service)
  imports → sp_analytics_service (service)

alert_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants             (table name strings)

activity_log_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

analytics_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

sp_analytics_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

connection.py
  imports → azure_connection      (Azure-specific driver)
  imports → settings              (reads DATABASE_MODE)
  imports → sqlite3               (Python stdlib)
```

---

## Contract at each boundary

| Boundary | What crosses it |
|---|---|
| Page → Service | function call, simple Python types (str, int, None) |
| Service → Repository | function call, simple Python types |
| Repository → Connection | calls `get_db()` context manager |
| Connection → Database | SQL string + params dict |
| Database → Connection | raw rows |
| Connection → Repository | connection object |
| Repository → Service | list of plain Python `dict` |
| Service → Page | dict or list of dicts |
| Page → Browser | Dash component tree (HTML) |

Nothing exotic crosses any boundary. No classes, no dataframes — plain Python dicts and lists throughout. Exceptions: `analytics_service.enrich_sp_data()` and `sp_analytics_service` work internally with pandas DataFrames but return dicts/lists to the page.

---

## Flow diagram

```mermaid
graph LR
    A[Page] -->|"calls f(str, str)"| B[Service]
    B -->|"calls f(str, str)"| C[Repository]
    C -->|"get_db()"| D[Connection]
    D -->|SQL| E[(Database)]
    E -->|raw rows| D
    D -->|conn object| C
    C -->|list of dict| B
    B -->|dict| A

    style A fill:#0891b2,color:#fff
    style B fill:#2563eb,color:#fff
    style C fill:#6d1a57,color:#fff
    style D fill:#4e0038,color:#fff
    style E fill:#1e293b,color:#fff
```

---

## Service-to-service calls (intentional)

Two services call other services rather than going directly to a repository:

1. `activity_log_service` calls `analytics_service` — to generate `INFO_FOR_ANALYST` from WHY flags at save time. Cleaner than duplicating analytics logic in the repository.
2. `long_run_service` calls both `alert_service` and `sp_analytics_service` — it needs review-status metadata from the alert layer and SP-level impact data from the analytics layer. Combining both into a single function is the correct level of abstraction.

---

## Why this matters

Because each layer only knows its immediate neighbour:

- Swap `connection.py` → different database, nothing else changes
- Swap a repository query → different SQL, service doesn't care
- Swap a page layout → different UI, service doesn't care
- Add a new service function → page calls it, repository stays untouched
