# Alert Lifecycle — Function-Level Trace

Alert used: `UNIQUE_ID = "ALT-CCGT-001"`, BMU `T_CCGT-01`, window `2026-02-03 08:00 → 10:00`

---

## Phase 1 — Alert Appears on Screen

**Analyst selects dates: 2026-02-02 to 2026-02-08**

```
[alert_review.py]
  callback: fetch_and_filter_alerts(start_date, end_date, ...)
    ↓
[alert_service.py]
  get_alerts_for_period("2026-02-02", "2026-02-08")
    ↓
[alert_repository.py]
  get_alerts_by_date_range("2026-02-02", "2026-02-08")
    → SQL: LEFT JOIN IMPORT_ALERTS + ACTIVITY_LOG
    → WHERE START_LOCAL >= "2026-02-02" AND < "2026-02-09"
    → returns list of dicts, ACTIVITY_LOG columns are NULL for ALT-CCGT-001 (never reviewed)
    ↓
[alert_service.py]
  derive_review_status(row)
    → ANALYSIS_STATUS is NULL → returns "Unreviewed"
    → row["DISPLAY_STATUS"] = "Unreviewed"
  collects bmu_options, party_options, fuel_options for dropdowns
  counts: total=N, unreviewed=N, open=0, closed=0
  returns { alerts: [...], summary: {...}, filter_options: {...} }
    ↓
[alert_review.py]
  callback returns:
    → DataTable data updated (amber "Unreviewed" row visible)
    → KPI cards updated
    → filter dropdowns populated
```

---

## Phase 2 — Analyst Ticks the Checkbox

```
[alert_review.py]
  callback: handle_alert_selection(selected_rows=[0], alerts_data=[...])
    → valid_indices = [0], single selection
    → alert = alerts_data[0]  ← already in memory, no DB call
    ↓
[analytics_service.py]
  get_aggregated_info_for_analyst(bmu_id="T_CCGT-01", start_gmt="2026-02-03 08:00", end_gmt="2026-02-03 10:00")
    ↓
[analytics_repository.py]
  get_why_values_for_alert("T_CCGT-01", "2026-02-03T08:00", "2026-02-03T10:00")
    → SQL: SELECT WHY FROM IMPORT_ALERTS_DATA WHERE BMU_ID=... AND GMT_FROM >= ... AND < ...
    → returns ["High Spread | SPREAD=42.3", "Price above fuel threshold"]
    ↓
[analytics_service.py]
  joins list → "High Spread | SPREAD=42.3 | Price above fuel threshold"
  returns string
    ↓
[alert_review.py]
  renders details card: BMU, counterparty, window, duration, INFO_FOR_ANALYST string
  calls get_bmrs_bmu_url(bmu_id="T_CCGT-01", start_gmt="2026-02-03 08:00")
    ↓
[bmrs_links.py]
  get_bmrs_bmu_url(...)
    → normalises bmu_id: adds "T_" prefix if missing
    → parses start_gmt → gets UTC day (2026-02-03T00:00:00Z to 2026-02-04T00:00:00Z)
    → builds URL with bmuId, activeTab, startDate, endDate query params
    → returns URL string
  get_bmrs_remit_url("T_CCGT-01")
    → returns REMIT URL string
    ↓
  callback returns:
    → store-selected-alert-id = ["ALT-CCGT-001"]
    → details card rendered
    → decision form pre-filled (all empty, never reviewed)
    → BMRS + REMIT links shown
```

---

## Phase 3 — Analyst Investigates (optional but common)

**Clicks "Open Detailed Analytical Evidence View" → new tab `/analytical-support?unique_id=ALT-CCGT-001`**

```
[analytical_support.py]
  callback: load_evidence(unique_id="ALT-CCGT-001")
    ↓
[alert_service.py]
  get_alert_by_id("ALT-CCGT-001")
    ↓
[alert_repository.py]
  get_alert_by_unique_id("ALT-CCGT-001")
    → LEFT JOIN query, single row, gets start_gmt + end_gmt
    ↓
[analytics_service.py]
  get_alert_evidence_payload(bmu_id="T_CCGT-01", start_gmt="2026-02-03 08:00", end_gmt="2026-02-03 10:00")
    ↓
[analytics_repository.py]
  get_sp_evidence_for_alert("T_CCGT-01", "2026-02-03T08:00", "2026-02-03T10:00")
    → SQL: SELECT * FROM IMPORT_ALERTS_DATA WHERE BMU_ID=... AND GMT_FROM >= ... AND < ...
    → returns 4 rows (08:00, 08:30, 09:00, 09:30)
    ↓
[analytics_service.py]
  enrich_sp_data(df)
    → pd.to_numeric() on SPREAD, OFFER_PRICE, OFFER_VOLUME_MWH etc (Azure DECIMAL fix)
    → COND_1/2/3 → bool
    → N_CONDITIONS_TRUE → BEHAVIOUR_CLASS ("Constrained - ensemble" for 2+ flags)
    → parse WHY string → WHY_CONDITIONS, WHY_DETAILS
    → calc IMPACT_C1 = max(SPREAD - MED_SPREAD_UNCON, 0) * volume
    → calc IMPACT_C2 = max(OFFER_PRICE - THR_FUEL, 0) * volume
    → calc IMPACT_C3 = max(SPREAD - (MED_SPREAD_UNCON + 30), 0) * volume
    → IMPACT_SP = mean(C1, C2, C3)
  computes metrics: avg_spread, avg_offer_price, avg_ref_price, total_estimated_impact
  returns { sp_records: [...4 rows enriched...], metrics: {...} }
    ↓
[analytical_support.py]
  renders SP DataTable + metric cards + Plotly charts
```

---

## Phase 4 — Analyst Saves

**Fills in form: Action Taken, Analysis Status, Review Comments. Clicks Save → ConfirmDialog → Confirm.**

### Case A — Saved as OPEN

```
Action Taken    = "Monitor Ongoing"
Analysis Status = "Open"
Review Comments = "Elevated spread confirmed. No STR warranted. Monitoring."

[alert_review.py]
  callback: save_review_callback(submit_n_clicks, alert_ids=["ALT-CCGT-001"], action_taken, analysis_status, comments)
    → validates all fields filled ✓
    → target_ids = ["ALT-CCGT-001"]
    ↓
[activity_log_service.py]
  save_analyst_review(
    alert_unique_id="ALT-CCGT-001",
    action_taken="Monitor Ongoing",
    analysis_status="Open",
    review_comments="Elevated spread confirmed..."
  )
    step 1 → SaveReviewRequest(...)
      → validate_action("Monitor Ongoing") → in CONTROLLED_ACTIONS ✓
      → validate_status("Open") → in CONTROLLED_STATUSES ✓
    step 2 → alert_repository.get_alert_by_unique_id("ALT-CCGT-001")
      → confirms alert exists, gets BMU_ID, START_GMT, END_GMT, COUNTERPARTY
    step 3 → analytics_service.get_aggregated_info_for_analyst("T_CCGT-01", ...)
      → analytics_repository.get_why_values_for_alert(...) → SQL query
      → returns "High Spread | Price above fuel threshold"
    step 4 → stamps now_iso, today_str, person_raising = LOCAL_ANALYST_NAME
    step 5 → builds record_payload = {
        ACTIVITY_LOG_ID:     "LOG-ALT-CCGT-001",
        ALERT_UNIQUE_ID:     "ALT-CCGT-001",
        BMU_ID:              "T_CCGT-01",
        PARTY_NAME:          "CCGT_CP",
        PARAMETER_BREACHED:  "Import Constraints",
        RAISE_DATE:          "2026-09-13",
        START_DATE:          "2026-02-03 08:00",
        END_DATE:            "2026-02-03 10:00",
        PERSON_RAISING:      "Local Prototype Analyst",
        NOTIFICATION_SOURCE: "IMPORT_CONSTRAINTS",
        ACTION_TAKEN:        "Monitor Ongoing",
        ANALYSIS_STATUS:     "Open",              ← KEY
        INFO_FOR_ANALYST:    "High Spread | Price above fuel threshold",
        REVIEW_COMMENTS:     "Elevated spread confirmed...",  ← analyst wrote this
        CREATED_DATETIME:    "2026-09-13T20:50:00",
        UPDATED_DATETIME:    "2026-09-13T20:50:00"
      }
    step 6 → activity_log_repository.save_activity_log(record_payload)
      → ensure_activity_log_table_exists() → table already exists, no-op
      → SELECT from ACTIVITY_LOG WHERE ALERT_UNIQUE_ID = "ALT-CCGT-001" → no row found
      → UUID already generated in Python (uuid.uuid5 / uuid.uuid4) and passed as :ACTIVITY_LOG_ID param
      → INSERT INTO ACTIVITY_LOG (...) VALUES (:ACTIVITY_LOG_ID, ...)
      → record_payload["ACTIVITY_LOG_ID"] = params["ACTIVITY_LOG_ID"]
      → returns saved record
    ↓
[alert_review.py]
  save_review_callback returns:
    → feedback = green "Review successfully persisted to SQL for 'ALT-CCGT-001'"
    → store-refresh-signal = 0 + 1 = 1
      ↓ (this triggers fetch_and_filter_alerts)
  fetch_and_filter_alerts re-runs
    → same LEFT JOIN query
    → now ACTIVITY_LOG has a row: ANALYSIS_STATUS = "Open"
    → derive_review_status() → "Open"
    → row["DISPLAY_STATUS"] = "Open"
    → table re-renders: row now BLUE, status = "Open"
    → KPI cards: unreviewed -1, open +1
```

---

### Case B — Saved as CLOSED

```
Action Taken    = "AutoClose"
Analysis Status = "Closed"
Review Comments = "False positive. Volume below materiality threshold. Closing."

Everything identical to Case A up to step 5. Differences in payload:

    record_payload = {
        ...
        ACTION_TAKEN:    "AutoClose",
        ANALYSIS_STATUS: "Closed",              ← KEY difference
        REVIEW_COMMENTS: "False positive...",
        ...
      }

[activity_log_repository.py]
  save_activity_log(record_payload)
    → SELECT → no existing row → INSERT (same path as Case A)
    ↓
[alert_review.py]
  store-refresh-signal increments → fetch_and_filter_alerts re-runs
    → LEFT JOIN now finds ANALYSIS_STATUS = "Closed"
    → derive_review_status() → "Closed"
    → row GREEN, status = "Closed"
    → KPI cards: unreviewed -1, closed +1
```

---

## Analyst Changes Their Mind (Re-review)

**Alert is already Open. Analyst selects it again, changes to Closed. Saves.**

```
[activity_log_service.py]
  save_analyst_review("ALT-CCGT-001", "AutoClose", "Closed", "Re-assessed. Now closing.")
    → same pipeline
    ↓
[activity_log_repository.py]
  save_activity_log(record_payload)
    → SELECT → row EXISTS (ACTIVITY_LOG_ID = "...", CREATED_DATETIME = "2026-09-13T20:50:00")
    → UPDATE path:
        SET ANALYSIS_STATUS = "Closed"
        SET ACTION_TAKEN = "AutoClose"
        SET REVIEW_COMMENTS = "Re-assessed. Now closing."
        SET UPDATED_DATETIME = "2026-09-13T21:05:00"   ← new timestamp
        WHERE ALERT_UNIQUE_ID = "ALT-CCGT-001"
    → record["CREATED_DATETIME"] = original "2026-09-13T20:50:00"  ← preserved
    → record["ACTIVITY_LOG_ID"] = original UUID                    ← preserved
```

**CREATED_DATETIME never changes. UPDATED_DATETIME stamps every revision. Full audit trail.**

---

## What Never Changes Between Case A and Case B

- The path from database → repo → service → page is identical
- `ACTIVITY_LOG` row structure is identical
- `INFO_FOR_ANALYST` is generated identically (system-derived from WHY flags)
- `REVIEW_COMMENTS` is always purely what the analyst typed
- The only difference: `ANALYSIS_STATUS = "Open"` vs `"Closed"`, `ACTION_TAKEN` value

The controlled vocabulary (`CONTROLLED_ACTIONS`, `CONTROLLED_STATUSES`) is the only gate that differs — Pydantic enforces the same rules for both cases.
