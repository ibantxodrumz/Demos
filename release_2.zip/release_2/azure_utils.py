# azure_utils.py - Integration with Azure Blob Storage

import pandas as pd
import io
import streamlit as st
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from constants import ACCOUNT_URL, CONTAINER_NAME

def get_blob_service_client():
    """Returns a BlobServiceClient using DefaultAzureCredential for local and cloud security."""
    try:
        credential = DefaultAzureCredential()
        return BlobServiceClient(account_url=ACCOUNT_URL, credential=credential)
    except Exception as e:
        st.error(f"Azure Authentication Failed: {str(e)}")
        return None

def list_csv_blobs():
    """Lists all .csv files in the configured Azure container."""
    client = get_blob_service_client()
    if not client:
        return []
    
    try:
        container_client = client.get_container_client(CONTAINER_NAME)
        blobs = container_client.list_blobs()
        return [blob.name for blob in blobs if blob.name.endswith('.csv')]
    except Exception as e:
        st.sidebar.warning(f"⚠️ Could not list Azure blobs: {str(e)}")
        return []

def load_blob_to_df(blob_name):
    """Downloads a blob and reads it directly into a Pandas DataFrame using BytesIO."""
    client = get_blob_service_client()
    if not client:
        return None
    
    try:
        container_client = client.get_container_client(CONTAINER_NAME)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Download blob content to stream
        stream = io.BytesIO()
        blob_client.download_blob().readinto(stream)
        stream.seek(0)
        
        return pd.read_csv(stream)
    except Exception as e:
        st.error(f"Error loading blob '{blob_name}': {str(e)}")
        return None
