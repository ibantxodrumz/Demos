# Import Constraints Dashboard — Release 2 (Phase 2 Analyst Intelligence)

This release transforms the dashboard into a **hybrid triage and diagnostics interface**. It provides an "Intelligence Layer" on top of the raw canonical data to help analysts decide: *close, monitor, discuss, or escalate?*

---

## 🚀 NEW: Phase 2 Analyst Intelligence Guide

### **1. Tab 4: Alerts for Monitoring (The Triage Cockpit)**
Use this tab to quickly assess the severity and volume of flagged alerts.
-   **KPIs**: Instantly see total alerts, number of BMUs involved, and **Total/Median Impact (£)** for the selected period.
-   **BMU Leaderboard**: An expandable summary of the top offenders ranked by total financial impact (`IMPACT_SP`). Start your investigation with the highest-ranked units.
-   **Enriched Table**: See exactly which conditions triggered (`C1`, `C2`, `C3`) and their individual contribution to the impact proxy.

### **2. Tab 5: Alert Windows (Persistence Diagnostics)**
Use this tab to determine if pricing behavior is a one-off or a sustained pattern.
-   **BMU Recurrence Table**: Surfaces BMUs with repeated alert windows. Sustained high-duration behavior is a prime candidate for escalation.
-   **Window Table**: Provides average and peak metrics for a continuous period of alerts.
-   **Interactive Drilldown**: Select any row in the **Window Detail** table to immediately see the underlying Settlement Period alerts listed below.

### **3. Impact Proxies explained**
These are calculated severeity indicators, not actual profit figures:
-   **SP Impact**: `max(Impact_C1, Impact_C2, Impact_C3)` — the most severe active condition's excess.
-   **Window Impact**: `Average Spread * Total Volume` for the window period.

---

## Included Files (Release 2)

- `app.py`: Updated script with the Analyst Intelligence Layer.
- `requirements.txt`: Python dependencies (`streamlit`, `pandas`, `plotly`).
- `inputs/`: Canonical datasets (`alerts_data.csv`).
- `.streamlit/`: UI configuration (custom theme).

## How to Run Locally

1. **Prerequisites:** Ensure you have Python 3.9+ installed.
2. **Setup:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Run:**
   ```bash
   streamlit run app.py
   ```

---

*Original Release 1 Reference:*

This folder contains a fully self-contained, interactive MVP (Minimum Viable Product) of the `Import Constraints Dashboard`. 

### Features (Original)
- **BMU Deep Dive:** Inspect daily condition occurrence rates and pricing for specific BMUs.
- **Ensemble Breakdowns:** Reporting on combinations of constraints (C1, C2, C3).
- **Spread Analysis:** Density curves and heatmaps for Fuel Types, Weekdays, and Hours.
