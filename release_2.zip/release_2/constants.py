# constants.py - Configuration for PN Accuracy Dashboard Release 2

# --- Azure Configuration ---
# Example: "https://pnanalyticsstorage.blob.core.windows.net"
ACCOUNT_URL = "https://<YOUR_STORAGE_ACCOUNT>.blob.core.windows.net"
CONTAINER_NAME = "pn-analytics"

# --- Local Configuration ---
LOCAL_INPUT_DIR = "inputs"

# --- App Settings ---
VERSION = "2.0 (Hybrid Cloud Architecture)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
