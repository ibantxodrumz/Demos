import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import os

# Custom Utilities & Constants
import constants
import azure_utils
import local_utils

# --- Page Config ---
st.set_page_config(
    page_title=f"PN Accuracy Dashboard {constants.VERSION}",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Styling & CSS (Ported from v1) ---
def force_light_chart(fig):
    """Explicitly force white background and dark text on Plotly charts."""
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#000000"),
        xaxis=dict(
            gridcolor="#e5e7eb",
            linecolor="#000000",
            tickfont=dict(color="#000000"),
            title_font=dict(color="#000000"),
        ),
        yaxis=dict(
            gridcolor="#e5e7eb",
            linecolor="#000000",
            tickfont=dict(color="#000000"),
            title_font=dict(color="#000000"),
        ),
        title_font=dict(color="#000000"),
    )
    return fig

st.markdown(
    """
<style>
    .stApp { background-color: #ffffff !important; color: #000000 !important; }
    section[data-testid="stSidebar"] { background-color: #f9fafb !important; }
    section[data-testid="stSidebar"] * { color: #000000 !important; }
    h1, h2, h3, h4, h5, h6, p, li, .stMarkdown, label { color: #000000 !important; }
    div[data-baseweb="select"] > div { background-color: #ffffff !important; color: #000000 !important; border-color: #d1d5db !important; }
    div[data-baseweb="popover"] { background-color: #ffffff !important; border: 1px solid #e5e7eb !important; }
    .stMetric { background-color: #ffffff !important; border: 1px solid #e5e7eb !important; }
    div[data-testid="stMetricValue"], div[data-testid="stMetricLabel"] { color: #000000 !important; }
    .stButton > button { background-color: #ffffff !important; color: #000000 !important; border: 1px solid #d1d5db !important; }
    .stButton > button:hover { background-color: #f9fafb !important; border-color: #4A90E2 !important; color: #4A90E2 !important; }
</style>
""",
    unsafe_allow_html=True,
)

# --- Data Processing Logic (Ported from v1) ---
def add_size_category(df):
    """Adds SizeCategory column based on installedCapacity_mwh or fallback."""
    def get_size_basis(row):
        cap = row.get("installedCapacity_mwh", 0)
        if pd.notnull(cap) and cap > 0: return cap
        return row.get("CapacityCalibrated", 0)

    df["SizeBasis"] = df.apply(get_size_basis, axis=1)
    def categorize(x):
        if x < 50: return "Small (<50MW)"
        elif x < 100: return "Medium (50-100MW)"
        else: return "Large (>100MW)"

    df["SizeCategory"] = df["SizeBasis"].apply(categorize)
    df["SizeCategory"] = pd.Categorical(df["SizeCategory"], categories=["Small (<50MW)", "Medium (50-100MW)", "Large (>100MW)"], ordered=True)
    return df

@st.cache_data
def process_raw_data(df_annual_raw, df_monthly_raw):
    """Shared logic to clean and calculate metrics for both Local and Cloud sources."""
    try:
        # 1. Annual Processing
        df_annual = df_annual_raw.copy()
        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)
        df_annual["Year"] = 2025
        df_annual["Grain"] = "annual"

        numeric_cols = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", "max_M_ABS_NetError%", "installedCapacity_mwh", "A_NetError%", "A_ABS_NetError%"]
        for col in numeric_cols:
            if col in df_annual.columns:
                df_annual[col] = pd.to_numeric(df_annual[col], errors="coerce").fillna(0)
        df_annual = add_size_category(df_annual)

        # 2. Monthly Processing
        df_monthly = df_monthly_raw.copy()
        def parse_date(x):
            try:
                parts = str(x).split("-")
                return datetime(int(parts[0]), int(parts[1]), 1) if len(parts) == 2 else pd.NaT
            except: return pd.NaT

        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_date)
        df_monthly["Year"] = df_monthly["YearMonthObj"].dt.year
        df_monthly["Month"] = df_monthly["YearMonthObj"].dt.month
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        df_monthly["YearMonth"] = df_monthly["YearMonthObj"].dt.strftime("%Y-%m")
        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)
        df_monthly["Grain"] = "monthly"

        monthly_numerics = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", "installedCapacity_mwh", "M_NetError%", "M_ABS_NetError%"]
        for col in monthly_numerics:
            if col in df_monthly.columns:
                df_monthly[col] = pd.to_numeric(df_monthly[col], errors="coerce").fillna(0)

        # 3. P90 & Attention Calculation
        p90_df = df_monthly.groupby("BMU")["M_ABS_NetError%"].quantile(0.9).reset_index(name="P90_monthly_error")
        df_annual = pd.merge(df_annual, p90_df, on="BMU", how="left").fillna(0)
        df_annual["NeedsAttention"] = (df_annual["A_ABS_NetError%"] >= 25) | (df_annual["P90_monthly_error"] >= 25)

        # 4. Error Bands
        def categorize_error(x):
            if x <= 1: return "0-1%"
            elif x <= 2: return "1-2%"
            elif x <= 4: return "2-4%"
            elif x <= 10: return "4-10%"
            else: return ">10%"
        df_annual["ErrorBand"] = df_annual["A_ABS_NetError%"].apply(categorize_error)
        df_annual["ErrorBand"] = pd.Categorical(df_annual["ErrorBand"], categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"], ordered=True)

        return df_annual, df_monthly, None
    except Exception as e:
        return None, None, f"Data Processing Error: {str(e)}"

# --- Sidebar: Data Sourcing ---
st.sidebar.title("Hybrid Data Control")
data_source = st.sidebar.radio("Select Data Source", ["Azure Cloud", "Local Filesystem"], index=1)

if st.sidebar.button("🔄 Global Refresh (Clear Cache)"):
    st.cache_data.clear()
    st.rerun()

# Dynamic File Selection based on source
annual_df_raw, monthly_df_raw = None, None

if data_source == "Azure Cloud":
    st.sidebar.info(f"Scanning Container: `{constants.CONTAINER_NAME}`")
    blobs = azure_utils.list_csv_blobs()
    if not blobs:
        st.error("No CSV blobs found or Azure Auth failed. Run `az login` locally.")
        st.stop()
    
    annual_blob = st.sidebar.selectbox("Select Annual Blob", blobs, index=blobs.index(next((b for b in blobs if "annual" in b.lower()), blobs[0])))
    monthly_blob = st.sidebar.selectbox("Select Monthly Blob", blobs, index=blobs.index(next((b for b in blobs if "monthly" in b.lower()), blobs[0])))
    
    if st.sidebar.button("Load from Azure"):
        annual_df_raw = azure_utils.load_blob_to_df(annual_blob)
        monthly_df_raw = azure_utils.load_blob_to_df(monthly_blob)
else:
    st.sidebar.info(f"Scanning Folder: `{constants.LOCAL_INPUT_DIR}/`")
    local_files = local_utils.list_local_csv_files()
    if not local_files:
        st.error(f"No CSV files found in `{constants.LOCAL_INPUT_DIR}`.")
        st.stop()
    
    annual_path = st.sidebar.selectbox("Select Annual File", local_files, index=local_files.index(next((f for f in local_files if "annual" in f.lower()), local_files[0])))
    monthly_path = st.sidebar.selectbox("Select Monthly File", local_files, index=local_files.index(next((f for f in local_files if "monthly" in f.lower()), local_files[0])))
    
    annual_df_raw = local_utils.load_local_file_to_df(annual_path)
    monthly_df_raw = local_utils.load_local_file_to_df(monthly_path)

if annual_df_raw is None or monthly_df_raw is None:
    st.info("Please select and load data files from the sidebar.")
    st.stop()

# --- Process & Global Filters ---
df_annual_raw, df_monthly_raw, err = process_raw_data(annual_df_raw, monthly_df_raw)
if err:
    st.error(err); st.stop()

st.sidebar.markdown("---")
st.sidebar.subheader("Global Filters")
all_fuels = sorted(df_annual_raw["Fuel"].unique().tolist())
selected_fuels = st.sidebar.multiselect("Fuel(s)", all_fuels, default=all_fuels)
available_bmus = sorted(df_annual_raw[df_annual_raw["Fuel"].isin(selected_fuels)]["BMU"].unique().tolist())
selected_bmus = st.sidebar.multiselect("BMU(s)", available_bmus, default=available_bmus)
needs_attention_only = st.sidebar.checkbox("🚩 'Needs Attention' only", value=False)

# Apply Filters
df_annual = df_annual_raw[df_annual_raw["Fuel"].isin(selected_fuels) & df_annual_raw["BMU"].isin(selected_bmus)]
if needs_attention_only:
    df_annual = df_annual[df_annual["NeedsAttention"] == True]
filtered_bmu_ids = df_annual["BMU"].unique()
df_monthly = df_monthly_raw[df_monthly_raw["BMU"].isin(filtered_bmu_ids) & df_monthly_raw["Fuel"].isin(selected_fuels)]

if df_annual.empty:
    st.warning("No data matches the current filters."); st.stop()

# --- Dashboard Layout (Tabs) ---
tabs = st.tabs(["🚀 Executive Summary", "📉 Trends", "📊 Fleet", "🔍 BMU Explorer", "🚩 Attention Needed", "📥 Exports"])

with tabs[0]: # Executive Summary
    st.title("Performance Executive Summary")
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Median Error %", f"{df_annual['A_ABS_NetError%'].median():.2f}%")
    k2.metric("P90 Error %", f"{df_annual['A_ABS_NetError%'].quantile(0.9):.2f}%")
    k3.metric("Total ABS (GWh)", f"{df_annual['ABSError'].sum()/1000:,.2f}")
    k4.metric("BMU Count", f"{len(df_annual)}")
    
    col1, col2 = st.columns(2)
    with col1:
        fig_dist = px.histogram(df_annual, x="A_ABS_NetError%", title="Annual Error Distribution", template="plotly_white", color_discrete_sequence=["#4A90E2"])
        st.plotly_chart(force_light_chart(fig_dist), use_container_width=True)
    with col2:
        fuel_sum = df_annual.groupby("Fuel").agg(Median=("A_ABS_NetError%", "median"), Total_GWh=("ABSError", lambda x: x.sum()/1000)).reset_index()
        st.dataframe(fuel_sum.style.format({"Median": "{:.2f}%", "Total_GWh": "{:,.2f}"}), hide_index=True, use_container_width=True)

with tabs[1]: # Trends
    st.header("Monthly Performance Trends")
    trend_data = df_monthly.groupby(["Month", "MonthName"]).agg(Median=("M_ABS_NetError%", "median"), P90=("M_ABS_NetError%", lambda x: x.quantile(0.9))).reset_index()
    fig_trend = px.line(trend_data, x="MonthName", y=["Median", "P90"], markers=True, title="Fleet Monthly Error Trend", template="plotly_white")
    st.plotly_chart(force_light_chart(fig_trend), use_container_width=True)

with tabs[2]: # Fleet
    st.header("Fleet Composition Analysis")
    fig_bubble = px.scatter(df_annual, x="SizeBasis", y="A_ABS_NetError%", size="SizeBasis", color="Fuel", hover_name="BMU", log_x=True, title="Capacity vs Error %", template="plotly_white")
    st.plotly_chart(force_light_chart(fig_bubble), use_container_width=True)

with tabs[3]: # BMU Explorer
    st.header("BMU Deep Dive")
    bmu_pick = st.selectbox("Select BMU to Explore", sorted(df_annual["BMU"].tolist()))
    b_data = df_annual[df_annual["BMU"] == bmu_pick].iloc[0]
    b_monthly = df_monthly[df_monthly["BMU"] == bmu_pick].sort_values("Month")
    
    c1, c2 = st.columns([1, 2])
    with c1:
        st.metric("Annual ABS Error", f"{b_data['A_ABS_NetError%']:.2f}%")
        st.write(f"**Fuel:** {b_data['Fuel']}")
        st.write(f"**Size:** {b_data['SizeCategory']}")
        if b_data['NeedsAttention']: st.error("⚠️ Needs Attention")
    with c2:
        fig_bmu = px.bar(b_monthly, x="MonthName", y="M_ABS_NetError%", title=f"Monthly Error for {bmu_pick}", template="plotly_white")
        st.plotly_chart(force_light_chart(fig_bmu), use_container_width=True)

with tabs[4]: # Attention Needed
    st.header("Action Required")
    attn = df_annual[df_annual["NeedsAttention"] == True]
    if attn.empty: st.success("No BMUs require attention.")
    else: st.dataframe(attn[["BMU", "Fuel", "A_ABS_NetError%", "P90_monthly_error"]], use_container_width=True, hide_index=True)

with tabs[5]: # Exports
    st.header("Data Exports")
    st.download_button("Download Processed Annual Data", df_annual.to_csv(index=False), "processed_annual.csv", "text/csv")
    st.download_button("Download Processed Monthly Data", df_monthly.to_csv(index=False), "processed_monthly.csv", "text/csv")

st.sidebar.markdown("---")
st.sidebar.caption(f"PN Analytics Dashboard v{constants.VERSION}")
