import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

# --- Configuration ---
st.set_page_config(
    page_title="Import Constraints Dashboard",
    page_icon="ICD",
    layout="wide",
    initial_sidebar_state="expanded",
)

import plotly.io as pio
pio.templates.default = "plotly"

# Custom CSS for a more premium look
st.markdown("""
<style>
    div[data-testid="stMetricValue"] {
        font-size: 2rem;
    }
    .stApp {
        background-color: white !important;
    }
    /* Increase font size for tab headers */
    button[data-baseweb="tab"] div[data-testid="stMarkdownContainer"] p {
        font-size: 20px !important;
        font-weight: 500 !important;
    }
</style>
""", unsafe_allow_html=True)

# --- Data Loading ---
@st.cache_data
def load_and_preprocess_csv(file_path_or_buffer):
    df = pd.read_csv(file_path_or_buffer)
    # Preprocessing
    df['LOCAL_DATETIME'] = pd.to_datetime(df['LOCAL_DATETIME'])
    df['SETTLEMENT_DATE'] = pd.to_datetime(df['SETTLEMENT_DATE'])
    if 'GMT_FROM' in df.columns:
        df['GMT_FROM'] = pd.to_datetime(df['GMT_FROM'])
    # Sort chronologically
    df = df.sort_values('LOCAL_DATETIME')
    return df

def get_data():
    st.sidebar.header("📁 Data Source")
    uploaded_file = st.sidebar.file_uploader("Upload Alerts CSV manually", type=['csv'])
    
    if uploaded_file is not None:
        try:
            df = load_and_preprocess_csv(uploaded_file)
            st.sidebar.success(f"Using uploaded file: {uploaded_file.name}")
            return df
        except Exception as e:
            st.sidebar.error(f"Error reading uploaded file: {e}")
            return pd.DataFrame()
            
    # Fallback to local files matching alerts_*.csv or alerts_cleaned.csv
    input_dir = Path("inputs")
    if input_dir.exists() and input_dir.is_dir():
        # Find all files matching alerts_*.csv
        csv_files = list(input_dir.glob("alerts_*.csv"))
        
        # Also let's ensure we can find alerts_clearned.csv if it was named with a typo
        if not csv_files:
            csv_files = list(input_dir.glob("alerts_clearned.csv"))
            
        if not csv_files:
            st.sidebar.warning("No alerts CSV files found in 'inputs/' directory.")
            st.error("No valid dataset found. Please upload a CSV file via the sidebar.")
            return pd.DataFrame()
        
        # If there are multiple, provide a selectbox
        if len(csv_files) > 1:
            selected_file = st.sidebar.selectbox(
                "Or select an existing local file:",
                options=csv_files,
                format_func=lambda x: x.name
            )
            df = load_and_preprocess_csv(selected_file)
            return df
        else:
            # Only one file found
            df = load_and_preprocess_csv(csv_files[0])
            st.sidebar.info(f"Using default local file: {csv_files[0].name}")
            return df
    else:
        st.sidebar.warning("The 'inputs' directory does not exist.")
        st.error("No valid dataset found. Please upload a CSV file via the sidebar.")
        return pd.DataFrame()

def parse_why(why_str):
    """Parse the WHY field into structured condition tags and numerical details."""
    if pd.isna(why_str) or str(why_str).strip() == '':
        return '', ''
    parts = str(why_str).split('|')
    conditions = parts[0].strip()  # e.g. 'C1,C2,C3'
    details = ' | '.join(p.strip() for p in parts[1:]) if len(parts) > 1 else ''
    return conditions, details

@st.cache_data
def infer_alerts(df):
    """Derive alerts from the cleaned dataset (ensemble passed and reason provided)."""
    mask = (df['ENSEMBLE'] == True) & (df['WHY'].notna()) & (df['WHY'] != '')
    return df[mask].copy()

def enrich_alerts_with_impact(alerts_df):
    """Add WHY parsed fields and condition-specific impact proxies to alerts_df."""
    if alerts_df.empty:
        return alerts_df
    df = alerts_df.copy()
    MATERIALITY = 30

    # Parse WHY into structured fields
    parsed = df['WHY'].apply(parse_why)
    df['WHY_CONDITIONS'] = parsed.apply(lambda x: x[0])
    df['WHY_DETAILS'] = parsed.apply(lambda x: x[1])

    # C1 impact: excess of SPREAD over THR_FUEL (Abs_threshold from WHY)
    df['IMPACT_C1'] = df.apply(
        lambda r: max(r['SPREAD'] - r['THR_FUEL'], 0) * r['OFFER_VOLUME_MWH']
        if r.get('COND_1', False) and pd.notna(r['THR_FUEL']) else 0, axis=1
    )
    # C2 impact: excess of OFFER_PRICE over THR_FUEL
    df['IMPACT_C2'] = df.apply(
        lambda r: max(r['OFFER_PRICE'] - r['THR_FUEL'], 0) * r['OFFER_VOLUME_MWH']
        if r.get('COND_2', False) and pd.notna(r['THR_FUEL']) else 0, axis=1
    )
    # C3 impact: excess of SPREAD_DIFF over materiality threshold
    df['IMPACT_C3'] = df.apply(
        lambda r: max(r['SPREAD_DIFF'] - MATERIALITY, 0) * r['OFFER_VOLUME_MWH']
        if r.get('COND_3', False) and pd.notna(r['SPREAD_DIFF']) else 0, axis=1
    )
    # Composite: max of active condition impacts (avoids double-counting when C1+C2 co-fire)
    df['IMPACT_SP'] = df[['IMPACT_C1', 'IMPACT_C2', 'IMPACT_C3']].max(axis=1)
    return df

@st.cache_data
def infer_alerts_windows(alerts_df):
    """Condense continuous alerts for the same BMU into windows with enriched metrics."""
    if alerts_df.empty:
        return pd.DataFrame()
        
    df_window = alerts_df.copy()
    df_window = df_window.sort_values(['BMU_ID', 'GMT_FROM'])
    
    # Identify continuous blocks (windows)
    df_window['prev_gmt'] = df_window.groupby('BMU_ID')['GMT_FROM'].shift(1)
    df_window['is_new_window'] = (df_window['GMT_FROM'] - df_window['prev_gmt']) > pd.Timedelta(minutes=30)
    df_window['is_new_window'] = df_window['is_new_window'].fillna(True)
    df_window['window_id'] = df_window['is_new_window'].cumsum()
    
    # Build base aggregation
    has_impact = 'IMPACT_SP' in df_window.columns
    agg_dict = dict(
        FUEL_TYPE=('FUEL_TYPE', 'first'),
        COUNTERPARTY=('COUNTERPARTY', 'first'),
        START_GMT=('GMT_FROM', 'min'),
        END_GMT=('GMT_FROM', lambda x: x.max() + pd.Timedelta(minutes=30)),
        START_LOCAL=('LOCAL_DATETIME', 'min'),
        END_LOCAL=('LOCAL_DATETIME', lambda x: x.max() + pd.Timedelta(minutes=30)),
        COUNT_SP=('SETTLEMENT_PERIOD', 'count'),
        C1_PRESENT=('COND_1', 'any'),
        C2_PRESENT=('COND_2', 'any'),
        C3_PRESENT=('COND_3', 'any'),
        AVG_SPREAD=('SPREAD', 'mean'),
        MAX_SPREAD=('SPREAD', 'max'),
        AVG_OFFER_PRICE=('OFFER_PRICE', 'mean'),
        SUM_VOLUME=('OFFER_VOLUME_MWH', 'sum'),
    )
    if has_impact:
        agg_dict['TOTAL_IMPACT_SP'] = ('IMPACT_SP', 'sum')

    grouped = df_window.groupby(['window_id', 'BMU_ID']).agg(**agg_dict).reset_index()
    
    grouped['DURATION_MIN'] = grouped['COUNT_SP'] * 30
    grouped['IMPACT_WINDOW'] = grouped['AVG_SPREAD'] * grouped['SUM_VOLUME']
    grouped['UNIQUE_ID'] = grouped['START_LOCAL'].dt.strftime('%Y%m%d%H%M') + grouped['window_id'].astype(str)
    
    # Round for display
    for col in ['AVG_SPREAD', 'MAX_SPREAD', 'AVG_OFFER_PRICE', 'IMPACT_WINDOW']:
        grouped[col] = grouped[col].round(2)

    base_cols = ['BMU_ID', 'FUEL_TYPE', 'COUNTERPARTY', 'START_GMT', 'END_GMT',
                 'START_LOCAL', 'END_LOCAL', 'DURATION_MIN', 'COUNT_SP',
                 'C1_PRESENT', 'C2_PRESENT', 'C3_PRESENT',
                 'AVG_SPREAD', 'MAX_SPREAD', 'AVG_OFFER_PRICE', 'SUM_VOLUME',
                 'IMPACT_WINDOW', 'UNIQUE_ID']
    if has_impact:
        base_cols.append('TOTAL_IMPACT_SP')
    return grouped[base_cols]

df = get_data()

if df.empty:
    st.stop()

# Helper for time filtering and grouping based on UX request
def apply_time_drilldown(df, view_mode, selected_date=None, selected_week=None, selected_month=None):
    if view_mode == "Specific Day" and selected_date:
        mask = df['SETTLEMENT_DATE'].dt.date == selected_date
        return df[mask].copy(), 'LOCAL_DATETIME' # Plot raw 48 periods
    elif view_mode == "Specific Week" and selected_week:
        mask = df['SETTLEMENT_DATE'].dt.strftime('%G-W%V') == selected_week
        return df[mask].copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D') # Plot daily averages for the week
    elif view_mode == "Specific Month" and selected_month:
        mask = df['SETTLEMENT_DATE'].dt.strftime('%Y-%m') == selected_month
        return df[mask].copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D') # Plot daily averages for the month
    else: # Entire Period
        return df.copy(), pd.Grouper(key='LOCAL_DATETIME', freq='D') # Default to daily over entire period

def render_time_drilldown_ui(df, key_prefix):
    view_mode = st.radio(
        "Select Time View:",
        options=["Entire Period", "Specific Month", "Specific Week", "Specific Day"],
        horizontal=True,
        key=f"view_mode_{key_prefix}"
    )
    
    selected_date = None
    selected_week = None
    selected_month = None
    
    if view_mode == "Specific Day":
        min_d = df['SETTLEMENT_DATE'].min().date()
        max_d = df['SETTLEMENT_DATE'].max().date()
        selected_date = st.date_input("Select Day to Drill Down", value=min_d, min_value=min_d, max_value=max_d, key=f"day_{key_prefix}")
    elif view_mode == "Specific Month":
        available_months = sorted(df['SETTLEMENT_DATE'].dt.strftime('%Y-%m').unique().tolist())
        selected_month = st.selectbox("Select Month to Drill Down", options=available_months, key=f"month_{key_prefix}")
    elif view_mode == "Specific Week":
        available_weeks = sorted(df['SETTLEMENT_DATE'].dt.strftime('%G-W%V').unique().tolist())
        selected_week = st.selectbox("Select Week to Drill Down", options=available_weeks, key=f"week_{key_prefix}")
        
    return view_mode, selected_date, selected_week, selected_month

# --- Sidebar Navigation & Filters ---
st.sidebar.title("⚡ Import Constraints Dashboard")
st.sidebar.markdown("Easily toggle timelines & load data.")

# Global Date Filter at the very top of Sidebar
st.sidebar.markdown("### 📅 Time Period Selection")
min_date = df['SETTLEMENT_DATE'].min().date()
max_date = df['SETTLEMENT_DATE'].max().date()

start_date = st.sidebar.date_input("Start Date", value=min_date, min_value=min_date, max_value=max_date)
end_date = st.sidebar.date_input("End Date", value=max_date, min_value=min_date, max_value=max_date)

st.sidebar.markdown("---")

# Data Loader in Sidebar happens naturally from get_data() but we need to call get_data() AFTER time period is defined if possible, 
# But wait, df is already loaded to get min_date. That's fine.

# Apply global date filter
mask = (df['SETTLEMENT_DATE'].dt.date >= start_date) & (df['SETTLEMENT_DATE'].dt.date <= end_date)
filtered_df = df[mask].copy()

if filtered_df.empty:
    st.warning("No data in the selected date range.")
    st.stop()

# Derive alerts and windows based on the filtered data set
alerts_df_raw = infer_alerts(filtered_df)
alerts_df = enrich_alerts_with_impact(alerts_df_raw)
alerts_sql_df = infer_alerts_windows(alerts_df)

# --- Main Dashboard Content ---

# Tabs
tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8 = st.tabs([
    "BMU Deep Dive", 
    "Fuel Type Performance", 
    "Constrained vs Unconstrained",
    "Alerts for Monitoring",
    "Alert Windows",
    "Ensemble Alerts Breakdown",
    "Ensemble Alerts Breakdown - 1",
    "Spread Analysis"
])

with tab1:
    st.header("BMU Deep Dive")
    st.markdown("Toggle between specific BMUs and drill down into daily or monthly behavior.")
    
    # Menus on the main page
    available_bmus = sorted(filtered_df['BMU_ID'].unique().tolist())
    target_bmu = st.selectbox("Select a BMU to Track:", options=available_bmus)
    view_mode_t1, sel_date_t1, sel_week_t1, sel_month_t1 = render_time_drilldown_ui(filtered_df, "tab1")
    
    # Apply global time drilldown to the base filtered_df
    drill_df, global_grouper = apply_time_drilldown(filtered_df, view_mode_t1, sel_date_t1, sel_week_t1, sel_month_t1)
    
    # Filter to specific BMU
    bmu_df = drill_df[drill_df['BMU_ID'] == target_bmu]
    
    # Top level metrics for this BMU (updated to reflect drilldown period)
    st.markdown(f"#### Overview for {target_bmu} ({view_mode_t1})")
    bmu_m1, bmu_m2, bmu_m3, bmu_m4 = st.columns(4)
    bmu_m1.metric("Total Records in Period", len(bmu_df))
    bmu_m2.metric("Flagged Cases", len(infer_alerts(bmu_df)) if not bmu_df.empty else 0)
    bmu_m3.metric("Avg Offer Price", f"£{bmu_df['OFFER_PRICE'].mean():.2f}" if not bmu_df.empty else "N/A")
    thr_val_metric = bmu_df['THR_FUEL'].iloc[0] if not bmu_df.empty and 'THR_FUEL' in bmu_df.columns else 0
    bmu_m4.metric("Threshold Price", f"£{thr_val_metric:.2f}" if thr_val_metric > 0 else "N/A")
    
    # Chart
    if global_grouper:
        # Calculate Offer Price and Reference Price based ONLY on the specific BMU
        if isinstance(global_grouper, str): # Raw local_datetime
            agg_bmu = bmu_df[['LOCAL_DATETIME', 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE']].dropna(subset=['OFFER_PRICE']) if not bmu_df.empty else pd.DataFrame(columns=['LOCAL_DATETIME', 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE'])
        else:
            agg_bmu = bmu_df.groupby(global_grouper)[['OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE']].mean().reset_index().dropna(subset=['OFFER_PRICE']) if not bmu_df.empty else pd.DataFrame(columns=[global_grouper.key, 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE'])
        
        time_col = 'LOCAL_DATETIME'
        
        fig1 = go.Figure()
        
        # Identify fuel type for the selected BMU
        fuel_type_str = bmu_df['FUEL_TYPE'].iloc[0] if not bmu_df.empty and 'FUEL_TYPE' in bmu_df.columns else "Unknown"
        # Only add Offer Price trace if there is data
        if not agg_bmu.empty:
            fig1.add_trace(go.Scatter(
                x=agg_bmu[time_col], y=agg_bmu['OFFER_PRICE'],
                mode='lines+markers', name=f'Offer Price ({target_bmu})',
                line=dict(color='#00B4D8', width=3),
                marker=dict(size=8)
            ))
            
            # Add Reference Price Trace
            if 'REFERENCE_PRICE' in agg_bmu.columns and not agg_bmu['REFERENCE_PRICE'].isna().all():
                fig1.add_trace(go.Scatter(
                    x=agg_bmu[time_col], y=agg_bmu['REFERENCE_PRICE'],
                    mode='lines', name=f'{fuel_type_str} Ref Price',
                    line=dict(color='#2ECC71', width=2, dash='dot'),
                    hovertemplate="Time: %{x}<br>Ref Price: £%{y:.2f}<extra></extra>"
                ))
            if 'THR_FUEL' in bmu_df.columns and not bmu_df.empty:
                thr_val = bmu_df['THR_FUEL'].iloc[0]
                if thr_val > 0:
                    fig1.add_hline(
                        y=thr_val, 
                        line_dash="dot", 
                        line_color="#E5383B", 
                        annotation_text=f"{fuel_type_str} Threshold (£{thr_val:.2f})",
                        annotation_position="bottom right"
                    )
        
        fig1.update_layout(
            paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6",
            title=f"{target_bmu} - Price Tracking",
            xaxis_title="Time",
            yaxis_title="Price (£/MWh)",
            yaxis=dict(rangemode='tozero', dtick=20),
            hovermode="x unified",
            
        )
        st.plotly_chart(fig1, use_container_width=True)

with tab2:
    st.header("Fuel Type Performance")
    st.markdown("Track how all BMUs of a specific fuel type compare against their fixed threshold price. Drill down by Day or Month.")
    
    available_fuels = sorted(filtered_df['FUEL_TYPE'].dropna().unique().tolist())
    target_fuel = st.selectbox("Select Fuel Type:", options=available_fuels)
    view_mode_t2, sel_date_t2, sel_week_t2, sel_month_t2 = render_time_drilldown_ui(filtered_df, "tab2")
        
    drill_df, global_grouper = apply_time_drilldown(filtered_df, view_mode_t2, sel_date_t2, sel_week_t2, sel_month_t2)
    fuel_df = drill_df[drill_df['FUEL_TYPE'] == target_fuel]
    
    if global_grouper:
        if isinstance(global_grouper, str):
             agg_fuel = fuel_df[['LOCAL_DATETIME', 'BMU_ID', 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE']].dropna(subset=['OFFER_PRICE']).copy() if not fuel_df.empty else pd.DataFrame(columns=['LOCAL_DATETIME', 'BMU_ID', 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE'])
        else:
             agg_fuel = fuel_df.groupby([global_grouper, 'BMU_ID'])[['OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE']].mean().reset_index().dropna(subset=['OFFER_PRICE']).copy() if not fuel_df.empty else pd.DataFrame(columns=[global_grouper.key, 'BMU_ID', 'OFFER_PRICE', 'THR_FUEL', 'REFERENCE_PRICE'])
        
        time_col = global_grouper.key if hasattr(global_grouper, 'key') else 'LOCAL_DATETIME'
        
        if not agg_fuel.empty:
            fig2 = go.Figure()
            
            # Get the static threshold
            thr_val = agg_fuel['THR_FUEL'].iloc[0] if 'THR_FUEL' in agg_fuel.columns else 0
            
            # Pre-calculate uplift and identify breaches (C2 logic)
            if thr_val > 0:
                agg_fuel['UPLIFT'] = agg_fuel['OFFER_PRICE'] - thr_val
                agg_fuel['IS_BREACH'] = agg_fuel['UPLIFT'] > 0
            else:
                agg_fuel['UPLIFT'] = 0
                agg_fuel['IS_BREACH'] = False

            # 1. Draw individual BMU lines
            unique_bmus = agg_fuel['BMU_ID'].unique()
            too_many_bmus = len(unique_bmus) > 10
            
            trace_mode = 'markers' if target_fuel == 'INTERCONNECTOR' else 'lines+markers'
            
            for bmu in unique_bmus:
                bmu_data = agg_fuel[agg_fuel['BMU_ID'] == bmu].sort_values(time_col)
                has_breach = bmu_data['IS_BREACH'].any()
                
                # If there are many BMUs, fully skip drawing the innocent ones to declutter the chart
                if too_many_bmus and not has_breach:
                    continue
                
                fig2.add_trace(go.Scatter(
                    x=bmu_data[time_col], y=bmu_data['OFFER_PRICE'],
                    mode=trace_mode, name=f"{bmu} (Offer)",
                    line=dict(width=2) if trace_mode != 'markers' else None,
                    marker=dict(size=4),
                    hovertemplate="<b>BMU: %{customdata[0]}</b><br>Time: %{x}<br>Offer Price: £%{y:.2f}<extra></extra>",
                    customdata=bmu_data[['BMU_ID']]
                ))
            
            # Plot Reference Price ONCE per Fuel Type, not per BMU
            if 'REFERENCE_PRICE' in agg_fuel.columns and not agg_fuel['REFERENCE_PRICE'].isna().all():
                # Get the median or mean reference price for the fuel type per time step
                ref_data = agg_fuel.groupby(time_col)['REFERENCE_PRICE'].median().reset_index()
                fig2.add_trace(go.Scatter(
                    x=ref_data[time_col], y=ref_data['REFERENCE_PRICE'],
                    mode='lines', name=f"{target_fuel} Ref Price",
                    line=dict(width=2, dash='dash', color='#2ECC71'),
                    hovertemplate="Time: %{x}<br>Ref Price: £%{y:.2f}<extra></extra>"
                ))

            # 2. Emphasize Breaches & Add Context
            if thr_val > 0:
                breaches = agg_fuel[agg_fuel['IS_BREACH']]
                if not breaches.empty:
                    # Explicit C2=True Markers
                    fig2.add_trace(go.Scatter(
                        x=breaches[time_col], y=breaches['OFFER_PRICE'],
                        mode='markers', name='Threshold Breach (C2=True)',
                        marker=dict(color='red', size=8, line=dict(width=1, color='darkred')),
                        hovertemplate="<b>🚨 Threshold Breach</b><br>BMU: %{customdata[0]}<br>Time: %{x}<br>Offer Price: £%{y:.2f}<br>Uplift: +£%{customdata[1]:.2f}<extra></extra>",
                        customdata=breaches[['BMU_ID', 'UPLIFT']]
                    ))
                
                # Threshold Line
                fig2.add_hline(
                    y=thr_val, 
                    line_dash="dot", 
                    line_color="#E5383B", 
                    annotation_text=f"{target_fuel} Threshold (£{thr_val:.2f})",
                    annotation_position="bottom right"
                )

            fig2.update_layout(
                paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6",
                title=f"BMU Offer Prices vs {target_fuel} Threshold (C2 Logic)",
                xaxis_title="Time",
                yaxis_title="Price (£/MWh)",
                yaxis=dict(rangemode='tozero'),
                hovermode="x unified",
                legend=dict(
                    orientation="v",
                    yanchor="top",
                    y=1,
                    xanchor="left",
                    x=1.02,
                    title="Legend"
                ),
                margin=dict(r=150) # Add right margin so legend fits
            )
        else:
            fig2 = go.Figure()
            fig2.update_layout(paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6", title=f"No Offer Prices for {target_fuel} vs Threshold")

        st.plotly_chart(fig2, use_container_width=True)

        # Leaderboard to surface the top offenders directly
        if not agg_fuel.empty and thr_val > 0:
            breaches = agg_fuel[agg_fuel['IS_BREACH']]
            if not breaches.empty:
                st.markdown("### Top BMUs with C2 Breaches")
                st.markdown("Summary of BMUs exceeding the fixed fuel threshold.")
                breach_stats = breaches.groupby('BMU_ID').agg(
                    Breach_Count=(time_col, 'count'),
                    Avg_Uplift=('UPLIFT', 'mean'),
                    Max_Uplift=('UPLIFT', 'max')
                ).reset_index().sort_values('Breach_Count', ascending=False)
                
                st.dataframe(
                    breach_stats,
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "BMU_ID": "BMU ID",
                        "Breach_Count": st.column_config.NumberColumn("Total Breaches (Count)", format="%d"),
                        "Avg_Uplift": st.column_config.NumberColumn("Average Uplift (£)", format="£%.2f"),
                        "Max_Uplift": st.column_config.NumberColumn("Peak Uplift (£)", format="£%.2f")
                    }
                )

with tab3:
    st.header("Constrained vs Unconstrained")
    st.markdown("Observe constrained versus unconstrained pricing behavior over time for a specific BMU.")
    
    available_bmus_t3 = sorted(filtered_df['BMU_ID'].unique().tolist())
    target_bmu_t3 = st.selectbox("Select a BMU to Track:", options=available_bmus_t3, key="bmu_tab3")
    view_mode_t3, sel_date_t3, sel_week_t3, sel_month_t3 = render_time_drilldown_ui(filtered_df, "tab3")
    
    drill_df, grouper = apply_time_drilldown(filtered_df, view_mode_t3, sel_date_t3, sel_week_t3, sel_month_t3)
    con_df = drill_df[drill_df['BMU_ID'] == target_bmu_t3]
    
    if grouper:
        # For the C3 chart, it's best to show raw granular data or daily peaks. We will use the raw dataset if possible
        # because conditions logic happens at the SP level. Let's aggregate if needed, but for "Specific Day" we get raw.
        if isinstance(grouper, str):
            agg_con = con_df.copy()
        else:
            # If grouping, what does C3=True mean? We could mark any day that had a C3.
            # But the user asked for specific rules. We must aggregate appropriately or just use the dataframe
            agg_con = con_df.groupby(grouper).agg({
                'MED_SPREAD_CON': 'mean',
                'MED_SPREAD_UNCON': 'mean',
                'SPREAD_DIFF': 'mean',
                'COND_3': 'any',  # Any C3 in the period
                'D_REF': lambda x: x.mode()[0] if not x.empty else 'missing'
            }).reset_index()

        # Fill missing values to allow subtraction if needed, though they should be present
        if 'SPREAD_DIFF' not in agg_con.columns:
            agg_con['SPREAD_DIFF'] = agg_con['MED_SPREAD_CON'] - agg_con['MED_SPREAD_UNCON']
            
        time_col = grouper.key if hasattr(grouper, 'key') else 'LOCAL_DATETIME'

        # Reference thresholds (constants usually defined based on the model logic)
        materiality = 30
        delta_threshold = 0

        fig3 = go.Figure()

        if not agg_con.empty:
            # Sort properly
            agg_con = agg_con.sort_values(time_col)

            # Line B: Unconstrained Spread (Grey)
            fig3.add_trace(go.Scatter(
                x=agg_con[time_col], y=agg_con['MED_SPREAD_UNCON'],
                mode='lines+markers', name='Unconstrained Spread (Line B)',
                line=dict(color='grey', width=2),
                marker=dict(size=4),
                hovertemplate="Time: %{x}<br>Uncon Spread: £%{y:.2f}<br>Ref: %{customdata}<extra></extra>",
                customdata=agg_con.get('D_REF', ['missing']*len(agg_con))
            ))

            # Line A: Constrained Spread (Purple)
            fig3.add_trace(go.Scatter(
                x=agg_con[time_col], y=agg_con['MED_SPREAD_CON'],
                mode='lines+markers', name='Constrained Spread (Line A)',
                line=dict(color='purple', width=2),
                marker=dict(size=4),
                # If we want to shade between CON and UNCON when SPREAD_DIFF > delta_threshold, Plotly fill='tonexty' can be tricky if they cross over.
                # Standard trick: fill='tonexty', but we can only color unconditionally, so let's stick to simple lines
                hovertemplate="Time: %{x}<br>Con Spread: £%{y:.2f}<extra></extra>"
            ))
            
            # Shading uplift: We can do a fill between A and B, but only when A > B. 
            # To do this correctly in plotly, we can add a dummy trace or just rely on spread diff series.
            
            # Line C: Spread Diff (Orange)
            fig3.add_trace(go.Scatter(
                x=agg_con[time_col], y=agg_con['SPREAD_DIFF'],
                mode='lines', name='Spread Diff (Line C)',
                line=dict(color='orange', width=2, dash='dot'),
                hovertemplate="Time: %{x}<br>Δ Spread: £%{y:.2f}<extra></extra>"
            ))

            # Threshold Lines
            fig3.add_hline(y=delta_threshold, line_dash="dash", line_color="black", annotation_text=f"Delta Threshold (£{delta_threshold})")
            fig3.add_hline(y=materiality, line_dash="dash", line_color="blue", annotation_text=f"Materiality Threshold (£{materiality})")

            # Mark C3=True explicitly
            if 'COND_3' in agg_con.columns:
                c3_mask = agg_con['COND_3'] == True
                if c3_mask.any():
                    c3_points = agg_con[c3_mask]

                    fig3.add_trace(go.Scatter(
                        x=c3_points[time_col], y=c3_points['SPREAD_DIFF'],
                        mode='markers', name='C3 = True',
                        marker=dict(color='red', size=8, line=dict(width=1, color='darkred')),
                        hovertemplate="<b>🚨 C3 = True</b><br>Time: %{x}<br>Δ Spread: £%{y:.2f}<br>Ref Type: %{customdata}<extra></extra>",
                        customdata=c3_points['D_REF']
                    ))

        fig3.update_layout(
            paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6",
            title=f"{target_bmu_t3} - C3 Detection Logic (Uplift Visualisation)",
            xaxis_title="Time",
            yaxis_title="Spread Value (£/MWh)",
            yaxis=dict(zeroline=True, zerolinewidth=2, zerolinecolor='black'),
            hovermode="x unified",
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        st.plotly_chart(fig3, use_container_width=True)

with tab4:
    st.header("Alerts for Monitoring")
    st.markdown("These are the alerts derived from the canonical dataset that have passed the `ENSEMBLE` by satisfying at least 2 conditions.")

    # --- Existing table (unchanged) — show original columns only ---
    ORIGINAL_ALERT_COLS = [
        'SETTLEMENT_DATE', 'SETTLEMENT_PERIOD', 'GMT_FROM', 'LOCAL_DATETIME',
        'COUNTERPARTY', 'BMU_ID', 'FUEL_TYPE', 'OFFER_PRICE', 'OFFER_VOLUME_MWH',
        'SPREAD', 'COND_1', 'COND_2', 'COND_3', 'N_CONDITIONS_TRUE', 'ENSEMBLE', 'WHY'
    ]
    orig_display_cols = [c for c in ORIGINAL_ALERT_COLS if c in alerts_df.columns]
    st.metric("Total Alerts", len(alerts_df))
    if not alerts_df.empty:
        st.dataframe(
            alerts_df[orig_display_cols],
            use_container_width=True,
            hide_index=True
        )

    st.markdown("---")
    st.subheader("🔍 Analyst Intelligence")

    # Filters
    t4_col_f1, t4_col_f2 = st.columns(2)
    with t4_col_f1:
        avail_fuels_t4 = sorted(alerts_df['FUEL_TYPE'].dropna().unique().tolist()) if not alerts_df.empty else []
        sel_fuels_t4 = st.multiselect("Filter by Fuel Type:", options=avail_fuels_t4, default=avail_fuels_t4, key="t4_fuel")
    with t4_col_f2:
        avail_bmus_t4 = sorted(alerts_df['BMU_ID'].dropna().unique().tolist()) if not alerts_df.empty else []
        sel_bmus_t4 = st.multiselect("Filter by BMU (leave blank for all):", options=avail_bmus_t4, default=[], key="t4_bmu")

    view_mode_t4, sel_date_t4, sel_week_t4, sel_month_t4 = render_time_drilldown_ui(filtered_df, "tab4")
    intel_alerts_df, _ = apply_time_drilldown(alerts_df, view_mode_t4, sel_date_t4, sel_week_t4, sel_month_t4)

    if sel_fuels_t4:
        intel_alerts_df = intel_alerts_df[intel_alerts_df['FUEL_TYPE'].isin(sel_fuels_t4)]
    if sel_bmus_t4:  # Only filter if user explicitly selected BMUs
        intel_alerts_df = intel_alerts_df[intel_alerts_df['BMU_ID'].isin(sel_bmus_t4)]

    # KPIs
    t4_k1, t4_k2, t4_k3, t4_k4 = st.columns(4)
    total_impact_t4 = intel_alerts_df['IMPACT_SP'].sum() if not intel_alerts_df.empty and 'IMPACT_SP' in intel_alerts_df.columns else 0
    median_impact_t4 = intel_alerts_df['IMPACT_SP'].median() if not intel_alerts_df.empty and 'IMPACT_SP' in intel_alerts_df.columns else 0
    t4_k1.metric("Alerts (filtered)", len(intel_alerts_df))
    t4_k2.metric("BMUs Flagged", intel_alerts_df['BMU_ID'].nunique() if not intel_alerts_df.empty else 0)
    t4_k3.metric("Total Impact (£)", f"£{total_impact_t4:,.0f}")
    t4_k4.metric("Median Impact (£)", f"£{median_impact_t4:,.0f}")

    # BMU Leaderboard
    if not intel_alerts_df.empty and 'IMPACT_SP' in intel_alerts_df.columns:
        with st.expander("📊 BMU Leaderboard — by Total Impact", expanded=True):
            leaderboard_t4 = intel_alerts_df.groupby(['BMU_ID', 'FUEL_TYPE']).agg(
                Alert_Count=('IMPACT_SP', 'count'),
                Total_Impact=('IMPACT_SP', 'sum'),
                Avg_Impact=('IMPACT_SP', 'mean')
            ).reset_index().sort_values('Total_Impact', ascending=False).head(20)
            leaderboard_t4['Total_Impact'] = leaderboard_t4['Total_Impact'].round(0)
            leaderboard_t4['Avg_Impact'] = leaderboard_t4['Avg_Impact'].round(0)
            st.dataframe(
                leaderboard_t4,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "BMU_ID": "BMU",
                    "FUEL_TYPE": "Fuel Type",
                    "Alert_Count": st.column_config.NumberColumn("Alert Count", format="%d"),
                    "Total_Impact": st.column_config.NumberColumn("Total Impact (£)", format="£%.0f"),
                    "Avg_Impact": st.column_config.NumberColumn("Avg Impact (£)", format="£%.0f"),
                }
            )

    # Enriched alert table
    if not intel_alerts_df.empty:
        st.subheader("Enriched Alert Detail")
        enriched_cols_t4 = [c for c in [
            'LOCAL_DATETIME', 'BMU_ID', 'FUEL_TYPE', 'SPREAD', 'OFFER_PRICE',
            'OFFER_VOLUME_MWH', 'IMPACT_C1', 'IMPACT_C2', 'IMPACT_C3', 'IMPACT_SP',
            'COND_1', 'COND_2', 'COND_3', 'WHY_CONDITIONS', 'WHY_DETAILS'
        ] if c in intel_alerts_df.columns]
        st.dataframe(
            intel_alerts_df[enriched_cols_t4].sort_values('IMPACT_SP', ascending=False),
            use_container_width=True,
            hide_index=True,
            column_config={
                "IMPACT_C1": st.column_config.NumberColumn("Impact C1 (£)", format="£%.0f"),
                "IMPACT_C2": st.column_config.NumberColumn("Impact C2 (£)", format="£%.0f"),
                "IMPACT_C3": st.column_config.NumberColumn("Impact C3 (£)", format="£%.0f"),
                "IMPACT_SP": st.column_config.NumberColumn("Impact SP (£)", format="£%.0f"),
                "OFFER_VOLUME_MWH": st.column_config.NumberColumn("Volume (MWh)", format="%.1f"),
                "WHY_CONDITIONS": "Conditions",
                "WHY_DETAILS": "WHY Details",
            }
        )

with tab5:
    st.header("Alert Windows")
    st.markdown("These are the alert windows created by combining contiguous half-hourly alerts for the same BMU.")

    # --- Existing table (unchanged) ---
    st.metric("Total Alert Windows", len(alerts_sql_df))
    if not alerts_sql_df.empty:
        st.dataframe(
            alerts_sql_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "START_GMT": st.column_config.DatetimeColumn("Start (GMT)", format="YYYY-MM-DD HH:mm:ss"),
                "END_GMT": st.column_config.DatetimeColumn("End (GMT)", format="YYYY-MM-DD HH:mm:ss"),
                "START_LOCAL": st.column_config.DatetimeColumn("Start (Local)", format="YYYY-MM-DD HH:mm:ss"),
                "END_LOCAL": st.column_config.DatetimeColumn("End (Local)", format="YYYY-MM-DD HH:mm:ss"),
                "DURATION_MIN": st.column_config.NumberColumn("Duration (min)", format="%d"),
            }
        )

    st.markdown("---")
    st.subheader("🔍 Analyst Intelligence")

    view_mode_t5, sel_date_t5, sel_week_t5, sel_month_t5 = render_time_drilldown_ui(filtered_df, "tab5")

    # Filter windows by time drilldown on START_LOCAL
    intel_windows_df = alerts_sql_df.copy() if not alerts_sql_df.empty else pd.DataFrame()
    if not intel_windows_df.empty:
        if view_mode_t5 == "Specific Day" and sel_date_t5:
            intel_windows_df = intel_windows_df[intel_windows_df['START_LOCAL'].dt.date == sel_date_t5]
        elif view_mode_t5 == "Specific Month" and sel_month_t5:
            intel_windows_df = intel_windows_df[intel_windows_df['START_LOCAL'].dt.strftime('%Y-%m') == sel_month_t5]
        elif view_mode_t5 == "Specific Week" and sel_week_t5:
            intel_windows_df = intel_windows_df[intel_windows_df['START_LOCAL'].dt.strftime('%G-W%V') == sel_week_t5]

    # BMU + Fuel Type filter
    t5_col_f1, t5_col_f2 = st.columns([1, 2])
    with t5_col_f1:
        avail_fuels_t5 = sorted(intel_windows_df['FUEL_TYPE'].dropna().unique().tolist()) if not intel_windows_df.empty else []
        sel_fuels_t5 = st.multiselect("Filter by Fuel Type:", options=avail_fuels_t5, default=avail_fuels_t5, key="t5_fuel")
    with t5_col_f2:
        avail_bmus_t5 = sorted(intel_windows_df['BMU_ID'].dropna().unique().tolist()) if not intel_windows_df.empty else []
        sel_bmus_t5 = st.multiselect("Filter by BMU (leave blank for all):", options=avail_bmus_t5, default=[], key="t5_bmu")

    if sel_fuels_t5:
        intel_windows_df = intel_windows_df[intel_windows_df['FUEL_TYPE'].isin(sel_fuels_t5)]
    if sel_bmus_t5:
        intel_windows_df = intel_windows_df[intel_windows_df['BMU_ID'].isin(sel_bmus_t5)]

    # KPIs
    t5_k1, t5_k2, t5_k3 = st.columns(3)
    total_win_impact = intel_windows_df['IMPACT_WINDOW'].sum() if not intel_windows_df.empty and 'IMPACT_WINDOW' in intel_windows_df.columns else 0
    t5_k1.metric("Windows (filtered)", len(intel_windows_df))
    t5_k2.metric("BMUs with Windows", intel_windows_df['BMU_ID'].nunique() if not intel_windows_df.empty else 0)
    t5_k3.metric("Total Window Impact (£)", f"£{total_win_impact:,.0f}")


    # BMU Recurrence Table
    if not intel_windows_df.empty:
        with st.expander("📊 BMU Recurrence — Persistence Summary", expanded=True):
            recur_cols = {k: v for k, v in {
                'Window_Count': ('UNIQUE_ID', 'count'),
                'Total_Duration_Min': ('DURATION_MIN', 'sum'),
                'Total_SP': ('COUNT_SP', 'sum'),
                'Total_Window_Impact': ('IMPACT_WINDOW', 'sum'),
            }.items()}
            recurrence_df = intel_windows_df.groupby('BMU_ID').agg(
                Window_Count=('UNIQUE_ID', 'count'),
                Total_Duration_Min=('DURATION_MIN', 'sum'),
                Total_SP=('COUNT_SP', 'sum'),
                Total_Window_Impact=('IMPACT_WINDOW', 'sum'),
            ).reset_index().sort_values('Total_Window_Impact', ascending=False)
            recurrence_df['Total_Window_Impact'] = recurrence_df['Total_Window_Impact'].round(0)
            st.dataframe(
                recurrence_df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Window_Count": st.column_config.NumberColumn("Window Count", format="%d"),
                    "Total_Duration_Min": st.column_config.NumberColumn("Total Duration (min)", format="%d"),
                    "Total_SP": st.column_config.NumberColumn("Total SPs", format="%d"),
                    "Total_Window_Impact": st.column_config.NumberColumn("Total Window Impact (£)", format="£%.0f"),
                }
            )

    # Enriched Windows Table (row-selectable)
    if not intel_windows_df.empty:
        st.markdown("#### Window Detail — select a row to inspect SP-level alerts")
        display_win_cols = [c for c in [
            'BMU_ID', 'FUEL_TYPE', 'START_LOCAL', 'END_LOCAL', 'DURATION_MIN', 'COUNT_SP',
            'C1_PRESENT', 'C2_PRESENT', 'C3_PRESENT',
            'AVG_SPREAD', 'MAX_SPREAD', 'AVG_OFFER_PRICE', 'SUM_VOLUME', 'IMPACT_WINDOW'
        ] if c in intel_windows_df.columns]

        win_selection = st.dataframe(
            intel_windows_df[display_win_cols].sort_values('IMPACT_WINDOW', ascending=False).reset_index(drop=True),
            use_container_width=True,
            hide_index=False,
            on_select="rerun",
            selection_mode="single-row",
            column_config={
                "START_LOCAL": st.column_config.DatetimeColumn("Start (Local)", format="YYYY-MM-DD HH:mm"),
                "END_LOCAL": st.column_config.DatetimeColumn("End (Local)", format="YYYY-MM-DD HH:mm"),
                "DURATION_MIN": st.column_config.NumberColumn("Duration (min)", format="%d"),
                "AVG_SPREAD": st.column_config.NumberColumn("Avg Spread (£)", format="£%.2f"),
                "MAX_SPREAD": st.column_config.NumberColumn("Max Spread (£)", format="£%.2f"),
                "AVG_OFFER_PRICE": st.column_config.NumberColumn("Avg Offer (£)", format="£%.2f"),
                "SUM_VOLUME": st.column_config.NumberColumn("Volume (MWh)", format="%.1f"),
                "IMPACT_WINDOW": st.column_config.NumberColumn("Window Impact (£)", format="£%.0f"),
            }
        )

        # SP-level breakdown when a row is selected
        selected_rows = win_selection.selection.rows if win_selection and hasattr(win_selection, 'selection') else []
        if selected_rows:
            sorted_windows = intel_windows_df[display_win_cols].sort_values('IMPACT_WINDOW', ascending=False).reset_index(drop=True)
            sel_row = sorted_windows.iloc[selected_rows[0]]
            sel_bmu = sel_row['BMU_ID']
            sel_start = sel_row['START_LOCAL']
            sel_end = sel_row['END_LOCAL']

            st.markdown(f"#### 🔎 SP Breakdown — {sel_bmu} | {sel_start.strftime('%Y-%m-%d %H:%M')} → {sel_end.strftime('%H:%M')}")

            sp_mask = (
                (alerts_df['BMU_ID'] == sel_bmu) &
                (alerts_df['LOCAL_DATETIME'] >= sel_start) &
                (alerts_df['LOCAL_DATETIME'] < sel_end)
            )
            sp_breakdown_df = alerts_df[sp_mask].copy()

            sp_cols = [c for c in [
                'LOCAL_DATETIME', 'SPREAD', 'OFFER_PRICE', 'OFFER_VOLUME_MWH',
                'IMPACT_C1', 'IMPACT_C2', 'IMPACT_C3', 'IMPACT_SP',
                'COND_1', 'COND_2', 'COND_3', 'WHY_CONDITIONS'
            ] if c in sp_breakdown_df.columns]

            if not sp_breakdown_df.empty:
                st.dataframe(
                    sp_breakdown_df[sp_cols].sort_values('LOCAL_DATETIME'),
                    use_container_width=True,
                    hide_index=True,
                    column_config={
                        "LOCAL_DATETIME": st.column_config.DatetimeColumn("Time (Local)", format="YYYY-MM-DD HH:mm"),
                        "IMPACT_C1": st.column_config.NumberColumn("Impact C1 (£)", format="£%.0f"),
                        "IMPACT_C2": st.column_config.NumberColumn("Impact C2 (£)", format="£%.0f"),
                        "IMPACT_C3": st.column_config.NumberColumn("Impact C3 (£)", format="£%.0f"),
                        "IMPACT_SP": st.column_config.NumberColumn("Impact SP (£)", format="£%.0f"),
                        "OFFER_VOLUME_MWH": st.column_config.NumberColumn("Volume (MWh)", format="%.1f"),
                        "WHY_CONDITIONS": "Conditions",
                    }
                )
            else:
                st.info("No SP-level alerts found for this window in the current data.")

with tab6:
    st.header("📊 Ensemble Alerts Breakdown")
    st.markdown("How often specific conditions trigger and what combinations make up the final alerts.")
    
    col_cb1, col_cb2 = st.columns(2)
    
    with col_cb1:
        st.subheader("Individual Condition Counts")
        st.markdown("Total counts of individual conditions across **all** analyzed periods.")
        if not filtered_df.empty:
            c1_hits = filtered_df['COND_1'].sum()
            c2_hits = filtered_df['COND_2'].sum()
            c3_hits = filtered_df['COND_3'].sum()
            
            cond_data = pd.DataFrame({
                'Condition': ['C1 (Historical Behavior)', 'C2 (Fuel Threshold)', 'C3 (Constrained vs Uncon)'],
                'Counts': [c1_hits, c2_hits, c3_hits]
            })
            
            fig_bar = px.bar(cond_data, x='Condition', y='Counts', text='Counts', color='Condition', 
                             color_discrete_sequence=['#00B4D8', '#FFB703', '#E5383B'])
            fig_bar.update_layout(paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6", showlegend=False)
            st.plotly_chart(fig_bar, use_container_width=True)
            
    with col_cb2:
        st.subheader("Ensemble Pairs")
        st.markdown("Breakdown of ensemble alerts counts (combinations of passing conditions).")
        if not alerts_df.empty:
            why_counts = alerts_df['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else 'Unknown').value_counts().reset_index()
            why_counts.columns = ['Conditions', 'Count']
            
            fig_why = px.pie(why_counts, names='Conditions', values='Count', hole=0.5,
                             color_discrete_sequence=px.colors.qualitative.Pastel)
            fig_why.update_traces(textinfo='value+percent')
            fig_why.update_layout(paper_bgcolor="#F0F2F6", plot_bgcolor="#F0F2F6", showlegend=True, legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5))
            st.plotly_chart(fig_why, use_container_width=True)
        else:
            st.warning("No alerts in the current time period to analyze.")

    st.markdown("---")
    st.subheader("Condition C3 Spread by BMU")
    st.markdown("Median Constrained vs Unconstrained spread per unit.")
    if not filtered_df.empty and 'BMU_ID' in filtered_df.columns and 'MED_SPREAD_CON' in filtered_df.columns and 'MED_SPREAD_UNCON' in filtered_df.columns:
        if 'FUEL_TYPE' in filtered_df.columns:
            available_fuels_t6 = sorted(filtered_df['FUEL_TYPE'].dropna().unique().tolist())
            selected_fuels_t6 = st.multiselect("Select Fuel Type(s):", options=available_fuels_t6, default=available_fuels_t6)
            fuel_filtered_df = filtered_df[filtered_df['FUEL_TYPE'].isin(selected_fuels_t6)] if selected_fuels_t6 else pd.DataFrame(columns=filtered_df.columns)
        else:
            fuel_filtered_df = filtered_df.copy()

        if not fuel_filtered_df.empty:
            plot_df = fuel_filtered_df.copy()
            bmu_spreads = plot_df.groupby("BMU_ID").agg(
                Median_Con=("MED_SPREAD_CON", "median"),
                Median_Uncon=("MED_SPREAD_UNCON", "median")
            ).reset_index()
            
            bmu_spreads = bmu_spreads.sort_values(by="Median_Con", ascending=False)
            
            fig_bmu = go.Figure()
            fig_bmu.add_trace(go.Bar(
                x=bmu_spreads["BMU_ID"],
                y=bmu_spreads["Median_Con"],
                name="Constrained Spread",
                marker_color='purple'
            ))
            fig_bmu.add_trace(go.Bar(
                x=bmu_spreads["BMU_ID"],
                y=bmu_spreads["Median_Uncon"],
                name="Unconstrained Spread",
                marker_color='grey'
            ))
            
            fig_bmu.update_layout(
                barmode='group',
                paper_bgcolor="#F0F2F6", 
                plot_bgcolor="#F0F2F6",
                xaxis_title="BMU",
                yaxis_title="Median Spread (£/MWh)",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_bmu, use_container_width=True)
        else:
            st.info("Please select at least one Fuel Type, or no data matches the selection.")
    else:
        st.info("No median spread data available for this chart.")

with tab7:
    st.header("📊 Ensemble Alerts Breakdown - 1 (BMU Level)")
    st.markdown("Detailed breakdown of condition counts (C1, C2, C3) and their combinations per individual unit.")
    
    if not filtered_df.empty:
        # Group by BMU to get individual condition flags
        bmu_conds = filtered_df.groupby('BMU_ID').agg(
            C1_Count=('COND_1', 'sum'),
            C2_Count=('COND_2', 'sum'),
            C3_Count=('COND_3', 'sum')
        ).reset_index()
        
        # Calculate pairs from the 'WHY' column in alerts_df, as that contains the parsed text like "C1+C2"
        if not alerts_df.empty:
            alerts_df['Conditions_Parsed'] = alerts_df['WHY'].apply(lambda x: str(x).split('|')[0].strip() if pd.notna(x) else '')
            
            # Pivot to count string occurrences per BMU
            pair_counts = pd.crosstab(alerts_df['BMU_ID'], alerts_df['Conditions_Parsed']).reset_index()
            
            # Merge individual counts and pair counts
            bmu_details = pd.merge(bmu_conds, pair_counts, on='BMU_ID', how='left').fillna(0)
        else:
            bmu_details = bmu_conds

        # Calculate a total column to sort by
        num_cols = [c for c in bmu_details.columns if c != 'BMU_ID']
        bmu_details['Total_Conditions'] = bmu_details[num_cols].sum(axis=1)
        bmu_details = bmu_details.sort_values('Total_Conditions', ascending=False).drop(columns=['Total_Conditions'])
        
        # Format for display
        st.dataframe(
            bmu_details,
            use_container_width=True,
            hide_index=True
        )
        
        st.info("""
        **Note on interpreting these counts:**
        *   **Individual Counts (C1_Count, C2_Count, C3_Count):** These represent the total number of times a single condition fired over the *entire period*, regardless of whether an alert was actually generated. 
        *   **Pair Counts (e.g., C1,C3):** These represent the number of times those exact conditions triggered *simultaneously*, satisfying the Ensemble Rule and generating an official alert.
        *   *Example: A BMU might have 147 C3 flags and 9 C1 flags in total, but if they only occurred at the exact same time during 7 periods, the 'C1,C3' alert count will only be 7.*
        """)
    else:
        st.info("No data available to calculate condition counts.")

with tab8:
    st.header("💡 Spread Analysis")
    st.markdown("Distribution of spreads across different fuel types and temporal spread patterns.")

    # Time Drill-Down for Spread Analysis tab
    view_mode_t8, sel_date_t8, sel_week_t8, sel_month_t8 = render_time_drilldown_ui(filtered_df, "tab8")
    drill_df, global_grouper = apply_time_drilldown(filtered_df, view_mode_t8, sel_date_t8, sel_week_t8, sel_month_t8)

    st.markdown("---")
    
    # 1. Heatmap — Median spread by Weekday × Hour (GMT)
    st.subheader("Median Spread by Weekday × Hour (GMT)")
    if not drill_df.empty and 'GMT_FROM' in drill_df.columns and 'SPREAD' in drill_df.columns:
        hm_df = drill_df[["GMT_FROM", "SPREAD"]].dropna().copy()
        if not hm_df.empty:
            hm_df["weekday"] = hm_df["GMT_FROM"].dt.day_name()
            hm_df["hour"] = hm_df["GMT_FROM"].dt.hour
            
            weekday_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
            
            pivot_med = hm_df.pivot_table(
                index="weekday", columns="hour", values="SPREAD", aggfunc="median"
            ).reindex(index=weekday_order)
            
            fig_hm = px.imshow(
                pivot_med,
                labels=dict(x="Hour (GMT)", y="Weekday", color="Median Spread (£/MWh)"),
                x=pivot_med.columns,
                y=pivot_med.index,
                color_continuous_scale="viridis_r",
                aspect="auto"
            )
            fig_hm.update_layout(
                paper_bgcolor="#F0F2F6",
                plot_bgcolor="#F0F2F6",
                margin=dict(t=20, b=20)
            )
            st.plotly_chart(fig_hm, use_container_width=True)
        else:
            st.info("No valid GMT_FROM and SPREAD data available.")
    else:
        st.info("GMT_FROM or SPREAD column is missing.")

    st.markdown("---")

    # 2. Spread Distributions by Fuel Type
    st.subheader("Spread Distributions by Fuel Type")
    if not drill_df.empty and 'SPREAD' in drill_df.columns and 'FUEL_TYPE' in drill_df.columns:
        ridge_df = drill_df[["FUEL_TYPE", "SPREAD"]].dropna()
        if not ridge_df.empty:
            fuel_order = ridge_df.groupby("FUEL_TYPE")["SPREAD"].median().sort_values(ascending=False).index.tolist()
            
            fig_ridge = go.Figure()
            for fuel in fuel_order[::-1]: # reverse so highest is on top when orientation=h
                fuel_data = ridge_df[ridge_df["FUEL_TYPE"] == fuel]
                fig_ridge.add_trace(go.Violin(
                    x=fuel_data["SPREAD"],
                    name=fuel,
                    side='positive',
                    line_color='black',
                    fillcolor='rgba(0,180,216,0.6)',
                    orientation='h',
                    meanline_visible=True,
                    showlegend=False
                ))
                
            fig_ridge.update_layout(
                paper_bgcolor="#F0F2F6", 
                plot_bgcolor="#F0F2F6",
                xaxis_title="Spread (£/MWh)",
                xaxis=dict(range=[0, min(260, ridge_df["SPREAD"].max() + 20)]),
                hovermode="closest"
            )
            st.plotly_chart(fig_ridge, use_container_width=True)
        else:
            st.info("No valid SPREAD and FUEL_TYPE data available.")
    else:
        st.info("SPREAD or FUEL_TYPE column is missing.")




