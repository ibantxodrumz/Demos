"""Release 6 Azure Package initialization."""
