# Physical Notification (PN) Accuracy Dashboard — Release 7

## 🎯 Overview
This enterprise analytical dashboard monitors and assesses the Physical Notification (PN) accuracy of Balancing Mechanism Units (BMUs) across the GB power generation fleet. It evaluates volume risk, directional bias, and compliance tolerances across multiple calendar years (2025, 2026+), with half-hourly Settlement Period (SP) root-cause investigation powered by DuckDB in-place querying.

---

## 🌟 What's New in Release 7

### 1. In-Place DuckDB Cloud Engine (Zero Multi-GB Downloads)
- **Zero Local Disk Bloat**: Multi-gigabyte Settlement Period datasets are queried directly where they reside:
  - **Azure Mode**: DuckDB connects natively via `azure://dlaaencmmdsffuks01.blob.core.windows.net/datalake/pn-accuracy-{year}/internal/sp_summary_{year}.csv` using DuckDB's `azure` extension (`PROVIDER CREDENTIAL_CHAIN`), streaming HTTP byte-range queries directly from Azure without downloading multi-GB files into `inputs/`.
  - **Local Mode**: DuckDB executes queries directly against local CSVs in `inputs/`.

### 2. Strict Source-Prioritized Routing & Reciprocal Fallbacks
- **Azure Mode (Azure First)**: Looks on Azure first for `sp_summary_{year}.csv`. Since the 2026 dataset is in Azure, it loads immediately via cloud query. If absent, it gracefully falls back to local inputs.
- **Local Mode (Local First & Vice Versa)**: Looks on local `inputs/` first. If absent from `inputs/`, it checks Azure Blob Storage as fallback.

### 3. Settlement Period Query Diagnostics & Smart Defaulting
- **Transparent Query Diagnostics**: Collapsible `🛠️ Settlement Period Query Diagnostics` expander detailing active data source mode, target URI/path, total file rows, and row counts before and after the date filter.
- **Smart Defaulting**: Defaults to `FOMO-1` (the sample unit present in the dataset) so full charts render immediately upon navigating to Tab 6.
- **Informative Zero-Row Feedback**: Selecting a BMU not present in the dataset provides immediate guidance with sample available units instead of a blank chart.

### 4. Usability, Narrative & Central Export Hub
- **Tab 1 (Executive Summary)**: Reordered hierarchy with Fuel Performance Summary placed prominently above Fleet Error Distribution; distribution colorized by 5 operational risk bands (0–1%, 1–2%, 2–4%, 4–10%, >10%).
- **Tab 2 (Median Error)**: Added tabular summary (`Fuel`, `Median Error %`, `BMU Count`) directly beneath chart.
- **Tab 3 (Total GWh Error)**: Added `% Fleet Contribution` to the summary table.
- **Tab 4 (By Technology)**: Split into **Top Performing BMUs** and **Bottom BMUs** (10 highest error) without `NeedsAttention` clutter.
- **Tab 7 (Require Attention)**: Added 5th KPI card: `% Fuel Fleet Flagged`, with cleaner `{Fuel} — List of Units` header.
- **Tab 8 (Exports)**: Central Export Hub consolidating 6 distinct CSV datasets for instant download.

### 5. Expanded Guardian Regression Suite
- **40 Automated Unit Tests**: Complete coverage across business rules, DuckDB SP querying, schema coercion, blob existence checks, and baseline analytical invariants.

---

## 💻 Windows 11 Setup Guide (VS Code + Conda)

This package is verified and self-contained to run on **Windows 11** using **Conda** and **Visual Studio Code**.

### 1. Prerequisites on Windows 11
* **Miniconda or Anaconda**: [Install Miniconda for Windows](https://docs.conda.io/en/latest/miniconda.html)
* **Visual Studio Code**: [Install VS Code](https://code.visualstudio.com/)
* **Azure CLI (Required for live Azure mode)**: [Install Azure CLI for Windows](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows)

---

### 2. Environment Setup (Terminal in VS Code)
Open VS Code, press ``Ctrl + ` `` to open the integrated terminal (PowerShell or Command Prompt), and run:

```powershell
# 1. Create a clean Conda environment with Python 3.11
conda create -n dashboard python=3.11 -y

# 2. Activate the environment
conda activate dashboard

# 3. Navigate into the release directory
cd release_7_azure

# 4. Install dependencies (includes duckdb)
pip install -r requirements.txt
```

---

### 3. Corporate Azure Authentication (`az login`)
To connect to live corporate Azure Blob Storage, authenticate once via the Azure CLI:

```powershell
az login
```
*(A browser window will open for corporate Single Sign-On / MFA. Once authenticated, the terminal will confirm your subscription).*

---

### 4. Verification: Run Guardian Test Suite
Before launching the application, verify that your environment passes all analytical and schema invariants:

```powershell
python tests/run_tests.py
```
*(All 40 guardian tests will execute and report `✅ ALL TEST SUITES PASSED` in < 2 seconds).*

---

### 5. Running the Dashboard

#### Option A: Live Azure Mode (Default)
With Azure CLI authenticated, launch the application:
```powershell
streamlit run app.py
```
* The sidebar will display `Azure Blob Storage` as the selected data source.
* You can switch between **2025** and **2026** directly from the **Calendar Year** dropdown.

#### Option B: Offline / Local Mode (Zero Cloud Credentials Required)
If operating on an unconfigured machine or without network access:
```powershell
streamlit run app.py
```
* If Azure credentials are not found, the app **automatically falls back** to bundled local inputs (`inputs/annual_summary_2025.csv`, `monthly_summary_2025.csv`, and `sp_summary_2025.csv`).
* Alternatively, select **Local (inputs/ folder)** or **Manual Upload (CSV)** directly in the sidebar.

---

## 📂 Project Structure
```
release_7_azure/
├── app.py                   # Single application entry point
├── constants.py             # Configuration endpoints & multi-year list
├── azure_blob_helper.py     # Azure Blob Storage connector (AzureCliCredential)
├── requirements.txt         # Pinned production dependencies (including duckdb)
├── README.md                # Windows 11 & VS Code execution guide
├── assets/                  # Corporate branding assets
│   ├── neso_logo.jpg        # Embedded corporate logo
│   └── dashboard_reference.png
├── documentation/           # Stakeholder user guide
│   └── How_to.docx
├── inputs/                  # Bundled offline fallback datasets
│   ├── annual_summary_2025.csv
│   ├── monthly_summary_2025.csv
│   └── sp_summary_2025.csv  # Settlement Period dataset for DuckDB querying
└── tests/                   # Guardian regression test suite
    ├── run_tests.py         # Single-command test runner (exit 0 on pass)
    ├── test_business_rules.py
    ├── test_data_processing.py
    ├── test_azure_and_fallback.py
    ├── test_baseline_invariants.py
    └── test_sp_duckdb.py    # DuckDB SP querying, azure:// URLs & deduplication tests
```

---

## 🛡️ Guardian Test Architecture

The regression test suite is split across 5 focused modules:
1. `test_business_rules.py` (13 tests): Wind/Solar thresholds ($\pm3\%$ net, $9.4\%$ ABS), other fuel thresholds ($\pm1\%$ net, $2.6\%$ ABS), reason string formatting, and 5 operational error bands.
2. `test_data_processing.py` (5 tests): Multi-year stamping, schema coercion, NaN handling, monthly date parsing, and attention flagging.
3. `test_azure_and_fallback.py` (6 tests): Dynamic multi-year blob path resolution (`pn-accuracy-{year}`), constants verification, and local fallback locator.
4. `test_baseline_invariants.py` (7 tests): Regression audit against canonical baseline datasets ensuring fleet counts, monthly records, and flagged attention units remain invariant.
5. `test_sp_duckdb.py` (9 tests): DuckDB Settlement Period query filtering, deduplication on `(BMU, settlementDate, settlementPeriod)`, absolute Bid/Offer volumes, missing file handling, `azure://` remote URL generation, and blob existence checking.

