import pandas as pd
from io import BytesIO

try:
    from azure.storage.blob import BlobServiceClient
    from azure.identity import AzureCliCredential
    AZURE_PACKAGES_AVAILABLE = True
except ImportError:
    AZURE_PACKAGES_AVAILABLE = False
    BlobServiceClient = None
    AzureCliCredential = None


class AzureBlobStorage:
    def __init__(self, account_url, container_name, project_name):
        self.account_url = account_url
        self.container_name = container_name
        self.project_name = project_name
        self._container_client = None

    @property
    def container_client(self):
        if self._container_client is not None:
            return self._container_client

        if not AZURE_PACKAGES_AVAILABLE or AzureCliCredential is None:
            raise RuntimeError(
                "Azure SDK packages ('azure-storage-blob' and 'azure-identity') are not installed in this Python environment."
            )

        credential = AzureCliCredential()
        self._container_client = BlobServiceClient(
            self.account_url, credential=credential
        ).get_container_client(self.container_name)
        return self._container_client

    @container_client.setter
    def container_client(self, client):
        self._container_client = client

    def _read_csv(self, blob_path: str) -> pd.DataFrame:
        blob_client = self.container_client.get_blob_client(blob_path)
        data = blob_client.download_blob().readall()
        return pd.read_csv(BytesIO(data))

    def _resolve_path(self, prefix: str, year=None) -> str:
        if year is not None:
            y = str(year)
            parts = self.project_name.rsplit("-", 1)
            if len(parts) == 2 and parts[1].isdigit():
                base = parts[0]
            else:
                base = self.project_name
            folder = f"{base}-{y}"
        else:
            folder = self.project_name
            y = folder.split("-")[-1] if ("-" in folder and folder.split("-")[-1].isdigit()) else "2025"
        return f"{folder}/internal/{prefix}_{y}.csv"

    def read_annual_summary(self, year=None) -> pd.DataFrame:
        return self._read_csv(self._resolve_path("annual_summary", year))

    def read_monthly_summary(self, year=None) -> pd.DataFrame:
        return self._read_csv(self._resolve_path("monthly_summary", year))

    def read_sp_summary(self, year=None) -> pd.DataFrame:
        return self._read_csv(self._resolve_path("sp_summary", year))

    def sp_blob_exists(self, year=None) -> bool:
        """Check whether the sp_summary_{year}.csv blob exists in the Azure container."""
        try:
            path = self._resolve_path("sp_summary", year)
            blob_client = self.container_client.get_blob_client(path)
            return blob_client.exists()
        except Exception:
            return False

    def get_access_token(self) -> str:
        """Attempt to retrieve an Azure access token using the active credential."""
        if not AZURE_PACKAGES_AVAILABLE or AzureCliCredential is None:
            return None
        try:
            credential = AzureCliCredential()
            token_obj = credential.get_token("https://storage.azure.com/.default")
            return getattr(token_obj, "token", None)
        except Exception:
            return None

    def get_sp_azure_url(self, year=None) -> str:
        """Construct the azure:// URL for DuckDB query engine without local file download."""
        path = self._resolve_path("sp_summary", year)
        account_name = self.account_url.replace("https://", "").replace("http://", "").split(".")[0]
        return f"azure://{account_name}.blob.core.windows.net/{self.container_name}/{path}"
