# Phase 2 Release 6: Rota UI Overhaul (Acceptance Testing)

This release contains the overhauled, dynamically generated Rota matrix UI for the Market Monitoring platform. It replaces the old linear list-view with a highly condensed, Excel-style matrix view across both the Weekly and Monthly administration pages.

## What's Included

* **Weekly Rota Page (`/rota-weekly`)**: Now displays a read-only matrix of the current week, explicitly singling out the Weekly IC Owner on Monday.
* **Monthly Rota Administration (`/rota-admin`)**: A fully editable, single-table condensed matrix view for the entire month. Changes made via dropdowns in this table are extracted and saved cleanly to Azure SQL.

## Acceptance Testing Instructions (Windows 11)

This release is pre-configured strictly for **Azure SQL mode**. Do not attempt to run this with SQLite.

1. Unzip this package and open the folder in VS Code.
2. Open a new **PowerShell** terminal in VS Code.
3. Activate your dedicated Conda environment (or create one):
   ```powershell
   conda activate market_monitoring_env
   ```
4. Install the required dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Ensure your Azure SQL credentials are set in your local Windows environment variables, or temporarily export them in your PowerShell session:
   ```powershell
   $env:DATABASE_MODE="azure"
   $env:AZURE_SQL_SERVER="your_server.database.windows.net"
   $env:AZURE_SQL_DATABASE="your_db"
   ```
6. Launch the application:
   ```powershell
   python src/app.py
   ```
7. Open your browser and navigate to `http://127.0.0.1:8050`.

### Things to verify during testing:
- Navigate to **Rota Administration**. Select **November 2026** (or whichever month you populated with `create_mm_rota.sql` in Azure). Ensure the full month loads as a single unified table.
- Change a few analyst dropdowns, including the "Owner" dropdown, and click **Save Changes**.
- Refresh the page and confirm the changes persisted correctly to the Azure SQL database.
- Navigate back to the Landing Page and verify that the "Rota for this week" preview matches the changes you just made.

Please report back with your findings!
