import dash
from dash import dcc, html, Input, Output, callback
from src.components.navbar import create_header, create_sidebar

app = dash.Dash(
    __name__,
    use_pages=True,
    suppress_callback_exceptions=True,
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

app.title = "NESO | Market Monitoring Platform"

app.layout = html.Div(
    className="app-container",
    children=[
        dcc.Location(id="url", refresh=False),
        dcc.Store(
            id="selected-analyst-store",
            storage_type="session",
            data=None,
        ),
        dcc.Store(
            id="operational-date-store",
            storage_type="session",
            data={"start_date": "2026-02-02", "end_date": "2026-02-08"},
        ),
        dcc.Store(
            id="closed-date-store",
            storage_type="session",
            data={"start_date": "2026-02-02", "end_date": "2026-02-08"},
        ),
        html.Div(id="platform-layout-container"),
    ],
)


@callback(
    Output("platform-layout-container", "children"),
    Input("url", "pathname"),
    Input("url", "search"),
)
def render_platform_layout(pathname, search):
    # On root Platform Landing Page ("/"), or Rota pages, render full canvas matching landing_page.png without header/sidebar
    if pathname in ["/", "/rota-weekly", "/rota-admin"] or not pathname:
        return html.Div(
            style={"width": "100%", "minHeight": "100vh", "backgroundColor": "#F4F4F6"},
            children=[dash.page_container],
        )

    # Standalone Detail Analytical Evidence View (no sidebar/header)
    if pathname == "/analytical-support" and search and "unique_id=" in search:
        return html.Div(
            style={"width": "100%", "minHeight": "100vh", "backgroundColor": "#F4F4F6"},
            children=[dash.page_container],
        )

    # On operational workstream pages, render top header bar and plum sidebar
    return html.Div(
        children=[
            create_header(),
            html.Div(
                className="neso-body-wrapper",
                children=[
                    create_sidebar(),
                    html.Div(
                        className="neso-main-content",
                        children=[dash.page_container],
                    ),
                ],
            ),
        ]
    )


server = app.server

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8050, debug=True)
