from pydantic import BaseModel, ConfigDict
from datetime import date
from typing import Optional

class RotaEntry(BaseModel):
    rota_id: Optional[int] = None
    review_date: str
    data_date: str
    analyst_name: str
    is_weekly_ic_owner: bool
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
