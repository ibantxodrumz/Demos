import dash
from dash import dcc, html, Input, Output, State, callback, ALL
import pandas as pd
from datetime import date, timedelta, datetime
from dateutil.relativedelta import relativedelta
from src.repositories.rota_repository import get_rota_for_month, update_rota_entry

dash.register_page(
    __name__,
    path="/rota-admin",
    title="Rota Administration",
)

def get_month_options():
    # Generate next 6 months options starting from Oct 2026 for demo context
    today = date(2026, 10, 1)
    options = []
    for i in range(6):
        month_date = today + relativedelta(months=i)
        label = month_date.strftime("%B %Y")
        value = month_date.strftime("%Y-%m")
        options.append({"label": label, "value": value})
    return options

layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "1400px",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#F4F4F6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        html.Div(
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                html.H1(
                    "Rota Administration",
                    style={"color": "#4E0038", "margin": "0", "fontSize": "28px"},
                ),
                html.A(
                    "← Back to Landing Page",
                    href="/",
                    target="_self",
                    style={
                        "backgroundColor": "#ffffff",
                        "color": "#4E0038",
                        "padding": "8px 16px",
                        "borderRadius": "6px",
                        "textDecoration": "none",
                        "fontWeight": "600",
                        "border": "1px solid #cbd5e1",
                        "display": "inline-block",
                        "cursor": "pointer",
                    },
                ),
            ],
        ),
        
        # Month Selector Bar
        html.Div(
            style={
                "backgroundColor": "#4E0038",
                "color": "#ffffff",
                "borderRadius": "8px",
                "padding": "16px 32px",
                "marginBottom": "28px",
                "display": "flex",
                "alignItems": "center",
                "justifyContent": "center",
                "gap": "16px",
                "boxShadow": "0 2px 6px rgba(0,0,0,0.1)",
            },
            children=[
                html.Label(
                    "Select Month:",
                    style={
                        "fontSize": "16px",
                        "fontWeight": "700",
                        "letterSpacing": "0.5px",
                    },
                ),
                dcc.Dropdown(
                    id="rota-admin-month-select",
                    options=get_month_options(),
                    value=get_month_options()[0]["value"],
                    clearable=False,
                    style={"color": "#1e293b", "minWidth": "250px"}
                ),
                html.Button(
                    "Save Changes",
                    id="btn-rota-admin-save",
                    n_clicks=0,
                    style={
                        "backgroundColor": "#46C18A",
                        "color": "#ffffff",
                        "border": "none",
                        "padding": "8px 24px",
                        "borderRadius": "6px",
                        "fontSize": "15px",
                        "fontWeight": "700",
                        "cursor": "pointer",
                        "boxShadow": "0 2px 4px rgba(0,0,0,0.2)",
                        "marginLeft": "auto",
                    }
                )
            ],
        ),
        
        html.Div(id="rota-admin-save-status", style={"marginBottom": "16px", "fontWeight": "bold"}),

        html.Div(
            id="rota-admin-content",
            style={
                "backgroundColor": "#ffffff",
                "border": "1px solid #cbd5e1",
                "borderRadius": "8px",
                "padding": "24px",
                "boxShadow": "0 2px 4px rgba(0,0,0,0.05)",
                "overflowX": "auto"
            },
        ),
    ]
)

@callback(
    Output("rota-admin-content", "children"),
    Input("rota-admin-month-select", "value")
)
def load_admin_rota(month_val):
    if not month_val:
        return dash.no_update
        
    year, month = map(int, month_val.split("-"))
    entries = get_rota_for_month(year, month)
    
    if not entries:
        return html.Div("No rota entries found for this month.", style={"color": "#64748b"})

    # Group into weeks by identifying all distinct Mondays
    mondays = set()
    for e in entries:
        r_date = datetime.strptime(e.review_date, "%Y-%m-%d").date()
        monday = r_date - timedelta(days=r_date.weekday())
        mondays.add(monday)
        
    mondays = sorted(list(mondays))
    analyst_options = [{"label": f"Analyst {i}", "value": f"Analyst {i}"} for i in [1,2,3]]
    
    # ---------------------------------------------------------
    # Single Unified Table for the Month
    # ---------------------------------------------------------
    
    # Main Header: Days of the week
    ths = [html.Th("Rota / Task", style={"backgroundColor": "#D4BDD8", "color": "#4E0038", "padding": "8px 12px", "border": "1px solid #cbd5e1", "width": "22%", "textAlign": "center", "fontWeight": "bold"})]
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    for dow_str in day_names:
        ths.append(html.Th(
            dow_str,
            style={"backgroundColor": "#D4BDD8", "color": "#4E0038", "padding": "8px 12px", "border": "1px solid #cbd5e1", "textAlign": "center", "width": "15.6%", "fontWeight": "bold", "fontSize": "15px"}
        ))
    thead = html.Thead(html.Tr(ths))
    
    tbody_rows = []
    
    for idx, monday in enumerate(mondays):
        days = [monday + timedelta(days=i) for i in range(5)] # Mon to Fri
        week_end = monday + timedelta(days=4)
        week_entries = [e for e in entries if monday <= datetime.strptime(e.review_date, "%Y-%m-%d").date() <= week_end]
        
        entries_by_date = {d.isoformat(): [] for d in days}
        for e in week_entries:
            entries_by_date[e.review_date].append(e)
            
        # SUB-HEADER ROW: Week dates and individual day dates
        week_str = f"Week: {monday.strftime('%d %b')} - {week_end.strftime('%d %b')}"
        date_subheaders = [html.Td(
            html.Div(week_str, style={"fontWeight": "bold", "fontSize": "13px", "color": "#4E0038"}),
            style={"backgroundColor": "#f1f5f9", "padding": "6px 12px", "border": "1px solid #cbd5e1", "textAlign": "left", "borderTop": "6px solid #D4BDD8" if idx > 0 else "1px solid #cbd5e1"}
        )]
        for d in days:
            date_subheaders.append(html.Td(
                d.strftime("%d-%b"),
                style={"backgroundColor": "#f1f5f9", "color": "#4E0038", "padding": "6px 12px", "border": "1px solid #cbd5e1", "textAlign": "center", "fontWeight": "600", "fontSize": "13px", "borderTop": "6px solid #D4BDD8" if idx > 0 else "1px solid #cbd5e1"}
            ))
        tbody_rows.append(html.Tr(date_subheaders))
        
        # ROW 1: Daily Tasks (Condensed)
        tr1_cells = [html.Td(
            dcc.Textarea(
                value="Pack Review Rota + TCLC for last week (-7 days) + IOLC AAE + IC Trading",
                style={"width": "100%", "minHeight": "70px", "border": "1px dashed #cbd5e1", "padding": "4px", "fontWeight": "bold", "color": "#4E0038", "backgroundColor": "transparent", "resize": "vertical", "fontSize": "13px"}
            ),
            style={"padding": "8px", "border": "1px solid #cbd5e1", "backgroundColor": "#f8fafc", "verticalAlign": "top"}
        )]
        
        for d in days:
            day_entries = entries_by_date[d.isoformat()]
            cell_content = []
            for e in day_entries:
                d_date = datetime.strptime(e.data_date, "%Y-%m-%d")
                data_day_short = d_date.strftime("%a")
                
                dropdown = dcc.Dropdown(
                    id={"type": "rota-analyst-dropdown", "rota_id": e.rota_id, "monday": monday.isoformat()},
                    options=analyst_options,
                    value=e.analyst_name,
                    clearable=False,
                    style={"flex": "1", "minWidth": "90px"} # condensed
                )
                
                cell_content.append(
                    html.Div([
                        html.Span(f"{data_day_short}:", style={"fontWeight": "600", "marginRight": "4px", "color": "#334155", "width": "35px"}),
                        html.Div(dropdown, style={"flex": "1"})
                    ], style={"marginBottom": "4px", "fontSize": "12px", "display": "flex", "alignItems": "center"})
                )
                
            tr1_cells.append(html.Td(
                cell_content,
                style={"padding": "8px", "border": "1px solid #cbd5e1", "textAlign": "left", "backgroundColor": "#ffffff", "verticalAlign": "top"}
            ))
            
        tbody_rows.append(html.Tr(tr1_cells))
        
        # ROW 2: IC Owner (Condensed)
        tr2_cells = [html.Td(
            dcc.Textarea(
                value="Import Constraints - for previous 2 week review",
                style={"width": "100%", "minHeight": "45px", "border": "1px dashed #cbd5e1", "padding": "4px", "fontWeight": "bold", "color": "#4E0038", "backgroundColor": "transparent", "resize": "vertical", "fontSize": "13px"}
            ),
            style={"padding": "4px 8px", "border": "1px solid #cbd5e1", "backgroundColor": "#f8fafc", "verticalAlign": "middle"}
        )]
        
        # Find IC owner for the week
        ic_owner = next((e.analyst_name for e in week_entries if e.is_weekly_ic_owner), "Analyst 1")
            
        # Monday cell
        ic_dropdown = dcc.Dropdown(
            id={"type": "rota-ic-dropdown", "monday": monday.isoformat()},
            options=analyst_options,
            value=ic_owner,
            clearable=False,
            style={"minWidth": "115px"}
        )
        
        tr2_cells.append(html.Td(
            html.Div([
                html.Div("Owner:", style={"fontSize": "12px", "color": "#64748b", "marginRight": "6px", "fontWeight": "600"}),
                html.Div(ic_dropdown, style={"flex": "1"})
            ], style={"display": "flex", "alignItems": "center", "justifyContent": "center"}),
            style={"padding": "4px 8px", "border": "1px solid #cbd5e1", "backgroundColor": "#f0fdf4"}
        ))
        
        # Tue-Fri cells (greyed out)
        for _ in range(4):
            tr2_cells.append(html.Td("", style={"padding": "4px 8px", "border": "1px solid #cbd5e1", "backgroundColor": "#e2e8f0"}))
            
        tbody_rows.append(html.Tr(tr2_cells))
        
    tbody = html.Tbody(tbody_rows)
    table = html.Table([thead, tbody], style={"width": "100%", "borderCollapse": "collapse"})
    
    return html.Div([
        html.H3(f"Monthly Rota: {datetime.strptime(month_val, '%Y-%m').strftime('%B %Y')}", style={"color": "#4E0038", "marginBottom": "20px", "marginTop": "0"}),
        table
    ])

@callback(
    Output("rota-admin-save-status", "children"),
    Output("rota-admin-save-status", "style"),
    Input("btn-rota-admin-save", "n_clicks"),
    State({"type": "rota-analyst-dropdown", "rota_id": ALL, "monday": ALL}, "value"),
    State({"type": "rota-analyst-dropdown", "rota_id": ALL, "monday": ALL}, "id"),
    State({"type": "rota-ic-dropdown", "monday": ALL}, "value"),
    State({"type": "rota-ic-dropdown", "monday": ALL}, "id"),
    prevent_initial_call=True
)
def save_admin_rota(n_clicks, analyst_values, analyst_ids, ic_values, ic_ids):
    if not n_clicks:
        return dash.no_update, dash.no_update
        
    try:
        ic_owner_map = {ic_id["monday"]: ic_val for ic_id, ic_val in zip(ic_ids, ic_values)}
        
        for a_val, a_id in zip(analyst_values, analyst_ids):
            rota_id = a_id["rota_id"]
            monday = a_id["monday"]
            ic_owner_for_week = ic_owner_map.get(monday)
            
            is_ic_owner = (a_val == ic_owner_for_week)
            update_rota_entry(rota_id, a_val, is_ic_owner)
            
        return "Changes saved successfully!", {"color": "#16a34a", "marginBottom": "16px", "fontWeight": "bold"}
    except Exception as e:
        return f"Error saving changes: {str(e)}", {"color": "#dc2626", "marginBottom": "16px", "fontWeight": "bold"}
