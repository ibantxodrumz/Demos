import dash
from dash import dcc, html, Input, Output, callback
import pandas as pd
from datetime import date, timedelta, datetime
from src.repositories.rota_repository import get_rota_for_week

dash.register_page(
    __name__,
    path="/rota-weekly",
    title="Rota for This Week",
)

def get_current_week_dates():
    # Hardcoded to a week that has data in our dummy dataset for demo purposes
    start = date(2026, 10, 19)
    end = date(2026, 10, 25)
    return start, end

layout = html.Div(
    style={
        "width": "100%",
        "maxWidth": "1200px",
        "margin": "0 auto",
        "minHeight": "100vh",
        "backgroundColor": "#F4F4F6",
        "padding": "28px 40px",
        "boxSizing": "border-box",
        "fontFamily": "Segoe UI, -apple-system, BlinkMacSystemFont, Roboto, sans-serif",
    },
    children=[
        html.Div(
            style={
                "display": "flex",
                "justifyContent": "space-between",
                "alignItems": "center",
                "marginBottom": "28px",
            },
            children=[
                html.H1(
                    "Rota for This Week",
                    style={"color": "#4E0038", "margin": "0", "fontSize": "28px"},
                ),
                html.A(
                    "← Back to Landing Page",
                    href="/",
                    target="_self",
                    style={
                        "backgroundColor": "#ffffff",
                        "color": "#4E0038",
                        "padding": "8px 16px",
                        "borderRadius": "6px",
                        "textDecoration": "none",
                        "fontWeight": "600",
                        "border": "1px solid #cbd5e1",
                        "display": "inline-block",
                        "cursor": "pointer",
                    },
                ),
            ],
        ),
        html.Div(
            id="rota-weekly-content",
            style={
                "backgroundColor": "#ffffff",
                "border": "1px solid #cbd5e1",
                "borderRadius": "8px",
                "padding": "24px",
                "boxShadow": "0 2px 4px rgba(0,0,0,0.05)",
                "overflowX": "auto"
            },
        ),
        dcc.Interval(id="rota-weekly-interval", interval=60000, n_intervals=0),
    ]
)

@callback(
    Output("rota-weekly-content", "children"),
    Input("rota-weekly-interval", "n_intervals")
)
def update_weekly_rota(n):
    start_date, end_date = get_current_week_dates()
    entries = get_rota_for_week(start_date.isoformat(), end_date.isoformat())
    
    if not entries:
        return html.Div("No rota entries found for this week.", style={"color": "#64748b"})

    # We will build a matrix for Monday to Friday
    days = [start_date + timedelta(days=i) for i in range(5)] # Mon to Fri
    
    # Group entries by review date
    entries_by_date = {d.isoformat(): [] for d in days}
    for e in entries:
        if e.review_date in entries_by_date:
            entries_by_date[e.review_date].append(e)
            
    # Table Header (Purple background for dates)
    ths = [html.Th("Rota / Task", style={"backgroundColor": "#D4BDD8", "color": "#4E0038", "padding": "12px", "border": "1px solid #cbd5e1", "width": "20%", "textAlign": "center", "fontWeight": "bold"})]
    for d in days:
        day_str = d.strftime("%d-%b")
        dow_str = d.strftime("%A")
        ths.append(html.Th(
            [html.Div(day_str, style={"fontWeight": "bold", "fontSize": "16px"}), html.Div(dow_str, style={"fontStyle": "italic", "fontSize": "14px", "marginTop": "4px"})],
            style={"backgroundColor": "#D4BDD8", "color": "#4E0038", "padding": "12px", "border": "1px solid #cbd5e1", "textAlign": "center", "width": "16%"}
        ))
        
    thead = html.Thead(html.Tr(ths))
    
    # Row 1: Daily Tasks
    tr1_cells = [html.Td(
        "Pack Review Rota + TCLC for last week (-7 days from review day) + IOLC AAE + IC Trading",
        style={"padding": "12px", "border": "1px solid #cbd5e1", "fontWeight": "bold", "color": "#4E0038", "backgroundColor": "#f8fafc", "fontSize": "14px"}
    )]
    
    for d in days:
        day_entries = entries_by_date[d.isoformat()]
        cell_content = []
        for e in day_entries:
            d_date = datetime.strptime(e.data_date, "%Y-%m-%d")
            data_day_short = d_date.strftime("%a")
            cell_content.append(
                html.Div([
                    html.Span(f"{data_day_short} =", style={"fontWeight": "600", "marginRight": "8px", "color": "#334155"}),
                    html.Span(e.analyst_name, style={"color": "#0f172a"})
                ], style={"marginBottom": "4px", "fontSize": "14px", "display": "flex", "justifyContent": "center"})
            )
            
        tr1_cells.append(html.Td(
            cell_content,
            style={"padding": "12px", "border": "1px solid #cbd5e1", "textAlign": "center", "backgroundColor": "#ffffff", "verticalAlign": "top"}
        ))
        
    tr1 = html.Tr(tr1_cells)
    
    # Row 2: IC Owner
    tr2_cells = [html.Td(
        "Import Constraints - for previous 2 week review (Monday to Sunday)",
        style={"padding": "12px", "border": "1px solid #cbd5e1", "fontWeight": "bold", "color": "#4E0038", "backgroundColor": "#f8fafc", "fontSize": "14px"}
    )]
    
    # For IC Owner, find the owner in the week
    ic_owner = None
    for e in entries:
        if e.is_weekly_ic_owner:
            ic_owner = e.analyst_name
            break
            
    # Monday cell
    tr2_cells.append(html.Td(
        html.Div([
            html.Span("✅ ", style={"marginRight": "4px"}),
            html.Span(f"{ic_owner}" if ic_owner else "Not assigned")
        ]),
        style={"padding": "12px", "border": "1px solid #cbd5e1", "textAlign": "center", "backgroundColor": "#f0fdf4", "fontWeight": "bold", "color": "#16a34a", "fontSize": "14px"}
    ))
    
    # Tue-Fri cells (greyed out)
    for _ in range(4):
        tr2_cells.append(html.Td("", style={"padding": "12px", "border": "1px solid #cbd5e1", "backgroundColor": "#e2e8f0"}))
        
    tr2 = html.Tr(tr2_cells)
    
    tbody = html.Tbody([tr1, tr2])
    table = html.Table([thead, tbody], style={"width": "100%", "borderCollapse": "collapse", "marginTop": "20px"})
    
    return html.Div([
        html.Div(
            f"Week : From {start_date.strftime('%d/%m/%Y')} to {end_date.strftime('%d/%m/%Y')}",
            style={
                "backgroundColor": "#4E0038",
                "color": "#ffffff",
                "padding": "16px",
                "borderRadius": "8px",
                "textAlign": "center",
                "fontWeight": "700",
                "fontSize": "18px",
            }
        ),
        table
    ])
