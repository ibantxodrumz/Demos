import sys
import os
from pathlib import Path

# Ensure src is in the python path
sys.path.insert(0, str(Path(__file__).parent))

# Import the Azure connection logic
from src.repositories.azure_connection import get_azure_connection

def deploy_rota_schema():
    print("Connecting to Azure SQL Database...")
    try:
        conn = get_azure_connection()
        print("Connected successfully!")
    except Exception as e:
        print(f"Failed to connect to Azure SQL: {e}")
        return

    sql_path = Path(__file__).parent / "src" / "config" / "create_mm_rota.sql"
    if not sql_path.exists():
        print(f"Error: Could not find {sql_path}")
        return
        
    print(f"Reading SQL script from {sql_path}...")
    sql_script = sql_path.read_text(encoding="utf-8")
    
    # Split by 'GO' keyword to execute statements individually 
    # since pyodbc does not support executing multiple batches with GO directly.
    import re
    statements = re.split(r'\bGO\b', sql_script, flags=re.IGNORECASE)
    
    try:
        for stmt in statements:
            stmt = stmt.strip()
            if stmt:
                print(f"Executing statement: {stmt[:50]}...")
                conn.execute(stmt)
        conn.commit()
        print("\n✅ Successfully created and populated the MM_ROTA table in Azure SQL!")
    except Exception as e:
        print(f"\n❌ Error executing SQL: {e}")
        conn.rollback()

if __name__ == "__main__":
    deploy_rota_schema()
