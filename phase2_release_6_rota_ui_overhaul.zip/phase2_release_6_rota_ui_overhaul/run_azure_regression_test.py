import sys
import os
import traceback
from pathlib import Path

# Ensure src is in the python path
sys.path.insert(0, str(Path(__file__).parent))

# Force Azure Mode for the regression test
os.environ["DATABASE_MODE"] = "azure"

from src.repositories.rota_repository import get_rota_for_week, get_rota_for_month
from src.repositories.activity_log_repository import ActivityLogRepository
from src.repositories.alert_repository import AlertRepository
from src.repositories.ic_analytics_repository import IcAnalyticsRepository

def run_regression_tests():
    print("======================================================")
    print("🚀 Starting Azure SQL Live Query Regression Suite")
    print("======================================================")
    
    success = True
    
    # 1. Test Rota Repository
    try:
        print("\n[1/5] Testing get_rota_for_week()...")
        entries = get_rota_for_week("2026-10-01", "2026-10-07")
        print(f"✅ Success! Retrieved {len(entries)} rota entries for the week.")
    except Exception as e:
        print(f"❌ Failed: {e}")
        traceback.print_exc()
        success = False

    try:
        print("\n[2/5] Testing get_rota_for_month()...")
        entries = get_rota_for_month(2026, 10)
        print(f"✅ Success! Retrieved {len(entries)} rota entries for the month.")
    except Exception as e:
        print(f"❌ Failed: {e}")
        traceback.print_exc()
        success = False

    # 2. Test Activity Log Repository
    try:
        print("\n[3/5] Testing ActivityLogRepository.get_closed_reviews()...")
        log_repo = ActivityLogRepository()
        reviews = log_repo.get_closed_reviews(workstream_name="IMPORT_CONSTRAINTS")
        print(f"✅ Success! Retrieved {len(reviews)} closed reviews.")
    except Exception as e:
        print(f"❌ Failed: {e}")
        traceback.print_exc()
        success = False

    # 3. Test Alert Repository
    try:
        print("\n[4/5] Testing AlertRepository.get_all_alerts()...")
        alert_repo = AlertRepository()
        alerts = alert_repo.get_all_alerts(workstream_name="IMPORT_CONSTRAINTS")
        print(f"✅ Success! Retrieved {len(alerts)} alerts.")
    except Exception as e:
        print(f"❌ Failed: {e}")
        traceback.print_exc()
        success = False

    # 4. Test Analytics Repository
    try:
        print("\n[5/5] Testing IcAnalyticsRepository.get_alert_durations()...")
        analytics_repo = IcAnalyticsRepository()
        durations = analytics_repo.get_alert_durations("2026-01-01", "2026-12-31")
        print(f"✅ Success! Retrieved duration analytics.")
    except Exception as e:
        print(f"❌ Failed: {e}")
        traceback.print_exc()
        success = False

    print("\n======================================================")
    if success:
        print("🎉 ALL AZURE SQL QUERIES PASSED SUCCESSFULLY!")
        print("There are no hidden syntax differences or missing objects.")
    else:
        print("⚠️ SOME QUERIES FAILED. Please review the tracebacks above.")
    print("======================================================")

if __name__ == "__main__":
    run_regression_tests()
