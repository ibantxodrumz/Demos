# sql_utils.py
import struct
import pandas as pd
import pyodbc
import streamlit as st

from azure.identity import AzureCliCredential, DefaultAzureCredential
from azure.core.exceptions import ClientAuthenticationError

from constants import SQL_SERVER, SQL_DATABASE, SQL_QUERY


# --- SQL Azure Token-based Authentication Logic ---


@st.cache_resource(ttl=3300)
def get_access_token():
    """
    Fetch an access token for Azure SQL.

    Local dev: prefers Azure CLI (az login).
    Fallback: DefaultAzureCredential which can use VS Code / shared token cache / interactive browser.
    """
    scope = "https://database.windows.net/.default"

    # 1) Most reliable for local dev on corporate laptops
    try:
        token = AzureCliCredential().get_token(scope)
        return token.token
    except Exception:
        pass

    # 2) Fallback chain (can use multiple sources)
    try:
        cred = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        token = cred.get_token(scope)
        return token.token
    except ClientAuthenticationError as e:
        raise ConnectionError(
            "Azure authentication failed. Run 'az login' in the same environment, "
            "or ensure your account is available to DefaultAzureCredential. "
            f"Details: {e}"
        )
    except Exception as e:
        raise ConnectionError(f"Azure authentication error: {e}")


def _pick_odbc_driver():
    """
    Prefer Driver 18, fallback to Driver 17 if present.
    """
    installed = pyodbc.drivers()
    for d in ["ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"]:
        if d in installed:
            return "{" + d + "}"
    # If neither found, keep the 18 name so the error is explicit
    return "{ODBC Driver 18 for SQL Server}"


def get_sql_connection():
    """
    Creates a pyodbc connection to Azure SQL using an AAD access token.
    """
    driver = _pick_odbc_driver()

    connection_string = (
        f"Driver={driver};"
        f"Server=tcp:{SQL_SERVER},1433;"
        f"Database={SQL_DATABASE};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        "Connection Timeout=30;"
    )

    token = get_access_token()

    # SQL_COPT_SS_ACCESS_TOKEN = 1256
    token_bytes = token.encode("UTF-16-LE")
    token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

    try:
        conn = pyodbc.connect(connection_string, attrs_before={1256: token_struct})
        return conn

    except pyodbc.Error as e:
        msg = str(e)
        drivers = pyodbc.drivers()

        # Driver missing / not registered
        if "Can't open lib" in msg or "ODBC Driver" in msg and "not found" in msg:
            raise EnvironmentError(
                "ODBC driver not available for pyodbc. "
                f"Installed drivers seen by pyodbc: {drivers}. "
                "You need ODBC Driver 18 (or 17)."
            )

        # Azure SQL firewall blocks are often phrased like this
        if "Client with IP address" in msg or "Firewall rule" in msg:
            raise ConnectionError(
                "Azure SQL firewall appears to be blocking your connection. "
                "Your client IP must be allow-listed on the SQL Server firewall."
            )

        # Common AAD/permissions failure
        if (
            "Login failed" in msg
            or "principal" in msg
            or "token-identified principal" in msg
        ):
            raise ConnectionError(
                "Authentication reached Azure SQL but the identity likely lacks permission "
                "to the server/database. You may need to be granted access in Azure SQL "
                "(Entra ID admin configured + user/group created in DB). "
                f"Raw error: {msg}"
            )

        raise ConnectionError(f"SQL connection failed: {msg}")


@st.cache_data(ttl=3600)
def fetch_sql_data():
    """Fetched data from Azure SQL and returns as a DataFrame."""
    try:
        conn = get_sql_connection()
        df = pd.read_sql(SQL_QUERY, conn)
        conn.close()
        return df
    except Exception as e:
        # Pass the error back to st.error handled in app.py
        raise e
