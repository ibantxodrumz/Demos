# This file is used to add utility functions for the project

import pandas as pd
import requests
import time

# disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None
from datetime import datetime, timedelta
import config

# IMPORT THE APPROPRIATE STORAGE CLASS BASED ON STORAGE_TYPE
if config.STORAGE_TYPE == "azure":
    from src.storage.azure_blob_storage import AzureBlobStorage as Storage
else:
    from src.storage.local_storage import LocalStorage as Storage
from dotenv import load_dotenv


def paginated_fetch(url, sp=1) -> list:
    "mainly to deal with B1610 data 400 bad request, query sp one by one sequentially"
    combined_json = []  # list
    while True:
        url_sp = f"{url}&settlementPeriodFrom={sp}&settlementPeriodTo={sp}"
        try:
            r = requests.get(url_sp, verify=False)
            r.raise_for_status()
            json_data = r.json()
            if not json_data:
                break  # stop when no more sp to fetch
            combined_json.extend(json_data)  # merge list
            sp += 1
            time.sleep(0.1)
        except requests.exceptions.RequestException:
            break
    return combined_json


def get_capacity():
    """
    delete old files before saving, to ensure only the latest file is kept
    """
    if config.STORAGE_TYPE == "azure":
        storage = Storage(
            config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
        )
    else:
        storage = Storage(config.BASE_DIR)

    storage.delete_old_capacity_file()
    # fetch the latest file
    Today = datetime.today().strftime("%Y-%m-%d")
    CAPACITY_URL = f"https://data.elexon.co.uk/bmrs/api/v1/datasets/IGCPU/stream?publishDateTimeFrom=2023-01-01&publishDateTimeTo={Today}"
    capacity = pd.read_json(CAPACITY_URL)
    cap = capacity[["registeredResourceName", "installedCapacity"]]
    cap.loc[:, "installedCapacity_mwh"] = cap["installedCapacity"] * 0.5
    storage.save_meta_data(cap, Today)
    return cap


def get_BMUID():
    if config.STORAGE_TYPE == "azure":
        storage = Storage(
            config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
        )
    else:
        storage = Storage(config.BASE_DIR)
    bmu_id = storage.read_meta_data()
    return bmu_id


def utc_to_localtime(day):
    """check on the given data if it's GMT or BST. Elexon use UTC to indicate datetime
    in the UK, GMT=UTC, BST=UTC+1.
    input: day: eg. Timestamp('2024-04-02 00:00:00)
    output: From: in UTC
            To:
    """

    @staticmethod
    def get_last_sunday(year, month):
        """find the date of the last sunday of any given year & month"""
        last_day = (
            datetime(year, month + 1, 1) - timedelta(days=1)
            if month != 12
            else datetime(year + 1, 1, 1) - timedelta(days=1)
        )
        last_sunday = last_day - timedelta(days=(last_day.weekday() + 1) % 7)
        return last_sunday

    bst_start_date = get_last_sunday(day.year, 3)  # e.g. 31st March 2024 46sp
    bst_end_date = get_last_sunday(day.year, 10)  # e.g. 27th October 2024 50sp
    if day == bst_start_date:  # 46sp but still in GMT
        From = day.strftime("%Y-%m-%dT00:00Z")
        To = day.strftime("%Y-%m-%dT22:59Z")
    elif day == bst_end_date:  # 50sp first two sps are from previous day,
        prev_day = day - timedelta(days=1)
        From = prev_day.strftime("%Y-%m-%dT23:00Z")
        To = day.strftime("%Y-%m-%dT23:59Z")
    elif day in pd.date_range(
        start=bst_start_date + timedelta(days=1), end=bst_end_date - timedelta(days=1)
    ):
        # exluding 31st March 2024 and 27th October 2024 which are already calibated before
        prev_day = day - timedelta(days=1)
        From = prev_day.strftime("%Y-%m-%dT23:00Z")
        To = day.strftime("%Y-%m-%dT22:59Z")
    else:  # GMT period = UTC
        From = day.strftime("%Y-%m-%dT00:00Z")
        To = day.strftime("%Y-%m-%dT23:59Z")
    return From, To


def get_latest_date_from_blob(folder_name):
    if config.STORAGE_TYPE == "azure":
        storage = Storage(
            config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
        )
    else:
        storage = Storage(config.BASE_DIR)

    latest_date = storage.get_latest_date(folder_name=folder_name)

    return latest_date


def main():

    # load environment variables to specify which storage solution to use
    load_dotenv()

    bmu = get_BMUID()
    cap = get_capacity()


if __name__ == "__main__":
    main()
