# The fetch_data.py file contains a class DataFetcher that fetches data from the Elexon API
# and saves the raw data as daily CSV files in the data/raw folder.
# The fetch_data method fetches data for a given endpoint and date range,
# converts the response to a DataFrame, and saves it as a CSV file.
# The main function initializes the DataFetcher class and fetches data for the PN endpoint based on user input for the start and end dates.
# The script is executed when the file is run as the main module.

import requests
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single InsecureRequestWarning from urllib3
urllib3.disable_warnings(InsecureRequestWarning)

import pandas as pd
import time

if __name__ == "__main__":
    import utils as utils
else:
    import src.utils as utils

import config

# IMPORT THE APPROPRIATE STORAGE CLASS BASED ON STORAGE_TYPE
if config.STORAGE_TYPE == "azure":
    from src.storage.azure_blob_storage import AzureBlobStorage as Storage
else:
    from src.storage.local_storage import LocalStorage as Storage
from dotenv import load_dotenv


class DataFetcher:
    """
    A class to fetch data from Elexon API and save the raw data as daily csv files in data/raw folder
    """

    def __init__(self, base_url):
        self.base_url = base_url
        if config.STORAGE_TYPE == "azure":
            self.storage = Storage(
                config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
            )
        else:
            self.storage = Storage(config.BASE_DIR)

    def fetch_data(self, endpoint, day):
        """
        Fetch data from Elexon API and save the raw data as daily csv files in data/raw folder
        :param endpoint: the endpoint of the API
        :param from_date: the start date of the data to fetch
        :param to_date: the end date of the data to fetch
        """

        @staticmethod
        def get_with_retry(url, max_retries=5, delay=2):
            """Repeatedly try requests.get until a 200 response is received or max_retries is reached."""
            attempt = 0
            while attempt < max_retries:
                try:
                    r = requests.get(url, verify=False)
                    if r.status_code == 200:
                        print(f"Request successful on attempt {attempt + 1}.")
                        json_data = r.json()  # list
                        return json_data
                    elif r.status_code == 400:
                        print(f"{r.status_code} bad request, try paginated fetching")
                        json_data = utils.paginated_fetch(url)
                        return json_data
                    else:
                        print(
                            f"Attempt {attempt + 1} failed with status code {r.status_code}. Retrying in {delay} seconds..."
                        )
                except requests.exceptions.RequestException as e:
                    print(f"Attempt {attempt + 1} failed with error: {e}.")

                time.sleep(delay)
                attempt += 1
            print(f"Failed to get a 200 response after {max_retries} attempts.")
            return None

        # construct the url
        if endpoint.startswith("datasets"):
            From, To = utils.utc_to_localtime(day)
            url = f"{self.base_url}{endpoint}?from={From}&to={To}"
        else:  # for bid/offer volumes
            sett_date = day.strftime("%Y-%m-%d")
            url = f"{self.base_url}{endpoint}/{sett_date}"

        json_data = get_with_retry(url)

        if json_data:  # not empty
            self.storage.save_raw_data(endpoint, day, json_data)
        else:
            print("Failed to fetch data for " + day.strftime("%Y-%m-%d") + "\n")


def main():
    # load environment variables to specify which storage solution to use
    load_dotenv()

    # specify the base url and endpoint
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/"

    PN_ep = "datasets/PN/stream"
    MEL_ep = "datasets/MELS/stream"
    METERED_ep = "datasets/B1610/stream"  # metered output
    BID_ep = (
        "balancing/settlement/acceptance/volumes/all/bid"  # volume of accepted bids
    )
    OFFER_ep = (
        "balancing/settlement/acceptance/volumes/all/offer"  # volume of accepted offers
    )

    # specify the period of interest
    start_date = input("Enter the start date (YYYY-MM-DD): ")
    end_date = input("Enter the end date (YYYY-MM-DD): ")

    # fetch and save raw data
    fetcher = DataFetcher(base_url)
    for day in pd.date_range(start=start_date, end=end_date):
        fetcher.fetch_data(PN_ep, day)
        fetcher.fetch_data(MEL_ep, day)
        fetcher.fetch_data(METERED_ep, day)
        fetcher.fetch_data(BID_ep, day)
        fetcher.fetch_data(OFFER_ep, day)


if __name__ == "__main__":
    main()
