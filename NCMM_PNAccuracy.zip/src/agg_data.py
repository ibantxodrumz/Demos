# This file is used to aggregate the results into settlement period, monthly and yearly summaries
# and save them to \output

import re
import pandas as pd
import config

# IMPORT THE APPROPRIATE STORAGE CLASS BASED ON STORAGE_TYPE
if config.STORAGE_TYPE == "azure":
    from src.storage.azure_blob_storage import AzureBlobStorage as Storage
else:
    from src.storage.local_storage import LocalStorage as Storage
from dotenv import load_dotenv


class DataAggregator:
    """
    A class to aggregate the results into monthly and yearly summaries
    """

    def __init__(self):
        if config.STORAGE_TYPE == "azure":
            self.storage = Storage(
                config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
            )
        else:
            self.storage = Storage(config.BASE_DIR)

    def cal_agg(self, start_date, end_date):
        # get the unique year-month and only update/agg the newly fetched files
        date_range = pd.date_range(start=start_date, end=end_date, freq="D")
        ym_list = date_range.to_series().dt.strftime("%Y-%m").unique().tolist()

        processed_files = self.storage.list_combined_files(ym_list)

        # combine daily files by year
        files_by_year = {}
        pattern = re.compile(r"(\d{4})-\d{2}-\d{2}")
        for file_name in processed_files:
            # file_name, e.g., 'pn-accuracy/input/combined/combined_2024_12_30.csv'
            match = pattern.search(file_name)
            if match:
                year = match.group(1)
                if year not in files_by_year:
                    files_by_year[year] = []
                files_by_year[year].append(file_name)

        # process each year's files separately
        for year, files in files_by_year.items():
            all_data = []  # list to store all the combined data for each year
            empty_files = (
                []
            )  # list to store the names of empty files for each year if there're any to flag
            for file in files:
                if file.endswith(".csv"):
                    print(f"Reading {file}")
                    try:
                        df = self.storage.read_combined_file(file)
                        if df.empty and df.columns.size == 0:
                            empty_files.append(file)  # append list
                            print(f"{file} is empty")
                        else:
                            print(
                                f"{file} has {df.shape[0]} rows and {df.shape[1]} columns"
                            )
                            # appned df to a list
                            all_data.append(df)  # append list

                    except pd.errors.EmptyDataError:
                        # file has no data (no rows and no columns)
                        empty_files.append(
                            file
                        )  # add empty file names to the list to flag

                    except Exception as e:
                        print(f"Error reading {file}: {e}")

                else:
                    print(f"{file} is not a csv file")

            print(f"Empty files for {year}: {empty_files}")

            # 1. convert all_data list to dataframe for each year
            new_df = pd.concat(all_data, ignore_index=True)
            # save to output: combined_df as sp_summary_{year}.csv
            self.storage.save_agg(
                df=new_df,
                file_name=f"sp_summary_{year}.csv",
                path="internal",
                key_cols=["nationalGridBmUnit", "settlementDate", "settlementPeriod"],
            )

            # 2. create monthly summary for each year
            monthly_agg, monthly_publish = self.create_monthly_agg(new_df)
            # save to output: monthly_agg as monthly_summary_{year}.csv
            df_month = self.storage.save_agg(
                df=monthly_agg,
                file_name=f"monthly_summary_{year}.csv",
                path="internal",
                key_cols=["nationalGridBmUnit", "year_month"],
            )

            self.storage.save_agg(
                df=monthly_publish,
                file_name=f"monthly_publish_{year}.csv",
                path="publish",
                key_cols=["BMU", "YearMonth"],
            )

            # 3. create annual summary for each year
            annual_agg = self.create_annual_agg(df_month)
            # save to output: annual_agg as annual_summary_{year}.csv
            self.storage.save_agg(
                df=annual_agg,
                file_name=f"annual_summary_{year}.csv",
                path="internal",
                key_cols=["nationalGridBmUnit"],
            )

    def create_monthly_agg(self, new_df):
        # create monthly summaries

        new_df["settlementDate"] = pd.to_datetime(new_df["settlementDate"])
        new_df["year_month"] = new_df["settlementDate"].dt.to_period("M")
        monthly_agg = new_df.groupby(
            ["year_month", "nationalGridBmUnit"], as_index=False
        ).agg(
            {
                "PNLevel": "sum",
                "MELLevel": "sum",
                "BidVolume": "sum",
                "OfferVolume": "sum",
                "Metered": "sum",
                "installedCapacity_mwh": "max",
                "Classification": "first",  # if Offshore or Onshore
                "ExpectOT": "sum",
                "CapacityCalibrated": "sum",  # calibrated with mel
                "NetError": "sum",
                "ABSError": "sum",
            }
        )

        # add monthly calculation
        # 1. keep rows where at least one of pn, mel, metered output is NOT zero
        monthly_agg = monthly_agg[
            monthly_agg[["PNLevel", "MELLevel", "Metered"]].any(axis=1)
        ].reset_index(drop=True)
        # 2. calculate the following new monthly metrics
        monthly_agg["M_NetError%"] = (
            (monthly_agg.NetError) * 100 / (monthly_agg.CapacityCalibrated + 0.001)
        )

        monthly_agg["M_ABS_NetError%"] = abs(monthly_agg["M_NetError%"])
        monthly_agg["Rank_M_ABS_NetError%"] = (
            monthly_agg.groupby("year_month")["M_ABS_NetError%"]
            .apply(lambda x: x.rank(ascending=True, na_option="keep"))
            .values
        )
        monthly_agg["PctRank_M_ABS_NetError%"] = monthly_agg.groupby("year_month")[
            "M_ABS_NetError%"
        ].rank(pct=True)

        monthly_agg["M_ABSError%"] = (
            (monthly_agg.ABSError) * 100 / (monthly_agg.CapacityCalibrated + 0.001)
        )
        monthly_agg["Rank_M_ABSError%"] = (
            monthly_agg.groupby("year_month")["M_ABSError%"]
            .apply(lambda x: x.rank(ascending=True, na_option="keep"))
            .values
        )
        monthly_agg["PctRank_M_ABSError%"] = monthly_agg.groupby("year_month")[
            "M_ABSError%"
        ].rank(pct=True)

        monthly_publish = monthly_agg[
            [
                "nationalGridBmUnit",
                "year_month",
                "ExpectOT",
                "CapacityCalibrated",
                "Metered",
                "NetError",
                "ABSError",
            ]
        ].copy()
        monthly_publish = monthly_publish.rename(
            columns={
                "nationalGridBmUnit": "BMU",
                "year_month": "YearMonth",
                "ExpectOT": "SUM_ExpectOuturn",
                "CapacityCalibrated": "SUM_CAPACITY_MEL",
                "Metered": "SUM_MeteredOutput",
                "NetError": "SUM_NetError",
                "ABSError": "SUM_ABSError",
            }
        )

        return monthly_agg, monthly_publish

    def create_annual_agg(self, df_month):
        # create annual summaries by using the complete monthly agg for the affected year only

        annual_agg = df_month.groupby("nationalGridBmUnit", as_index=False).agg(
            {
                "PNLevel": "sum",
                "MELLevel": "sum",
                "BidVolume": "sum",
                "OfferVolume": "sum",
                "Metered": "sum",
                "installedCapacity_mwh": "max",
                "Classification": "first",  # if Offshore or Onshore
                "ExpectOT": "sum",
                "CapacityCalibrated": "sum",  # calibrated with mel
                "NetError": "sum",
                "ABSError": "sum",
                "M_ABS_NetError%": "max",
                "M_ABSError%": "max",
            }
        )

        # add annual calculation
        # 1. add prefix to monthly max
        annual_agg.rename(
            columns=lambda x: "max_" + x if x.startswith("M_") else x, inplace=True
        )

        # 2. calculate the following new annual metrics
        annual_agg["A_NetError%"] = (
            (annual_agg.NetError) * 100 / (annual_agg.CapacityCalibrated + 0.001)
        )

        # get the absolute of net error percentage for ranking purpose
        annual_agg["A_ABS_NetError%"] = abs(annual_agg["A_NetError%"])
        annual_agg["Rank_A_ABS_NetError%"] = annual_agg["A_ABS_NetError%"].rank(
            ascending=True, na_option="keep"
        )
        annual_agg["PctRank_A_ABS_NetError%"] = annual_agg["A_ABS_NetError%"].rank(
            pct=True
        )
        annual_agg["Max_Rank_M_ABS_NetError%"] = annual_agg["max_M_ABS_NetError%"].rank(
            ascending=True, na_option="keep"
        )
        annual_agg["Max_PctRank_M_ABS_NetError%"] = annual_agg[
            "max_M_ABS_NetError%"
        ].rank(pct=True)

        # get the absolute error percentage
        annual_agg["A_ABSError%"] = (
            (annual_agg.ABSError) * 100 / (annual_agg.CapacityCalibrated + 0.001)
        )
        annual_agg["Rank_A_ABSError%"] = annual_agg["A_ABSError%"].rank(
            ascending=True, na_option="keep"
        )
        annual_agg["PctRank_A_ABSError%"] = annual_agg["A_ABSError%"].rank(pct=True)
        annual_agg["Max_Rank_M_ABSError%"] = annual_agg["max_M_ABSError%"].rank(
            ascending=True, na_option="keep"
        )
        annual_agg["Max_PctRank_M_ABSError%"] = annual_agg["max_M_ABSError%"].rank(
            pct=True
        )

        return annual_agg


def main():
    # load environment variables to specify which storage solution to use
    load_dotenv()

    aggregator = DataAggregator()
    aggregator.cal_agg()


if __name__ == "__main__":
    main()
