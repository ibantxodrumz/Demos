import pandas as pd
import os
from azure.storage.blob import BlobServiceClient
from azure.identity import ManagedIdentityCredential, DefaultAzureCredential
from io import BytesIO
import re
from datetime import datetime


class AzureBlobStorage:

    def __init__(self, account_url, container_name, project_name):
        client_id = os.environ.get("DEFAULT_IDENTITY_CLIENT_ID")
        credential = ManagedIdentityCredential(client_id=client_id)
        # credential = DefaultAzureCredential()
        self.blob_service_client = BlobServiceClient(account_url, credential=credential)
        self.container_client = self.blob_service_client.get_container_client(
            container_name
        )
        self.project_name = project_name
        self.metadata_folder = "meta"
        self.input_folder = "input"
        # output in consumable/pn-accuracy
        self.consumable_client = self.blob_service_client.get_container_client(
            "consumable"
        )

    def read_meta_data(self):
        """
        read bmu_id from metadata_folder
        """
        blob_name = (
            f"{self.project_name}/{self.metadata_folder}/full_list_of_wind_units.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def read_raw_data(self, endpoint, day):
        """
        read daily file from input/endpoint
        """
        blob_name = (
            f"{self.project_name}/{self.input_folder}/{endpoint}/{endpoint}_{day}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def read_combined_file(self, file_name):
        """
        read combined file from input/combined
        """
        blob_name = f"{self.project_name}/{self.input_folder}/combined/{file_name}"
        blob_client = self.container_client.get_blob_client(blob_name)
        data = blob_client.download_blob().readall()
        df = pd.read_csv(BytesIO(data))
        return df

    def list_combined_files(self, ym_list):
        """
        List all file names in pn-accuracy/input/combined folder
        only the newly fetched ones
        """
        BASE_PREFIX = f"{self.project_name}/{self.input_folder}/combined/"
        list_of_files = []
        for ym in ym_list:
            PREFIX = f"{BASE_PREFIX}combined_{ym}"
            blobs_list = self.container_client.list_blobs(name_starts_with=PREFIX)
            # RETURN ONLY THE FILE NAMES
            list_of_files.extend([blob.name[len(BASE_PREFIX) :] for blob in blobs_list])

        return list_of_files

    def save_meta_data(self, df, today):
        """
        save the registered capacity file in the metadata_folder
        """
        blob_name = f"{self.project_name}/{self.metadata_folder}/capacity_{today}.csv"
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Latest capacity data saved to {blob_name}\n")

    def save_raw_data(self, endpoint, day, json_data):
        """
        Save the raw data as a csv file in input/endpoint folder
        """
        segments = endpoint.split("/")
        names = ["PN", "MELS", "B1610", "bid", "offer"]
        name = [x for x in names if x in segments][0].upper()
        date_str = day.strftime("%Y-%m-%d")
        blob_name = (
            f"{self.project_name}/{self.input_folder}/{name}/{name}_{date_str}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        if endpoint.startswith("datasets"):
            df = pd.DataFrame(json_data)
        else:  # for bid/offer volumes
            df = pd.json_normalize(json_data["data"])
        # it looks like [PN data] from the previous day sp 48 is always included
        # make sure only the queried date is included
        df = df[df["settlementDate"] == date_str]
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Data fetched and saved to {blob_name}\n")

    def save_combined_data(self, df, date_str):
        """
        save the combined data by date_str
        """
        blob_name = (
            f"{self.project_name}/{self.input_folder}/combined/combined_{date_str}.csv"
        )
        blob_client = self.container_client.get_blob_client(blob_name)
        blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
        print(f"Combined data saved to {blob_name}\n")

    def save_agg(self, df, file_name, path, key_cols):
        """
        save all aggregated data in the output_folder/internal
        df: newly fetched data
        this is done by update the existing df with the new df
        """
        blob_name = f"{self.project_name}/{path}/{file_name}"
        blob_client = self.consumable_client.get_blob_client(blob_name)

        def _convert_dtype(key_cols, df, existing_df):
            """make sure df always have the same dtype as the existing_df"""
            for col in key_cols:
                if col in ["year_month", "YearMonth"]:
                    df[col] = df[col].astype(str)
                else:
                    df[col] = df[col].astype(existing_df[col].dtype)
            return df

        try:
            # check if blob exists
            existing_blob = blob_client.download_blob().readall()
            existing_df = pd.read_csv(BytesIO(existing_blob))
            # before merging: drop duplicates if any
            existing_df = existing_df.drop_duplicates(subset=key_cols, keep="first")
            # before merging: make sure dtype in df are the same as existing_df
            df = _convert_dtype(key_cols, df, existing_df)
            # merge existing df with the new df
            merged_df = pd.merge(
                existing_df, df, on=key_cols, how="outer", suffixes=("", "_new")
            )
            # ensure dtype consistency after merging in case
            merged_df = _convert_dtype(key_cols, merged_df, existing_df)
            # replace existing records with the new values from df
            for col in df.columns:
                if col not in key_cols:
                    merged_df[col] = merged_df[col + "_new"].combine_first(
                        merged_df[col]
                    )
                    merged_df = merged_df.drop(columns=[col + "_new"])
            # drop duplicates
            merged_df = _convert_dtype(key_cols, merged_df, existing_df)
            merged_df = merged_df.drop_duplicates(subset=key_cols, keep="first")
            # upload the merged df which is the final updated df
            blob_client.upload_blob(merged_df.to_csv(index=False), overwrite=True)
            print(f"Aggregated data appended and saved to {blob_name}\n")
            return merged_df

        except:
            # if the blob does not exist, upload the new data
            blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
            print(f"Aggregated data saved to {blob_name}\n")
            return df

    # def save_publish(self, df, file_name):
    #     """
    #     save the published data in the output_folder/publish
    #     """
    #     blob_name = f'{self.project_name}/publish/{file_name}'
    #     blob_client = self.consumable_client.get_blob_client(blob_name)
    #     blob_client.upload_blob(df.to_csv(index=False), overwrite=True)
    #     print(f'Published data saved to {blob_name}\n')

    def delete_old_capacity_file(self):
        """
        remove existing capacity file before saving the new one
        """
        PREFIX = f"{self.project_name}/{self.metadata_folder}/"
        blobs_list = self.container_client.list_blobs(name_starts_with=PREFIX)
        for blob in blobs_list:
            if blob.name[len(PREFIX) :].startswith("capacity_") and blob.name[
                len(PREFIX) :
            ].endswith(".csv"):
                self.container_client.delete_blob(blob.name)
                print(f"The old file deleted: {blob.name}")

    def get_latest_date(self, folder_name):
        PREFIX = f"{self.project_name}/{self.input_folder}/{folder_name}/"
        blob_list = self.container_client.list_blobs(name_starts_with=PREFIX)
        date_pattern = re.compile(
            rf"{re.escape(folder_name)}_(\d{{4}}-\d{{2}}-\d{{2}})\.csv"
        )
        dates = []
        for blob in blob_list:
            match = date_pattern.search(blob.name)
            if match:
                date_str = match.group(1)
                date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
                dates.append(date_obj)

        # Return the latest date found in the blob filenames
        return max(dates) if dates else None
