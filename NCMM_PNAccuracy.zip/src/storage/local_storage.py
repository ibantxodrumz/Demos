import os
import pandas as pd


class LocalStorage:

    def __init__(self, base_dir):
        self.base_dir = base_dir

        # get the current script's directory: '/home/azureuser/cloudfiles/code/Users/Yuchang.Wang/NCMM_PNAccuracy/src/storage'
        curr_dir = os.path.dirname(os.path.abspath(__file__))
        # go up two levels to reach root directory of the project: '/home/azureuser/cloudfiles/code/Users/Yuchang.Wang/NCMM_PNAccuracy'
        root_dir = os.path.dirname(os.path.dirname(curr_dir))

        self.metadata_folder = os.path.join(root_dir, self.base_dir, "meta")
        if not os.path.exists(self.metadata_folder):
            os.makedirs(self.metadata_folder, exist_ok=True)

        self.input_folder = os.path.join(root_dir, self.base_dir, "input")
        if not os.path.exists(self.input_folder):
            os.makedirs(self.input_folder, exist_ok=True)

        self.output_folder = os.path.join(root_dir, self.base_dir, "output")
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder, exist_ok=True)

    def read_meta_data(self):
        """
        read bmu_id from metadata_folder
        """
        file_path = os.path.join(self.metadata_folder, f"full_list_of_wind_units.csv")
        df = pd.read_csv(file_path)
        return df

    def read_raw_data(self, endpoint, day):
        """
        read daily file from data/input/endpoint
        """
        file_path = os.path.join(self.input_folder, endpoint, f"{endpoint}_{day}.csv")
        df = pd.read_csv(file_path)
        return df

    def read_combined_file(self, file_name):
        """
        read combined file from data/input/combined
        """
        file_path = os.path.join(self.input_folder, "combined", file_name)
        df = pd.read_csv(file_path)
        return df

    def list_combined_files(self):
        """
        List all file names in data/input/combined folder
        """
        file_path = os.path.join(self.input_folder, "combined")
        list_of_files = os.listdir(file_path)
        return list_of_files

    def save_meta_data(self, df, today):
        """
        save the registered capacity file in the metadata_folder
        """
        file_path = os.path.join(self.metadata_folder, f"capacity_{today}.csv")
        df.to_csv(file_path, index=False)
        print(f"Latest capacity data saved to {file_path}\n")

    def save_raw_data(self, endpoint, day, json_data):
        """
        Save the raw data as a csv file in data/input/endpoint folder
        """
        segments = endpoint.split("/")
        names = ["PN", "MELS", "B1610", "bid", "offer"]
        name = [x for x in names if x in segments][0].upper()
        date_str = day.strftime("%Y-%m-%d")
        ep_path = os.path.join(self.input_folder, name)
        if not os.path.exists(ep_path):
            os.makedirs(ep_path, exist_ok=True)
        file_path = os.path.join(ep_path, f"{name}_{date_str}.csv")
        if endpoint.startswith("datasets"):
            df = pd.DataFrame(json_data)
        else:  # for bid/offer volumes
            df = pd.json_normalize(json_data["data"])
        # it looks like [PN data] from the previous day sp 48 is always included
        # make sure only the queried date is included
        df = df[df["settlementDate"] == date_str]
        df.to_csv(file_path, index=False)
        print(f"Data fetched and saved to {file_path}\n")

    def save_combined_data(self, df, date_str):
        """
        save the combined data by date_str
        """
        # sub folder to store the combined data
        sub_folder = os.path.join(self.input_folder, "combined")
        if not os.path.exists(sub_folder):
            os.makedirs(sub_folder, exist_ok=True)
        file_path = os.path.join(sub_folder, f"combined_{date_str}.csv")
        df.to_csv(file_path, index=False)
        print(f"Combined data saved to {file_path}\n")

    def save_agg(self, df, file_name):
        """
        save the aggregated data in the output_folder/internal
        """
        file_path = os.path.join(self.output_folder, "internal", file_name)
        df.to_csv(file_path, index=False)
        print(f"Aggregated data saved to {file_path}\n")

    def save_publish(self, df, file_name):
        """
        save the published data in the output_folder/publish
        """
        file_path = os.path.join(self.output_folder, "publish", file_name)
        df.to_csv(file_path, index=False)
        print(f"Published data saved to {file_path}\n")

    def delete_old_capacity_file(self):
        """
        remove existing capacity file before saving the new one
        """
        for file in os.listdir(self.metadata_folder):
            if file.startswith("capacity_") and file.endswith(".csv"):
                file_path = os.path.join(self.metadata_folder, file)
                os.remove(file_path)
                print(f"The old file deleted: {file_path}")
