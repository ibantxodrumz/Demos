# This file is used to clean and process the raw data fetched from Elexon API

import pandas as pd

# disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None
import numpy as np

if __name__ == "__main__":
    import utils as utils
else:
    import src.utils as utils

import config

# IMPORT THE APPROPRIATE STORAGE CLASS BASED ON STORAGE_TYPE
if config.STORAGE_TYPE == "azure":
    from src.storage.azure_blob_storage import AzureBlobStorage as Storage
else:
    from src.storage.local_storage import LocalStorage as Storage
from dotenv import load_dotenv


class DataCleaner:
    """
    A class to clean the raw data fetched from Elexon API
    """

    def __init__(self):
        if config.STORAGE_TYPE == "azure":
            self.storage = Storage(
                config.ACCOUNT_URL, config.CONTAINER_NAME, config.PROJECT_NAME
            )
        else:
            self.storage = Storage(config.BASE_DIR)

    def clean_dataset(self, endpoint, day):
        """
        Clean raw data of each endpoint
        """

        @staticmethod
        def clean_data_PN(df):
            # Clean data for PN
            df["timeFrom"] = pd.to_datetime(df["timeFrom"]).dt.tz_localize(None)
            df["timeTo"] = pd.to_datetime(df["timeTo"]).dt.tz_localize(None)
            df["duration_min"] = (
                df["timeTo"] - df["timeFrom"]
            ).dt.total_seconds() / 60  # minutes
            # get the average of PN level for the duration then convert it to MWh
            df["PNLevel"] = (
                ((df["levelFrom"] + df["levelTo"]) / 2)
                * (df["duration_min"] / 30)
                * (1 / 2)
            )
            # group by settlementPeriod
            df_grouped = df.groupby(
                ["nationalGridBmUnit", "settlementDate", "settlementPeriod"],
                as_index=False,
            ).agg(
                {
                    "timeFrom": "min",
                    "timeTo": "max",
                    "PNLevel": "sum",
                    "duration_min": "sum",
                }
            )
            return df_grouped

        @staticmethod
        def clean_data_MEL(df):
            # Clean data for MEL
            df["timeFrom"] = pd.to_datetime(df["timeFrom"]).dt.tz_localize(None)
            df["timeTo"] = pd.to_datetime(df["timeTo"]).dt.tz_localize(None)
            df["duration_min"] = (df["timeTo"] - df["timeFrom"]).dt.total_seconds() / 60
            # get the average of MEL level for the duration then convert it to MWh
            df["MELLevel"] = (
                ((df["levelFrom"] + df["levelTo"]) / 2)
                * (df["duration_min"] / 30)
                * (1 / 2)
            )
            df_grouped = df.groupby(
                ["nationalGridBmUnit", "settlementDate", "settlementPeriod"],
                as_index=False,
            ).agg(
                {
                    "timeFrom": "min",
                    "timeTo": "max",
                    "MELLevel": "sum",
                    "duration_min": "sum",  # some less than 30 min, eg. FFSE02
                }
            )
            return df_grouped

        @staticmethod
        def clean_data_B1610(df):
            # Clean data for Metered Output
            # fill negatvie quantity with 0
            df["quantity"] = np.where(df["quantity"] < 0, 0, df["quantity"])
            df = df[df["quantity"] >= 0]
            # for wind units, metered output >=0 (NOTE Negative values)
            # quantity is in MWh
            cols = [
                "settlementDate",
                "settlementPeriod",
                "nationalGridBmUnitId",
                "quantity",
            ]
            df = df[cols]
            # drop nan in nationalGridBmUnitId
            df = df.dropna(subset=["nationalGridBmUnitId"])
            df = df.rename(
                columns={
                    "nationalGridBmUnitId": "nationalGridBmUnit",
                    "quantity": "Metered",
                }
            )
            return df

        @staticmethod
        def clean_data_BID(df):
            # Clean data for bid volume
            # filter only non-zero bid
            # volume in MWh
            df = df[df["totalVolumeAccepted"] != 0]
            df_grouped = (
                df.groupby(["settlementDate", "settlementPeriod", "nationalGridBmUnit"])
                .agg({"totalVolumeAccepted": "sum"})
                .reset_index()
            )
            df_grouped = df_grouped.rename(columns={"totalVolumeAccepted": "BidVolume"})
            return df_grouped

        @staticmethod
        def clean_data_OFFER(df):
            # Clean data for offer volume
            # filter only non-zero offer
            # volumne in MWh
            df = df[df["totalVolumeAccepted"] != 0]
            df_grouped = (
                df.groupby(["settlementDate", "settlementPeriod", "nationalGridBmUnit"])
                .agg({"totalVolumeAccepted": "sum"})
                .reset_index()
            )
            df_grouped = df_grouped.rename(
                columns={"totalVolumeAccepted": "OfferVolume"}
            )
            return df_grouped

        date_str = day.strftime("%Y-%m-%d")
        df = self.storage.read_raw_data(endpoint, date_str)

        if endpoint == "PN":
            cleaned_df = clean_data_PN(df)
        elif endpoint == "MELS":
            cleaned_df = clean_data_MEL(df)
        elif endpoint == "B1610":
            cleaned_df = clean_data_B1610(df)
        elif endpoint == "BID":
            cleaned_df = clean_data_BID(df)
        elif endpoint == "OFFER":
            cleaned_df = clean_data_OFFER(df)
        else:
            raise ValueError("Invalid endpoint")

        return cleaned_df

    def combine_all(self, dict_cleaned, day):
        """
        combine all parameters
        """
        date_str = day.strftime("%Y-%m-%d")
        pn = dict_cleaned["PN"]
        mel = dict_cleaned["MELS"]
        mo = dict_cleaned["B1610"]
        bid = dict_cleaned["BID"]
        offer = dict_cleaned["OFFER"]

        # 1. merge bid and offer
        df_BOA = pd.merge(
            bid,
            offer,
            on=["settlementDate", "settlementPeriod", "nationalGridBmUnit"],
            how="outer",
        ).reset_index(drop=True)

        # 2. merge pn and mel
        df_pn_mel = pd.merge(
            pn,
            mel,
            on=[
                "nationalGridBmUnit",
                "settlementDate",
                "settlementPeriod",
                "timeFrom",
                "timeTo",
            ],
            suffixes=("_PN", "_MEL"),
            how="outer",
        ).reset_index(drop=True)

        # 3. merge 1 and 2
        df_boa_pn_mel = pd.merge(
            df_pn_mel,
            df_BOA,
            on=["nationalGridBmUnit", "settlementDate", "settlementPeriod"],
            how="outer",
        ).reset_index(drop=True)

        # 4. merge 3 with metered output
        df_boa_pn_mel_mo = pd.merge(
            df_boa_pn_mel,
            mo,
            on=["nationalGridBmUnit", "settlementDate", "settlementPeriod"],
            how="outer",
        ).reset_index(drop=True)

        # 5. merge 4 with bmu id
        df_bmu = utils.get_BMUID()  # wind lookup table
        df_boa_pn_mel_mo_bmu = pd.merge(
            df_boa_pn_mel_mo,
            df_bmu,
            left_on=["nationalGridBmUnit"],
            right_on=["BMU_ID"],
            how="left",
        ).reset_index(drop=True)

        # 6. merge 5 with capacity
        df_capacity = utils.get_capacity()
        df_boa_pn_mel_mo_bmu_cap = pd.merge(
            df_boa_pn_mel_mo_bmu,
            df_capacity,
            left_on=["nationalGridBmUnit"],
            right_on=["registeredResourceName"],
            how="left",
        ).reset_index(drop=True)

        # 6. process the combined dataframe
        ## filter only wind units
        df_processed = df_boa_pn_mel_mo_bmu_cap[
            df_boa_pn_mel_mo_bmu_cap["FUEL_I"] == "WIND"
        ]
        df_processed = df_processed.drop(
            [
                "BMU_ID",
                "registeredResourceName",
                "GEN_ID",
                "CATEGORY",
                "Capacity",
                "GRP_ID",
                "installedCapacity",
                "duration_min_PN",
                "duration_min_MEL",
            ],
            axis=1,
        )

        ## fill nan in pn, bid, offer, metered output as zero
        @staticmethod
        def fillna(df):
            df["PNLevel"] = df["PNLevel"].fillna(0)
            df["BidVolume"] = df["BidVolume"].fillna(0)
            df["OfferVolume"] = df["OfferVolume"].fillna(0)
            df["Metered"] = df["Metered"].fillna(0)
            ## fill nan in timeFrom, timeTo with the existing ones
            df = df.sort_values(by=["timeFrom", "timeTo"], na_position="last")
            datetime_lookup = df.drop_duplicates(
                subset=["settlementDate", "settlementPeriod"], keep="first"
            )
            datetime_lookup = datetime_lookup[
                ["settlementDate", "settlementPeriod", "timeFrom", "timeTo"]
            ]
            merged = df.merge(
                datetime_lookup,
                on=["settlementDate", "settlementPeriod"],
                suffixes=("", "_y"),
            )
            merged["timeFrom"] = merged["timeFrom"].fillna(merged["timeFrom_y"])
            merged["timeTo"] = merged["timeTo"].fillna(merged["timeTo_y"])
            merged = merged.drop(columns=["timeFrom_y", "timeTo_y"])
            return merged

        df_processed = fillna(df_processed)

        ## expected outturn is the minimum of mel and pn+boa,
        ## if mel is nan then it equals to pn+boa
        df_processed["ExpectOT"] = np.where(
            pd.notnull(df_processed["MELLevel"]),
            np.minimum(
                df_processed["MELLevel"],
                df_processed["PNLevel"]
                + df_processed["BidVolume"]
                + df_processed["OfferVolume"],
            ),
            df_processed["PNLevel"]
            + df_processed["BidVolume"]
            + df_processed["OfferVolume"],
        )

        ## calibrate the installed capacity with mel
        df_processed["CapacityCalibrated"] = np.where(
            pd.notnull(df_processed["installedCapacity_mwh"])
            & pd.notnull(
                df_processed["MELLevel"]
            ),  # if both exists, assign the minimum of two
            np.minimum(df_processed["installedCapacity_mwh"], df_processed["MELLevel"]),
            np.where(
                pd.notnull(
                    df_processed["installedCapacity_mwh"]
                ),  # if only one exists, assign the other one
                df_processed["installedCapacity_mwh"],
                np.where(
                    pd.notnull(df_processed["MELLevel"]),
                    df_processed["MELLevel"],
                    np.nan,  # if neither exists, assign as nan
                ),
            ),
        )

        ## calculate Net Error
        df_processed["NetError"] = df_processed["ExpectOT"] - df_processed["Metered"]
        df_processed["ABSError"] = abs(df_processed["NetError"])

        ## calculate the error percentage of capacity
        df_processed["NetError%"] = (
            df_processed["NetError"]
            / (df_processed["CapacityCalibrated"] + 0.001)
            * 100
        )
        df_processed["ABSError%"] = (
            df_processed["ABSError"]
            / (df_processed["CapacityCalibrated"] + 0.001)
            * 100
        )

        # save to input/combined
        self.storage.save_combined_data(df_processed, date_str)


def main():

    # example
    start_date = "2025-02-01"
    end_date = "2025-02-02"

    # load environment variables to specify which storage solution to use
    load_dotenv()

    cleaner = DataCleaner()

    for day in pd.date_range(start=start_date, end=end_date):
        dict_cleaned = {}  # initiate a dict for each day
        for name in ["PN", "MELS", "B1610", "BID", "OFFER"]:
            df = cleaner.clean_dataset(name, day)
            dict_cleaned[name] = df

        # combine all and save to path
        cleaner.combine_all(dict_cleaned, day)


if __name__ == "__main__":
    main()
