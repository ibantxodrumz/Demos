import argparse
from datetime import datetime, timedelta
from azure.ai.ml import MLClient
from azure.ai.ml.dsl import pipeline
from azure.ai.ml.entities import (
    Environment,
    CommandComponent,
    CronTrigger,
    JobSchedule,
    PipelineJobSettings,
)
from azure.identity import ManagedIdentityCredential


def main():

    parser = argparse.ArgumentParser(
        description="Configure and register an AML environment, component, and scheduled job."
    )

    parser.add_argument("--environment", type=str, default="pn-accuracy")
    parser.add_argument("--subscription_id", type=str, default="126945b8-057f-40a8-b55d-8ab1723a522e")
    parser.add_argument("--resource_group", type=str, default="rg-aae-ncmm-fof-uks-01")
    parser.add_argument("--workspace", type=str, default="mlw-aae-ncmm-fof-uks-01")
    parser.add_argument("--compute_name", type=str, default="compclust-ncmm-01")

    args = parser.parse_args()

    ml_client = MLClient(
        ManagedIdentityCredential(),
        args.subscription_id,
        args.resource_group,
        args.workspace,
    )

    env = Environment(
        image="mcr.microsoft.com/azureml/openmpi4.1.0-ubuntu20.04:latest",
        conda_file="setup/conda.yaml",
        name=args.environment,
    )

    registered_env = ml_client.environments.create_or_update(env)

    compute_target = ml_client.compute.get(args.compute_name)

    def create_pipeline_job(days_offset):

        start_date = (datetime.now() - timedelta(days=days_offset)).strftime("%Y-%m-%d")
        end_date = start_date

        component = CommandComponent(
            # ✅ FIX: replace '-' with '_' to comply with AML naming rules
            name=f"run_pipeline_{days_offset}_days_{args.environment.lower().replace('-', '_')}",
            command=f"python -u NCMM_PNAccuracy/main.py --start-date {start_date} --end-date {end_date}",
            environment=f"{registered_env.name}:{registered_env.version}",
            code="..",
            is_deterministic=False,
        )

        registered_component = ml_client.components.create_or_update(component)

        @pipeline(default_compute=compute_target.name)
        def daily_pipeline():
            step = registered_component()
            step.compute = compute_target.name
            return step

        pipeline_job = daily_pipeline()

        pipeline_job.settings = PipelineJobSettings(
            max_retries=5,
            retry_interval=timedelta(hours=3),
        )

        cron_trigger = CronTrigger(
            expression="30 14 * * *"
        )

        job_schedule = JobSchedule(
            name=f"{args.environment}-schedule-D-{days_offset}",
            trigger=cron_trigger,
            create_job=pipeline_job,
        )

        ml_client.schedules.begin_create_or_update(job_schedule).result()

        print(f"Scheduled pipeline: {job_schedule.name}")

    create_pipeline_job(10)
    create_pipeline_job(35)
    create_pipeline_job(70)
    create_pipeline_job(100)


if __name__ == "__main__":
    main()
