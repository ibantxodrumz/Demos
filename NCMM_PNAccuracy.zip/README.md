# Introduction 
This project provides tools for fetching, cleaning, and aggregating data from Elexon to produce PN Accuracy metrics and storing it either in local directory or in Azure Blob Storage.

# Getting Started
1.	Installation process

```bash
git clone https://NGRID@dev.azure.com/NGRID/ESO-DAP-AAEs/_git/NCMM_PNAccuracy
```


2.	Prerequisites

- Python 3.12 or higher
- Azure account (Azure Dev Ops and Azure ML)

3. Create a conda environment in Azure

- First, start the compute instance assigned to you
- Go to `terminal` of your compute
- `az login` if needed
- In the project root directory, to create a conda environment:

    ```bash
    conda env create -f setup/conda.yaml
    ```

4.	Latest releases

Latest stable version is in the `develop` branch, which is used for deployment. Active changes are being made in the `feature/your-feature-name`, for example. Once these changes are ready, they should be merged into the `develop` via a pull request. 

The `main` branch is updated periodically to maintain the structure and is used for production only when necessary.


# Running the Program 
1. Environment Variables

To switch between storing data in a local directory or Azure Blob Storage, you need to configure the environment variables in `.env` file, located in the root directory of the project. Uncomment the appropriate lines based on your storage choice. By default, the configuration is set to use Azure Blob Storage.

Example `.env` for Azure Blob Storage:

```bash
STORAGE_TYPE = azure
ACCOUNT_URL = https://{storage_account_name}.blob.core.windows.net
CONTAINER_NAME = datalake
PROJECT_NAME = pn-accuracy
```

Example `.env` for Local Storage:

```bash
STORAGE_TYPE = local
```

2. Configuration

You might have noticed the `config.py` file. This file reads the environment variables and sets the configuration accordingly. It also prints the values to verify that they are loaded correctly. 

3. Running the program

The `main.py` script loads the environment variables from the `.env` file, applies the configuration, and runs the data fetching, cleaning, and aggregation processes. You need to provide a start date and an end date as input parameters.

Example command: 

```bash
conda activate py312

python main.py --start-date YYYY-MM-DD --end-date YYYY-MM-DD
```

Data Storage:

- Azure Blob Storage: 
    - Input data is saved to `datalake/project_name/input/`
    - Metadata is saved to `datalake/project_name/meta/`
    - Output data is saved to `consumable/project_name/`
- Local Storage:
    - Input data is saved to `project_name/data/input/`
    - Metadata is saved to `project_name/data/meta/`
    - Output data is saved to `project_name/data/output/`

# AML Pipeline and CI/CD

This project configures and registers multiple automated pipelines in Azure Machine Learning (AML) to manage and execute tasks efficiently. These pipelines are designed to run jobs at specified intervals, ensuring timely data processing.

## Pipeline Setup

1. **Environment Configuration**:  
   The process begins by defining the computing environment, which includes all necessary dependencies specified in a Conda environment file. This environment is registered within AML, providing a consistent setup for running tasks.

2. **Component Registration**:  
   For each pipeline, a command component is created. This component specifies the execution command for the machine learning task, including any necessary parameters such as start and end dates for data processing. This component is then registered with AML.

3. **Pipeline Definition**:  
   Each pipeline is defined to run the registered component on a selected compute target. The compute target is chosen from available resources that match specific criteria.

4. **Scheduling**:  
   The pipelines are scheduled to run automatically at specified times using Cron expressions. Four separate pipelines are created to handle data processing for different historical data ranges (D-10, D-35, D-70, and D-100 days), that align with Elexon Settlement Calendar to ensure settlement metering data is updated. Each pipeline is set to retry up to five times with a three-hour interval between retries to ensure robust execution.

These automated pipelines streamline the workflow by reducing manual intervention and ensuring consistent execution of tasks over time.

## CI/CD Pipeline

This section provides an overview of the Continuous Integration and Continuous Deployment (CI/CD) pipeline configuration used for managing the Azure Machine Learning (AML) pipelines.

### Pipeline Triggers

- **Branch Triggers**: 
  - The pipeline is triggered for any changes in all branches.
  
- **Pull Request Triggers**:
  - Automatically triggered for pull requests made to the `main` and `develop` branches.

### Build Pool

- The pipeline uses an agent pool named `ado-linux-uk-agent` to execute jobs on a Linux environment.

### Variables

- **projectName**: Name of the project, set to `ESO_DAP_NCMM_PNAccuracy`.
- **deployTarget**: Determines the deployment target environment based on the branch:
  - `PROD` for the `main` branch.
  - `FOF` for the `develop` branch.
  - `DEV` for all other branches.
- **Environment Specific Variables**: Loaded from a template file based on the `deployTarget`.

### Resources

- **Repositories**:
  - Includes a Git repository named `ddtd_dev_ops_tests` from the `ESO-DAP-AAEs` project, specifically the `develop` branch.

### Stages

#### Stage 1: Setup

- Uses a template `azure-pipelines_python.yml` to set up the Python environment.
- Parameters include project name and backend package manager (`pip`).

#### Stage 2: Create ADO Tasks

- **Display Name**: 'Create ADO tasks'
- **Dependencies**: Depends on the completion of a previous stage named `Code_Scanning_${{ variables.projectName }}`.
- **Jobs**:
  - **Job: Create_pipeline**:
    - **Display Name**: 'Create AML pipelines'
    - **Steps**:
      1. **Install Dependencies**:
         - Installs Python and necessary Azure packages (`azure-ai-ml`, `azure-identity`) using a script.
      2. **Register AML Pipeline**:
         - Uses the `AzureCLI@2` task to run a Python script `register_aml_job.py` that registers AML pipelines.
         - Conditional Execution:
           - Runs only if the build is successful.
           - Applicable for changes in `main` or `develop` branches.
           - Triggered by an individual Continuous Integration (CI) event.

This CI/CD pipeline automates the process of setting up environments, managing dependencies, and registering Azure Machine Learning pipelines, ensuring efficient development and deployment workflows.


# Contribute

If you would like to contribute, create a `feature` branch off the `develop` branch and make all necessary changes. Once your changes are ready, merge them into develop via a pull request.

Example command:

```bash
# Step 1: ensure you are on the develop branch
git checkout develop

# Step 2: pull the latest changes from the remote repository
git pull origin develop

# Step 3: create and checkout a new feature branch
git checkout -b feature/your-feature-name

# Step 4: push the new feature branch to the remote repository
git push -u origin feature/your-feature-name
```

