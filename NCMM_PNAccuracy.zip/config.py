import os

## define environment variable to allow switching between local and azure storage

# to retrieve environment variables defined in .env, if the variable is not found, the default value is returned instead.
STORAGE_TYPE = os.getenv("STORAGE_TYPE", "azure")
print(f"STORAGE_TYPE: {STORAGE_TYPE}")

if STORAGE_TYPE == "azure":
    ACCOUNT_URL = os.getenv(
        "ACCOUNT_URL", "https://dlaaencmmdsffuks01.blob.core.windows.net/"
    )
    print(f"ACCOUNT_URL: {ACCOUNT_URL}")
    CONTAINER_NAME = os.getenv("CONTAINER_NAME", "datalake")
    print(f"CONTAINER_NAME: {CONTAINER_NAME}")
    PROJECT_NAME = os.getenv("PROJECT_NAME", "pn-accuracy")
    print(f"PROJECT_NAME: {PROJECT_NAME}")
else:
    BASE_DIR = "data"
    print(f"BASE_DIR: {BASE_DIR}")
