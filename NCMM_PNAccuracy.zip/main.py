# This file is the main entry point for the project and is used to run the data pipeline

import argparse
from datetime import datetime, timedelta
import urllib3
from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single InsecureRequestWarning from urllib3
urllib3.disable_warnings(InsecureRequestWarning)

from dotenv import load_dotenv

# load environment variables from .env file
load_dotenv()

from src.fetch_data import DataFetcher
from src.clean_data import DataCleaner
from src.agg_data import DataAggregator
from src.utils import get_latest_date_from_blob
import pandas as pd
import time

# disable SettingWithCopyWarning
pd.options.mode.chained_assignment = None


def main(start_date, end_date):
    # specify the base url
    base_url = "https://data.elexon.co.uk/bmrs/api/v1/"

    # define dictionary for endpoints
    dict_ep = {
        "PN_ep": "datasets/PN/stream",
        "MELS_ep": "datasets/MELS/stream",
        "B1610_ep": "datasets/B1610/stream",  # metered output
        "BID_ep": "balancing/settlement/acceptance/volumes/all/bid",  # volume of accepted bids
        "OFFER_ep": "balancing/settlement/acceptance/volumes/all/offer",  # volume of accepted offers
    }

    fetcher = DataFetcher(base_url)
    cleaner = DataCleaner()

    for day in pd.date_range(start=start_date, end=end_date):
        ####### fetch and save the raw data by day #######
        for ep in dict_ep.keys():
            fetcher.fetch_data(dict_ep[ep], day)

        ####### clean and save the processed day by day #######
        dict_cleaned = {}  # initiate a dict for each day
        for name in [key.split("_")[0] for key in dict_ep.keys()]:
            df = cleaner.clean_dataset(name, day)
            dict_cleaned[name] = df
        # combine all and save to path
        cleaner.combine_all(dict_cleaned, day)

        # sleep for 0.1 second to avoid rate limiting
        time.sleep(0.1)

    ####### aggregate metrics and save to output #######
    aggregator = DataAggregator()
    # only aggregate the newly fetched data
    aggregator.cal_agg(start_date, end_date)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PN Accuracy Processing")
    parser.add_argument(
        "--start-date",
        type=str,
        default=(datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
        help="Start date in YYYY-MM-DD format",
    )
    parser.add_argument(
        "--end-date",
        type=str,
        default=(datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
        help="End date in YYYY-MM-DD format",
    )
    args = parser.parse_args()

    # Get the latest date from blob storage
    latest_date = get_latest_date_from_blob(folder_name="combined")
    current_default_start_date = args.start_date

    if latest_date:
        if (
            latest_date + timedelta(days=1)
            < datetime.strptime(current_default_start_date, "%Y-%m-%d").date()
        ):
            args.start_date = (latest_date + timedelta(days=1)).strftime("%Y-%m-%d")
        else:
            args.start_date = current_default_start_date
    else:
        args.start_date = current_default_start_date

    s = time.time()
    print(f"For period {args.start_date} to {args.end_date}")

    main(args.start_date, args.end_date)
    #print(f"Current execution time: {datetime.now().strftime("%d-%b-%Y %H:%M")}")
    e = time.time()
    duration = round((e - s) / 60, 1)
    print(f"Time elapsed: {duration} minutes.")
