import os
import sys

# Windows 11 & cross-platform wrapper launcher for pn_accuracy_dashboard.py -> app.py
current_dir = os.path.dirname(os.path.abspath(__file__))
target_script = os.path.join(current_dir, "app.py")

with open(target_script, "r", encoding="utf-8") as f:
    code = f.read()

exec(compile(code, target_script, "exec"), {"__name__": "__main__", "__file__": target_script})
