# Development Log — Market Monitoring: PN Accuracy Dashboard (Release 4)

**Date**: 19 October 2026  
**Project**: Market Monitoring — Physical Notification (PN) Accuracy Dashboard  
**Release**: `release_4_azure`  
**Target Environments**: Windows (Enterprise Azure Blob Storage) & macOS/Local (Offline / Local Fallback)

---

## 1. Executive Summary of Changes

Today's development focused on upgrading the Physical Notification (PN) Accuracy Dashboard from Release 3 to Release 4. Key objectives achieved:
1. **Azure & Local Fallback Architecture**: Enabled seamless local and offline execution without breaking enterprise Azure Blob Storage authentication on Windows machines.
2. **Corporate Visual Design**: Aligned UI styling with NESO brand guidelines (plum `#400732`, raspberry accent `#d02670`, warm cards, custom top navbar, and embedded logo).
3. **Tab Streamlining**: Reduced and clarified the dashboard tabs from 10 tabs to 8 focused, text-only tabs.
4. **BMU Explorer Enhancement**: Implemented search and filter controls with dedicated Search and Reset buttons.
5. **Fuel-Specific Attention Thresholds**: Implemented exact business rules for flagging BMUs needing operational attention.
6. **Environment Resilience & VS Code Compatibility**: Guarded against missing Azure libraries on non-configured environments and added a root launcher for VS Code terminals.

---

## 2. Detailed Technical Breakdown

### 2.1 Azure & Local Data Fallback System
* **Context**: In Release 3, running the dashboard on a laptop without Azure credentials configured immediately raised an uncaught exception (`Azure Loading Error`), halting execution (`st.stop()`).
* **Implementation in Release 4**:
  * **Data Source Selector**: Added a sidebar radio button offering:
    1. `Azure Blob Storage`: Connects to `aaeffuksaaencmmdsdl01.blob.core.windows.net/datalake/pn-accuracy-2025/internal/`.
    2. `Local (inputs/ folder)`: Reads bundled `annual_summary_2025.csv` and `monthly_summary_2025.csv`.
    3. `Manual Upload (CSV)`: Allows dragging-and-dropping custom CSV files.
  * **Automatic Fallback (`auto_fallback=True`)**: If Azure connection fails (due to missing CLI, unconfigured credentials, or network errors), the dashboard catches the exception, displays an informative notice banner, and automatically loads local data from `inputs/`.
  * **Optional CSV Override**: Users running in local mode can optionally upload one or both CSVs via an expander to override the default local files.
  * **Import Protection**: Guarded `azure.storage.blob` and `azure.identity` in `azure_blob_helper.py` with `try...except ImportError` so Python environments lacking the Azure SDK do not crash on startup.
  * **Windows & POSIX Azure CLI Detection**: Added cross-platform checking for `az`, `az.cmd`, `az.bat`, `az.exe`, and standard Windows SDK paths (`C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd`).

### 2.2 Corporate Visual Design & Typography
* **Branding & Top Bar**:
  * Clean top navigation bar with the NESO logo, title (`Market Monitoring`), subtitle (`PN Accuracy Dashboard`), and an environment status badge.
  * Removed all extraneous clutter, including mentions of `'OPERATIONAL DECISION WORKSPACE'`, `'Release 4'`, and generic placeholder subtitles.
* **Color Palette & Cards**:
  * Primary Plum: `#400732`
  * Accent Raspberry: `#d02670`
  * Neutral Canvas: `#fcfafc`
  * Card Border: `#edd8e8` with light box shadows (`rgba(64, 7, 50, 0.04)`).
  * KPI metric cards redesigned with top-accent colored border, clear bold metrics, and status badges.
* **Plotly Chart Standardization**:
  * Integrated `force_light_chart()` helper to apply corporate fonts, light gridlines (`#f3e8f1`), and plum axis labels to all Plotly figures.

### 2.3 Tab Structure & Simplification
* Removed tab pill icons/emojis across all tabs for a cleaner, corporate aesthetic.
* Removed redundant tabs:
  * Removed **P90 Error** tab.
  * Removed **Fleet: Distribution** tab.
* Standardized to **8 core tabs**:
  1. `Executive Summary`
  2. `Median Error`
  3. `Total GWh Error`
  4. `Fleet: Capacity`
  5. `By Technology`
  6. `BMU Explorer`
  7. `Require Attention`
  8. `Exports`

### 2.4 BMU Explorer Improvements
* **Search & Filter Controls**:
  * Added text search box (`st.text_input("Search BMU Code / Name")`).
  * Added **Search** and **Reset** buttons to allow users to filter down the BMU dropdown quickly (e.g., typing `ABER` filters directly to Aberthaw units).
* **Selection State Stability**:
  * Bound the selectbox to `st.session_state["bmu_active_picker_selectbox"]` to prevent accidental resets during reruns.
* **Profile Charts**:
  * Detailed KPI cards for the selected unit (Fuel, Annual Generation, Error %, Absolute GWh Error).
  * 12-month bar chart displaying Monthly PN Absolute Error (GWh).
  * 12-month line chart displaying Monthly Net Error (%) with 0% reference benchmark.

### 2.5 Fuel-Specific "Require Attention" Business Rules
* Updated data processing logic to flag BMUs based on specific fuel technology thresholds:
  * **Wind & Solar**:
    * Net Error outside `[-3.0%, +3.0%]` OR Absolute Error `≥ 9.4%`.
  * **All Other Fuels** (CCGT, Nuclear, Biomass, Hydro, Storage, Other, etc.):
    * Net Error outside `[-1.0%, +1.0%]` OR Absolute Error `≥ 2.6%`.
* Added detailed reason tagging in the dataset (e.g., `Net Error -100.00% (outside ±1%); ABS Error 100.00% (≥ 2.6%)`).
* Dedicated **Require Attention** tab features:
  * High-level summary metrics (Total Flagged BMUs, Fleet Impact %).
  * Fuel breakdown bar chart and distribution table.
  * Searchable and filterable data table of flagged units with the exact violation reason.
  * One-click CSV export: `flagged_bmus_require_attention.csv`.

### 2.6 VS Code Launch Compatibility
* Created workspace root `app.py` launcher (`/Users/ivansanz/Desktop/PN_streamlit/app.py`).
* Allows developers and analysts to run `streamlit run app.py` directly from the VS Code terminal regardless of whether their terminal CWD is the project root or the `release_4_azure/` folder.

---

## 3. Files Created or Modified

| File Path | Description of Changes |
| :--- | :--- |
| `release_4_azure/app.py` | Core dashboard application with 8 tabs, fallback handling, BMU search, and fuel thresholds. |
| `release_4_azure/azure_blob_helper.py` | Azure authentication helper with guarded imports and cross-platform CLI checks. |
| `release_4_azure/constants.py` | Project constants, default file names, and Azure container URLs. |
| `release_4_azure/inputs/annual_summary_2025.csv` | Bundled local fallback data for annual summary. |
| `release_4_azure/inputs/monthly_summary_2025.csv` | Bundled local fallback data for monthly summary. |
| `release_4_azure/neso_logo.png` | Corporate logo used in top navbar and sidebar. |
| `app.py` (Workspace Root) | Root launcher to invoke `release_4_azure/app.py` seamlessly from root terminal. |
| `release_4_azure/development_log.md` | Comprehensive log of architecture and design updates. |

---

## 4. Verification & Testing

* **macOS (Without Azure SDK / Offline)**:
  * Verified that launching in conda env `dashboard` (where `azure` is not installed) does not crash.
  * Verified automatic fallback displays local data with notice banner.
  * Verified BMU search filtering and monthly error charts.
  * Verified "Require Attention" tab accurately filters 559 flagged BMUs meeting the fuel-specific thresholds.
* **Root Launcher**:
  * Verified that running `streamlit run app.py` from `/Users/ivansanz/Desktop/PN_streamlit` cleanly starts Release 4.

---

## 5. Upcoming Testing on Windows Machines

* **Objective**: Test Release 4 on Windows enterprise machines equipped with corporate Azure credentials / Azure CLI (`az login`).
* **Expected Behavior**:
  1. The app detects Windows Azure CLI (`az.cmd` / `DefaultAzureCredential`).
  2. Data is directly streamed from Azure Blob Storage (`datalake/pn-accuracy-2025/internal/`).
  3. Status indicator displays `Azure Data Loaded Successfully`.
  4. If run without VPN or credentials, it gracefully falls back to the bundled `inputs/` folder.

---

## 6. Multi-Year Selection Support (20 October 2026)

* **Objective**: Enable switching between data years (e.g., 2025, 2026) in both Azure and local modes.
* **Architecture**:
  * Azure Pattern A: Formats blob paths dynamically as `pn-accuracy-{year}/internal/annual_summary_{year}.csv` and `monthly_summary_{year}.csv`.
  * Predefined Year Registry: Configured in `constants.py` via `AVAILABLE_YEARS = [2025, 2026]` and `DEFAULT_YEAR = 2025`.
  * Dynamic Local Detection: Scans `inputs/` for `annual_summary_{year}.csv` and `monthly_summary_{year}.csv`. If absent (e.g. 2026 offline before files are populated), displays clear guidance and allows manual CSV upload.
  * Downstream UI Alignment: Executive summary review badge, processed dataframe `Year` column, and all CSV export filenames dynamically incorporate the chosen year.
* **Verification**:
  * Unit test verified blob path construction for both 2025 and 2026.
  * Verified `process_data` correctly populates `df_annual['Year']` to the selected year.

---

## 7. Guardian Regression Test Suite & Release Gate (20 October 2026)

* **Objective**: Implement a self-contained, offline-compatible guardian test suite adhering to the *"Tests Are Guardians, Not Obstacles"* principle in `GEMINI.md`.
* **Test Architecture** (`tests/` directory):
  * `test_business_rules.py` (13 tests): Wind/Solar thresholds (±3% net, 9.4% ABS), thermal thresholds (±1% net, 2.6% ABS), reason formatting, and 5-tier error banding.
  * `test_data_processing.py` (5 tests): Multi-year stamping, schema coercion, NaN handling, monthly date parsing, and P90 error aggregation.
  * `test_azure_and_fallback.py` (5 tests): Dynamic multi-year blob URL resolution, constants verification, and local fallback locator.
  * `test_baseline_invariants.py` (7 tests): Regression audit against canonical 2025 dataset (1,449 units, 14,237 monthly records, exactly 559 flagged attention units).
  * `run_tests.py`: Single-command runner exiting with `0` on success, `1` on failure.
* **Execution Evidence**:
  * 30 tests executed across all 4 suites.
  * Execution time: 0.31 seconds.
  * Result: 30 Passed, 0 Failures, 0 Errors.

---

## 8. Release 4 Handover & Operational Status (20 October 2026)

* **Current Status**: Milestone Release 4 is complete, tested, and packaged.
* **Key Artifacts Generated**:
  1. `AGENTS.md`: Mandatory operational rules requiring all future releases to be validated on Windows 11 using Conda and VS Code, with pre-release test gates enforced.
  2. `release_4_azure.zip` (728 KB): Fully self-contained archive verified by sandbox unpack and 30-test execution pass.
  3. `tests/`: 4 guardian test suites (`test_business_rules.py`, `test_data_processing.py`, `test_azure_and_fallback.py`, `test_baseline_invariants.py`, `run_tests.py`) mirrored in both workspace root and `release_4_azure/tests/`.
  4. `README.md`: End-to-end Windows 11 execution guide for Conda and VS Code with corporate Azure authentication (`az login`) and offline modes.
* **Pending Actions / Ready for Feedback**:
  * User validation on enterprise Windows 11 machine with active Azure corporate credentials.
  * Analyst review of multi-year switching and operational queues.



