import os
import shutil
import pandas as pd
from io import BytesIO

try:
    from azure.storage.blob import BlobServiceClient
    from azure.identity import AzureCliCredential, DefaultAzureCredential
    AZURE_PACKAGES_AVAILABLE = True
except ImportError:
    AZURE_PACKAGES_AVAILABLE = False
    BlobServiceClient = None
    AzureCliCredential = None
    DefaultAzureCredential = None


class AzureBlobStorage:
    def __init__(self, account_url, container_name, project_name):
        self.account_url = account_url
        self.container_name = container_name
        self.project_name = project_name
        self._container_client = None

    def _get_container_client(self):
        if self._container_client is not None:
            return self._container_client

        if not AZURE_PACKAGES_AVAILABLE:
            raise RuntimeError(
                "Azure SDK packages ('azure-storage-blob' and 'azure-identity') are not installed in this Python environment."
            )

        # Check for connection string in environment
        conn_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        if conn_str:
            self._container_client = BlobServiceClient.from_connection_string(
                conn_str
            ).get_container_client(self.container_name)
            return self._container_client

        # Check if Azure CLI is installed (handling both Windows 'az.cmd' / 'az.exe' and POSIX 'az')
        has_az_cli = bool(
            shutil.which("az")
            or shutil.which("az.cmd")
            or shutil.which("az.bat")
            or shutil.which("az.exe")
        )
        if not has_az_cli and os.name == "nt":
            common_windows_paths = [
                r"C:\Program Files\Microsoft SDKs\Azure\CLI2\wbin\az.cmd",
                r"C:\Program Files (x86)\Microsoft SDKs\Azure\CLI2\wbin\az.cmd",
            ]
            has_az_cli = any(os.path.exists(p) for p in common_windows_paths)

        has_env_creds = bool(
            os.getenv("AZURE_CLIENT_ID")
            and os.getenv("AZURE_TENANT_ID")
            and os.getenv("AZURE_CLIENT_SECRET")
        )

        if not has_az_cli and not has_env_creds:
            raise RuntimeError(
                "Azure CLI ('az') is not installed or configured on this machine, "
                "and no Azure environment credentials were found."
            )

        try:
            credential = AzureCliCredential() if has_az_cli else DefaultAzureCredential()
            self._container_client = BlobServiceClient(
                self.account_url, credential=credential
            ).get_container_client(self.container_name)
            return self._container_client
        except Exception as e:
            raise RuntimeError(f"Azure authentication setup failed: {str(e)}")

    def _read_csv(self, blob_path: str) -> pd.DataFrame:
        container_client = self._get_container_client()
        blob_client = container_client.get_blob_client(blob_path)
        data = blob_client.download_blob().readall()
        return pd.read_csv(BytesIO(data))

    def read_annual_summary(self, year: int = 2025) -> pd.DataFrame:
        project_folder = (
            f"{self.project_name}-{year}"
            if not self.project_name.endswith(f"-{year}")
            else self.project_name
        )
        return self._read_csv(f"{project_folder}/internal/annual_summary_{year}.csv")

    def read_monthly_summary(self, year: int = 2025) -> pd.DataFrame:
        project_folder = (
            f"{self.project_name}-{year}"
            if not self.project_name.endswith(f"-{year}")
            else self.project_name
        )
        return self._read_csv(f"{project_folder}/internal/monthly_summary_{year}.csv")
