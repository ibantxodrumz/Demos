# Proposal: PN Error Cost Dashboard

**Author:** Senior Data Scientist
**Date:** 2026-02-08
**Context:** Estimating the financial impact of PN errors using existing volume data.

---

## 1. The Challenge (Data Limitations)
Our current input files (`annual_summary_2025.csv`, `monthly_summary_2025.csv`) contain **Volumes (MWh)** but not **Prices (£/MWh)**.
In the Balancing Mechanism, the cost of an error typically depends on the **Imbalance Price** (System Buy/Sell Price) at that specific hour.

*   **Shortfall (Under-Gen)**: You pay System Buy Price (High).
*   **Surplus (Over-Gen)**: You receive System Sell Price (Low).

**Without hourly price data, we cannot calculate the exact accounting cost.**

## 2. Phase 1: The "Value Leakage" Proxy (Immediate Solution)
Since we cannot calculate exact settlement figures today, I propose we model the **"Value Leakage"** or **Opportunity Cost** using a standardized **Penalty Spread**.

### The Formula
$$ \text{Estimated Loss (£)} = \text{Total ABS Error (MWh)} \times \text{Average Penalty Spread (£/MWh)} $$

*   **Average Penalty Spread**: A proxy value representing the typical cost of being "wrong".
    *   *Example*: If the market usually penalizes you £30/MWh for being out of balance, we apply this uniformly.
    *   **User Input**: We will allow the user to adjust this "Sensitivity Factor" (e.g., Low: £10, Med: £30, High: £50).

### Why this works
*   It highlights **relative financial risk**. A unit with huge errors is risky regardless of the specific hourly price.
*   It allows **"What-If" Analysis**. "If imbalance prices spike next year, how much will this poor accuracy cost us?"

---

## 3. Dashboard Design (Concept)

**Title:** 💷 PN Impact: Financial Analysis

### Tab 1: Financial Executive Summary
*   **Headline KPIs**:
    *   **Total Estimated Value Leakage (£)**: The big number.
    *   **Avg Cost per Active Day (£)**.
    *   **Worst Month (£)**.
*   **Scenario Slider**: "Assumed Penalty Spread (£/MWh)" [Slider: £0 - £100]. Moving this updates all numbers instantly.

### Tab 2: Cost Drivers (The "Pareto" View)
*   **Chart**: **Treemap of Value Leakage**.
    *   **Size of Box**: Estimated Cost (£).
    *   **Color**: Fuel Type.
    *   *Insight*: Instantly see if 80% of your financial loss comes from just 3 massive Coal units.
*   **Table**: "The Million-Pound Club". List of BMUs with >£1M estimated loss.

### Tab 3: Fuel Type Economics
*   **Scatter Plot**: **Efficiency vs. Cost**.
    *   X-Axis: Annual Error % (Accuracy).
    *   Y-Axis: Total Estimated Cost (Financial Impact).
    *   *Insight*: Identify "Expensive Errors" (High Cost, Low Accuracy) vs. "Cheap Errors" (Low Cost, Low Accuracy - maybe smaller units).

### Tab 4: Fleet Comparison
*   **Bar Chart**: **Cost per Installed MW (£/MW)**.
    *   Normalizes cost by size. Identifying small units that are disproportionately expensive to run due to fines.

---

## 4. Phase 2: "Precision Model" Requirements (Future State)
To move from *Estimated Risk* to *Accounting-Grade Cost*, we would need:

1.  **Granularity**: 
    *   **30-min Settlement Period (SP) Data**: We cannot use Annual/Monthly aggregates. Prices change every 30 mins.
    *   **System State**: Was the system Long or Short in that period? (Determines which price applies).

2.  **Price Data**:
    *   **System Buy Price (SBP)**: The price you pay if you are short (under-generated).
    *   **System Sell Price (SSP)**: The price you receive if you are long (over-generated).
    *   *Note*: While "Offer/Bid" data builds these prices, for settlement we specifically need the final **Cash-Out Prices** (SBP/SSP).

3.  **Calculation Logic**:
    *   If `NetError` < 0 (Short) AND System is Short: **Pay SBP**.
    *   If `NetError` > 0 (Long) AND System is Long: **Receive SSP**.
    *   *System Benefit*: Sometimes your error helps the system! (e.g., You go Long when System is Short). In these cases, you might not be penalized.

**Data Gap**: Our current dataset lacks `Price` and `SystemLength` columns.
