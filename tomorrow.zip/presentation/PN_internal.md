# PN Accuracy Dashboard Guide (Internal Technical)

## 🛠 Dashboard Architecture & Logic

This document details the technical implementation, data sources, and calculation logic of the `pn_accuracy_dashboard.py` application.

---

## 📂 Data Inputs

| Source File | Description | Frequency | Key Columns Used |
| :--- | :--- | :--- | :--- |
| `annual_summary_2025.csv` | Aggregated annual statistics per BMU. | Annual | `A_ABS_NetError%`, `ABSError`, `NetError`, `CapacityCalibrated` |
| `monthly_summary_2025.csv` | Monthly granularity per BMU. | Monthly | `M_ABS_NetError%`, `year_month` |

### ⚠️ Data Handling Notes
*   **Missing Values**: Numeric columns are coerced; NaNs are filled with `0`.
*   **Date Parsing**: `year_month` (e.g., "2025-1") is parsed to `YYYY-MM-DD` for time-series plotting.

---

## 🧮 Metric Calculations

### 1. Normalization
*   **Field**: `A_ABS_NetError%`
*   **Logic**: Pre-calculated in source CSV. 
*   **Check**: Ensure this value is $\frac{\mid Expected - Metered \mid}{\text{Capacity}}$. The dashboard assumes this normalization is already applied.

### 2. Size Categorization (`add_size_category`)
Logic to bucket BMUs based on size:
1.  **Basis**: Uses `installedCapacity_mwh` if available (>0). Fallback to `CapacityCalibrated`.
2.  **Thresholds**:
    *   **Small**: < 50 MW
    *   **Medium**: 50 - 100 MW
    *   **Large**: > 100 MW

### 3. Net Error Direction
*   **Field**: `NetError` (GWh)
*   **Formula**: `Expected (PN) - Metered`
*   **Interpretation**:
    *   **Positive (>0)**: Over-Forecast (Generated LESS than expected).
    *   **Negative (<0)**: Under-Forecast (Generated MORE than expected).

### 4. "Needs Attention" Logic
A unit is flagged if it breaches **EITHER** of these conditions:
1.  `A_ABS_NetError%` >= 25.0% (Annual Average)
2.  `P90_monthly_error` >= 25.0% (Monthly Risk)

---

## 📊 Tab-Specific Technical Details

### Tab 1: Executive Summary
*   **Fleet Median**: Calculated as `df["A_ABS_NetError%"].median()`. *Do not average the averages.*
*   **Combined Table**: Aggregates by `Fuel` using `groupby().agg()` with functions: `median`, `quantile(0.9)`, and `sum`.

### Tab 2: Fleet Overview
*   **Error Bands**: Hardcoded bins: `0-1%`, `1-2%`, `2-4%`, `4-10%`, `>10%`.
*   **Bubble Chart**: 
    *   **Size**: `SizeBasis_Abs` (Absolute value of capacity) to prevent negative size errors in Plotly.
    *   **Log Scale**: Applied to X-Axis only.

### Tab 3: By Technology
*   **Filtering**: Affects both Annual and Monthly dataframes based on `Fuel` selection.
*   **Histograms (Tabbed)**:
    *   **Efficiency Tab**: Annual Error histogram. Fixed range `[0, 100]`.
    *   **Bias Tab**: Net Error histogram. Auto-ranged (shows negative values).

### Tab 5: Attention Needed
*   **Filtering**: `df[df["NeedsAttention"] == True]`
*   **Reason Generation**: Dynamic lambda function concatenates the reasons for the flag (e.g., "Annual Error > 25%").

---

## 🔄 Maintenance & Updates

### Updating Data
1.  Place new CSVs in `inputs/` folder.
2.  Update `default_annual_path` / `default_monthly_path` in `pn_accuracy_dashboard.py` if filenames change.
3.  Restart Streamlit server.

### Modifying Thresholds
*   **Attention Threshold**: Edit lines ~264 in `load_data()` function.
*   **Size Categories**: Edit `add_size_category()` function.
