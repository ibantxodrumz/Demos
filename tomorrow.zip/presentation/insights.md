# Executive Insights: PN Accuracy 2025

**Role:** Senior Data Scientist Review
**Date:** 2026-02-08
**Context:** Strategic analysis of the PN Accuracy Dashboard data.

---

## 📊 Summary for Presentation

This document outlines key insights derived from the dashboard data, structured for an executive presentation.

### Slide 1: The "1%" Illusion
*   **Insight**: The fleet's Median Error is excellent at **~1.0%**.
*   **The Catch**: This median hides massive volume risks. While most units are accurate, a few specific categories are driving **>60,000 GWh** of absolute error.
*   **Visual**: Show **Tab 1 KPI Panel** (Low Median %) vs. **Tab 1 Total ABS Error** (High GWh).

### Slide 2: The "Size" Paradox
*   **Insight**: **Large Units (>100MW)** are incredibly precise (`0.06%` median error). They are optimized and well-managed.
*   **The Problem**: **Medium & Small units** are ~15x less accurate (`~1.0%`).
*   **Action**: Stop worrying about the big CCGTs/Nuclear plants. Focus optimization efforts on the distributed fleet.
*   **Visual**: **Tab 2 "Size Category Analysis"** Box Plot.

### Slide 3: The "Unknown" Risk Factor
*   **Critical Finding**: The **`OTHER`** fuel category contributes **47,652 GWh** of error (approx. 70% of total system error).
*   **Action**: Immediate audit required. What assets are in "OTHER"? (Likely Aggregators, Waste-to-Energy, or misclassified assets). Fixing this category alone solves the majority of the system imbalance.
*   **Visual**: **Tab 1 "Total GWh Error"** Bar Chart (highlighting the massive "OTHER" bar).

### Slide 4: Wind's "Optimism Bias"
*   **Insight**: **Wind** is the second largest error source (14,762 GWh) and shows a specific **Positive Bias** (+1,146 GWh).
*   **Interpretation**: Wind farms are systematically **Over-forecasting** (promising more power than they deliver).
*   **Visual**: **Tab 3 "Bias (Net GWh)"** Histogram for Wind (skewed right/positive).

---

## 🤝 How to Use the Dashboard as a Companion

Don't just show screenshots. Drive the dashboard live during the meeting:

1.  **The "Hook"**: Start on **Executive Summary**.
    *   *Say*: "On average, we look great (1% error)."
    *   *Click*: **Total GWh Error** tab histogram.
    *   *Say*: "But 'OTHER' and 'WIND' are costing us millions in imbalance."

2.  **The "Deep Dive"**: Switch to **Fleet Overview (Capacity)**.
    *   *Action*: Toggle Y-Axis to **Total Error (GWh)**.
    *   *Show*: The "Wall of Bubbles" at the top (High Error, Low Capacity). This proves the "Small Unit" problem visually.

3.  **The "Solution"**: End on **Attention Needed**.
    *   *Show*: The list of specific units.
    *   *Say*: "We don't need to fix everyone. We just need to fix *these* 50 units to resolve 80% of our error."
