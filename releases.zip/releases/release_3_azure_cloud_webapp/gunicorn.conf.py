# Gunicorn Production Configuration
import os

bind = f"0.0.0.0:{os.getenv('PORT', '8050')}"
workers = int(os.getenv("WEB_CONCURRENCY", "4"))
threads = int(os.getenv("PYTHON_GET_THREADS", "2"))
timeout = 120
keepalive = 5
loglevel = "info"
