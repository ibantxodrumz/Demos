"""
Required service tests (spec §Required Service Tests).
Tests that:
- Source alert fields are mapped correctly into the service result
- Alert status is derived correctly (Unreviewed / Open / Closed)
- Service validation rejects missing required values
- Repository errors are surfaced as meaningful exceptions
- UI-ready data contains the expected columns
"""

from pathlib import Path
import shutil
import tempfile
import pytest

from src.config.settings import DEMO_WEEK_1
from src.services import alert_service, activity_log_service
from src.repositories import alert_repository

ROOT_DIR = Path(__file__).resolve().parents[1]
DB_PATH = ROOT_DIR / "import_constraints_local_prototype" / "data" / "prototype.db"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@pytest.fixture
def temp_db():
    """Copy the production DB to a temp location so write tests are isolated."""
    tmp_dir = tempfile.mkdtemp()
    tmp_db_path = Path(tmp_dir) / "test_prototype.db"
    shutil.copy(DB_PATH, tmp_db_path)
    yield tmp_db_path
    shutil.rmtree(tmp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Status derivation
# ---------------------------------------------------------------------------


def test_derive_review_status_unreviewed():
    """Row with no ACTIVITY_LOG record → Unreviewed."""
    row = {"ANALYSIS_STATUS": None}
    assert alert_service.derive_review_status(row) == "Unreviewed"


def test_derive_review_status_open():
    row = {"ANALYSIS_STATUS": "Open"}
    assert alert_service.derive_review_status(row) == "Open"


def test_derive_review_status_closed():
    row = {"ANALYSIS_STATUS": "Closed"}
    assert alert_service.derive_review_status(row) == "Closed"


def test_derive_review_status_empty_string():
    """Empty string in ANALYSIS_STATUS should be treated as Unreviewed."""
    row = {"ANALYSIS_STATUS": ""}
    assert alert_service.derive_review_status(row) == "Unreviewed"


def test_derive_review_status_whitespace():
    """Whitespace-only string should be treated as Unreviewed."""
    row = {"ANALYSIS_STATUS": "   "}
    assert alert_service.derive_review_status(row) == "Unreviewed"


# ---------------------------------------------------------------------------
# Field mapping: get_alerts_for_period
# ---------------------------------------------------------------------------


def test_get_alerts_for_period_returns_expected_columns():
    """UI-ready result must contain required fields."""
    result = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )

    assert "alerts" in result
    assert "summary" in result
    assert "filter_options" in result

    # Summary keys
    summary = result["summary"]
    for key in ("total_count", "unreviewed_count", "open_count", "closed_count"):
        assert key in summary, f"Missing summary key: {key}"

    # Filter option keys
    opts = result["filter_options"]
    for key in ("bmus", "parties", "fuels", "statuses"):
        assert key in opts, f"Missing filter_options key: {key}"

    # Each alert row must have DISPLAY_STATUS and UNIQUE_ID
    for a in result["alerts"]:
        assert "DISPLAY_STATUS" in a, "Alert row missing DISPLAY_STATUS"
        assert "UNIQUE_ID" in a, "Alert row missing UNIQUE_ID"
        assert a["DISPLAY_STATUS"] in ("Unreviewed", "Open", "Closed")


def test_get_alerts_for_period_maps_source_fields():
    """Alerts must carry key IMPORT_ALERTS source fields."""
    result = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    required_fields = [
        "UNIQUE_ID",
        "BMU_ID",
        "COUNTERPARTY",
        "FUEL_TYPE",
        "START_GMT",
        "END_GMT",
        "START_LOCAL",
        "END_LOCAL",
        "DURATION_MIN",
        "COUNT_SP",
    ]
    for alert in result["alerts"]:
        for field in required_fields:
            assert field in alert, f"Alert row missing field: {field}"


# ---------------------------------------------------------------------------
# Filter logic
# ---------------------------------------------------------------------------


def test_bmu_filter_returns_only_matching_bmu():
    result_all = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    # Pick the first BMU that appears
    first_bmu = result_all["alerts"][0]["BMU_ID"]

    result_filtered = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
        bmu_filter=first_bmu,
    )

    assert all(a["BMU_ID"] == first_bmu for a in result_filtered["alerts"])
    assert len(result_filtered["alerts"]) <= len(result_all["alerts"])


def test_status_filter_unreviewed_excludes_reviewed(temp_db):
    """After saving a review for one alert, filtering by Unreviewed excludes it."""
    result_all = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    target_id = result_all["alerts"][0]["UNIQUE_ID"]

    # Save a review for the first alert
    activity_log_service.save_analyst_review(
        alert_unique_id=target_id,
        action_taken="AutoClose",
        analysis_status="Closed",
        review_comments="",
        db_path=temp_db,
    )

    # Now re-retrieve from the same temp_db using the repository directly
    alerts_after = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=temp_db,
    )
    reviewed_row = next((a for a in alerts_after if a["UNIQUE_ID"] == target_id), None)
    assert reviewed_row is not None
    assert reviewed_row["ANALYSIS_STATUS"] == "Closed"


# ---------------------------------------------------------------------------
# Empty date range
# ---------------------------------------------------------------------------


def test_empty_date_range_returns_empty_list_not_exception():
    """A date range with no alerts must return an empty list, not raise."""
    result = alert_service.get_alerts_for_period(
        start_date="2020-01-01",
        end_date="2020-01-07",
    )
    assert result["alerts"] == []
    assert result["summary"]["total_count"] == 0


# ---------------------------------------------------------------------------
# get_alert_by_id
# ---------------------------------------------------------------------------


def test_get_alert_by_id_returns_correct_record():
    result = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    target = result["alerts"][0]
    fetched = alert_service.get_alert_by_id(target["UNIQUE_ID"])

    assert fetched is not None
    assert fetched["UNIQUE_ID"] == target["UNIQUE_ID"]
    assert fetched["BMU_ID"] == target["BMU_ID"]
    assert "DISPLAY_STATUS" in fetched


def test_get_alert_by_id_non_existent_returns_none():
    result = alert_service.get_alert_by_id("DOES_NOT_EXIST_XYZ")
    assert result is None


def test_party_and_fuel_filters():
    """Verify that party_filter and fuel_filter correctly isolate matching records."""
    result_all = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    assert len(result_all["alerts"]) > 0

    party = result_all["alerts"][0]["COUNTERPARTY"]
    fuel = result_all["alerts"][0]["FUEL_TYPE"]

    filtered_party = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
        party_filter=party,
    )
    assert all(a["COUNTERPARTY"] == party for a in filtered_party["alerts"])

    filtered_fuel = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
        fuel_filter=fuel,
    )
    assert all(a["FUEL_TYPE"] == fuel for a in filtered_fuel["alerts"])


def test_summary_counts_match_filtered_alerts():
    """Summary counts must equal exact breakdowns of returned alert list."""
    result = alert_service.get_alerts_for_period(
        start_date=DEMO_WEEK_1["start"],
        end_date=DEMO_WEEK_1["end"],
    )
    summary = result["summary"]
    alerts = result["alerts"]

    assert summary["total_count"] == len(alerts)
    assert summary["unreviewed_count"] == sum(1 for a in alerts if a["DISPLAY_STATUS"] == "Unreviewed")
    assert summary["open_count"] == sum(1 for a in alerts if a["DISPLAY_STATUS"] == "Open")
    assert summary["closed_count"] == sum(1 for a in alerts if a["DISPLAY_STATUS"] == "Closed")


def test_invalid_db_path_surfaces_exception():
    """Repository error caused by non-existent database file raises an exception."""
    with pytest.raises(Exception):
        alert_service.get_alerts_for_period(
            start_date=DEMO_WEEK_1["start"],
            end_date=DEMO_WEEK_1["end"],
            db_path="/non/existent/path/to/db.sqlite",
        )

