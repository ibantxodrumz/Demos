import shutil
import sqlite3
import tempfile
from pathlib import Path
import pytest

from src.repositories import activity_log_repository, alert_repository
from src.services import activity_log_service

ROOT_DIR = Path(__file__).resolve().parents[1]
ORIG_DB_PATH = ROOT_DIR / "import_constraints_local_prototype" / "data" / "prototype.db"


@pytest.fixture
def temp_db():
    temp_dir = tempfile.mkdtemp()
    temp_db_path = Path(temp_dir) / "test_prototype.db"
    shutil.copy(ORIG_DB_PATH, temp_db_path)
    # Clear any saved reviews that may exist in the production DB copy so every
    # test starts from a known-empty ACTIVITY_LOG regardless of local state.
    with sqlite3.connect(temp_db_path) as conn:
        conn.execute("DELETE FROM ACTIVITY_LOG")
    yield temp_db_path
    shutil.rmtree(temp_dir, ignore_errors=True)


def test_insert_and_update_activity_log(temp_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=temp_db)
    target_alert = alerts[0]
    unique_id = target_alert["UNIQUE_ID"]

    # Initial Save -> INSERT
    saved_1 = activity_log_service.save_analyst_review(
        alert_unique_id=unique_id,
        action_taken="AutoClose",
        analysis_status="Closed",
        review_comments="Initial automated review note",
        analyst_name="Test Analyst",
        db_path=temp_db,
    )

    assert saved_1["ACTIVITY_LOG_ID"] == f"LOG-{unique_id}"
    assert saved_1["ACTION_TAKEN"] == "AutoClose"
    assert saved_1["ANALYSIS_STATUS"] == "Closed"
    created_time_1 = saved_1["CREATED_DATETIME"]

    # Verify single row created
    all_reviews_1 = activity_log_service.get_saved_reviews(db_path=temp_db)
    assert len(all_reviews_1) == 1

    # Second Save -> UPDATE
    saved_2 = activity_log_service.save_analyst_review(
        alert_unique_id=unique_id,
        action_taken="Monitor Ongoing",
        analysis_status="Open",
        review_comments="Updated analyst observation",
        analyst_name="Test Analyst",
        db_path=temp_db,
    )

    assert saved_2["ACTION_TAKEN"] == "Monitor Ongoing"
    assert saved_2["ANALYSIS_STATUS"] == "Open"
    assert saved_2["REVIEW_COMMENTS"] == "Updated analyst observation"
    assert (
        saved_2["CREATED_DATETIME"] == created_time_1
    ), "CREATED_DATETIME must remain unchanged on update"

    # Verify row count remains 1 (no duplicate record)
    all_reviews_2 = activity_log_service.get_saved_reviews(db_path=temp_db)
    assert len(all_reviews_2) == 1


def test_invalid_action_or_status_rejected(temp_db):
    alerts = alert_repository.get_alerts_by_date_range("2026-02-02", "2026-02-08", db_path=temp_db)
    unique_id = alerts[0]["UNIQUE_ID"]

    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id=unique_id,
            action_taken="INVALID_ACTION",
            analysis_status="Closed",
            db_path=temp_db,
        )

    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id=unique_id,
            action_taken="AutoClose",
            analysis_status="INVALID_STATUS",
            db_path=temp_db,
        )


def test_non_existent_alert_id_rejected(temp_db):
    with pytest.raises(ValueError):
        activity_log_service.save_analyst_review(
            alert_unique_id="NON_EXISTENT_ID_999999",
            action_taken="AutoClose",
            analysis_status="Closed",
            db_path=temp_db,
        )
