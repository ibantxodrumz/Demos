import shutil
import sqlite3
import tempfile
from pathlib import Path

import pytest

from import_constraints_local_prototype.scripts import initialise_database
from src.repositories import connection

ROOT_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT_DIR / "import_constraints_local_prototype" / "data"
DB_PATH = DATA_DIR / "prototype.db"


@pytest.fixture(scope="module")
def fresh_db():
    """
    Runs initialise_database against a temporary directory so the production
    prototype.db is never deleted during a test run.  All DB-structure tests
    operate on this isolated copy.
    """
    tmp_dir = tempfile.mkdtemp()
    tmp_db = Path(tmp_dir) / "prototype.db"
    initialise_database.initialise_database(db_path=tmp_db)
    yield tmp_db
    shutil.rmtree(tmp_dir, ignore_errors=True)


def test_database_exists_and_populated(fresh_db):
    """Production DB exists; both source tables are populated."""
    assert fresh_db.exists()
    with connection.get_db(fresh_db) as conn:
        count_sp = conn.execute("SELECT COUNT(*) FROM IMPORT_ALERTS_DATA").fetchone()[0]
        assert count_sp > 0

        count_alerts = conn.execute("SELECT COUNT(*) FROM IMPORT_ALERTS").fetchone()[0]
        assert count_alerts > 0

        count_log = conn.execute("SELECT COUNT(*) FROM ACTIVITY_LOG").fetchone()[0]
        assert count_log == 0, "ACTIVITY_LOG must be empty after initialisation"


def test_expected_tables_exist(fresh_db):
    """Exactly the three expected tables exist — no extras, no renames."""
    with connection.get_db(fresh_db) as conn:
        rows = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        table_names = {r["name"] for r in rows}

    expected = {"IMPORT_ALERTS_DATA", "IMPORT_ALERTS", "ACTIVITY_LOG"}
    assert expected == table_names, f"Unexpected table set. Expected {expected}, got {table_names}"


def test_unique_ids_are_unique(fresh_db):
    """IMPORT_ALERTS.UNIQUE_ID values must all be distinct."""
    with connection.get_db(fresh_db) as conn:
        total = conn.execute("SELECT COUNT(*) FROM IMPORT_ALERTS").fetchone()[0]
        distinct = conn.execute("SELECT COUNT(DISTINCT UNIQUE_ID) FROM IMPORT_ALERTS").fetchone()[0]
    assert total == distinct, "IMPORT_ALERTS contains duplicate UNIQUE_ID values"


def test_foreign_keys_enabled(fresh_db):
    with connection.get_db(fresh_db) as conn:
        fk_status = conn.execute("PRAGMA foreign_keys;").fetchone()[0]
        assert fk_status == 1


def test_alert_duration_check_constraint(fresh_db):
    with connection.get_db(fresh_db) as conn:
        invalid_count = conn.execute(
            "SELECT COUNT(*) FROM IMPORT_ALERTS WHERE DURATION_MIN != COUNT_SP * 30"
        ).fetchone()[0]
        assert invalid_count == 0


def test_unique_id_not_null_and_non_empty(fresh_db):
    """UNIQUE_ID in IMPORT_ALERTS must not contain null or empty values."""
    with connection.get_db(fresh_db) as conn:
        invalid_count = conn.execute(
            "SELECT COUNT(*) FROM IMPORT_ALERTS WHERE UNIQUE_ID IS NULL OR TRIM(UNIQUE_ID) = ''"
        ).fetchone()[0]
        assert invalid_count == 0


def test_empty_date_range_db_query(fresh_db):
    """Direct SQL query with out-of-bounds date range returns zero rows."""
    with connection.get_db(fresh_db) as conn:
        count = conn.execute(
            "SELECT COUNT(*) FROM IMPORT_ALERTS WHERE START_LOCAL >= '2000-01-01' AND START_LOCAL < '2000-01-08'"
        ).fetchone()[0]
        assert count == 0

