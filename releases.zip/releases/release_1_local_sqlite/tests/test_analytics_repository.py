from pathlib import Path
import pytest
from src.config.settings import DEMO_WEEK_1
from src.repositories import alert_repository, analytics_repository
from src.services import analytics_service

ROOT_DIR = Path(__file__).resolve().parents[1]
DB_PATH = ROOT_DIR / "import_constraints_local_prototype" / "data" / "prototype.db"


def test_sp_evidence_retrieval():
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=DB_PATH,
    )
    alert = alerts[0]

    sp_records = analytics_repository.get_sp_evidence_for_alert(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=DB_PATH,
    )

    assert len(sp_records) == alert["COUNT_SP"]
    start_gmt_norm = str(alert["START_GMT"]).replace(" ", "T")
    end_gmt_norm = str(alert["END_GMT"]).replace(" ", "T")
    for r in sp_records:
        assert r["BMU_ID"] == alert["BMU_ID"]
        assert r["GMT_FROM"] >= start_gmt_norm
        assert r["GMT_FROM"] < end_gmt_norm


def test_get_why_values_for_alert():
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=DB_PATH,
    )
    alert = alerts[0]

    why_values = analytics_repository.get_why_values_for_alert(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=DB_PATH,
    )

    assert isinstance(why_values, list)
    for val in why_values:
        assert val is not None
        assert val != ""
        assert val.lower() != "nan"


def test_analytics_payload_service():
    alerts = alert_repository.get_alerts_by_date_range(
        DEMO_WEEK_1["start"],
        DEMO_WEEK_1["end"],
        db_path=DB_PATH,
    )
    alert = alerts[0]

    payload = analytics_service.get_alert_evidence_payload(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=DB_PATH,
    )

    assert "sp_records" in payload
    assert "metrics" in payload
    assert "info_for_analyst" in payload
    assert payload["sp_count"] == alert["COUNT_SP"]


def test_get_database_date_bounds():
    from src.repositories import sp_analytics_repository

    bounds = sp_analytics_repository.get_database_date_bounds(db_path=DB_PATH)
    assert "start" in bounds
    assert "end" in bounds
    assert bounds["start"] <= bounds["end"]
    assert bounds["start"] == "2026-01-01"
