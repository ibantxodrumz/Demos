from pathlib import Path
from src.services.long_run_service import get_long_run_counterparty_stats

TEST_DB_PATH = Path("/Users/ivansanz/Desktop/PoC/import_constraints_local_prototype/data/prototype.db")


def test_get_long_run_counterparty_stats_dual_thresholds():
    res = get_long_run_counterparty_stats(
        start_date="2026-02-01",
        end_date="2026-02-10",
        threshold_volume=3,
        threshold_impact_gbp=50000.0,
        db_path=TEST_DB_PATH,
    )
    assert "summary" in res
    assert "counterparties" in res
    assert res["summary"]["total_alerts"] > 0
    assert "total_gbp_impact" in res["summary"]
    assert len(res["counterparties"]) > 0

    first_party = res["counterparties"][0]
    assert "COUNTERPARTY" in first_party
    assert "TOTAL_ALERTS" in first_party
    assert "TOTAL_GBP_IMPACT" in first_party
    assert "FRAMING_STATUS" in first_party
