import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, Optional, Union
from src.config.settings import DATABASE_MODE, DB_PATH
from src.repositories import azure_connection


def get_connection(db_path: Optional[Union[Path, str]] = None) -> Any:
    # If a specific db_path is passed (e.g. in unit tests), always use SQLite for that path
    if db_path or DATABASE_MODE == "sqlite":
        target_path = Path(db_path) if db_path else DB_PATH
        if not target_path.exists():
            raise FileNotFoundError(
                f"Database file not found at '{target_path}'. "
                "Please run: python import_constraints_local_prototype/scripts/initialise_database.py"
            )
        conn = sqlite3.connect(target_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn
    elif DATABASE_MODE == "azure":
        return azure_connection.get_azure_connection()
    else:
        raise ValueError(
            f"Unsupported DATABASE_MODE '{DATABASE_MODE}'. Must be 'sqlite' or 'azure'."
        )


@contextmanager
def get_db(db_path: Optional[Union[Path, str]] = None) -> Generator[Any, None, None]:
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
