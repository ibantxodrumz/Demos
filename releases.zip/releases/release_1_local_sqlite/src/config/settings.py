import os
from pathlib import Path

# Workspace Root
ROOT_DIR = Path(__file__).resolve().parents[2]

# Database Configuration
DATABASE_MODE = os.getenv("DATABASE_MODE", "sqlite").lower()  # "sqlite" or "azure"
DEFAULT_DB_PATH = ROOT_DIR / "import_constraints_local_prototype" / "data" / "prototype.db"
DB_PATH = Path(os.getenv("DATABASE_PATH", str(DEFAULT_DB_PATH)))

AZURE_SQL_SERVER = os.getenv("AZURE_SQL_SERVER", "")
AZURE_SQL_DATABASE = os.getenv("AZURE_SQL_DATABASE", "")


# Analyst Configuration
LOCAL_ANALYST_NAME = os.getenv("LOCAL_ANALYST_NAME", "Local Prototype Analyst")

# Domain Configuration
DEFAULT_PARAMETER_BREACHED = "Import Constraints"
DEFAULT_NOTIFICATION_SOURCE = "IMPORT_CONSTRAINTS"

# Controlled Outcome Values
CONTROLLED_ACTIONS = [
    "AutoClose",
    "Monitor Ongoing",
    "Resolved With Provider",
    "Review For Potential STR",
    "Escalated To STR",
    "Escalated To MIR",
    "Bad Data",
    "Closed by Ivan",
    "Close by dkfjdkfjkdjfkj",
    "REMIT email sent",
    "Data improvement",
    "Poor quality remit",
    "Under 100MW REMIT",
]

CONTROLLED_STATUSES = [
    "Open",
    "Closed",
]

# Demonstration Weeks for Testing & Validation
DEMO_WEEK_1 = {
    "label": "Demo Week 1 (Feb 2 - Feb 8, 2026)",
    "start": "2026-02-02",
    "end": "2026-02-08",
}

DEMO_WEEK_2 = {
    "label": "Demo Week 2 (May 4 - May 10, 2026)",
    "start": "2026-05-04",
    "end": "2026-05-10",
}
