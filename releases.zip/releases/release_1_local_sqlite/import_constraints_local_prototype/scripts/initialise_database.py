from pathlib import Path
from typing import Optional
import sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DEFAULT_DB_PATH = DATA_DIR / "prototype.db"
SCHEMA_PATH = ROOT / "sql" / "schema.sql"


def initialise_database(db_path: Optional[Path] = None) -> None:
    """
    Create (or recreate) the SQLite database.

    Args:
        db_path: Override the default DB location. Used by tests to target a
                 temporary path so the production prototype.db is never deleted
                 during automated test runs. Defaults to the standard data/
                 directory path when called from the CLI.
    """
    target = Path(db_path) if db_path else DEFAULT_DB_PATH
    try:
        target.unlink(missing_ok=True)
    except PermissionError:
        pass

    alerts_data = pd.read_csv(DATA_DIR / "IMPORT_ALERTS_DATA.csv")
    alerts = pd.read_csv(DATA_DIR / "IMPORT_ALERTS.csv")

    with sqlite3.connect(target) as connection:
        connection.execute("PRAGMA foreign_keys = OFF;")
        connection.executescript("""
            DROP TABLE IF EXISTS ACTIVITY_LOG;
            DROP TABLE IF EXISTS IMPORT_ALERTS;
            DROP TABLE IF EXISTS IMPORT_ALERTS_DATA;
        """)
        connection.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        alerts_data.to_sql("IMPORT_ALERTS_DATA", connection, if_exists="append", index=False)
        alerts.to_sql("IMPORT_ALERTS", connection, if_exists="append", index=False)


if __name__ == "__main__":
    initialise_database()
