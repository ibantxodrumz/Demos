from pathlib import Path
import pytest
from src.services.long_run_service import get_long_run_counterparty_stats


def test_get_long_run_counterparty_stats_dual_thresholds(fresh_db):
    res = get_long_run_counterparty_stats(
        start_date="2026-02-01",
        end_date="2026-02-10",
        threshold_volume=1,
        threshold_impact_gbp=0.0,
        db_path=fresh_db,
    )
    assert "summary" in res
    assert "counterparties" in res
    assert "total_alerts" in res["summary"]
    assert "total_gbp_impact" in res["summary"]
    assert isinstance(res["counterparties"], list)
