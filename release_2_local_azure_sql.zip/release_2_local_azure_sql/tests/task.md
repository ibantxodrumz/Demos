# Fix Tasks

- [x] Bug 1: test_database.py autouse wipes production DB
- [x] Bug 2: alert_repository.py query boundary — <= 23:59:59 → < next_day  
- [x] Missing test: test_alert_service.py (field mapping, status derivation, validation)
- [x] Missing DB tests: table names, UNIQUE_ID uniqueness, empty range

