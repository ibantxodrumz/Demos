import dash

app = dash.Dash(__name__, use_pages=True, pages_folder="/Users/ivansanz/Desktop/PoC/src/pages")
from src.pages import user_guide


def test_user_guide_layout():
    layout = user_guide.layout
    assert layout is not None
    assert hasattr(layout, "children")
    assert len(layout.children) >= 2
