from src.repositories import azure_connection


def test_azure_driver_picker():
    driver = azure_connection.pick_odbc_driver()
    assert driver is not None
    assert "ODBC Driver" in driver


def test_azure_row_dict_compatibility():
    row = azure_connection.AzureRow({"col1": "val1", "col2": 42})
    assert row["col1"] == "val1"
    assert row["col2"] == 42
    assert row[0] == "val1"
    assert row[1] == 42
    assert dict(row) == {"col1": "val1", "col2": 42}
