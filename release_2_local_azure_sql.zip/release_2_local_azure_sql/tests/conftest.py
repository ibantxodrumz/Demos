import sqlite3
import pytest
from pathlib import Path
from src.config import settings

SCHEMA_SQL = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS IMPORT_ALERTS_DATA (
    SETTLEMENT_DATE TEXT NOT NULL,
    SETTLEMENT_PERIOD INTEGER NOT NULL,
    GMT_FROM TEXT NOT NULL,
    LOCAL_DATETIME TEXT,
    MONTH_YEAR TEXT,
    WEEK_YEAR TEXT,
    COUNTERPARTY TEXT,
    BMU_ID TEXT NOT NULL,
    FUEL_TYPE TEXT,
    OFFER_PRICE NUMERIC DEFAULT 50.0,
    OFFER_VOLUME_MWH NUMERIC DEFAULT 10.0,
    BOPAIR_ID INTEGER DEFAULT 1,
    REASON_CODE TEXT DEFAULT 'TEST',
    CONSTRAINT_GROUP TEXT DEFAULT 'TEST',
    CONSTRAINT_REASON TEXT DEFAULT 'TEST',
    HH_WAP REAL DEFAULT 10.0,
    HIGH_TRADED_PRICE REAL DEFAULT 20.0,
    REFERENCE_PRICE NUMERIC DEFAULT 15.0,
    SPREAD NUMERIC DEFAULT 5.0,
    P_SELF_USED NUMERIC DEFAULT 0,
    COND_1 INTEGER NOT NULL CHECK (COND_1 IN (0, 1)),
    THR_FUEL NUMERIC DEFAULT 1.0,
    COND_2 INTEGER NOT NULL CHECK (COND_2 IN (0, 1)),
    MED_SPREAD_CON NUMERIC DEFAULT 2.0,
    MED_SPREAD_UNCON NUMERIC DEFAULT 1.0,
    SPREAD_DIFF NUMERIC DEFAULT 1.0,
    COND_3 INTEGER NOT NULL CHECK (COND_3 IN (0, 1)),
    D_REF TEXT DEFAULT 'REF',
    N_CONDITIONS_TRUE INTEGER NOT NULL CHECK (N_CONDITIONS_TRUE BETWEEN 0 AND 3),
    ENSEMBLE INTEGER NOT NULL CHECK (ENSEMBLE IN (0, 1)),
    WHY TEXT,
    UNIQUE_ID TEXT NOT NULL PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS IMPORT_ALERTS (
    BMU_ID TEXT NOT NULL,
    FUEL_TYPE TEXT,
    COUNTERPARTY TEXT,
    START_GMT TEXT NOT NULL,
    END_GMT TEXT NOT NULL,
    START_LOCAL TEXT,
    END_LOCAL TEXT,
    DURATION_MIN INTEGER NOT NULL,
    COUNT_SP INTEGER NOT NULL,
    UNIQUE_ID TEXT NOT NULL PRIMARY KEY,
    CHECK (DURATION_MIN = COUNT_SP * 30)
);

CREATE TABLE IF NOT EXISTS ACTIVITY_LOG (
    ACTIVITY_LOG_ID TEXT NOT NULL PRIMARY KEY,
    ALERT_UNIQUE_ID TEXT NOT NULL UNIQUE,
    BMU_ID TEXT NOT NULL,
    PARTY_NAME TEXT,
    PARAMETER_BREACHED TEXT NOT NULL,
    RAISE_DATE TEXT NOT NULL,
    START_DATE TEXT NOT NULL,
    END_DATE TEXT NOT NULL,
    PERSON_RAISING TEXT,
    NOTIFICATION_SOURCE TEXT NOT NULL,
    ACTION_TAKEN TEXT,
    ANALYSIS_STATUS TEXT,
    INFO_FOR_ANALYST TEXT,
    REVIEW_COMMENTS TEXT,
    CREATED_DATETIME TEXT NOT NULL,
    UPDATED_DATETIME TEXT,
    FOREIGN KEY (ALERT_UNIQUE_ID) REFERENCES IMPORT_ALERTS (UNIQUE_ID)
);
"""

def seed_test_database(db_path: Path):
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA_SQL)

    # Insert sample alert for Demo Week 1 (2026-02-02 to 2026-02-08)
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS (
            BMU_ID, FUEL_TYPE, COUNTERPARTY, START_GMT, END_GMT, START_LOCAL, END_LOCAL, DURATION_MIN, COUNT_SP, UNIQUE_ID
        ) VALUES (
            'T_TEST-1', 'GAS', 'TEST_CP', '2026-02-02 08:00', '2026-02-02 09:00', '2026-02-02 08:00', '2026-02-02 09:00', 60, 2, 'ALT-TEST-001'
        )
        """
    )

    # Insert repeated BMU alert for Demo Week 1
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS (
            BMU_ID, FUEL_TYPE, COUNTERPARTY, START_GMT, END_GMT, START_LOCAL, END_LOCAL, DURATION_MIN, COUNT_SP, UNIQUE_ID
        ) VALUES (
            'T_TEST-1', 'GAS', 'TEST_CP', '2026-02-03 10:00', '2026-02-03 11:00', '2026-02-03 10:00', '2026-02-03 11:00', 60, 2, 'ALT-TEST-002'
        )
        """
    )

    # Insert sample alert for Demo Week 2 (2026-05-04 to 2026-05-10)
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS (
            BMU_ID, FUEL_TYPE, COUNTERPARTY, START_GMT, END_GMT, START_LOCAL, END_LOCAL, DURATION_MIN, COUNT_SP, UNIQUE_ID
        ) VALUES (
            'T_TEST-2', 'WIND', 'TEST_CP2', '2026-05-04 12:00', '2026-05-04 13:00', '2026-05-04 12:00', '2026-05-04 13:00', 60, 2, 'ALT-TEST-003'
        )
        """
    )
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS (
            BMU_ID, FUEL_TYPE, COUNTERPARTY, START_GMT, END_GMT, START_LOCAL, END_LOCAL, DURATION_MIN, COUNT_SP, UNIQUE_ID
        ) VALUES (
            'T_TEST-2', 'WIND', 'TEST_CP2', '2026-05-05 14:00', '2026-05-05 15:00', '2026-05-05 14:00', '2026-05-05 15:00', 60, 2, 'ALT-TEST-004'
        )
        """
    )

    # Insert 2 corresponding SP data records for ALT-TEST-001 (2 SPs: 08:00 and 08:30)
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS_DATA (
            SETTLEMENT_DATE, SETTLEMENT_PERIOD, GMT_FROM, LOCAL_DATETIME, BMU_ID, OFFER_VOLUME_MWH, COND_1, COND_2, COND_3, N_CONDITIONS_TRUE, ENSEMBLE, WHY, UNIQUE_ID
        ) VALUES (
            '2026-02-02', 17, '2026-02-02T08:00', '2026-02-02 08:00', 'T_TEST-1', 10.0, 1, 1, 0, 2, 1, 'High Spread', 'SP-TEST-001'
        )
        """
    )
    conn.execute(
        """
        INSERT INTO IMPORT_ALERTS_DATA (
            SETTLEMENT_DATE, SETTLEMENT_PERIOD, GMT_FROM, LOCAL_DATETIME, BMU_ID, OFFER_VOLUME_MWH, COND_1, COND_2, COND_3, N_CONDITIONS_TRUE, ENSEMBLE, WHY, UNIQUE_ID
        ) VALUES (
            '2026-02-02', 18, '2026-02-02T08:30', '2026-02-02 08:30', 'T_TEST-1', 12.5, 1, 1, 0, 2, 1, 'High Spread', 'SP-TEST-002'
        )
        """
    )

    conn.commit()
    conn.close()

@pytest.fixture(autouse=True)
def set_sqlite_test_env(monkeypatch, tmp_path):
    db_file = tmp_path / "test_prototype.db"
    seed_test_database(db_file)
    monkeypatch.setattr(settings, "DATABASE_MODE", "sqlite")
    # Patch connection.get_db default argument so calls with db_path=None use this db_file during tests
    from src.repositories import connection
    orig_get_connection = connection.get_connection
    def test_get_connection(db_path=None):
        return orig_get_connection(db_path or db_file)
    monkeypatch.setattr(connection, "get_connection", test_get_connection)
    yield db_file

@pytest.fixture
def fresh_db(set_sqlite_test_env):
    return set_sqlite_test_env
