import re
import struct
import time
from typing import Any, Dict, List, Optional, Tuple, Union
from src.config.settings import AZURE_SQL_DATABASE, AZURE_SQL_SERVER

try:
    import pyodbc
    from azure.core.exceptions import ClientAuthenticationError
    from azure.identity import AzureCliCredential, DefaultAzureCredential

    HAS_AZURE_LIBS = True
except ImportError:
    HAS_AZURE_LIBS = False

_TOKEN_CACHE: Optional[str] = None
_TOKEN_EXPIRES_AT: float = 0.0


class AzureRow(dict):
    """Row object that supports both dict access and dict(row) conversion."""

    def __getitem__(self, key: Union[str, int]) -> Any:
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


class AzureCursorWrapper:
    """Cursor wrapper translating SQLite named params (:name) to pyodbc positional params (?)

    and wrapping rows in AzureRow dicts for compatibility with sqlite3.Row.
    """

    def __init__(self, pyodbc_cursor: Any):
        self._cursor = pyodbc_cursor
        self.description = None

    def execute(
        self, query: str, params: Optional[Union[Dict[str, Any], Tuple[Any, ...], List[Any]]] = None
    ) -> "AzureCursorWrapper":
        if params is None:
            self._cursor.execute(query)
        elif isinstance(params, dict):
            # Translate :param_name to ? and order parameter values accordingly
            param_names: List[str] = []

            def _replacer(match):
                param_names.append(match.group(1))
                return "?"

            # Match :param_name (word characters)
            translated_query = re.sub(r":([a_zA-Z0-9_]+)", _replacer, query)
            param_values = tuple(params[name] for name in param_names)
            self._cursor.execute(translated_query, param_values)
        else:
            self._cursor.execute(query, params)

        self.description = self._cursor.description
        return self

    def fetchone(self) -> Optional[AzureRow]:
        row = self._cursor.fetchone()
        if row is None:
            return None
        cols = [c[0] for c in self._cursor.description]
        return AzureRow(zip(cols, row))

    def fetchall(self) -> List[AzureRow]:
        rows = self._cursor.fetchall()
        if not rows:
            return []
        cols = [c[0] for c in self._cursor.description]
        return [AzureRow(zip(cols, r)) for r in rows]


class SqliteCompatibleAzureConnectionWrapper:
    """Connection wrapper providing a sqlite3-compatible interface for pyodbc."""

    def __init__(self, pyodbc_conn: Any):
        self._conn = pyodbc_conn

    def execute(
        self, query: str, params: Optional[Union[Dict[str, Any], Tuple[Any, ...], List[Any]]] = None
    ) -> AzureCursorWrapper:
        cursor = AzureCursorWrapper(self._conn.cursor())
        cursor.execute(query, params)
        return cursor

    def commit(self) -> None:
        self._conn.commit()

    def rollback(self) -> None:
        self._conn.rollback()

    def close(self) -> None:
        self._conn.close()


def get_access_token() -> str:
    """Fetch an access token for Azure SQL with a 55-minute in-memory cache."""
    global _TOKEN_CACHE, _TOKEN_EXPIRES_AT

    if not HAS_AZURE_LIBS:
        raise ImportError(
            "Azure dependencies (pyodbc, azure-identity) are not installed. "
            "Install them via 'pip install pyodbc azure-identity' or 'uv sync --extra azure'."
        )

    now = time.time()
    if _TOKEN_CACHE and now < _TOKEN_EXPIRES_AT:
        return _TOKEN_CACHE

    scope = "https://database.windows.net/.default"

    # 1) Try AzureCliCredential (most reliable for local dev on corporate laptops)
    try:
        token = AzureCliCredential().get_token(scope)
        _TOKEN_CACHE = token.token
        _TOKEN_EXPIRES_AT = now + 3300  # 55 minutes
        return _TOKEN_CACHE
    except Exception:
        pass

    # 2) Fallback chain using DefaultAzureCredential
    try:
        cred = DefaultAzureCredential(exclude_interactive_browser_credential=False)
        token = cred.get_token(scope)
        _TOKEN_CACHE = token.token
        _TOKEN_EXPIRES_AT = now + 3300
        return _TOKEN_CACHE
    except ClientAuthenticationError as e:
        raise ConnectionError(
            "Azure authentication failed. Run 'az login' in the terminal. " f"Details: {e}"
        )
    except Exception as e:
        raise ConnectionError(f"Azure authentication error: {e}")


def pick_odbc_driver() -> str:
    """Prefer ODBC Driver 18, fallback to Driver 17 if installed."""
    if not HAS_AZURE_LIBS:
        return "{ODBC Driver 18 for SQL Server}"
    installed = pyodbc.drivers()
    for d in ["ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"]:
        if d in installed:
            return "{" + d + "}"
    return "{ODBC Driver 18 for SQL Server}"


def get_azure_connection(
    server: Optional[str] = None, database: Optional[str] = None
) -> SqliteCompatibleAzureConnectionWrapper:
    """Creates a pyodbc connection to Azure SQL wrapped for SQLite interface compatibility."""
    if not HAS_AZURE_LIBS:
        raise ImportError(
            "Azure dependencies (pyodbc/azure-identity) are missing. Run 'uv sync --extra azure'."
        )

    srv = server or AZURE_SQL_SERVER
    db = database or AZURE_SQL_DATABASE

    if not srv or not db:
        raise ValueError(
            "AZURE_SQL_SERVER and AZURE_SQL_DATABASE environment variables must be configured."
        )

    driver = pick_odbc_driver()

    connection_string = (
        f"Driver={driver};"
        f"Server=tcp:{srv},1433;"
        f"Database={db};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        "Connection Timeout=30;"
    )

    token = get_access_token()
    token_bytes = token.encode("UTF-16-LE")
    token_struct = struct.pack(f"<I{len(token_bytes)}s", len(token_bytes), token_bytes)

    try:
        conn = pyodbc.connect(connection_string, attrs_before={1256: token_struct})
        return SqliteCompatibleAzureConnectionWrapper(conn)
    except pyodbc.Error as e:
        raise ConnectionError(f"SQL connection failed to {srv}/{db}: {e}")
