from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.repositories.connection import get_db


def get_sp_evidence_for_alert(
    bmu_id: str,
    start_gmt: str,
    end_gmt: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Retrieve settlement-period evidence for a specific BMU and time window [start_gmt, end_gmt).
    """
    # Normalize timestamp format (IMPORT_ALERTS uses space ' ', IMPORT_ALERTS_DATA uses ISO 'T')
    gmt_start_norm = str(start_gmt).replace(" ", "T")
    gmt_end_norm = str(end_gmt).replace(" ", "T")

    query = """
    SELECT *
    FROM IMPORT_ALERTS_DATA
    WHERE BMU_ID = :bmu_id
      AND GMT_FROM >= :start_gmt
      AND GMT_FROM < :end_gmt
    ORDER BY GMT_FROM ASC
    """
    with get_db(db_path) as conn:
        cursor = conn.execute(
            query, {"bmu_id": bmu_id, "start_gmt": gmt_start_norm, "end_gmt": gmt_end_norm}
        )
        rows = cursor.fetchall()
        return [dict(r) for r in rows]


def get_why_values_for_alert(
    bmu_id: str,
    start_gmt: str,
    end_gmt: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[str]:
    """
    Retrieve distinct, non-null, non-empty WHY explanation strings for an alert window.
    """
    gmt_start_norm = str(start_gmt).replace(" ", "T")
    gmt_end_norm = str(end_gmt).replace(" ", "T")

    query = """
    SELECT WHY
    FROM IMPORT_ALERTS_DATA
    WHERE BMU_ID = :bmu_id
      AND GMT_FROM >= :start_gmt
      AND GMT_FROM < :end_gmt
    ORDER BY GMT_FROM ASC
    """
    with get_db(db_path) as conn:
        cursor = conn.execute(
            query, {"bmu_id": bmu_id, "start_gmt": gmt_start_norm, "end_gmt": gmt_end_norm}
        )
        rows = cursor.fetchall()
        why_list = []
        for r in rows:
            val = r["WHY"]
            if val is not None and str(val).strip() != "" and str(val).strip().lower() != "nan":
                if val not in why_list:
                    why_list.append(str(val).strip())
        return why_list
