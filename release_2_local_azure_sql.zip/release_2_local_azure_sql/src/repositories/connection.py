import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Generator, Optional, Union
from src.config.settings import DATABASE_MODE
from src.repositories import azure_connection


def get_connection(db_path: Optional[Union[Path, str]] = None) -> Any:
    # If a specific db_path is passed (e.g. in unit tests), use SQLite for that path/memory db
    if db_path or DATABASE_MODE == "sqlite":
        if db_path:
            target_path = Path(db_path)
            if target_path.name != ":memory:" and not target_path.exists():
                raise FileNotFoundError(f"SQLite database file not found at '{target_path}'.")
            conn = sqlite3.connect(target_path)
        else:
            conn = sqlite3.connect(":memory:")
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn
    elif DATABASE_MODE == "azure":
        return azure_connection.get_azure_connection()
    else:
        raise ValueError(
            f"Unsupported DATABASE_MODE '{DATABASE_MODE}'. Must be 'azure' or 'sqlite'."
        )


@contextmanager
def get_db(db_path: Optional[Union[Path, str]] = None) -> Generator[Any, None, None]:
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
