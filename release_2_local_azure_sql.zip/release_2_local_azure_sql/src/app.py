import dash
from dash import dcc, html
from src.components.navbar import create_header, create_sidebar

app = dash.Dash(
    __name__,
    use_pages=True,
    suppress_callback_exceptions=True,
    meta_tags=[{"name": "viewport", "content": "width=device-width, initial-scale=1"}],
)

app.title = "NESO | Market Monitoring Platform"

app.layout = html.Div(
    className="app-container",
    children=[
        dcc.Location(id="url", refresh=False),
        dcc.Store(
            id="operational-date-store",
            storage_type="session",
            data={"start_date": "2026-02-02", "end_date": "2026-02-08"},
        ),
        dcc.Store(
            id="closed-date-store",
            storage_type="session",
            data={"start_date": "2026-02-02", "end_date": "2026-02-08"},
        ),
        create_header(),
        html.Div(
            className="neso-body-wrapper",
            children=[
                create_sidebar(),
                html.Div(
                    className="neso-main-content",
                    children=[dash.page_container],
                ),
            ],
        ),
    ],
)

server = app.server

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8050, debug=True)
