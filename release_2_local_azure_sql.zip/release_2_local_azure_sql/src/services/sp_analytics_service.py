from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import pandas as pd

from src.repositories import sp_analytics_repository


def get_database_date_bounds(db_path: Optional[Union[Path, str]] = None) -> Dict[str, str]:
    """Retrieve minimum start date and maximum end date of alerts present in the database."""
    return sp_analytics_repository.get_database_date_bounds(db_path=db_path)


def get_behaviour_class(r: pd.Series) -> str:
    """Classifies a constrained settlement period based on the ensemble rule."""
    n_true = r.get("N_CONDITIONS_TRUE", 0)
    if n_true == 0:
        return "Constrained - normal behaviour"
    elif n_true == 1:
        return "Constrained - elevated signal"
    else:
        return "Constrained - ensemble"


def parse_why(why_str: Any) -> Tuple[str, str]:
    """Splits the detect-reason string into summary conditions and expanded details."""
    if pd.isna(why_str) or str(why_str).strip() == "" or str(why_str).strip().lower() == "nan":
        return "", ""
    parts = str(why_str).split("|")
    conditions = parts[0].strip()
    details = " | ".join(p.strip() for p in parts[1:]) if len(parts) > 1 else ""
    return conditions, details


def preprocess_data(raw_df: pd.DataFrame) -> pd.DataFrame:
    """Standardizes columns and calculates behavioral classes across dataset."""
    if raw_df.empty:
        return raw_df

    df = raw_df.copy()

    # Preprocessing datetime columns
    if "LOCAL_DATETIME" in df.columns:
        df["LOCAL_DATETIME"] = pd.to_datetime(df["LOCAL_DATETIME"])
    if "SETTLEMENT_DATE" in df.columns:
        df["SETTLEMENT_DATE"] = pd.to_datetime(df["SETTLEMENT_DATE"])
    if "GMT_FROM" in df.columns:
        df["GMT_FROM"] = pd.to_datetime(df["GMT_FROM"])

    # Standardize condition columns
    for col in ["COND_1", "COND_2", "COND_3"]:
        if col not in df.columns:
            df[col] = False
        else:
            df[col] = df[col].astype(bool)

    if "N_CONDITIONS_TRUE" not in df.columns:
        df["N_CONDITIONS_TRUE"] = df[["COND_1", "COND_2", "COND_3"]].sum(axis=1)

    if "ENSEMBLE" not in df.columns:
        df["ENSEMBLE"] = df["N_CONDITIONS_TRUE"] >= 2

    # Define BEHAVIOUR_CLASS taxonomy
    df["BEHAVIOUR_CLASS"] = df.apply(get_behaviour_class, axis=1)

    # Sort chronologically
    if "LOCAL_DATETIME" in df.columns:
        df = df.sort_values("LOCAL_DATETIME")
    return df


def enrich_alerts_with_impact(alerts_df: pd.DataFrame) -> pd.DataFrame:
    """Calculates granular estimated financial impact (£) per flag based on threshold deviations."""
    if alerts_df.empty:
        return alerts_df
    df = alerts_df.copy()
    MATERIALITY = 30.0

    if "WHY" in df.columns:
        parsed = df["WHY"].apply(parse_why)
        df["WHY_CONDITIONS"] = [p[0] for p in parsed]
        df["WHY_DETAILS"] = [p[1] for p in parsed]
    else:
        df["WHY_CONDITIONS"] = ""
        df["WHY_DETAILS"] = ""

    def calc_c1(r):
        spread = r.get("SPREAD") or 0.0
        med_uncon = r.get("MED_SPREAD_UNCON") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_1") and pd.notna(med_uncon):
            return max(spread - med_uncon, 0.0) * vol
        return 0.0

    def calc_c2(r):
        price = r.get("OFFER_PRICE") or 0.0
        thr_fuel = r.get("THR_FUEL") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_2") and pd.notna(thr_fuel):
            return max(price - thr_fuel, 0.0) * vol
        return 0.0

    def calc_c3(r):
        spread = r.get("SPREAD") or 0.0
        med_uncon = r.get("MED_SPREAD_UNCON") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_3") and pd.notna(med_uncon):
            return max(spread - (med_uncon + MATERIALITY), 0.0) * vol
        return 0.0

    df["IMPACT_C1"] = df.apply(calc_c1, axis=1)
    df["IMPACT_C2"] = df.apply(calc_c2, axis=1)
    df["IMPACT_C3"] = df.apply(calc_c3, axis=1)
    df["IMPACT_SP"] = df[["IMPACT_C1", "IMPACT_C2", "IMPACT_C3"]].mean(axis=1).round(2)
    return df


def infer_alerts_windows(alerts_df: pd.DataFrame) -> pd.DataFrame:
    """Groups individual ensemble settlement periods into continuous temporal episodes/windows."""
    if alerts_df.empty:
        return pd.DataFrame()

    df_window = alerts_df.copy()
    if "GMT_FROM" in df_window.columns:
        time_col = "GMT_FROM"
    else:
        time_col = "LOCAL_DATETIME"

    df_window = df_window.sort_values(["BMU_ID", time_col])

    df_window["prev_time"] = df_window.groupby("BMU_ID")[time_col].shift(1)
    df_window["is_new_window"] = (df_window[time_col] - df_window["prev_time"]) > pd.Timedelta(
        minutes=30
    )
    df_window["is_new_window"] = df_window["is_new_window"].fillna(True)
    df_window["window_id"] = df_window["is_new_window"].cumsum()

    has_impact = "IMPACT_SP" in df_window.columns

    agg_dict: Dict[str, Tuple[str, Any]] = {
        "FUEL_TYPE": ("FUEL_TYPE", "first"),
        "COUNTERPARTY": ("COUNTERPARTY", "first"),
        "START_GMT": ("GMT_FROM" if "GMT_FROM" in df_window.columns else "LOCAL_DATETIME", "min"),
        "END_GMT": (
            "GMT_FROM" if "GMT_FROM" in df_window.columns else "LOCAL_DATETIME",
            lambda x: x.max() + pd.Timedelta(minutes=30),
        ),
        "START_LOCAL": ("LOCAL_DATETIME", "min"),
        "END_LOCAL": (
            "LOCAL_DATETIME",
            lambda x: x.max() + pd.Timedelta(minutes=30),
        ),
        "COUNT_SP": ("SETTLEMENT_PERIOD", "count"),
        "C1_PRESENT": ("COND_1", "any"),
        "C2_PRESENT": ("COND_2", "any"),
        "C3_PRESENT": ("COND_3", "any"),
        "AVG_SPREAD": ("SPREAD", "mean"),
        "MAX_SPREAD": ("SPREAD", "max"),
        "AVG_OFFER_PRICE": ("OFFER_PRICE", "mean"),
        "SUM_VOLUME": (
            "OFFER_VOLUME_MWH" if "OFFER_VOLUME_MWH" in df_window.columns else "SETTLEMENT_PERIOD",
            "sum" if "OFFER_VOLUME_MWH" in df_window.columns else "count",
        ),
    }

    if "CONSTRAINT_GROUP" in df_window.columns:
        agg_dict["CONSTRAINT_GROUP"] = ("CONSTRAINT_GROUP", "first")

    if has_impact:
        agg_dict["TOTAL_IMPACT_SP"] = ("IMPACT_SP", "sum")

    grouped = df_window.groupby(["window_id", "BMU_ID"]).agg(**agg_dict).reset_index()

    grouped["DURATION_MIN"] = grouped["COUNT_SP"] * 30
    grouped["IMPACT_WINDOW"] = (
        grouped["TOTAL_IMPACT_SP"]
        if has_impact
        else (grouped["AVG_SPREAD"] * grouped["SUM_VOLUME"])
    )
    grouped["UNIQUE_ID"] = grouped["START_LOCAL"].dt.strftime("%Y%m%d%H%M") + grouped[
        "window_id"
    ].astype(str)

    for col in ["AVG_SPREAD", "MAX_SPREAD", "AVG_OFFER_PRICE"]:
        if col in grouped.columns:
            grouped[col] = grouped[col].round(2)
    grouped["IMPACT_WINDOW"] = grouped["IMPACT_WINDOW"].round(2)

    base_cols = ["BMU_ID"]
    if "CONSTRAINT_GROUP" in grouped.columns:
        base_cols.append("CONSTRAINT_GROUP")
    base_cols.extend(
        [
            "FUEL_TYPE",
            "COUNTERPARTY",
            "START_GMT",
            "END_GMT",
            "START_LOCAL",
            "END_LOCAL",
            "DURATION_MIN",
            "COUNT_SP",
            "C1_PRESENT",
            "C2_PRESENT",
            "C3_PRESENT",
            "AVG_SPREAD",
            "MAX_SPREAD",
            "AVG_OFFER_PRICE",
            "SUM_VOLUME",
            "IMPACT_WINDOW",
            "UNIQUE_ID",
        ]
    )
    if has_impact:
        base_cols.append("TOTAL_IMPACT_SP")

    valid_cols = [c for c in base_cols if c in grouped.columns]
    return grouped[valid_cols]


def get_sp_workspace_data(
    start_date: str,
    end_date: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """High-level service fetching and enriching settlement period data for the analytical workspace."""
    raw_records = sp_analytics_repository.get_sp_data_for_period(
        start_date, end_date, db_path=db_path
    )
    if not raw_records:
        empty_df = pd.DataFrame()
        return {
            "sp_df": empty_df,
            "alerts_df": empty_df,
            "windows_df": empty_df,
            "filter_options": {"bmus": [], "fuels": [], "parties": [], "constraint_groups": []},
        }

    raw_df = pd.DataFrame(raw_records)
    sp_df = preprocess_data(raw_df)

    ensemble_raw = sp_df[sp_df["BEHAVIOUR_CLASS"] == "Constrained - ensemble"].copy()
    alerts_df = enrich_alerts_with_impact(ensemble_raw)
    windows_df = infer_alerts_windows(alerts_df)

    bmus = sorted(list(sp_df["BMU_ID"].dropna().unique())) if "BMU_ID" in sp_df.columns else []
    fuels = (
        sorted(list(sp_df["FUEL_TYPE"].dropna().unique())) if "FUEL_TYPE" in sp_df.columns else []
    )
    parties = (
        sorted(list(sp_df["COUNTERPARTY"].dropna().unique()))
        if "COUNTERPARTY" in sp_df.columns
        else []
    )
    c_groups = (
        sorted(list(sp_df["CONSTRAINT_GROUP"].dropna().unique()))
        if "CONSTRAINT_GROUP" in sp_df.columns
        else []
    )

    return {
        "sp_df": sp_df,
        "alerts_df": alerts_df,
        "windows_df": windows_df,
        "filter_options": {
            "bmus": bmus,
            "fuels": fuels,
            "parties": parties,
            "constraint_groups": c_groups,
        },
    }
