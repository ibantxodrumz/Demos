from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import pandas as pd
from src.repositories import analytics_repository


def parse_why(why_str: Any) -> Tuple[str, str]:
    if pd.isna(why_str) or str(why_str).strip() == "" or str(why_str).strip().lower() == "nan":
        return "", ""
    parts = str(why_str).split("|")
    conditions = parts[0].strip()
    details = " | ".join(p.strip() for p in parts[1:]) if len(parts) > 1 else ""
    return conditions, details


def get_behaviour_class(n_cond_true: int) -> str:
    if n_cond_true == 0:
        return "Constrained - normal behaviour"
    elif n_cond_true == 1:
        return "Constrained - elevated signal"
    else:
        return "Constrained - ensemble"


def enrich_sp_data(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    res = df.copy()

    # Normalize condition counts
    for col in ["COND_1", "COND_2", "COND_3"]:
        if col not in res.columns:
            res[col] = 0

    if "N_CONDITIONS_TRUE" not in res.columns:
        res["N_CONDITIONS_TRUE"] = res[["COND_1", "COND_2", "COND_3"]].sum(axis=1)

    res["BEHAVIOUR_CLASS"] = res["N_CONDITIONS_TRUE"].apply(get_behaviour_class)

    # Parse WHY
    if "WHY" in res.columns:
        parsed = res["WHY"].apply(parse_why)
        res["WHY_CONDITIONS"] = [p[0] for p in parsed]
        res["WHY_DETAILS"] = [p[1] for p in parsed]

    # Calculate financial/operational impact estimates
    materiality = 30.0

    def calc_c1(r):
        spread = r.get("SPREAD") or 0.0
        med_uncon = r.get("MED_SPREAD_UNCON") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_1") and pd.notna(med_uncon):
            return max(spread - med_uncon, 0.0) * vol
        return 0.0

    def calc_c2(r):
        price = r.get("OFFER_PRICE") or 0.0
        thr_fuel = r.get("THR_FUEL") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_2") and pd.notna(thr_fuel):
            return max(price - thr_fuel, 0.0) * vol
        return 0.0

    def calc_c3(r):
        spread = r.get("SPREAD") or 0.0
        med_uncon = r.get("MED_SPREAD_UNCON") or 0.0
        vol = r.get("OFFER_VOLUME_MWH") or 0.0
        if r.get("COND_3") and pd.notna(med_uncon):
            return max(spread - (med_uncon + materiality), 0.0) * vol
        return 0.0

    res["IMPACT_C1"] = res.apply(calc_c1, axis=1)
    res["IMPACT_C2"] = res.apply(calc_c2, axis=1)
    res["IMPACT_C3"] = res.apply(calc_c3, axis=1)
    res["IMPACT_SP"] = res[["IMPACT_C1", "IMPACT_C2", "IMPACT_C3"]].mean(axis=1).round(2)

    if "OFFER_VOLUME_MWH" in res.columns:
        res["ACCEPTED_VOL_MWH"] = res["OFFER_VOLUME_MWH"].round(2)
    else:
        res["ACCEPTED_VOL_MWH"] = (
            res["IMPACT_SP"] / res["SPREAD"].replace(0, 1.0)
        ).round(2)

    return res


def get_aggregated_info_for_analyst(
    bmu_id: str,
    start_gmt: str,
    end_gmt: str,
    db_path: Optional[Union[Path, str]] = None,
) -> str:
    why_list = analytics_repository.get_why_values_for_alert(
        bmu_id, start_gmt, end_gmt, db_path=db_path
    )
    if not why_list:
        return ""
    return " | ".join(why_list)


def get_alert_evidence_payload(
    bmu_id: str,
    start_gmt: str,
    end_gmt: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    raw_sp = analytics_repository.get_sp_evidence_for_alert(
        bmu_id, start_gmt, end_gmt, db_path=db_path
    )
    df = pd.DataFrame(raw_sp) if raw_sp else pd.DataFrame()

    if not df.empty:
        df = enrich_sp_data(df)
        info_for_analyst = get_aggregated_info_for_analyst(
            bmu_id, start_gmt, end_gmt, db_path=db_path
        )
        avg_spread = float(df["SPREAD"].mean()) if "SPREAD" in df.columns else 0.0
        avg_offer_price = float(df["OFFER_PRICE"].mean()) if "OFFER_PRICE" in df.columns else 0.0
        avg_ref_price = (
            float(df["REFERENCE_PRICE"].mean()) if "REFERENCE_PRICE" in df.columns else 0.0
        )
        total_estimated_impact = float(df["IMPACT_SP"].sum()) if "IMPACT_SP" in df.columns else 0.0
        records = df.to_dict(orient="records")
    else:
        info_for_analyst = ""
        avg_spread = 0.0
        avg_offer_price = 0.0
        avg_ref_price = 0.0
        total_estimated_impact = 0.0
        records = []

    return {
        "sp_records": records,
        "sp_count": len(records),
        "info_for_analyst": info_for_analyst,
        "metrics": {
            "avg_spread": round(avg_spread, 2),
            "avg_offer_price": round(avg_offer_price, 2),
            "avg_ref_price": round(avg_ref_price, 2),
            "total_estimated_impact": round(total_estimated_impact, 2),
        },
    }
