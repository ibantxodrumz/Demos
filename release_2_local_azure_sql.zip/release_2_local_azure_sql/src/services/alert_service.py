from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.repositories import alert_repository


def derive_review_status(row: Dict[str, Any]) -> str:
    """
    Derive the logical display status:
    - If no linked ACTIVITY_LOG or ANALYSIS_STATUS is null/empty -> Unreviewed
    - If ANALYSIS_STATUS == 'Open' -> Open
    - If ANALYSIS_STATUS == 'Closed' -> Closed
    """
    status = row.get("ANALYSIS_STATUS")
    if not status or str(status).strip() == "":
        return "Unreviewed"
    return str(status).strip()


def get_alerts_for_period(
    start_date: str,
    end_date: str,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    status_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    raw_alerts = alert_repository.get_alerts_by_date_range(start_date, end_date, db_path=db_path)

    processed_alerts = []
    bmu_options = set()
    party_options = set()
    fuel_options = set()

    for item in raw_alerts:
        item["DISPLAY_STATUS"] = derive_review_status(item)
        if item.get("BMU_ID"):
            bmu_options.add(item["BMU_ID"])
        if item.get("COUNTERPARTY"):
            party_options.add(item["COUNTERPARTY"])
        if item.get("FUEL_TYPE"):
            fuel_options.add(item["FUEL_TYPE"])

        # Apply filters
        if bmu_filter and item.get("BMU_ID") != bmu_filter:
            continue
        if party_filter and item.get("COUNTERPARTY") != party_filter:
            continue
        if fuel_filter and item.get("FUEL_TYPE") != fuel_filter:
            continue
        if status_filter and status_filter != "All":
            if item["DISPLAY_STATUS"] != status_filter:
                continue

        processed_alerts.append(item)

    total_count = len(processed_alerts)
    unreviewed_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Unreviewed")
    open_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Open")
    closed_count = sum(1 for a in processed_alerts if a["DISPLAY_STATUS"] == "Closed")

    return {
        "alerts": processed_alerts,
        "summary": {
            "total_count": total_count,
            "unreviewed_count": unreviewed_count,
            "open_count": open_count,
            "closed_count": closed_count,
        },
        "filter_options": {
            "bmus": sorted(list(bmu_options)),
            "parties": sorted(list(party_options)),
            "fuels": sorted(list(fuel_options)),
            "statuses": ["All", "Unreviewed", "Open", "Closed"],
        },
    }


def get_alert_by_id(
    unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    alert = alert_repository.get_alert_by_unique_id(unique_id, db_path=db_path)
    if alert:
        alert["DISPLAY_STATUS"] = derive_review_status(alert)
    return alert


def get_available_time_options() -> Dict[str, Any]:
    """
    Returns structured options for time period selection:
    Months, ISO weeks, and date bounds.
    """
    months = [
        {
            "label": "January 2026",
            "value": "2026-01-01|2026-01-31",
            "start": "2026-01-01",
            "end": "2026-01-31",
        },
        {
            "label": "February 2026",
            "value": "2026-02-01|2026-02-28",
            "start": "2026-02-01",
            "end": "2026-02-28",
        },
        {
            "label": "March 2026",
            "value": "2026-03-01|2026-03-31",
            "start": "2026-03-01",
            "end": "2026-03-31",
        },
        {
            "label": "April 2026",
            "value": "2026-04-01|2026-04-30",
            "start": "2026-04-01",
            "end": "2026-04-30",
        },
        {
            "label": "May 2026",
            "value": "2026-05-01|2026-05-31",
            "start": "2026-05-01",
            "end": "2026-05-31",
        },
        {
            "label": "June 2026",
            "value": "2026-06-01|2026-06-30",
            "start": "2026-06-01",
            "end": "2026-06-30",
        },
    ]

    weeks = [
        {
            "label": "Week 01 (Jan 01 - Jan 04, 2026)",
            "value": "2026-01-01|2026-01-04",
            "start": "2026-01-01",
            "end": "2026-01-04",
        },
        {
            "label": "Week 02 (Jan 05 - Jan 11, 2026)",
            "value": "2026-01-05|2026-01-11",
            "start": "2026-01-05",
            "end": "2026-01-11",
        },
        {
            "label": "Week 03 (Jan 12 - Jan 18, 2026)",
            "value": "2026-01-12|2026-01-18",
            "start": "2026-01-12",
            "end": "2026-01-18",
        },
        {
            "label": "Week 04 (Jan 19 - Jan 25, 2026)",
            "value": "2026-01-19|2026-01-25",
            "start": "2026-01-19",
            "end": "2026-01-25",
        },
        {
            "label": "Week 05 (Jan 26 - Feb 01, 2026)",
            "value": "2026-01-26|2026-02-01",
            "start": "2026-01-26",
            "end": "2026-02-01",
        },
        {
            "label": "Week 06 (Feb 02 - Feb 08, 2026)",
            "value": "2026-02-02|2026-02-08",
            "start": "2026-02-02",
            "end": "2026-02-08",
        },
        {
            "label": "Week 07 (Feb 09 - Feb 15, 2026)",
            "value": "2026-02-09|2026-02-15",
            "start": "2026-02-09",
            "end": "2026-02-15",
        },
        {
            "label": "Week 08 (Feb 16 - Feb 22, 2026)",
            "value": "2026-02-16|2026-02-22",
            "start": "2026-02-16",
            "end": "2026-02-22",
        },
        {
            "label": "Week 09 (Feb 23 - Mar 01, 2026)",
            "value": "2026-02-23|2026-03-01",
            "start": "2026-02-23",
            "end": "2026-03-01",
        },
        {
            "label": "Week 10 (Mar 02 - Mar 08, 2026)",
            "value": "2026-03-02|2026-03-08",
            "start": "2026-03-02",
            "end": "2026-03-08",
        },
        {
            "label": "Week 11 (Mar 09 - Mar 15, 2026)",
            "value": "2026-03-09|2026-03-15",
            "start": "2026-03-09",
            "end": "2026-03-15",
        },
        {
            "label": "Week 12 (Mar 16 - Mar 22, 2026)",
            "value": "2026-03-16|2026-03-22",
            "start": "2026-03-16",
            "end": "2026-03-22",
        },
        {
            "label": "Week 13 (Mar 23 - Mar 29, 2026)",
            "value": "2026-03-23|2026-03-29",
            "start": "2026-03-23",
            "end": "2026-03-29",
        },
        {
            "label": "Week 14 (Mar 30 - Apr 05, 2026)",
            "value": "2026-03-30|2026-04-05",
            "start": "2026-03-30",
            "end": "2026-04-05",
        },
        {
            "label": "Week 15 (Apr 06 - Apr 12, 2026)",
            "value": "2026-04-06|2026-04-12",
            "start": "2026-04-06",
            "end": "2026-04-12",
        },
        {
            "label": "Week 16 (Apr 13 - Apr 19, 2026)",
            "value": "2026-04-13|2026-04-19",
            "start": "2026-04-13",
            "end": "2026-04-19",
        },
        {
            "label": "Week 17 (Apr 20 - Apr 26, 2026)",
            "value": "2026-04-20|2026-04-26",
            "start": "2026-04-20",
            "end": "2026-04-26",
        },
        {
            "label": "Week 18 (Apr 27 - May 03, 2026)",
            "value": "2026-04-27|2026-05-03",
            "start": "2026-04-27",
            "end": "2026-05-03",
        },
        {
            "label": "Week 19 (May 04 - May 10, 2026)",
            "value": "2026-05-04|2026-05-10",
            "start": "2026-05-04",
            "end": "2026-05-10",
        },
        {
            "label": "Week 20 (May 11 - May 17, 2026)",
            "value": "2026-05-11|2026-05-17",
            "start": "2026-05-11",
            "end": "2026-05-17",
        },
        {
            "label": "Week 21 (May 18 - May 24, 2026)",
            "value": "2026-05-18|2026-05-24",
            "start": "2026-05-18",
            "end": "2026-05-24",
        },
        {
            "label": "Week 22 (May 25 - May 31, 2026)",
            "value": "2026-05-25|2026-05-31",
            "start": "2026-05-25",
            "end": "2026-05-31",
        },
        {
            "label": "Week 23 (Jun 01 - Jun 07, 2026)",
            "value": "2026-06-01|2026-06-07",
            "start": "2026-06-01",
            "end": "2026-06-07",
        },
        {
            "label": "Week 24 (Jun 08 - Jun 14, 2026)",
            "value": "2026-06-08|2026-06-14",
            "start": "2026-06-08",
            "end": "2026-06-14",
        },
        {
            "label": "Week 25 (Jun 15 - Jun 21, 2026)",
            "value": "2026-06-15|2026-06-21",
            "start": "2026-06-15",
            "end": "2026-06-21",
        },
        {
            "label": "Week 26 (Jun 22 - Jun 28, 2026)",
            "value": "2026-06-22|2026-06-28",
            "start": "2026-06-22",
            "end": "2026-06-28",
        },
        {
            "label": "Week 27 (Jun 29 - Jun 30, 2026)",
            "value": "2026-06-29|2026-06-30",
            "start": "2026-06-29",
            "end": "2026-06-30",
        },
    ]

    return {
        "months": months,
        "weeks": weeks,
        "min_date": "2026-01-01",
        "max_date": "2026-06-30",
    }


def get_reviews_by_status_for_period(
    target_status: str,
    start_date: str,
    end_date: str,
    bmu_filter: Optional[str] = None,
    party_filter: Optional[str] = None,
    fuel_filter: Optional[str] = None,
    action_filter: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Retrieve alerts specifically filtered by target_status ('Open' or 'Closed') for a given period.
    """
    period_res = get_alerts_for_period(
        start_date=start_date,
        end_date=end_date,
        bmu_filter=bmu_filter,
        party_filter=party_filter,
        fuel_filter=fuel_filter,
        status_filter=target_status,
        db_path=db_path,
    )

    alerts = period_res["alerts"]
    if action_filter and action_filter != "All":
        alerts = [a for a in alerts if a.get("ACTION_TAKEN") == action_filter]

    action_options = sorted(list(set(a.get("ACTION_TAKEN") for a in alerts if a.get("ACTION_TAKEN"))))

    return {
        "alerts": alerts,
        "summary": {
            "count": len(alerts),
            "autoclose_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "AutoClose"),
            "monitor_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "Monitor Ongoing"),
            "escalated_count": sum(1 for a in alerts if a.get("ACTION_TAKEN") == "Escalated to Compliance"),
        },
        "filter_options": {
            "bmus": period_res["filter_options"]["bmus"],
            "parties": period_res["filter_options"]["parties"],
            "fuels": period_res["filter_options"]["fuels"],
            "actions": ["All"] + action_options,
        },
    }
