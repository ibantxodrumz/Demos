from typing import Any, Dict, List
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def build_price_comparison_chart(records: List[Dict[str, Any]]) -> go.Figure:
    if not records:
        fig = go.Figure()
        fig.update_layout(
            title="No Settlement Period Evidence Available",
            template="plotly_white",
            font=dict(family="Inter, Segoe UI, sans-serif"),
        )
        return fig

    df = pd.DataFrame(records).copy()

    if "LOCAL_DATETIME" in df.columns:
        df["dt"] = pd.to_datetime(df["LOCAL_DATETIME"])
        df = df.sort_values("dt").reset_index(drop=True)
        last_dt = df["dt"].iloc[-1] + pd.Timedelta(minutes=30)
        times = list(df["dt"]) + [last_dt]
        offer_prices = list(df["OFFER_PRICE"]) + [df["OFFER_PRICE"].iloc[-1]]
        ref_prices = (
            list(df["REFERENCE_PRICE"]) + [df["REFERENCE_PRICE"].iloc[-1]]
            if "REFERENCE_PRICE" in df.columns
            else []
        )
    else:
        x_col = "GMT_FROM" if "GMT_FROM" in df.columns else "SETTLEMENT_PERIOD"
        times = list(df[x_col])
        offer_prices = list(df.get("OFFER_PRICE", []))
        ref_prices = list(df.get("REFERENCE_PRICE", []))

    fig = go.Figure()
    if len(offer_prices) > 0:
        fig.add_trace(
            go.Scatter(
                x=times,
                y=offer_prices,
                mode="lines+markers",
                name="OFFER_PRICE",
                line=dict(color="#4e0038", width=2.5),
                marker=dict(size=6),
            )
        )
    if len(ref_prices) > 0:
        fig.add_trace(
            go.Scatter(
                x=times,
                y=ref_prices,
                mode="lines+markers",
                name="REFERENCE_PRICE",
                line=dict(color="#0284c7", width=2.0),
                marker=dict(size=6),
            )
        )

    fig.update_layout(
        title=dict(
            text="Offer Price vs Reference Price (£/MWh)",
            font=dict(size=14, color="#0f172a", family="Inter, Segoe UI, sans-serif"),
        ),
        xaxis_title="Date & Time",
        yaxis_title="Price (£/MWh)",
        hovermode="x unified",
        template="plotly_white",
        font=dict(family="Inter, Segoe UI, sans-serif"),
        margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    return fig


def build_spread_chart(records: List[Dict[str, Any]]) -> go.Figure:
    if not records:
        fig = go.Figure()
        fig.update_layout(
            title="No Spread Data Available",
            template="plotly_white",
            font=dict(family="Inter, Segoe UI, sans-serif"),
        )
        return fig

    df = pd.DataFrame(records).copy()

    if "LOCAL_DATETIME" in df.columns:
        df["dt"] = pd.to_datetime(df["LOCAL_DATETIME"])
        df = df.sort_values("dt").reset_index(drop=True)
        last_dt = df["dt"].iloc[-1] + pd.Timedelta(minutes=30)
        times = list(df["dt"]) + [last_dt]
        spreads = list(df["SPREAD"]) + [df["SPREAD"].iloc[-1]]
    else:
        x_col = "GMT_FROM" if "GMT_FROM" in df.columns else "SETTLEMENT_PERIOD"
        times = list(df[x_col])
        spreads = list(df.get("SPREAD", []))

    fig = go.Figure()
    if len(spreads) > 0:
        fig.add_trace(
            go.Scatter(
                x=times,
                y=spreads,
                mode="lines",
                name="Spread (£/MWh)",
                line=dict(color="#4e0038", width=2.5),
            )
        )

    if "ENSEMBLE" in df.columns:
        ens_df = df[df["ENSEMBLE"] == 1]
        if not ens_df.empty:
            ens_times = (
                pd.to_datetime(ens_df["LOCAL_DATETIME"])
                if "LOCAL_DATETIME" in ens_df.columns
                else ens_df.get("GMT_FROM", ens_df.index)
            )
            fig.add_trace(
                go.Scatter(
                    x=ens_times,
                    y=ens_df["SPREAD"],
                    mode="markers",
                    name="Ensemble Breach",
                    marker=dict(color="#ef4444", size=8, symbol="circle"),
                    hovertemplate="Ensemble Breach<br>Time: %{x}<br>Spread: £%{y:.2f}/MWh<extra></extra>",
                )
            )

    fig.update_layout(
        title=dict(
            text="Price Spread Over Time (£/MWh)",
            font=dict(size=14, color="#0f172a", family="Inter, Segoe UI, sans-serif"),
        ),
        xaxis_title="Date & Time",
        yaxis_title="Spread (£/MWh)",
        hovermode="x unified",
        template="plotly_white",
        font=dict(family="Inter, Segoe UI, sans-serif"),
        margin=dict(l=40, r=40, t=50, b=40),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    return fig


def build_conditions_timeline(records: List[Dict[str, Any]]) -> go.Figure:
    if not records:
        fig = go.Figure()
        fig.update_layout(
            title="No Breach Conditions Available",
            template="plotly_white",
            font=dict(family="Inter, Segoe UI, sans-serif"),
        )
        return fig

    df = pd.DataFrame(records)
    x_col = "LOCAL_DATETIME" if "LOCAL_DATETIME" in df.columns else "GMT_FROM"

    colors = []
    for _, r in df.iterrows():
        ens = r.get("ENSEMBLE", 0)
        n_cond = r.get("N_CONDITIONS_TRUE", 0)
        if ens == 1 or n_cond >= 2:
            colors.append("#c026d3")  # NESO Magenta/Purple for ensemble breach
        elif n_cond == 1:
            colors.append("#d97706")  # Amber for elevated signal
        else:
            colors.append("#16a34a")  # Green for normal

    fig = go.Figure()
    if "N_CONDITIONS_TRUE" in df.columns:
        fig.add_trace(
            go.Bar(
                x=df[x_col],
                y=df["N_CONDITIONS_TRUE"],
                name="Breach Conditions Count",
                marker_color=colors,
                text=df["BEHAVIOUR_CLASS"] if "BEHAVIOUR_CLASS" in df.columns else None,
            )
        )

    fig.update_layout(
        title=dict(
            text="Breach Conditions Severity Timeline (ENSEMBLE Breaches in Magenta)",
            font=dict(size=14, color="#4e0038", family="Inter, Segoe UI, sans-serif"),
        ),
        xaxis_title="Time",
        yaxis_title="Active Conditions Count (0-3)",
        yaxis=dict(dtick=1, range=[0, 3.5]),
        template="plotly_white",
        font=dict(family="Inter, Segoe UI, sans-serif"),
        margin=dict(l=40, r=40, t=50, b=40),
    )
    return fig
