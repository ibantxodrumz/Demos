import urllib.parse
from typing import Optional


def get_bmrs_bmu_url(bmu_id: str) -> str:
    """
    Generates external link to Elexon BMRS portal for a specific BMU.
    """
    if not bmu_id or str(bmu_id).strip() == "":
        return "https://bmrs.elexon.co.uk/"
    encoded_bmu = urllib.parse.quote(str(bmu_id).strip())
    return f"https://bmrs.elexon.co.uk/bmu/{encoded_bmu}"


def get_bmrs_remit_url(bmu_id: str) -> str:
    """
    Generates external link to Elexon REMIT portal for a specific BMU.
    """
    if not bmu_id or str(bmu_id).strip() == "":
        return "https://www.elexonportal.co.uk/news/latest"
    encoded_bmu = urllib.parse.quote(str(bmu_id).strip())
    return f"https://bmrs.elexon.co.uk/remit?bmu={encoded_bmu}"
