from datetime import datetime
from typing import Optional, Union


def format_currency(value: Optional[Union[int, float]]) -> str:
    if value is None:
        return "£0.00"
    try:
        return f"£{float(value):,.2f}"
    except (ValueError, TypeError):
        return "£0.00"


def format_number(value: Optional[Union[int, float]], decimal_places: int = 2) -> str:
    if value is None:
        return "-"
    try:
        return f"{float(value):,.{decimal_places}f}"
    except (ValueError, TypeError):
        return "-"


def format_datetime_str(dt_str: Optional[str]) -> str:
    if not dt_str or str(dt_str).strip() == "":
        return "-"
    try:
        dt = datetime.fromisoformat(str(dt_str).replace("Z", "+00:00"))
        return dt.strftime("%d %b %Y %H:%M")
    except ValueError:
        return str(dt_str)
