import dash
from dash import dcc, html

dash.register_page(
    __name__,
    path="/user-guide",
    title="User Guide - Market Monitoring Platform",
)

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Inter, Segoe UI, sans-serif"},
    children=[
        # Page Title Banner
        html.Div(
            style={"marginBottom": "24px"},
            children=[
                html.H2(
                    "Market Monitoring Platform — Analyst User Guide",
                    className="neso-page-title",
                ),
                html.P(
                    "Operational overview covering alert triage, analytical evidence gathering, weekly review meetings, historical audit logs, and repeat behavior analytics.",
                    className="neso-page-subtitle",
                ),
            ],
        ),
        # Quick Start Summary Container
        html.Div(
            style={
                "backgroundColor": "#fdf4fa",
                "border": "1px solid #4e0038",
                "borderRadius": "8px",
                "padding": "20px",
                "marginBottom": "24px",
            },
            children=[
                html.H3("Operational Workflow Overview", style={"margin": "0 0 10px 0", "color": "#4e0038", "fontSize": "16px"}),
                html.P(
                    "The platform supports analysts through 5 core operational stages, providing a consistent framework across active and future monitoring workstreams:",
                    style={"margin": "0 0 14px 0", "color": "#1e293b", "fontSize": "14px"},
                ),
                html.Div(
                    style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))", "gap": "12px"},
                    children=[
                        html.Div([html.Strong("1. Triage Queue"), html.Div("Alert Review", style={"fontSize": "12px", "color": "#64748b"})], style={"backgroundColor": "#ffffff", "padding": "10px 14px", "borderRadius": "6px", "border": "1px solid #f9a8d4"}),
                        html.Div([html.Strong("2. Evidence Support"), html.Div("Analytical Support", style={"fontSize": "12px", "color": "#64748b"})], style={"backgroundColor": "#ffffff", "padding": "10px 14px", "borderRadius": "6px", "border": "1px solid #f9a8d4"}),
                        html.Div([html.Strong("3. Weekly Review"), html.Div("Open Reviews", style={"fontSize": "12px", "color": "#64748b"})], style={"backgroundColor": "#ffffff", "padding": "10px 14px", "borderRadius": "6px", "border": "1px solid #f9a8d4"}),
                        html.Div([html.Strong("4. Audit Archive"), html.Div("Closed Reviews", style={"fontSize": "12px", "color": "#64748b"})], style={"backgroundColor": "#ffffff", "padding": "10px 14px", "borderRadius": "6px", "border": "1px solid #f9a8d4"}),
                        html.Div([html.Strong("5. Governance Analytics"), html.Div("Long-Run Statistics", style={"fontSize": "12px", "color": "#64748b"})], style={"backgroundColor": "#ffffff", "padding": "10px 14px", "borderRadius": "6px", "border": "1px solid #f9a8d4"}),
                    ],
                ),
            ],
        ),
        # Step-by-Step Sections Container
        html.Div(
            style={"display": "flex", "flexDirection": "column", "gap": "20px", "marginBottom": "30px"},
            children=[
                # Step 1: Alert Review
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        "borderLeft": "5px solid #4e0038",
                    },
                    children=[
                        html.H3("Step 1: Daily Alert Triage (Alert Review)", style={"margin": "0 0 10px 0", "color": "#4e0038", "fontSize": "18px"}),
                        html.P("Located on the main landing page. Defaults to displaying unreviewed alerts for the selected operational date window.", style={"color": "#475569", "fontSize": "14px"}),
                        html.Ul(
                            style={"margin": "10px 0", "paddingLeft": "20px", "color": "#1e293b", "fontSize": "14px", "lineHeight": "1.6"},
                            children=[
                                html.Li([html.Strong("Select Monitoring Window: "), "Choose your date range using quick presets, single day selection, or custom start and end dates."]),
                                html.Li([html.Strong("Record Decision Metadata: "), "For each alert, select the appropriate Action Taken (e.g., AutoClose, Monitor Ongoing, Escalated), Analysis Status (Open or Closed), Person Raising, and Analyst Remarks."]),
                                html.Li([html.Strong("Save Decisions: "), "Click 'Save Decisions' to persist your entries to the database."]),
                                html.Li([html.Strong("Operational Queue Filter: "), "Once an alert is saved, it automatically clears from the unreviewed view so you can focus on remaining alerts requiring triage."]),
                            ],
                        ),
                    ],
                ),
                # Step 2: Analytical Support
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        "borderLeft": "5px solid #2563eb",
                    },
                    children=[
                        html.H3("Step 2: Investigation Evidence and Deep Dives (Analytical Support)", style={"margin": "0 0 10px 0", "color": "#2563eb", "fontSize": "18px"}),
                        html.P("Located under 'Analytical Support'. Provides generic diagnostic evidence and context for alert root-cause analysis.", style={"color": "#475569", "fontSize": "14px"}),
                        html.Ul(
                            style={"margin": "10px 0", "paddingLeft": "20px", "color": "#1e293b", "fontSize": "14px", "lineHeight": "1.6"},
                            children=[
                                html.Li([html.Strong("Workstream Diagnostics: "), "Access summary metrics, settlement period breakdowns, market participant views, parameter breach logs, and visual analytics."]),
                                html.Li([html.Strong("External Validation Links: "), "Direct links to Elexon BMRS are provided to validate operational events and market data (additional external platforms TBC post-PoC if required)."]),
                                html.Li([html.Strong("Detailed Event Inspection: "), "Review offer prices, volumes, spreads, and condition flags across relevant time windows."]),
                            ],
                        ),
                    ],
                ),
                # Step 3: Open Reviews
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        "borderLeft": "5px solid #d97706",
                    },
                    children=[
                        html.H3("Step 3: Weekly Team Review Meetings (Open Reviews)", style={"margin": "0 0 10px 0", "color": "#d97706", "fontSize": "18px"}),
                        html.P("Located under 'Open Reviews'. Used during weekly team discussions to review cases undergoing active investigation.", style={"color": "#475569", "fontSize": "14px"}),
                        html.Ul(
                            style={"margin": "10px 0", "paddingLeft": "20px", "color": "#1e293b", "fontSize": "14px", "lineHeight": "1.6"},
                            children=[
                                html.Li([html.Strong("Active Open Cases: "), "Displays all alerts currently classified as 'Open' for the selected period."]),
                                html.Li([html.Strong("Interactive Decision Panel: "), "Select any record to view its full context in the decision panel."]),
                                html.Li([html.Strong("Update and Finalize: "), "Update investigation notes, adjust classifications, or change status to 'Closed' once resolved."]),
                            ],
                        ),
                    ],
                ),
                # Step 4: Closed Reviews
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        "borderLeft": "5px solid #16a34a",
                    },
                    children=[
                        html.H3("Step 4: Historical Audit Trail (Closed Reviews)", style={"margin": "0 0 10px 0", "color": "#16a34a", "fontSize": "18px"}),
                        html.P("Located under 'Closed Reviews'. Provides a complete historical audit trail of all finalized investigations.", style={"color": "#475569", "fontSize": "14px"}),
                        html.Ul(
                            style={"margin": "10px 0", "paddingLeft": "20px", "color": "#1e293b", "fontSize": "14px", "lineHeight": "1.6"},
                            children=[
                                html.Li([html.Strong("Independent Date Search: "), "Search historical periods independently without changing your operational date window."]),
                                html.Li([html.Strong("Audit Filtering: "), "Filter records by market participant, BMU, or Action Taken for compliance and governance reporting."]),
                            ],
                        ),
                    ],
                ),
                # Step 5: Long-Run Statistics
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "24px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                        "borderLeft": "5px solid #7c3aed",
                    },
                    children=[
                        html.H3("Step 5: Repeat Behavior and Governance (Long-Run Statistics)", style={"margin": "0 0 10px 0", "color": "#7c3aed", "fontSize": "18px"}),
                        html.P("Located under 'Long-Run Statistics'. Identifies market participants generating repeated alert volumes or financial impact over time.", style={"color": "#475569", "fontSize": "14px"}),
                        html.Ul(
                            style={"margin": "10px 0", "paddingLeft": "20px", "color": "#1e293b", "fontSize": "14px", "lineHeight": "1.6"},
                            children=[
                                html.Li([html.Strong("Dual Threshold Framing: "), "Specify custom threshold limits for Alert Volume (count) and £ Financial Impact."]),
                                html.Li([html.Strong("Direct Manual Inputs: "), "Type threshold values directly into input fields."]),
                                html.Li([html.Strong("Governance Status Badges: "), "Automatically evaluates market participants against defined thresholds to highlight potential candidates for escalation."]),
                            ],
                        ),
                    ],
                ),
            ],
        ),
    ],
)
