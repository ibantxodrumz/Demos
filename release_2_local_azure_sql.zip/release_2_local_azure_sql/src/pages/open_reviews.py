import dash
from dash import dash_table, dcc, html, Input, Output, State, callback
import pandas as pd

from src.config.settings import LOCAL_ANALYST_NAME
from src.models.activity_log import CONTROLLED_ACTIONS, CONTROLLED_STATUSES
from src.services import activity_log_service, alert_service, analytics_service
from src.utils.bmrs_links import get_bmrs_bmu_url, get_bmrs_remit_url

dash.register_page(
    __name__, path="/open-reviews", title="Open Reviews - Market Monitoring Platform"
)

time_opts = alert_service.get_available_time_options()

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Inter, Segoe UI, sans-serif"},
    children=[
        # Title Banner
        html.Div(
            style={"marginBottom": "20px"},
            children=[
                html.H2(
                    "Open Reviews Workspace — Active Investigations",
                    className="neso-page-title",
                ),
                html.P(
                    "Weekly review workspace tracking open alerts. Re-evaluate evidence, update comments, or close resolved alerts.",
                    className="neso-page-subtitle",
                ),
            ],
        ),
        # Controls Card: Workstream & Date Period Selection
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "20px",
            },
            children=[
                # Workstream Domain Selector
                html.Div(
                    style={"marginBottom": "16px"},
                    children=[
                        html.Label(
                            "Active Workstream Domain:",
                            style={"fontWeight": "600", "fontSize": "13px", "marginBottom": "6px", "display": "block"},
                        ),
                        dcc.Dropdown(
                            id="open-workstream-domain",
                            options=[
                                {"label": "Import Constraints (Active)", "value": "import_constraints"},
                                {"label": "TBC (Upcoming)", "value": "tbc_1", "disabled": True},
                                {"label": "TBC (Upcoming)", "value": "tbc_2", "disabled": True},
                            ],
                            value="import_constraints",
                            clearable=False,
                            style={"width": "100%"},
                        ),
                    ],
                ),
                # Time Controls Row
                html.Div(
                    style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(220px, 1fr))", "gap": "16px", "marginBottom": "16px"},
                    children=[
                        html.Div([
                            html.Label("Start Date:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.DatePickerSingle(
                                id="open-picker-start-date",
                                min_date_allowed=time_opts["min_date"],
                                max_date_allowed=time_opts["max_date"],
                                initial_visible_month="2026-02-02",
                                date="2026-02-02",
                                display_format="YYYY-MM-DD",
                                style={"width": "100%"},
                            ),
                        ]),
                        html.Div([
                            html.Label("End Date:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.DatePickerSingle(
                                id="open-picker-end-date",
                                min_date_allowed=time_opts["min_date"],
                                max_date_allowed=time_opts["max_date"],
                                initial_visible_month="2026-02-08",
                                date="2026-02-08",
                                display_format="YYYY-MM-DD",
                                style={"width": "100%"},
                            ),
                        ]),
                        html.Div([
                            html.Label("Select Whole Week:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(
                                id="open-dropdown-select-week",
                                options=time_opts["weeks"],
                                placeholder="Select a Week Preset...",
                                clearable=True,
                            ),
                        ]),
                        html.Div([
                            html.Label("Select Whole Month:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(
                                id="open-dropdown-select-month",
                                options=time_opts["months"],
                                placeholder="Select a Month Preset...",
                                clearable=True,
                            ),
                        ]),
                    ],
                ),
                # Active Window Indicator Badge
                html.Div(id="open-active-window-badge", style={"marginBottom": "16px"}),
                # Secondary Filters Row
                html.Div(
                    style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))", "gap": "16px"},
                    children=[
                        html.Div([
                            html.Label("Filter BMU:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="open-filter-bmu", placeholder="All BMUs", clearable=True),
                        ]),
                        html.Div([
                            html.Label("Filter Party:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="open-filter-party", placeholder="All Parties", clearable=True),
                        ]),
                        html.Div([
                            html.Label("Filter Fuel Type:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="open-filter-fuel", placeholder="All Fuel Types", clearable=True),
                        ]),
                    ],
                ),
            ],
        ),
        # KPI Summary Cards Container
        html.Div(
            id="open-summary-metrics-container",
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(200px, 1fr))",
                "gap": "16px",
                "marginBottom": "20px",
            },
        ),
        # Main Layout: 2 Columns (Open Queue + Decision Panel)
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "20px"},
            children=[
                # Left Column: Open Reviews Queue DataTable
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3(
                            "Active Open Reviews Queue (Select row to edit / close)",
                            style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                        ),
                        html.Div(id="open-reviews-table-container"),
                    ],
                ),
                # Right Column: Decision Capture & Investigation Panel
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3(
                            "Weekly Review Decision Capture",
                            style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                        ),
                        html.Div(id="open-selected-alert-details-container"),
                        html.Hr(style={"margin": "16px 0", "border": "none", "borderTop": "1px solid #e2e8f0"}),
                        # Decision Inputs
                        html.Div(
                            children=[
                                html.Label("Action Taken:", style={"fontWeight": "600", "fontSize": "13px", "display": "block", "marginBottom": "4px"}),
                                dcc.Dropdown(
                                    id="open-input-action-taken",
                                    options=[{"label": a, "value": a} for a in CONTROLLED_ACTIONS],
                                    placeholder="Select Action Taken...",
                                    style={"marginBottom": "14px"},
                                ),
                                html.Label("Analysis Status:", style={"fontWeight": "600", "fontSize": "13px", "display": "block", "marginBottom": "4px"}),
                                dcc.Dropdown(
                                    id="open-input-analysis-status",
                                    options=[{"label": s, "value": s} for s in CONTROLLED_STATUSES],
                                    placeholder="Select Status...",
                                    style={"marginBottom": "14px"},
                                ),
                                html.Label("Review Comments (Human Input):", style={"fontWeight": "600", "fontSize": "13px", "display": "block", "marginBottom": "4px"}),
                                dcc.Textarea(
                                    id="open-input-review-comments",
                                    placeholder="Enter updated investigation remarks...",
                                    style={
                                        "width": "100%",
                                        "height": "90px",
                                        "padding": "8px",
                                        "borderRadius": "6px",
                                        "borderColor": "#cbd5e1",
                                        "marginBottom": "14px",
                                    },
                                ),
                                html.Button(
                                    "Save Decision to SQL",
                                    id="btn-save-open-review",
                                    n_clicks=0,
                                    className="btn-neso-primary",
                                    style={"width": "100%", "marginBottom": "12px"},
                                ),
                                html.Div(id="open-save-feedback-container"),
                                html.Hr(style={"margin": "14px 0", "border": "none", "borderTop": "1px solid #e2e8f0"}),
                                # Action / External Links
                                html.Div(
                                    id="open-investigation-links-container",
                                    style={"display": "flex", "flexDirection": "column", "gap": "8px"},
                                ),
                            ]
                        ),
                    ],
                ),
            ],
        ),
        # Hidden Stores for State
        dcc.Store(id="open-store-selected-alert-id"),
        dcc.Store(id="open-store-refresh-signal", data=0),
    ],
)


# Preset Handlers
@callback(
    Output("open-picker-start-date", "date"),
    Output("open-picker-end-date", "date"),
    Input("open-dropdown-select-week", "value"),
    Input("open-dropdown-select-month", "value"),
    State("operational-date-store", "data"),
    prevent_initial_call=False,
)
def handle_open_review_dates(week_val, month_val, store_data):
    ctx = dash.callback_context
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0] if ctx.triggered else ""
    if triggered_id == "open-dropdown-select-week" and week_val and "|" in str(week_val):
        parts = str(week_val).split("|")
        return parts[0], parts[1]
    elif triggered_id == "open-dropdown-select-month" and month_val and "|" in str(month_val):
        parts = str(month_val).split("|")
        return parts[0], parts[1]
    elif store_data and "start_date" in store_data and "end_date" in store_data:
        return store_data["start_date"], store_data["end_date"]
    return "2026-02-02", "2026-02-08"


@callback(
    Output("operational-date-store", "data", allow_duplicate=True),
    Input("open-picker-start-date", "date"),
    Input("open-picker-end-date", "date"),
    prevent_initial_call="initial_duplicate",
)
def update_operational_date_store_from_open(start_d, end_d):
    if start_d and end_d:
        return {"start_date": str(start_d)[:10], "end_date": str(end_d)[:10]}
    return dash.no_update


@callback(
    Output("open-active-window-badge", "children"),
    Output("open-reviews-table-container", "children"),
    Output("open-filter-bmu", "options"),
    Output("open-filter-party", "options"),
    Output("open-filter-fuel", "options"),
    Output("open-summary-metrics-container", "children"),
    Input("open-picker-start-date", "date"),
    Input("open-picker-end-date", "date"),
    Input("open-filter-bmu", "value"),
    Input("open-filter-party", "value"),
    Input("open-filter-fuel", "value"),
    Input("open-store-refresh-signal", "data"),
)
def update_open_reviews(start_date, end_date, bmu_f, party_f, fuel_f, refresh_signal):
    if not start_date or not end_date:
        return html.Div("Select valid date window."), html.Div("No dates selected."), [], [], [], []

    start_str = str(start_date)[:10]
    end_str = str(end_date)[:10]

    try:
        d1 = pd.to_datetime(start_str)
        d2 = pd.to_datetime(end_str)
        num_days = (d2 - d1).days + 1
    except Exception:
        num_days = 1

    badge = html.Div(
        style={
            "backgroundColor": "#fdf4fa",
            "border": "1px solid #4e0038",
            "borderRadius": "8px",
            "padding": "10px 16px",
            "fontWeight": "600",
            "color": "#4e0038",
            "fontSize": "13px",
            "display": "flex",
            "alignItems": "center",
            "gap": "12px",
            "flexWrap": "wrap",
        },
        children=[
            html.Span("Active Review Window:"),
            html.Div([
                html.Span("Start Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                html.Strong(start_str, style={"color": "#4e0038", "fontSize": "14px"}),
            ], style={"backgroundColor": "#ffffff", "padding": "4px 10px", "borderRadius": "6px", "border": "1px solid #cbd5e1"}),
            html.Span("───▶", style={"color": "#94a3b8"}),
            html.Div([
                html.Span("End Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                html.Strong(end_str, style={"color": "#4e0038", "fontSize": "14px"}),
            ], style={"backgroundColor": "#ffffff", "padding": "4px 10px", "borderRadius": "6px", "border": "1px solid #cbd5e1"}),
            html.Span(f"({num_days} Day{'s' if num_days != 1 else ''} selected)", style={"color": "#64748b", "fontWeight": "500"}),
        ],
    )

    res = alert_service.get_reviews_by_status_for_period(
        target_status="Open",
        start_date=start_str,
        end_date=end_str,
        bmu_filter=bmu_f,
        party_filter=party_f,
        fuel_filter=fuel_f,
    )

    alerts = res["alerts"]
    summary = res["summary"]
    opts = res["filter_options"]

    cards = [
        html.Div(
            style={
                "backgroundColor": "#fdf4fa",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #f9a8d4",
                "borderRight": "1px solid #f9a8d4",
                "borderBottom": "1px solid #f9a8d4",
            },
            children=[
                html.Div("Total Open Reviews", style={"fontSize": "12px", "color": "#4e0038", "fontWeight": "600"}),
                html.Div(str(summary["count"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#4e0038"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #2563eb",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div("Monitor Ongoing", style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"}),
                html.Div(str(summary["monitor_count"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #d97706",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div("Escalated to Compliance", style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"}),
                html.Div(str(summary["escalated_count"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"}),
            ],
        ),
    ]

    if not alerts:
        table_el = html.Div(
            "No Open reviews found for the selected window and filter criteria.",
            style={"color": "#64748b", "fontStyle": "italic", "padding": "20px 0"},
        )
        return badge, table_el, opts["bmus"], opts["parties"], opts["fuels"], cards

    table_data = []
    for a in alerts:
        uid = a.get("UNIQUE_ID")
        table_data.append({
            "UNIQUE_ID": uid,
            "BMU_ID": a.get("BMU_ID"),
            "COUNTERPARTY": a.get("COUNTERPARTY"),
            "FUEL_TYPE": a.get("FUEL_TYPE"),
            "START_LOCAL": a.get("START_LOCAL"),
            "END_LOCAL": a.get("END_LOCAL"),
            "DURATION_MIN": a.get("DURATION_MIN"),
            "COUNT_SP": a.get("COUNT_SP"),
            "DISPLAY_STATUS": a.get("DISPLAY_STATUS", "Open"),
            "ACTION_TAKEN": a.get("ACTION_TAKEN"),
            "PERSON_RAISING": a.get("PERSON_RAISING"),
            "REVIEW_COMMENTS": a.get("REVIEW_COMMENTS"),
            "UPDATED_DATETIME": a.get("UPDATED_DATETIME"),
            "START_GMT": a.get("START_GMT"),
            "END_GMT": a.get("END_GMT"),
        })

    table_el = dash_table.DataTable(
        id="open-reviews-table",
        columns=[
            {"name": "BMU ID", "id": "BMU_ID"},
            {"name": "Party Name", "id": "COUNTERPARTY"},
            {"name": "Fuel Type", "id": "FUEL_TYPE"},
            {"name": "Start Time (Local)", "id": "START_LOCAL"},
            {"name": "End Time (Local)", "id": "END_LOCAL"},
            {"name": "Duration (min)", "id": "DURATION_MIN"},
            {"name": "SPs", "id": "COUNT_SP"},
            {"name": "Status", "id": "DISPLAY_STATUS"},
            {"name": "Action Taken", "id": "ACTION_TAKEN"},
            {"name": "Person Raising", "id": "PERSON_RAISING"},
            {"name": "Review Comments", "id": "REVIEW_COMMENTS"},
            {"name": "Last Updated", "id": "UPDATED_DATETIME"},
        ],
        data=table_data,
        row_selectable="multi",
        selected_rows=[],
        style_table={"overflowX": "auto", "borderRadius": "8px", "border": "1px solid #e2e8f0"},
        style_header={
            "backgroundColor": "#edf1f7",
            "color": "#4e0038",
            "fontWeight": "700",
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "borderBottom": "2px solid #cbd5e1",
        },
        style_cell={
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "fontFamily": "Inter, Segoe UI, sans-serif",
            "whiteSpace": "normal",
            "height": "auto",
            "color": "#1e293b",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#f8fafc"},
            {"if": {"state": "selected"}, "backgroundColor": "#fdf4fa", "border": "1px solid #4e0038"},
            {"if": {"column_id": "DISPLAY_STATUS"}, "color": "#2563eb", "fontWeight": "700"},
        ],
        page_size=15,
    )

    return badge, table_el, opts["bmus"], opts["parties"], opts["fuels"], cards


# Open Alert Selection Callback
@callback(
    Output("open-store-selected-alert-id", "data"),
    Output("open-selected-alert-details-container", "children"),
    Output("open-input-action-taken", "value"),
    Output("open-input-analysis-status", "value"),
    Output("open-input-review-comments", "value"),
    Output("open-investigation-links-container", "children"),
    Input("open-reviews-table", "selected_rows"),
    State("open-reviews-table", "data"),
)
def handle_open_alert_selection(selected_rows, alerts_data):
    if not selected_rows or not alerts_data:
        no_select = html.Div(
            "Select one or more open alert rows to inspect and capture decision.",
            style={"color": "#64748b", "fontStyle": "italic", "fontSize": "13px"},
        )
        return None, no_select, None, None, "", []

    valid_indices = [idx for idx in selected_rows if idx < len(alerts_data)]
    if not valid_indices:
        return None, html.Div("No valid alerts selected."), None, None, "", []

    if len(valid_indices) == 1:
        idx = valid_indices[0]
        alert = alerts_data[idx]
        unique_id = alert["UNIQUE_ID"]
        bmu_id = alert["BMU_ID"]

        info_sys = analytics_service.get_aggregated_info_for_analyst(
            bmu_id=bmu_id,
            start_gmt=alert.get("START_GMT", ""),
            end_gmt=alert.get("END_GMT", ""),
        )

        details_card = html.Div(
            style={"fontSize": "13px", "display": "flex", "flexDirection": "column", "gap": "6px"},
            children=[
                html.Div([html.Strong("BMU ID: "), html.Span(bmu_id, style={"color": "#4e0038", "fontWeight": "600"})]),
                html.Div([html.Strong("Counterparty: "), html.Span(alert.get("COUNTERPARTY") or "-")]),
                html.Div([html.Strong("Time Window: "), html.Span(f"{alert.get('START_LOCAL')} to {alert.get('END_LOCAL')}")]),
                html.Div([html.Strong("Duration / SPs: "), html.Span(f"{alert.get('DURATION_MIN')} mins ({alert.get('COUNT_SP')} SPs)")]),
                html.Div([
                    html.Strong("System Info (INFO_FOR_ANALYST): "),
                    html.P(info_sys or "No breach WHY flags", style={"margin": "2px 0 0 0", "color": "#475569", "backgroundColor": "#f8fafc", "padding": "6px", "borderRadius": "4px", "fontSize": "12px"}),
                ]),
            ],
        )

        bmrs_url = get_bmrs_bmu_url(bmu_id)
        remit_url = get_bmrs_remit_url(bmu_id)
        nav_analytical_url = f"/analytical-support?unique_id={unique_id}"

        links = [
            html.A("Open Detailed Analytical Evidence View", href=nav_analytical_url, target="_blank", className="btn-neso-primary", style={"padding": "8px 12px", "textDecoration": "none", "fontSize": "12px", "textAlign": "center"}),
            html.A("View BMU on Elexon BMRS", href=bmrs_url, target="_blank", style={"backgroundColor": "#f1f5f9", "color": "#0f172a", "padding": "6px 12px", "borderRadius": "6px", "textDecoration": "none", "fontSize": "12px", "textAlign": "center", "border": "1px solid #cbd5e1"}),
            html.A("View REMIT Data", href=remit_url, target="_blank", style={"backgroundColor": "#f1f5f9", "color": "#0f172a", "padding": "6px 12px", "borderRadius": "6px", "textDecoration": "none", "fontSize": "12px", "textAlign": "center", "border": "1px solid #cbd5e1"}),
        ]

        return [unique_id], details_card, alert.get("ACTION_TAKEN"), alert.get("DISPLAY_STATUS", "Open"), alert.get("REVIEW_COMMENTS") or "", links

    # Multi-Row Case
    selected_alerts = [alerts_data[idx] for idx in valid_indices]
    unique_ids = [a["UNIQUE_ID"] for a in selected_alerts]
    bmu_ids = sorted(list(set(a["BMU_ID"] for a in selected_alerts)))

    batch_details_card = html.Div(
        style={"fontSize": "13px", "display": "flex", "flexDirection": "column", "gap": "6px"},
        children=[
            html.Div([html.Strong("Batch Mode Active: "), html.Span(f"{len(unique_ids)} open alerts selected", style={"color": "#4e0038", "fontWeight": "700"})]),
            html.Div([html.Strong("Alert IDs: "), html.Span(", ".join(unique_ids))]),
            html.Div([html.Strong("BMU IDs: "), html.Span(", ".join(bmu_ids))]),
            html.Div("Decisions entered below will be applied to ALL selected open alerts.", style={"color": "#64748b", "fontStyle": "italic", "fontSize": "12px", "backgroundColor": "#f8fafc", "padding": "6px", "borderRadius": "4px", "marginTop": "4px"}),
        ],
    )

    return unique_ids, batch_details_card, None, None, "", []


# Save Decision Callback for Open Reviews
@callback(
    Output("open-save-feedback-container", "children"),
    Output("open-store-refresh-signal", "data"),
    Input("btn-save-open-review", "n_clicks"),
    State("open-store-selected-alert-id", "data"),
    State("open-input-action-taken", "value"),
    State("open-input-analysis-status", "value"),
    State("open-input-review-comments", "value"),
    State("open-store-refresh-signal", "data"),
    prevent_initial_call=True,
)
def save_open_review_callback(n_clicks, alert_ids_data, action_taken, analysis_status, comments, current_signal):
    if not alert_ids_data:
        return html.Div("Please select at least one open alert from the table first.", style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"}), current_signal

    if not action_taken or not analysis_status or not comments or not str(comments).strip():
        return html.Div("All fields are required: Select Action Taken, Analysis Status (Open or Closed), and enter Review Comments.", style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"}), current_signal

    target_ids = alert_ids_data if isinstance(alert_ids_data, list) else [str(alert_ids_data)]

    try:
        for aid in target_ids:
            activity_log_service.save_analyst_review(
                alert_unique_id=aid,
                action_taken=action_taken,
                analysis_status=analysis_status,
                review_comments=comments.strip(),
                analyst_name=LOCAL_ANALYST_NAME,
            )

        if analysis_status == "Closed":
            msg_text = f"Review successfully closed for {len(target_ids)} alert(s)! Moved to Closed Reviews Archive."
        else:
            msg_text = f"Review successfully updated for {len(target_ids)} alert(s)."

        msg = html.Div(msg_text, style={"color": "#16a34a", "fontSize": "12px", "fontWeight": "600"})
        return msg, (current_signal or 0) + 1
    except Exception as e:
        msg = html.Div(f"Error persisting review: {str(e)}", style={"color": "#dc2626", "fontSize": "12px", "fontWeight": "600"})
        return msg, current_signal
