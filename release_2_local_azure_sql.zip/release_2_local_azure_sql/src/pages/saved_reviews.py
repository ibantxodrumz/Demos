import dash
from dash import dcc, html

dash.register_page(
    __name__, path="/saved-reviews", title="Closed Reviews - Market Monitoring Platform"
)

layout = html.Div(
    children=[
        dcc.Location(id="redirect-to-closed-reviews", pathname="/closed-reviews"),
        html.Div("Redirecting to Closed Reviews Historical View..."),
    ]
)
