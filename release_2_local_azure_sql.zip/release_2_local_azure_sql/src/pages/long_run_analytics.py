import dash
from dash import dash_table, dcc, html, Input, Output, State, callback
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src.services import alert_service, long_run_service

dash.register_page(
    __name__,
    path="/long-run-analytics",
    title="Long-Run Statistics - Market Monitoring Platform",
)

time_opts = alert_service.get_available_time_options()

layout = html.Div(
    style={"width": "100%", "boxSizing": "border-box", "fontFamily": "Inter, Segoe UI, sans-serif"},
    children=[
        # Title Banner
        html.Div(
            style={"marginBottom": "20px"},
            children=[
                html.H2(
                    "Long-Run Statistics & Repeat Behavior Analytics",
                    className="neso-page-title",
                ),
                html.P(
                    "Evaluate dual threshold framing (Alert Volume & £ Financial Impact), analyze repeat market participant behavior, and support regulatory governance.",
                    className="neso-page-subtitle",
                ),
            ],
        ),
        # Controls Card
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                "marginBottom": "20px",
            },
            children=[
                # Active Workstream Domain
                html.Div(
                    style={"marginBottom": "16px"},
                    children=[
                        html.Label(
                            "Active Workstream Domain:",
                            style={"fontWeight": "600", "fontSize": "13px", "marginBottom": "6px", "display": "block"},
                        ),
                        dcc.Dropdown(
                            id="longrun-workstream-domain",
                            options=[
                                {"label": "Import Constraints (Active)", "value": "import_constraints"},
                                {"label": "TBC (Upcoming)", "value": "tbc_1", "disabled": True},
                                {"label": "TBC (Upcoming)", "value": "tbc_2", "disabled": True},
                            ],
                            value="import_constraints",
                            clearable=False,
                            style={"width": "100%"},
                        ),
                    ],
                ),
                # Quick Presets Bar
                html.Div(
                    style={"display": "flex", "alignItems": "center", "gap": "12px", "marginBottom": "16px", "flexWrap": "wrap"},
                    children=[
                        html.Span("Quick Time Presets:", style={"fontSize": "13px", "fontWeight": "600", "color": "#475569"}),
                        html.Button(
                            "All History / Entire Period",
                            id="btn-longrun-select-all",
                            n_clicks=0,
                            style={
                                "backgroundColor": "#fdf4fa",
                                "color": "#4e0038",
                                "border": "1px solid #4e0038",
                                "padding": "6px 14px",
                                "borderRadius": "6px",
                                "fontWeight": "600",
                                "fontSize": "12px",
                                "cursor": "pointer",
                            },
                        ),
                    ],
                ),
                # Time Controls Row + Dual Threshold Manual Text Inputs
                html.Div(
                    style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(170px, 1fr))", "gap": "16px", "marginBottom": "16px"},
                    children=[
                        html.Div([
                            html.Label("Start Date:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.DatePickerSingle(
                                id="longrun-picker-start-date",
                                min_date_allowed=time_opts["min_date"],
                                max_date_allowed=time_opts["max_date"],
                                initial_visible_month="2026-02-02",
                                date="2026-02-02",
                                display_format="YYYY-MM-DD",
                                style={"width": "100%"},
                            ),
                        ]),
                        html.Div([
                            html.Label("End Date:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.DatePickerSingle(
                                id="longrun-picker-end-date",
                                min_date_allowed=time_opts["min_date"],
                                max_date_allowed=time_opts["max_date"],
                                initial_visible_month="2026-02-08",
                                date="2026-02-08",
                                display_format="YYYY-MM-DD",
                                style={"width": "100%"},
                            ),
                        ]),
                        html.Div([
                            html.Label("Select Any Single Day:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.DatePickerSingle(
                                id="longrun-picker-single-day",
                                min_date_allowed=time_opts["min_date"],
                                max_date_allowed=time_opts["max_date"],
                                placeholder="Pick a Single Day...",
                                display_format="YYYY-MM-DD",
                                style={"width": "100%"},
                            ),
                        ]),
                        html.Div([
                            html.Label("Select Whole Week:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(
                                id="longrun-dropdown-select-week",
                                options=time_opts["weeks"],
                                placeholder="Select a Week Preset...",
                                clearable=True,
                            ),
                        ]),
                        html.Div([
                            html.Label("Select Whole Month:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(
                                id="longrun-dropdown-select-month",
                                options=time_opts["months"],
                                placeholder="Select a Month Preset...",
                                clearable=True,
                            ),
                        ]),
                        # Threshold 1: Alert Volume (Manual Input, No Spinners)
                        html.Div([
                            html.Label("Alert Volume Threshold:", style={"fontSize": "12px", "fontWeight": "700", "color": "#dc2626", "display": "block", "marginBottom": "4px"}),
                            dcc.Input(
                                id="longrun-input-threshold",
                                type="text",
                                value="50",
                                placeholder="Type volume threshold (e.g. 50)...",
                                style={
                                    "width": "100%",
                                    "padding": "8px",
                                    "borderRadius": "6px",
                                    "border": "2px solid #dc2626",
                                    "fontWeight": "700",
                                },
                            ),
                        ]),
                        # Threshold 2: £ Financial Impact Threshold (Manual Input, No Spinners)
                        html.Div([
                            html.Label("£ Impact Threshold (£):", style={"fontSize": "12px", "fontWeight": "700", "color": "#7c3aed", "display": "block", "marginBottom": "4px"}),
                            dcc.Input(
                                id="longrun-input-impact-gbp",
                                type="text",
                                value="4000000",
                                placeholder="Type £ impact threshold (e.g. 4000000)...",
                                style={
                                    "width": "100%",
                                    "padding": "8px",
                                    "borderRadius": "6px",
                                    "border": "2px solid #7c3aed",
                                    "fontWeight": "700",
                                },
                            ),
                        ]),
                    ],
                ),
                # Active Window Indicator Badge
                html.Div(id="longrun-active-window-badge", style={"marginBottom": "16px"}),
                # Secondary Filters Row
                html.Div(
                    style={"display": "grid", "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))", "gap": "16px"},
                    children=[
                        html.Div([
                            html.Label("Filter BMU:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="longrun-filter-bmu", placeholder="All BMUs", clearable=True),
                        ]),
                        html.Div([
                            html.Label("Filter Party:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="longrun-filter-party", placeholder="All Parties", clearable=True),
                        ]),
                        html.Div([
                            html.Label("Filter Fuel Type:", style={"fontSize": "12px", "fontWeight": "600", "display": "block", "marginBottom": "4px"}),
                            dcc.Dropdown(id="longrun-filter-fuel", placeholder="All Fuel Types", clearable=True),
                        ]),
                    ],
                ),
            ],
        ),
        # KPI Summary Cards Container
        html.Div(
            id="longrun-summary-metrics-container",
            style={
                "display": "grid",
                "gridTemplateColumns": "repeat(auto-fit, minmax(180px, 1fr))",
                "gap": "16px",
                "marginBottom": "20px",
            },
        ),
        # Visual Analytics Charts Row
        html.Div(
            style={"display": "grid", "gridTemplateColumns": "2fr 1fr", "gap": "20px", "marginBottom": "20px"},
            children=[
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3("Counterparty Alert Volume & £ Impact Dual Framing", style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"}),
                        dcc.Graph(id="longrun-chart-volume-threshold", config={"displayModeBar": False}),
                    ],
                ),
                html.Div(
                    style={
                        "backgroundColor": "#ffffff",
                        "padding": "20px",
                        "borderRadius": "8px",
                        "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
                    },
                    children=[
                        html.H3("Dual Threshold Framing Distribution", style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"}),
                        dcc.Graph(id="longrun-chart-status-donut", config={"displayModeBar": False}),
                    ],
                ),
            ],
        ),
        # Counterparty Repeat Behavior Table Container
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "20px",
                "borderRadius": "8px",
                "boxShadow": "0 1px 3px rgba(0,0,0,0.1)",
            },
            children=[
                html.H3(
                    "Market Participant Dual Threshold Evaluation Table",
                    style={"margin": "0 0 14px 0", "fontSize": "16px", "color": "#4e0038"},
                ),
                html.Div(id="longrun-table-container"),
            ],
        ),
    ],
)


# Date Control Handlers
@callback(
    Output("longrun-picker-start-date", "date"),
    Output("longrun-picker-end-date", "date"),
    Input("btn-longrun-select-all", "n_clicks"),
    Input("longrun-picker-single-day", "date"),
    Input("longrun-dropdown-select-week", "value"),
    Input("longrun-dropdown-select-month", "value"),
    State("operational-date-store", "data"),
    prevent_initial_call=False,
)
def handle_longrun_dates(all_clicks, single_day_val, week_val, month_val, store_data):
    ctx = dash.callback_context
    triggered_id = ctx.triggered[0]["prop_id"].split(".")[0] if ctx.triggered else ""
    if triggered_id == "btn-longrun-select-all" and all_clicks:
        return "2026-01-01", "2026-06-30"
    elif triggered_id == "longrun-picker-single-day" and single_day_val:
        day_str = str(single_day_val)[:10]
        return day_str, day_str
    elif triggered_id == "longrun-dropdown-select-week" and week_val and "|" in str(week_val):
        parts = str(week_val).split("|")
        return parts[0], parts[1]
    elif triggered_id == "longrun-dropdown-select-month" and month_val and "|" in str(month_val):
        parts = str(month_val).split("|")
        return parts[0], parts[1]
    elif store_data and "start_date" in store_data and "end_date" in store_data:
        return store_data["start_date"], store_data["end_date"]
    return "2026-02-02", "2026-02-08"


# Main Long-Run Analytics Callback
@callback(
    Output("longrun-active-window-badge", "children"),
    Output("longrun-table-container", "children"),
    Output("longrun-filter-bmu", "options"),
    Output("longrun-filter-party", "options"),
    Output("longrun-filter-fuel", "options"),
    Output("longrun-summary-metrics-container", "children"),
    Output("longrun-chart-volume-threshold", "figure"),
    Output("longrun-chart-status-donut", "figure"),
    Input("longrun-picker-start-date", "date"),
    Input("longrun-picker-end-date", "date"),
    Input("longrun-input-threshold", "value"),
    Input("longrun-input-impact-gbp", "value"),
    Input("longrun-filter-bmu", "value"),
    Input("longrun-filter-party", "value"),
    Input("longrun-filter-fuel", "value"),
)
def update_longrun_analytics(start_date, end_date, vol_threshold, gbp_threshold, bmu_f, party_f, fuel_f):
    if not start_date or not end_date:
        empty_fig = go.Figure()
        return html.Div("Select valid date window."), html.Div("No dates selected."), [], [], [], [], empty_fig, empty_fig

    try:
        val_vol = int(str(vol_threshold or "5").replace(",", "").strip())
    except Exception:
        val_vol = 5

    try:
        val_gbp = float(str(gbp_threshold or "50000").replace(",", "").replace("£", "").strip())
    except Exception:
        val_gbp = 50000.0

    start_str = str(start_date)[:10]
    end_str = str(end_date)[:10]

    try:
        d1 = pd.to_datetime(start_str)
        d2 = pd.to_datetime(end_str)
        num_days = (d2 - d1).days + 1
    except Exception:
        num_days = 1

    badge = html.Div(
        style={
            "backgroundColor": "#fdf4fa",
            "border": "1px solid #4e0038",
            "borderRadius": "8px",
            "padding": "10px 16px",
            "fontWeight": "600",
            "color": "#4e0038",
            "fontSize": "13px",
            "display": "flex",
            "alignItems": "center",
            "gap": "12px",
            "flexWrap": "wrap",
        },
        children=[
            html.Span("Active Review Window:"),
            html.Div([
                html.Span("Start Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                html.Strong(start_str, style={"color": "#4e0038", "fontSize": "14px"}),
            ], style={"backgroundColor": "#ffffff", "padding": "4px 10px", "borderRadius": "6px", "border": "1px solid #cbd5e1"}),
            html.Span("───▶", style={"color": "#94a3b8"}),
            html.Div([
                html.Span("End Date: ", style={"color": "#64748b", "fontSize": "12px"}),
                html.Strong(end_str, style={"color": "#4e0038", "fontSize": "14px"}),
            ], style={"backgroundColor": "#ffffff", "padding": "4px 10px", "borderRadius": "6px", "border": "1px solid #cbd5e1"}),
            html.Span(f"({num_days} Day{'s' if num_days != 1 else ''} selected)", style={"color": "#64748b", "fontWeight": "500"}),
            html.Span(f"| Vol Limit: {val_vol} Alerts", style={"color": "#dc2626", "fontWeight": "700"}),
            html.Span(f"| £ Impact Limit: £{val_gbp:,.0f}", style={"color": "#7c3aed", "fontWeight": "700"}),
        ],
    )

    res = long_run_service.get_long_run_counterparty_stats(
        start_date=start_str,
        end_date=end_str,
        threshold_volume=val_vol,
        threshold_impact_gbp=val_gbp,
        bmu_filter=bmu_f,
        party_filter=party_f,
        fuel_filter=fuel_f,
    )

    summary = res["summary"]
    parties_data = res["counterparties"]
    opts = res["filter_options"]

    cards = [
        html.Div(
            style={
                "backgroundColor": "#fdf4fa",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #4e0038",
                "borderTop": "1px solid #f9a8d4",
                "borderRight": "1px solid #f9a8d4",
                "borderBottom": "1px solid #f9a8d4",
            },
            children=[
                html.Div("Total Alerts in Window", style={"fontSize": "12px", "color": "#4e0038", "fontWeight": "600"}),
                html.Div(str(summary["total_alerts"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#4e0038"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#f5f3ff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #7c3aed",
                "borderTop": "1px solid #ddd6fe",
                "borderRight": "1px solid #ddd6fe",
                "borderBottom": "1px solid #ddd6fe",
            },
            children=[
                html.Div("Total Estimated £ Impact", style={"fontSize": "12px", "color": "#6d28d9", "fontWeight": "600"}),
                html.Div(f"£{summary['total_gbp_impact']:,.0f}", style={"fontSize": "20px", "fontWeight": "700", "color": "#6d28d9"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#fef2f2",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #dc2626",
                "borderTop": "1px solid #fca5a5",
                "borderRight": "1px solid #fca5a5",
                "borderBottom": "1px solid #fca5a5",
            },
            children=[
                html.Div(f"Exceeding Vol (≥ {val_vol})", style={"fontSize": "12px", "color": "#991b1b", "fontWeight": "700"}),
                html.Div(str(summary["parties_exceeding_vol_threshold"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#dc2626"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#fff7ed",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #ea580c",
                "borderTop": "1px solid #ffedd5",
                "borderRight": "1px solid #ffedd5",
                "borderBottom": "1px solid #ffedd5",
            },
            children=[
                html.Div(f"Exceeding £ (≥ £{val_gbp:,.0f})", style={"fontSize": "12px", "color": "#c2410c", "fontWeight": "700"}),
                html.Div(str(summary["parties_exceeding_gbp_threshold"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#ea580c"}),
            ],
        ),
        html.Div(
            style={
                "backgroundColor": "#ffffff",
                "padding": "16px 18px",
                "borderRadius": "8px",
                "borderLeft": "4px solid #451a03",
                "borderTop": "1px solid #e2e8f0",
                "borderRight": "1px solid #e2e8f0",
                "borderBottom": "1px solid #e2e8f0",
            },
            children=[
                html.Div("Exceeding Both Thresholds", style={"fontSize": "12px", "color": "#64748b", "fontWeight": "600"}),
                html.Div(str(summary["parties_exceeding_both"]), style={"fontSize": "24px", "fontWeight": "700", "color": "#1e293b"}),
            ],
        ),
    ]

    if not parties_data:
        empty_table = html.Div("No long-run counterparty statistics found for selected filters.", style={"color": "#64748b", "fontStyle": "italic", "padding": "20px 0"})
        empty_fig = go.Figure()
        return badge, empty_table, opts["bmus"], opts["parties"], opts["fuels"], cards, empty_fig, empty_fig

    table_rows = []
    for p in parties_data:
        table_rows.append({
            "COUNTERPARTY": p["COUNTERPARTY"],
            "TOTAL_ALERTS": p["TOTAL_ALERTS"],
            "TOTAL_GBP_IMPACT": f"£{p['TOTAL_GBP_IMPACT']:,.2f}",
            "FRAMING_STATUS": p["FRAMING_STATUS"],
            "UNREVIEWED_COUNT": p["UNREVIEWED_COUNT"],
            "OPEN_COUNT": p["OPEN_COUNT"],
            "CLOSED_COUNT": p["CLOSED_COUNT"],
            "AUTOCLOSE_COUNT": p["AUTOCLOSE_COUNT"],
            "MONITOR_COUNT": p["MONITOR_COUNT"],
            "ESCALATED_COUNT": p["ESCALATED_COUNT"],
            "TOTAL_DURATION_MIN": p["TOTAL_DURATION_MIN"],
            "TOTAL_SPS": p["TOTAL_SPS"],
            "ASSOCIATED_BMUS": ", ".join(p["BMUS"]) if p["BMUS"] else "-",
        })

    table_el = dash_table.DataTable(
        id="longrun-table",
        columns=[
            {"name": "Counterparty Name", "id": "COUNTERPARTY"},
            {"name": "Alert Volume", "id": "TOTAL_ALERTS"},
            {"name": "£ Financial Impact", "id": "TOTAL_GBP_IMPACT"},
            {"name": "Dual Threshold Framing", "id": "FRAMING_STATUS"},
            {"name": "Unreviewed", "id": "UNREVIEWED_COUNT"},
            {"name": "Open Cases", "id": "OPEN_COUNT"},
            {"name": "Closed Cases", "id": "CLOSED_COUNT"},
            {"name": "AutoClosed", "id": "AUTOCLOSE_COUNT"},
            {"name": "Monitor Ongoing", "id": "MONITOR_COUNT"},
            {"name": "Escalated", "id": "ESCALATED_COUNT"},
            {"name": "Duration (min)", "id": "TOTAL_DURATION_MIN"},
            {"name": "SPs Breached", "id": "TOTAL_SPS"},
            {"name": "Associated BMUs", "id": "ASSOCIATED_BMUS"},
        ],
        data=table_rows,
        style_table={"overflowX": "auto", "borderRadius": "8px", "border": "1px solid #e2e8f0"},
        style_header={
            "backgroundColor": "#edf1f7",
            "color": "#4e0038",
            "fontWeight": "700",
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "borderBottom": "2px solid #cbd5e1",
        },
        style_cell={
            "textAlign": "left",
            "padding": "12px 14px",
            "fontSize": "13px",
            "fontFamily": "Inter, Segoe UI, sans-serif",
            "whiteSpace": "normal",
            "height": "auto",
            "color": "#1e293b",
            "borderBottom": "1px solid #f1f5f9",
        },
        style_data_conditional=[
            {"if": {"row_index": "odd"}, "backgroundColor": "#f8fafc"},
            {"if": {"column_id": "FRAMING_STATUS", "filter_query": "{FRAMING_STATUS} contains 'BREACHED BOTH'"}, "color": "#991b1b", "fontWeight": "700", "backgroundColor": "#fef2f2"},
            {"if": {"column_id": "FRAMING_STATUS", "filter_query": "{FRAMING_STATUS} contains 'BREACHED VOLUME'"}, "color": "#c2410c", "fontWeight": "700", "backgroundColor": "#fff7ed"},
            {"if": {"column_id": "FRAMING_STATUS", "filter_query": "{FRAMING_STATUS} contains 'BREACHED £ IMPACT'"}, "color": "#6d28d9", "fontWeight": "700", "backgroundColor": "#f5f3ff"},
            {"if": {"column_id": "FRAMING_STATUS", "filter_query": "{FRAMING_STATUS} contains 'Within Limits'"}, "color": "#16a34a", "fontWeight": "600"},
            {"if": {"column_id": "TOTAL_ALERTS"}, "fontWeight": "700", "color": "#4e0038"},
            {"if": {"column_id": "TOTAL_GBP_IMPACT"}, "fontWeight": "700", "color": "#6d28d9"},
        ],
        page_size=15,
    )

    # 1. Bar Chart: Counterparty Volume & £ Impact
    df_party = pd.DataFrame(parties_data)
    fig_bar = px.bar(
        df_party,
        x="COUNTERPARTY",
        y="TOTAL_ALERTS",
        text="TOTAL_ALERTS",
        title=f"Alert Volume per Counterparty vs. User Thresholds",
        color="FRAMING_STATUS",
        color_discrete_map={
            "BREACHED BOTH (Volume & £ Impact)": "#dc2626",
            f"BREACHED VOLUME (≥ {val_vol} Alerts)": "#ea580c",
            f"BREACHED £ IMPACT (≥ £{val_gbp:,.0f})": "#7c3aed",
            "Within Limits": "#16a34a",
        },
        labels={"COUNTERPARTY": "Market Participant", "TOTAL_ALERTS": "Alert Count", "FRAMING_STATUS": "Framing Status"},
    )
    fig_bar.add_shape(
        type="line",
        x0=-0.5,
        x1=len(df_party) - 0.5,
        y0=val_vol,
        y1=val_vol,
        line=dict(color="#dc2626", width=3, dash="dash"),
    )
    fig_bar.update_layout(
        font_family="Inter",
        plot_bgcolor="#ffffff",
        paper_bgcolor="#ffffff",
        margin=dict(l=40, r=40, t=50, b=50),
        xaxis=dict(tickangle=-30),
        height=340,
    )

    # 2. Donut Chart: Dual Threshold Framing Distribution
    framing_counts = df_party["FRAMING_STATUS"].value_counts().reset_index()
    framing_counts.columns = ["Framing_Status", "Count"]

    fig_donut = px.pie(
        framing_counts,
        values="Count",
        names="Framing_Status",
        hole=0.5,
        color="Framing_Status",
        color_discrete_map={
            "BREACHED BOTH (Volume & £ Impact)": "#dc2626",
            f"BREACHED VOLUME (≥ {val_vol} Alerts)": "#ea580c",
            f"BREACHED £ IMPACT (≥ £{val_gbp:,.0f})": "#7c3aed",
            "Within Limits": "#16a34a",
        },
        title="Dual Threshold Framing Distribution",
    )
    fig_donut.update_layout(
        font_family="Inter",
        paper_bgcolor="#ffffff",
        margin=dict(l=20, r=20, t=50, b=20),
        height=340,
    )

    return badge, table_el, opts["bmus"], opts["parties"], opts["fuels"], cards, fig_bar, fig_donut
