-- =========================================================================
-- Azure SQL DDL Script: Create ACTIVITY_LOG Table & Indexes
-- Target Database: Azure SQL Database (e.g. sqldb-ned-prod / sqldb-ned-dev)
-- Description: Creates the persistence table for analyst review outcomes.
-- =========================================================================

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ACTIVITY_LOG]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ACTIVITY_LOG] (
        [ACTIVITY_LOG_ID]    VARCHAR(255) NOT NULL PRIMARY KEY,
        [ALERT_UNIQUE_ID]    VARCHAR(255) NOT NULL,
        [BMU_ID]             VARCHAR(100) NULL,
        [PARTY_NAME]         VARCHAR(255) NULL,
        [PARAMETER_BREACHED] VARCHAR(255) NULL,
        [RAISE_DATE]         VARCHAR(50) NULL,
        [START_DATE]         VARCHAR(50) NULL,
        [END_DATE]           VARCHAR(50) NULL,
        [PERSON_RAISING]     VARCHAR(255) NULL,
        [NOTIFICATION_SOURCE] VARCHAR(255) NULL,
        [ACTION_TAKEN]       VARCHAR(255) NULL,
        [ANALYSIS_STATUS]    VARCHAR(50) NULL,
        [INFO_FOR_ANALYST]   NVARCHAR(MAX) NULL,
        [REVIEW_COMMENTS]    NVARCHAR(MAX) NULL,
        [CREATED_DATETIME]   VARCHAR(50) NULL,
        [UPDATED_DATETIME]   VARCHAR(50) NULL,
        CONSTRAINT [UQ_ACTIVITY_LOG_ALERT_UNIQUE_ID] UNIQUE ([ALERT_UNIQUE_ID])
    );

    -- Indexes for fast query lookup
    CREATE INDEX [IX_ACTIVITY_LOG_ALERT_UNIQUE_ID] ON [dbo].[ACTIVITY_LOG] ([ALERT_UNIQUE_ID]);
    CREATE INDEX [IX_ACTIVITY_LOG_ANALYSIS_STATUS] ON [dbo].[ACTIVITY_LOG] ([ANALYSIS_STATUS]);
    CREATE INDEX [IX_ACTIVITY_LOG_PARTY_NAME] ON [dbo].[ACTIVITY_LOG] ([PARTY_NAME]);

    PRINT 'ACTIVITY_LOG table and indexes successfully created in Azure SQL.';
END
ELSE
BEGIN
    PRINT 'ACTIVITY_LOG table already exists in Azure SQL.';
END
GO
