import io
import pandas as pd
import streamlit as st
import logging

from azure.identity import InteractiveBrowserCredential
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ServiceRequestError

from constants import ACCOUNT_URL, CONTAINER_NAME, ANNUAL_BLOB, MONTHLY_BLOB

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _get_alternative_urls(base_url: str):
    """Generates alternative Azure endpoints (privatelink, dfs) for the same account."""
    urls = [base_url]
    host = base_url.replace("https://", "").split("/")[0]
    
    if ".blob.core.windows.net" in host:
        # Try privatelink
        urls.append(base_url.replace(".blob.core.windows.net", ".privatelink.blob.core.windows.net"))
        # Try DFS (Data Lake Gen2) - often has different DNS routing
        urls.append(base_url.replace(".blob.core.windows.net", ".dfs.core.windows.net"))
        urls.append(base_url.replace(".blob.core.windows.net", ".privatelink.dfs.core.windows.net"))
        
    return list(dict.fromkeys(urls)) # Remove duplicates

@st.cache_resource(show_spinner=False)
def get_credential():
    """Returns the InteractiveBrowserCredential for web sign-in."""
    return InteractiveBrowserCredential()

def _load_from_url(url: str, container: str, blob: str, credential) -> pd.DataFrame:
    """Internal helper to attempt a download from a specific URL."""
    try:
        service_client = BlobServiceClient(account_url=url, credential=credential)
        blob_client = service_client.get_blob_client(container=container, blob=blob)
        
        # We use a short timeout for the download attempt to fail fast during DNS probing
        download_stream = blob_client.download_blob(timeout=10)
        
        stream = io.BytesIO()
        download_stream.readinto(stream)
        stream.seek(0)
        return pd.read_csv(stream)
    except Exception as e:
        logger.warning(f"Failed to load from {url}: {str(e)}")
        raise e

def load_annual_and_monthly():
    """
    Primary entry point: Tries to load both CSVs from Azure.
    Iterates through multiple possible endpoints (blob, privatelink, dfs) to overcome DNS issues.
    """
    credential = get_credential()
    potential_urls = _get_alternative_urls(ACCOUNT_URL)
    
    last_error = "No endpoints attempted"
    
    for url in potential_urls:
        try:
            logger.info(f"Attempting Azure connection via: {url}")
            df_annual = _load_from_url(url, CONTAINER_NAME, ANNUAL_BLOB, credential)
            df_monthly = _load_from_url(url, CONTAINER_NAME, MONTHLY_BLOB, credential)
            
            # If we reached here, both succeeded
            st.session_state["azure_connected_url"] = url
            return df_annual, df_monthly, None
        except ServiceRequestError as e:
            # Common for DNS resolution failures (Errno 11005, 11001, etc)
            last_error = f"DNS/Network Error at {url}: {str(e)}"
            continue
        except Exception as e:
            last_error = f"Error at {url}: {str(e)}"
            continue
            
    return None, None, last_error

def list_csv_blobs():
    """Lists available CSV blobs in the configured container."""
    try:
        credential = get_credential()
        url = st.session_state.get("azure_connected_url", ACCOUNT_URL)
        service_client = BlobServiceClient(account_url=url, credential=credential)
        container_client = service_client.get_container_client(CONTAINER_NAME)
        
        blobs = [b.name for b in container_client.list_blobs() if b.name.endswith('.csv')]
        return blobs
    except Exception as e:
        logger.error(f"Failed to list blobs: {str(e)}")
        return []
