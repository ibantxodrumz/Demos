import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import os
import logging

# Custom Utilities & Constants (Moved to utils/ folder)
from utils import constants, azure_utils, local_utils

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Page Config ---
st.set_page_config(
    page_title=f"PN Accuracy Dashboard {constants.VERSION}",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# --- Styling & CSS ---
def force_light_chart(fig):
    fig.update_layout(
        paper_bgcolor="white", plot_bgcolor="white", font=dict(color="#000000"),
        xaxis=dict(gridcolor="#e5e7eb", linecolor="#000000", tickfont=dict(color="#000000"), title_font=dict(color="#000000")),
        yaxis=dict(gridcolor="#e5e7eb", linecolor="#000000", tickfont=dict(color="#000000"), title_font=dict(color="#000000")),
        title_font=dict(color="#000000"),
    )
    return fig

st.markdown("""<style>
    .stApp { background-color: #ffffff !important; color: #000000 !important; }
    section[data-testid="stSidebar"] { background-color: #f9fafb !important; }
    section[data-testid="stSidebar"] * { color: #000000 !important; }
    h1, h2, h3, h4, h5, h6, p, li, .stMarkdown, label { color: #000000 !important; }
    .stMetric { background-color: #ffffff !important; border: 1px solid #e5e7eb !important; border-radius: 8px; padding: 10px; }
    div[data-testid="stMetricValue"], div[data-testid="stMetricLabel"] { color: #000000 !important; }
    .stButton > button { background-color: #ffffff !important; color: #000000 !important; border: 1px solid #d1d5db !important; }
    .stButton > button:hover { background-color: #f3f4f6 !important; border-color: #4A90E2 !important; color: #4A90E2 !important; }
</style>""", unsafe_allow_html=True)

# --- Data Processing Utility ---
def add_size_category(df):
    def get_size_basis(row):
        cap = row.get("installedCapacity_mwh", 0)
        return cap if pd.notnull(cap) and cap > 0 else row.get("CapacityCalibrated", 0)
    df["SizeBasis"] = df.apply(get_size_basis, axis=1)
    def categorize(x):
        if x < 50: return "Small (<50MW)"
        elif x < 100: return "Medium (50-100MW)"
        else: return "Large (>100MW)"
    df["SizeCategory"] = df["SizeBasis"].apply(categorize)
    df["SizeCategory"] = pd.Categorical(df["SizeCategory"], categories=["Small (<50MW)", "Medium (50-100MW)", "Large (>100MW)"], ordered=True)
    return df

@st.cache_data
def process_raw_data(df_annual_raw, df_monthly_raw):
    try:
        df_annual = df_annual_raw.copy()
        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)
        df_annual["Year"] = 2025
        df_annual["Grain"] = "annual"
        cols = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", "max_M_ABS_NetError%", "installedCapacity_mwh", "A_NetError%", "A_ABS_NetError%"]
        for c in cols:
            if c in df_annual.columns: df_annual[c] = pd.to_numeric(df_annual[c], errors="coerce").fillna(0)
        df_annual = add_size_category(df_annual)

        df_monthly = df_monthly_raw.copy()
        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(lambda x: datetime(int(str(x).split("-")[0]), int(str(x).split("-")[1]), 1) if (isinstance(x, str) and "-" in x) else pd.NaT)
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)
        m_cols = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", "installedCapacity_mwh", "M_NetError%", "M_ABS_NetError%"]
        for c in m_cols:
            if c in df_monthly.columns: df_monthly[c] = pd.to_numeric(df_monthly[c], errors="coerce").fillna(0)

        p90 = df_monthly.groupby("BMU")["M_ABS_NetError%"].quantile(0.9).reset_index(name="P90_monthly_error")
        df_annual = pd.merge(df_annual, p90, on="BMU", how="left").fillna(0)
        df_annual["NeedsAttention"] = (df_annual["A_ABS_NetError%"] >= 25) | (df_annual["P90_monthly_error"] >= 25)

        def bnd(x):
            if x <= 1: return "0-1%"
            elif x <= 2: return "1-2%"
            elif x <= 4: return "2-4%"
            elif x <= 10: return "4-10%"
            else: return ">10%"
        df_annual["ErrorBand"] = df_annual["A_ABS_NetError%"].apply(bnd)
        df_annual["ErrorBand"] = pd.Categorical(df_annual["ErrorBand"], categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"], ordered=True)
        return df_annual, df_monthly, None
    except Exception as e: return None, None, str(e)

# --- Sidebar: Data Sourcing ---
st.sidebar.title("Data Selection")
if "data_source" not in st.session_state: st.session_state.data_source = "Azure Cloud"
source_choice = st.sidebar.radio("Active Source", ["Azure Cloud", "Local Filesystem"], index=0 if st.session_state.data_source == "Azure Cloud" else 1)
st.session_state.data_source = source_choice

if st.sidebar.button("🔄 Clear Cache & Reload", key="azure_refresh"):
    st.cache_data.clear(); st.cache_resource.clear(); st.rerun()

# --- Loading Phase ---
annual_raw, monthly_raw, load_err = None, None, None
if st.session_state.data_source == "Azure Cloud":
    with st.spinner("Connecting to Azure..."):
        annual_raw, monthly_raw, load_err = azure_utils.load_annual_and_monthly()
    if load_err:
        st.sidebar.error(load_err); st.sidebar.warning("Fallback: checking local folder...")
        local_fs = local_utils.list_local_csv_files()
        if local_fs:
            try:
                annual_raw = local_utils.load_local_file_to_df(next(f for f in local_fs if "annual" in f.lower()))
                monthly_raw = local_utils.load_local_file_to_df(next(f for f in local_fs if "monthly" in f.lower()))
            except: st.error("No local files matched patterns."); st.stop()
        else: st.error("No local files found."); st.stop()
    else:
        conn_method = st.session_state.get("azure_connected_method", "Success")
        st.sidebar.success(f"Connected to Azure ({conn_method})")
else:
    local_fs = local_utils.list_local_csv_files()
    if not local_fs: st.error("Local files not found."); st.stop()
    a_p = st.sidebar.selectbox("Annual", local_fs, index=local_fs.index(next((f for f in local_fs if "annual" in f.lower()), local_fs[0])), key="a_sm")
    m_p = st.sidebar.selectbox("Monthly", local_fs, index=local_fs.index(next((f for f in local_fs if "monthly" in f.lower()), local_fs[0])), key="m_sm")
    annual_raw, monthly_raw = local_utils.load_local_file_to_df(a_p), local_utils.load_local_file_to_df(m_p)

# --- UI Tabs ---
if annual_raw is not None and monthly_raw is not None:
    df_annual_raw, df_monthly_raw, p_err = process_raw_data(annual_raw, monthly_raw)
    if p_err: st.error(p_err); st.stop()
    
    st.sidebar.markdown("---")
    fuels = sorted(df_annual_raw["Fuel"].unique())
    sel_fuels = st.sidebar.multiselect("Fuels", fuels, default=fuels, key="f_ms")
    bmus = sorted(df_annual_raw[df_annual_raw["Fuel"].isin(sel_fuels)]["BMU"].unique())
    sel_bmus = st.sidebar.multiselect("BMUs", bmus, default=bmus, key="b_ms")
    attn_only = st.sidebar.checkbox("🚩 Attention Only", key="a_cb")

    df_a = df_annual_raw[df_annual_raw["Fuel"].isin(sel_fuels) & df_annual_raw["BMU"].isin(sel_bmus)]
    if attn_only: df_a = df_a[df_a["NeedsAttention"]]
    df_m = df_monthly_raw[df_monthly_raw["BMU"].isin(df_a["BMU"].unique()) & df_monthly_raw["Fuel"].isin(sel_fuels)]

    if df_a.empty: st.warning("No matches."); st.stop()

    t1, t2, t3, t4, t5, t6, t7, t8, t9, t10 = st.tabs(["🚀 Exec", "📉 Med", "📈 P90", "🔋 GWh", "📊 Dist", "📉 Cap", "⚡ Tech", "🔍 BMU", "🚩 Attn", "📥 Exp"])
    with t1:
        st.title("Executive Summary")
        k1, k2, k3 = st.columns(3)
        k1.metric("Median", f"{df_a['A_ABS_NetError%'].median():.2f}%")
        k2.metric("P90", f"{df_a['A_ABS_NetError%'].quantile(0.9):.2f}%")
        k3.metric("Count", len(df_a))
        c1, c2 = st.columns(2)
        with c1: st.plotly_chart(force_light_chart(px.histogram(df_a, x="A_ABS_NetError%", title="Error Distribution")), use_container_width=True)
        with c2: st.dataframe(df_a.groupby("Fuel").agg(Median=("A_ABS_NetError%", "median"), GWh=("ABSError", lambda x: x.sum()/1000)).reset_index(), use_container_width=True)
    with t8:
        st.header("BMU Explorer")
        pk = st.selectbox("Pick BMU", sorted(df_a["BMU"].unique()), key="pk_bmu")
        ba = df_a[df_a["BMU"] == pk].iloc[0]
        bm = df_m[df_m["BMU"] == pk]
        st.write(f"**Fuel:** {ba['Fuel']} | **Size:** {ba['SizeCategory']}")
        st.plotly_chart(force_light_chart(px.line(bm, x="MonthName", y="M_ABS_NetError%", markers=True, title=f"{pk} Monthly Error")), use_container_width=True)
    with t9:
        st.header("Attention Needed")
        st.dataframe(df_a[df_a["NeedsAttention"]][["BMU", "Fuel", "A_ABS_NetError%"]], use_container_width=True)
    with t10:
        st.header("Exports")
        st.download_button("Download CSV", df_a.to_csv(index=False), "export.csv", "text/csv")
else: st.info("Loading...")
