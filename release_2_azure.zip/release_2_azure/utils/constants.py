# constants.py - Configuration for PN Accuracy Dashboard 2025 (Azure Release)

# --- Azure Configuration ---
# OPTION 1: Standard Account Name + Browser Login
# Just provide the name (e.g., 'datalake')
STORAGE_ACCOUNT_NAME = "datalake"
CONTAINER_NAME = "pn-accuracy-2025"

# OPTION 2: Connection String (Bypasses most DNS/Auth issues)
# Set this to your 'Primary Connection String' from the Azure Portal.
CONNECTION_STRING = None  # Example: "DefaultEndpointsProtocol=https;AccountName=..."

# OPTION 3: SAS Token (Appended to the URL)
# Helpful if your company blocks standard SDK logins.
SAS_TOKEN = None  # Example: "?sv=2020-08-04&ss=b&srt=sco&sp=rl&se=..."

ANNUAL_BLOB = "internal/annual_summary_2025.csv"
MONTHLY_BLOB = "internal/monthly_summary_2025.csv"

# --- Local Configuration ---
LOCAL_INPUT_DIR = "inputs"

# --- App Settings ---
VERSION = "2.1 (Refactor & Hybrid Access)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
