# constants.py - Configuration for PN Accuracy Dashboard 2025

# --- Azure Storage Settings ---
# Paste your 'Primary Connection String' from the Azure Portal here.
CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=datalake;AccountKey=...;EndpointSuffix=core.windows.net"

CONTAINER_NAME = "pn-accuracy-2025"
ANNUAL_BLOB = "internal/annual_summary_2025.csv"
MONTHLY_BLOB = "internal/monthly_summary_2025.csv"

# --- Local Folders ---
LOCAL_INPUT_DIR = "inputs"            # For manual local files
AZURE_LOCAL_DIR = "inputs_azure"      # Staging folder for cloud downloads

# --- App Settings ---
VERSION = "4.0 (Simplest Cloud Sync)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
