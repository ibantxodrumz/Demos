# constants.py - Configuration for PN Accuracy Dashboard 2025 (Azure Hybrid Release)

# --- Azure Cloud Settings ---

# 1. Standard Storage Account Details
STORAGE_ACCOUNT_NAME = "datalake" 
CONTAINER_NAME = "pn-accuracy-2025"

# 2. Resilient Access (Highest Priority)
# Provide a 'Primary Connection String' from the Azure Portal to bypass DNS and Auth issues.
CONNECTION_STRING = None  

# 3. Direct Access (Alternative)
# Provide a Shared Access Signature (SAS) Token if standard SDK access is blocked by your network.
SAS_TOKEN = None  

# 4. Blob File Paths
ANNUAL_BLOB = "internal/annual_summary_2025.csv"
MONTHLY_BLOB = "internal/monthly_summary_2025.csv"


# --- Local Filesystem Settings ---

# Folder for manually uploaded or local-only CSV files
LOCAL_INPUT_DIR = "inputs"

# Folder for cloud staging and persistent cache (Inside the release folder)
AZURE_LOCAL_DIR = "inputs_azure"  


# --- Application Metadata ---

VERSION = "3.1 (Integrated Release Structure)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
