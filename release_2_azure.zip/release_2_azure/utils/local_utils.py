# local_utils.py - Local Filesystem Data Access

import os
import pandas as pd
from .constants import LOCAL_INPUT_DIR

def list_local_csv_files():
    """Recursively scans the local ./inputs/ directory for CSV files."""
    if not os.path.exists(LOCAL_INPUT_DIR):
        os.makedirs(LOCAL_INPUT_DIR)
    
    csv_files = []
    for root, dirs, files in os.walk(LOCAL_INPUT_DIR):
        for file in files:
            if file.endswith('.csv'):
                # Store relative path for UI selection
                csv_files.append(os.path.join(root, file))
    
    return sorted(csv_files)

def load_local_file_to_df(file_path):
    """Reads a local CSV into a Pandas DataFrame."""
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading local file '{file_path}': {str(e)}")
        return None
