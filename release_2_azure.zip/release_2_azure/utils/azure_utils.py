import io
import pandas as pd
import streamlit as st
import logging

from azure.identity import InteractiveBrowserCredential
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ServiceRequestError

# Use relative import for the new folder structure
from . import constants

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _get_alternative_urls(account_name: str):
    """Generates alternative Azure endpoints (blob, privatelink, dfs) for the account name."""
    # Standard URL: https://<name>.blob.core.windows.net
    urls = [f"https://{account_name}.blob.core.windows.net"]
    
    # Private Link: https://<name>.privatelink.blob.core.windows.net
    urls.append(f"https://{account_name}.privatelink.blob.core.windows.net")
    
    # DFS (Data Lake Gen2): https://<name>.dfs.core.windows.net
    urls.append(f"https://{account_name}.dfs.core.windows.net")
    
    # Private Link DFS: https://<name>.privatelink.dfs.core.windows.net
    urls.append(f"https://{account_name}.privatelink.dfs.core.windows.net")
    
    return list(dict.fromkeys(urls)) # Remove duplicates

@st.cache_resource(show_spinner=False)
def get_credential():
    """Returns the InteractiveBrowserCredential for web sign-in."""
    return InteractiveBrowserCredential()

def _load_from_url(url: str, container: str, blob: str, credential=None, connection_string=None) -> pd.DataFrame:
    """Internal helper to attempt a download from a specific URL or Connection String."""
    try:
        if connection_string:
            service_client = BlobServiceClient.from_connection_string(connection_string)
        else:
            service_client = BlobServiceClient(account_url=url, credential=credential)
            
        blob_client = service_client.get_blob_client(container=container, blob=blob)
        
        # We use a short timeout for the download attempt to fail fast during DNS probing
        download_stream = blob_client.download_blob(timeout=10)
        
        stream = io.BytesIO()
        download_stream.readinto(stream)
        stream.seek(0)
        return pd.read_csv(stream)
    except Exception as e:
        logger.warning(f"Failed to load from {url if url else 'Connection String'}: {str(e)}")
        raise e

def load_annual_and_monthly():
    """
    Primary entry point: Tries to load both CSVs from Azure.
    1. Try Connection String if provided (Most resilient).
    2. Try SAS Token if provided.
    3. Try Probing multiple endpoints based on Account Name.
    """
    # --- Option A: Connection String ---
    if constants.CONNECTION_STRING:
        try:
            logger.info("Attempting Azure connection via CONNECTION_STRING...")
            df_a = _load_from_url(None, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, connection_string=constants.CONNECTION_STRING)
            df_m = _load_from_url(None, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, connection_string=constants.CONNECTION_STRING)
            st.session_state["azure_connected_method"] = "Connection String"
            return df_a, df_m, None
        except Exception as e:
            logger.error(f"Connection String failed: {str(e)}")

    # --- Option B: SAS Token ---
    if constants.SAS_TOKEN:
        try:
            # Build URL: https://<account>.blob.core.windows.net/<sas_token>
            account_url = f"https://{constants.STORAGE_ACCOUNT_NAME}.blob.core.windows.net"
            sas_url = f"{account_url.rstrip('/')}/{constants.SAS_TOKEN.lstrip('?')}"
            
            logger.info("Attempting Azure connection via SAS_TOKEN...")
            df_a = _load_from_url(sas_url, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, credential=None)
            df_m = _load_from_url(sas_url, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, credential=None)
            st.session_state["azure_connected_method"] = "SAS Token"
            return df_a, df_m, None
        except Exception as e:
            logger.error(f"SAS Token failed: {str(e)}")

    # --- Option C: Endpoint Probing (Account Name + Auth) ---
    credential = get_credential()
    potential_urls = _get_alternative_urls(constants.STORAGE_ACCOUNT_NAME)
    
    last_error = "No endpoints attempted"
    
    for url in potential_urls:
        try:
            logger.info(f"Attempting Azure connection via: {url}")
            df_annual = _load_from_url(url, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, credential=credential)
            df_monthly = _load_from_url(url, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, credential=credential)
            
            # If we reached here, both succeeded
            st.session_state["azure_connected_url"] = url
            st.session_state["azure_connected_method"] = f"SDK ({url})"
            return df_annual, df_monthly, None
        except ServiceRequestError as e:
            last_error = f"DNS/Network Error at {url}: {str(e)}"
            continue
        except Exception as e:
            last_error = f"Error at {url}: {str(e)}"
            continue
            
    return None, None, last_error

def list_csv_blobs():
    """Lists available CSV blobs (only if connected via standard URL/SDK)."""
    try:
        credential = get_credential()
        # Default to standard blob URL if not connected
        url = st.session_state.get("azure_connected_url", f"https://{constants.STORAGE_ACCOUNT_NAME}.blob.core.windows.net")
        service_client = BlobServiceClient(account_url=url, credential=credential)
        container_client = service_client.get_container_client(constants.CONTAINER_NAME)
        
        blobs = [b.name for b in container_client.list_blobs() if b.name.endswith('.csv')]
        return blobs
    except Exception as e:
        logger.error(f"Failed to list blobs: {str(e)}")
        return []
