import os
import pandas as pd
import streamlit as st
import logging

from azure.storage.blob import BlobServiceClient

# Use relative import for the new folder structure
from . import constants

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _download_blob(blob_name: str, local_path: str):
    """Directly downloads a blob using the connection string."""
    try:
        if not constants.CONNECTION_STRING:
            raise ValueError("No Connection String provided in constants.py")

        service_client = BlobServiceClient.from_connection_string(constants.CONNECTION_STRING)
        blob_client = service_client.get_blob_client(container=constants.CONTAINER_NAME, blob=blob_name)
        
        with open(local_path, "wb") as f:
            download_stream = blob_client.download_blob(timeout=60)
            download_stream.readinto(f)
        return True
    except Exception as e:
        logger.error(f"Download failed for {blob_name}: {str(e)}")
        # Only delete if we didn't have anything before
        if os.path.exists(local_path) and os.path.getsize(local_path) == 0:
            os.remove(local_path)
        return False

def load_annual_and_monthly():
    """
    Simpler Sync Strategy:
    1. Access Blob via Connection String.
    2. Download 2 files to 'inputs_azure/' folder.
    3. Load both files into the dashboard.
    """
    if not os.path.exists(constants.AZURE_LOCAL_DIR):
        os.makedirs(constants.AZURE_LOCAL_DIR)

    annual_local = os.path.join(constants.AZURE_LOCAL_DIR, "annual_summary_sync.csv")
    monthly_local = os.path.join(constants.AZURE_LOCAL_DIR, "monthly_summary_sync.csv")
    
    # Attempt Synchronization
    logger.info("Initializing direct cloud sync...")
    a_success = _download_blob(constants.ANNUAL_BLOB, annual_local)
    m_success = _download_blob(constants.MONTHLY_BLOB, monthly_local)

    # Final Data Loading
    if a_success and m_success:
        df_a = pd.read_csv(annual_local)
        df_m = pd.read_csv(monthly_local)
        st.session_state["azure_connected_method"] = "Direct Cloud Sync (Connection String)"
        return df_a, df_m, None
    else:
        # Fallback to local 'frozen' copy if sync failed
        if os.path.exists(annual_local) and os.path.exists(monthly_local):
            df_a = pd.read_csv(annual_local)
            df_m = pd.read_csv(monthly_local)
            st.session_state["azure_connected_method"] = "Offline Mode (Using Local Cache)"
            return df_a, df_m, "Sync failed, but using existing files in your folder."
        
        return None, None, "Sync failed and no local files were found in 'inputs_azure/'."

def list_csv_blobs():
    """Simple list of blobs based on connection string."""
    try:
        service_client = BlobServiceClient.from_connection_string(constants.CONNECTION_STRING)
        container_client = service_client.get_container_client(constants.CONTAINER_NAME)
        return [b.name for b in container_client.list_blobs() if b.name.endswith('.csv')]
    except:
        return []
