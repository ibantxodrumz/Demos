import io
import os
import pandas as pd
import streamlit as st
import logging

from azure.identity import InteractiveBrowserCredential
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ServiceRequestError

# Use relative import for the new folder structure
from . import constants

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _get_alternative_urls(account_name: str):
    """
    Generates potential Azure endpoints for a given storage account.
    Includes blob, privatelink, and DFS variants to bypass network/VPN routing issues.
    """
    urls = [f"https://{account_name}.blob.core.windows.net"]
    urls.append(f"https://{account_name}.privatelink.blob.core.windows.net")
    urls.append(f"https://{account_name}.dfs.core.windows.net")
    urls.append(f"https://{account_name}.privatelink.dfs.core.windows.net")
    return list(dict.fromkeys(urls)) 

@st.cache_resource(show_spinner=False)
def get_credential():
    """Returns the InteractiveBrowserCredential for centralized web authentication."""
    return InteractiveBrowserCredential()

def _download_blob_to_file(url: str, container: str, blob_name: str, local_path: str, credential=None, connection_string=None):
    """
    Downloads a specific blob from Azure to a local filesystem path.
    Supports Connection Strings, SAS Tokens, and standard Service Client URLs.
    """
    try:
        if connection_string:
            service_client = BlobServiceClient.from_connection_string(connection_string)
        else:
            service_client = BlobServiceClient(account_url=url, credential=credential)
            
        blob_client = service_client.get_blob_client(container=container, blob=blob_name)
        
        # Stream download directly to local file
        with open(local_path, "wb") as f:
            download_stream = blob_client.download_blob(timeout=30)
            download_stream.readinto(f)
        return True
    except Exception as e:
        logger.warning(f"Download unsuccessful for {blob_name} to {local_path}: {str(e)}")
        if os.path.exists(local_path):
            os.remove(local_path) # Prevent corrupted partial files
        raise e

def load_annual_and_monthly():
    """
    Synchronizes critical cloud data to a local staging environment and returns the resulting DataFrames.
    Implement multiple connection strategies (Connection String -> SAS Token -> Endpoint Probing)
    to ensure maximum reliability in restrictive corporate network environments.
    """
    if not os.path.exists(constants.AZURE_LOCAL_DIR):
        os.makedirs(constants.AZURE_LOCAL_DIR)

    annual_local = os.path.join(constants.AZURE_LOCAL_DIR, "annual_summary_sync.csv")
    monthly_local = os.path.join(constants.AZURE_LOCAL_DIR, "monthly_summary_sync.csv")
    
    conn_method = "None"
    sync_success = False
    error_log = ""

    # Strategy 1: Connection String (Primary Reliability)
    if constants.CONNECTION_STRING:
        try:
            logger.info("Synchronizing data via Connection String...")
            _download_blob_to_file(None, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, annual_local, connection_string=constants.CONNECTION_STRING)
            _download_blob_to_file(None, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, monthly_local, connection_string=constants.CONNECTION_STRING)
            conn_method = "Connection String"
            sync_success = True
        except Exception as e:
            error_log = f"Connection String Error: {str(e)}"

    # Strategy 2: Shared Access Signature (SAS) Token
    if not sync_success and constants.SAS_TOKEN:
        try:
            account_url = f"https://{constants.STORAGE_ACCOUNT_NAME}.blob.core.windows.net"
            sas_url = f"{account_url.rstrip('/')}/{constants.SAS_TOKEN.lstrip('?')}"
            logger.info("Synchronizing data via SAS Token...")
            _download_blob_to_file(sas_url, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, annual_local)
            _download_blob_to_file(sas_url, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, monthly_local)
            conn_method = "SAS Token"
            sync_success = True
        except Exception as e:
            error_log = f"SAS Token Error: {str(e)}"

    # Strategy 3: Multi-Endpoint Network Probing
    if not sync_success:
        credential = get_credential()
        potential_hosts = _get_alternative_urls(constants.STORAGE_ACCOUNT_NAME)
        for host_url in potential_hosts:
            try:
                logger.info(f"Attempting synchronization via endpoint: {host_url}...")
                _download_blob_to_file(host_url, constants.CONTAINER_NAME, constants.ANNUAL_BLOB, annual_local, credential=credential)
                _download_blob_to_file(host_url, constants.CONTAINER_NAME, constants.MONTHLY_BLOB, monthly_local, credential=credential)
                conn_method = f"SDK Probing ({host_url})"
                sync_success = True
                break
            except Exception as e:
                error_log = f"Endpoint {host_url} unreachable: {str(e)}"

    # Process loaded data
    if sync_success:
        df_a = pd.read_csv(annual_local)
        df_m = pd.read_csv(monthly_local)
        st.session_state["azure_connected_method"] = conn_method
        return df_a, df_m, None
    else:
        # Fallback to local 'frozen' cache if cloud synchronization fails
        if os.path.exists(annual_local) and os.path.exists(monthly_local):
            df_a = pd.read_csv(annual_local)
            df_m = pd.read_csv(monthly_local)
            st.session_state["azure_connected_method"] = "Local Cache (Disconnected)"
            return df_a, df_m, f"Sync Failed. Displaying last valid local cache. {error_log}"
        
        return None, None, f"Initial synchronization failed and no local cache found. {error_log}"

def list_csv_blobs():
    """Lists available CSV blobs in the configured container for advanced users."""
    try:
        credential = get_credential()
        base_url = st.session_state.get("azure_connected_url", f"https://{constants.STORAGE_ACCOUNT_NAME}.blob.core.windows.net")
        service_client = BlobServiceClient(account_url=base_url, credential=credential)
        container_client = service_client.get_container_client(constants.CONTAINER_NAME)
        return [b.name for b in container_client.list_blobs() if b.name.endswith('.csv')]
    except Exception as e:
        logger.error(f"Blob enumeration failed: {str(e)}")
        return []
