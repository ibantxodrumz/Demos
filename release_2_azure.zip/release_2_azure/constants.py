# constants.py - Configuration for PN Accuracy Dashboard 2025 (Azure Release)

# --- Azure Configuration ---
ACCOUNT_URL = "https://datalake.blob.core.windows.net"
CONTAINER_NAME = "pn-accuracy-2025"

ANNUAL_BLOB = "internal/annual_summary_2025.csv"
MONTHLY_BLOB = "internal/monthly_summary_2025.csv"

# --- Local Configuration ---
LOCAL_INPUT_DIR = "inputs"

# --- App Settings ---
VERSION = "2.0 (Premium Hybrid Architecture)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
