# Phase 2 — Landing Page, Analyst Identity, Rota & Date Analysis

## Status: Phase 2 Design Decisions Confirmed (September 2026)

This document replaces the earlier exploratory analysis. All design decisions below are confirmed.

---

## Decision 1: Landing Page + Analyst Identity

### Current State (Release 2 Final)
- Analyst identity is set via the `LOCAL_ANALYST_NAME` environment variable — a developer workaround, not a production mechanism.
- A workstream dropdown sits on every operational page (`alert_review`, `open_reviews`, `closed_reviews`, `long_run_analytics`, `import_constraints`), requiring each page's callbacks to read the current workstream.

### Confirmed Target State
A **landing page** (`/`) is the application entry point.

**Analyst flow on landing:**
1. The landing page reads today's rota from the `ROTA` table in Azure SQL.
2. The on-duty analyst for today is **suggested** (highlighted) on the landing page.
3. The analyst must **actively confirm** by clicking their name — this is a deliberate, auditable act.
4. Override is always available: any analyst from the `ANALYSTS` table can be selected (e.g. for cover arrangements).
5. Confirmed analyst name is written to `dcc.Store(storage_type='session')` as the active identity.
6. Analyst is then routed into the application (e.g. `/alert-review` for Import Constraints).

**Confirmed approach: Session Store (Option B)**
- URLs remain unchanged (`/alert-review`, `/open-cases`, etc.)
- All operational pages read analyst identity and workstream from the session store — not from a dropdown or env var.
- If a user lands on any page with an empty session (e.g. direct URL bookmark), the app redirects to `/` (landing page).

---

## Decision 2: Admin Page — Analyst Rota

A dedicated **Admin page** provides full CRUD management of the analyst rota.

### New Azure SQL Tables

| Table | Purpose |
|-------|---------|
| `ANALYSTS` | Master list of analysts: ANALYST_ID, NAME, EMAIL, ACTIVE (boolean) |
| `ROTA` | Weekly schedule: ROTA_ID, ANALYST_ID, WEEK_START_DATE, ON_DUTY_DAYS, WORKSTREAM, ROLE |

### Rota Tracks Two Things (both confirmed)
1. **General on-duty schedule** — who covers the monitoring shift per day of the week
2. **Workstream assignment per week** — which analyst is assigned to which workstream for a given week

### Admin Page Capabilities
- **Analysts CRUD**: Add, Edit, Deactivate analysts in the `ANALYSTS` table
- **Rota CRUD**: Add, Edit, Remove rota entries
- **Views**: Weekly and monthly rota views
- **Excel import**: Initial rota population from the existing team Excel rota
- **Ad-hoc changes**: Any entry can be changed at any time

---

## Decision 3: Sidebar Redesign

**Remove**: The `dcc.Dropdown(id="select-workstream")` from all 5 operational pages.

**Add to `navbar.py`**:
- A **"Home"** link at the top of the sidebar — routes back to `/`
- Active **analyst name** displayed in the sidebar header (read from session store)
- Active **workstream name** displayed in the sidebar header (read from session store)

---

## Decision 4: Dynamic Date Fix (P0 — Active Bug)

`get_available_time_options()` in `alert_service.py` is hardcoded to January–June 2026 only. Broken today (September 2026).

**Fix**: Dynamic generator using `datetime.today()` as upper bound and `get_database_date_bounds()` as lower bound. Auto-generates all months and ISO weeks in that range. Self-maintaining — no code change needed as time passes.

---

## Decision 5: Workstream Abstraction & Separation of Concerns (KEY DECISION)

To ensure **Import Constraints** is built as **one workstream within a platform**, not **the** application:

- **`WorkstreamRegistry`**: Create a central registry mapping `workstream_id` → database tables (`IMPORT_ALERTS`, `IMPORT_ALERTS_DATA`), evidence engines, and portal links.
- **Generic Core Services**: `alert_service.py` and `activity_log_service.py` will query database schemas dynamically based on the active session workstream.
- **Isolated Analytical Dashboards**: Workstream-specific analytics (such as `import_constraints.py`) will remain strictly decoupled in dedicated view modules.

---

## Technical Risk Analysis & Mitigation

1. **Empty Session Store / Bookmark Risk**: Users bypassing landing page via direct URLs.
   - *Mitigation*: Client-side route guard checking session store state on page layout render.
2. **Workstream Table Schema Differences**: Future workstreams may have slight column variances.
   - *Mitigation*: Adapter pattern in `alert_repository.py` using standard `AlertModel` mapping.
3. **Rota Excel Import Duplicates**: Re-uploading rota files causing primary key or duplicate week conflicts.
   - *Mitigation*: SQL `MERGE`/`UPSERT` logic on `(ANALYST_ID, WEEK_START_DATE)`.
4. **Cross-Workstream Review Contamination**: Reviews for WS1 showing up under WS2 cases.
   - *Mitigation*: Mandatory `WORKSTREAM_ID` indexing and filtering in `ACTIVITY_LOG`.

---

## Phase 2 Part A — Implementation Order

| Priority | Task | Complexity |
|----------|------|-----------|
| P0 | Fix dynamic dates in `get_available_time_options()` | Low |
| P1 | Create `ANALYSTS` + `ROTA` tables in Azure SQL | Low |
| P2 | Implement `WorkstreamRegistry` and workstream abstraction mapping | Low |
| P3 | Build Admin page with CRUD + weekly/monthly views | Medium |
| P4 | Build landing page with rota suggestion + analyst confirmation | Medium |
| P5 | Remove workstream dropdown from all 5 operational pages | Medium |
| P6 | Update all 5 pages callbacks to read from session store via `WorkstreamRegistry` | Medium |
| P7 | Redesign sidebar (`navbar.py`) — Home link + active identity display | Low |
| P8 | Remove `saved_reviews.py` dead stub | Trivial |

---

## Deferred to Phase 2 Part B

- Workstream 2 alert data integration
- Workstream 2 specific analytical dashboard onboarding
- AAD / Entra ID authentication
- Historical NED data migration (separate discussion)
