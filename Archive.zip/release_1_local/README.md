# PN Accuracy Dashboard 2025 (Local Release)

This is a self-contained local release of the Flask-driven PN Accuracy Dashboard.

## Prerequisites
- **Python 3.9+** installed on your system.
- **VS Code** (or any text/code editor).

## Directory Structure
- `app.py`: The main Flask application backend.
- `requirements.txt`: Python package dependencies.
- `inputs/`: Contains the Annual and Monthly CSV files the dashboard reads.
- `templates/` & `static/`: HTML, CSS, and JS files for the frontend.

## How to Run Locally

### 1. Open the Folder in VS Code
Open this entire folder (`release_1_local`) in Visual Studio Code.

### 2. Create a Virtual Environment (Recommended)
Open a new terminal within VS Code (Terminal -> New Terminal) and run:
```bash
# On Mac/Linux:
python3 -m venv .venv
source .venv/bin/activate

# On Windows:
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install Dependencies
With the virtual environment activated, install the required packages:
```bash
pip install -r requirements.txt
```

### 4. Run the Application
Start the Flask server:
```bash
python app.py
```
*Note: The script is configured to automatically open your default web browser to the application at `http://127.0.0.1:5000/`.*

## Updating Data Files
If you receive updated versions of `annual_summary_2025.csv` or `monthly_summary_2025.csv`, you can simply overwrite the existing files in the `inputs/` folder. 
Once replaced, click the **"Refresh Data"** button in the dashboard sidebar to instantly load the new data without needing to restart the backend terminal server.
