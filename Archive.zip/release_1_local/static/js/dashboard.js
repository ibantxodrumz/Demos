document.addEventListener('DOMContentLoaded', () => {
    // --- UI Logic: Tabs ---
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            btn.classList.add('active');
            const target = btn.getAttribute('data-tab');
            document.getElementById(target).classList.add('active');
            
            // Plotly needs a resize event to layout correctly if chart was hidden
            window.dispatchEvent(new Event('resize'));
        });
    });

    const miniTabBtns = document.querySelectorAll('.mini-tab');
    const miniTabPanes = document.querySelectorAll('.mini-tab-pane');
    miniTabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            miniTabBtns.forEach(b => b.classList.remove('active'));
            miniTabPanes.forEach(p => p.style.display = 'none');
            
            btn.classList.add('active');
            document.getElementById(btn.getAttribute('data-target')).style.display = 'block';
            window.dispatchEvent(new Event('resize'));
        });
    });

    // --- Data Fetching Logic ---
    const getSelectedValues = (selectId) => {
        const select = document.getElementById(selectId);
        return Array.from(select.selectedOptions).map(opt => opt.value);
    };

    const updateDashboard = async () => {
        const fuels = getSelectedValues('fuel-select');
        const bmus = getSelectedValues('bmu-select');
        const attentionOnly = document.getElementById('attention-flag').checked;
        const focusFuel = document.getElementById('focus-fuel-select').value;
        const bmuPick = document.getElementById('single-bmu-pick').value;

        try {
            const response = await fetch('/api/dashboard', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    fuels: fuels,
                    bmus: bmus,
                    attention_only: attentionOnly,
                    focus_fuel: focusFuel,
                    bmu_pick: bmuPick
                })
            });

            if (!response.ok) {
                console.error("Dashboard api failed", response.status);
                return;
            }

            const data = await response.json();

            if (data.error) {
                alert(data.error);
                return;
            }

            // 1. Update KPIs
            document.getElementById('kpi-median').innerText = data.kpis.fleet_median_error.toFixed(2) + '%';
            document.getElementById('kpi-p90').innerText = data.kpis.fleet_p90_error.toFixed(2) + '%';
            document.getElementById('kpi-max').innerText = data.kpis.fleet_max_error.toFixed(2) + '%';
            document.getElementById('kpi-max-delta').innerText = data.kpis.max_bmu_info;
            document.getElementById('kpi-count').innerText = data.kpis.bmu_count;
            
            const formatGWh = (val) => new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(val);
            document.getElementById('kpi-abs-gwh').innerText = formatGWh(data.kpis.fleet_abs_gwh);
            document.getElementById('kpi-net-gwh').innerText = formatGWh(data.kpis.fleet_net_gwh);

            // 2. Tables
            document.getElementById('fuel-summary-table').innerHTML = data.fuel_summary_html;
            document.getElementById('fleet-table-container').innerHTML = data.fleet_table_html;
            document.getElementById('attention-container').innerHTML = data.attention_html;

            // 3. Render Generic Charts
            const chartMapping = [
                'fig_hist', 'fig_hm1', 'fig_hm2', 'fig_mwh', 
                'fig_band', 'fig_box', 'fig_bub'
            ];

            chartMapping.forEach(id => {
                if(data.charts[id]) {
                    Plotly.react(id, data.charts[id].data, data.charts[id].layout, {responsive: true});
                }
            });

            // 4. Update By Technology
            if (data.tech_data && data.tech_data.kpis) {
                const tk = data.tech_data.kpis;
                document.getElementById('tech-analysis-title').innerText = `${tk.focus_fuel} Performance Analysis`;
                document.getElementById('tkpi-median').innerText = tk.t_median.toFixed(2) + '%';
                document.getElementById('tkpi-p90').innerText = tk.t_p90.toFixed(2) + '%';
                document.getElementById('tkpi-count').innerText = tk.t_count;
                document.getElementById('tkpi-worst').innerText = `${tk.t_worst} (${tk.t_worst_val.toFixed(1)}%)`;
                document.getElementById('tkpi-attention').innerText = tk.t_attention;
                document.getElementById('tkpi-abs').innerText = formatGWh(tk.t_abs_gwh);
                document.getElementById('tkpi-net').innerText = formatGWh(tk.t_net_gwh);

                document.getElementById('tech-best-10').innerHTML = data.tech_data.best_10;
                document.getElementById('tech-worst-10').innerHTML = data.tech_data.worst_10;

                ['fig_thist', 'fig_net_hist', 'fig_trend'].forEach(id => {
                    if(data.charts[id]) Plotly.react(id, data.charts[id].data, data.charts[id].layout, {responsive: true});
                });
            }

            // 5. BMU Explorer
            if (data.bmu_data && data.bmu_data.annual) {
                const b = data.bmu_data.annual;
                document.getElementById('bmu-profile-title').innerText = `Profile: ${b.bmu_pick}`;
                
                let metricsHtml = `
                    <li><strong>Fuel:</strong> <span>${b.Fuel}</span></li>
                    <li><strong>Size Category:</strong> <span>${b.SizeCategory}</span></li>
                    <li><strong>Annual Net Error %:</strong> <span>${b.A_NetErrorPct.toFixed(2)}%</span></li>
                    <li><strong>Annual ABS Error %:</strong> <span>${b.A_ABS_NetErrorPct.toFixed(2)}%</span></li>
                    <li><strong>Total ABS Error (GWh):</strong> <span>${formatGWh(b.ABSError_GWh)}</span></li>
                    <li><strong>Net Error (GWh):</strong> <span>${formatGWh(b.NetError_GWh)}</span></li>
                    <li><strong>Monthly P90 Error:</strong> <span>${b.P90_monthly_error.toFixed(2)}%</span></li>
                `;
                document.getElementById('bmu-metrics-list').innerHTML = metricsHtml;

                if (b.NeedsAttention) {
                    document.getElementById('bmu-status-flag').innerHTML = `<div class="error-alert">⚠️ Flagged: Needs Attention</div>`;
                } else {
                    document.getElementById('bmu-status-flag').innerHTML = `<div class="success-alert">✅ Status: OK</div>`;
                }

                if (data.charts['fig_spark']) {
                    Plotly.react('fig_spark', data.charts['fig_spark'].data, data.charts['fig_spark'].layout, {responsive: true});
                }
                
                document.getElementById('bmu-monthly-table').innerHTML = data.bmu_data.monthly_html || "";
            }

        } catch (e) {
            console.error("Failed to fetch dashboard data:", e);
        }
    };

    // --- Event Listeners ---
    ['fuel-select', 'bmu-select', 'attention-flag', 'focus-fuel-select', 'single-bmu-pick'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', updateDashboard);
    });

    // BMU Search filter
    const bmuSearch = document.getElementById('bmu-search-input');
    const bmuSelect = document.getElementById('single-bmu-pick');
    if (bmuSearch && bmuSelect) {
        // save orig options
        const originalOptions = Array.from(bmuSelect.options).map(opt => ({value: opt.value, text: opt.text}));
        
        bmuSearch.addEventListener('input', (e) => {
            const term = e.target.value.toUpperCase();
            bmuSelect.innerHTML = '';
            originalOptions.forEach(opt => {
                if (opt.text.toUpperCase().includes(term)) {
                    bmuSelect.add(new Option(opt.text, opt.value));
                }
            });
            // trigger update if selection changed implicitly, or just let user click
        });
    }

    // Initial Load
    updateDashboard();

    // --- Refresh Data Logic ---
    const btnRefresh = document.getElementById('btn-refresh-data');
    if (btnRefresh) {
        btnRefresh.addEventListener('click', async () => {
            const originalText = btnRefresh.innerHTML;
            btnRefresh.innerHTML = '⏳ Refreshing...';
            btnRefresh.disabled = true;

            try {
                const response = await fetch('/api/refresh', { method: 'POST' });
                if (!response.ok) throw new Error("Failed to refresh");
                
                const data = await response.json();
                if (data.success) {
                    // Update the dropdown options just in case new fuels/BMUs appeared
                    const updateSelect = (selectId, newOptions) => {
                        const select = document.getElementById(selectId);
                        if (!select) return;
                        
                        // Keep track of what was currently selected
                        const currentlySelected = getSelectedValues(selectId);
                        
                        select.innerHTML = '';
                        newOptions.forEach(opt => {
                            const optionEl = new Option(opt, opt);
                            if (currentlySelected.includes(opt)) {
                                optionEl.selected = true;
                            } else if (currentlySelected.length === 0) {
                                // if nothing was selected, select all by default
                                optionEl.selected = true;
                            }
                            select.add(optionEl);
                        });
                    };

                    updateSelect('fuel-select', data.fuels);
                    updateSelect('bmu-select', data.all_bmus);
                    
                    const focusFuelSelect = document.getElementById('focus-fuel-select');
                    if (focusFuelSelect) {
                        const currentFocus = focusFuelSelect.value;
                        focusFuelSelect.innerHTML = '';
                        data.fuels.forEach(f => focusFuelSelect.add(new Option(f, f)));
                        if (data.fuels.includes(currentFocus)) {
                            focusFuelSelect.value = currentFocus;
                        }
                    }

                    // For the single BMU pick, we also need to recreate the options
                    const singleBmuPick = document.getElementById('single-bmu-pick');
                    if (singleBmuPick) {
                        const currentPick = singleBmuPick.value;
                        singleBmuPick.innerHTML = '';
                        data.all_bmus.forEach(b => singleBmuPick.add(new Option(b, b)));
                        if (data.all_bmus.includes(currentPick)) {
                            singleBmuPick.value = currentPick;
                        }
                    }

                    // Reload the dashboard charts
                     await updateDashboard();
                } else {
                    alert("Error refreshing data: " + data.error);
                }
            } catch (e) {
                console.error(e);
                alert("Failed to refresh data from server.");
            } finally {
                btnRefresh.innerHTML = originalText;
                btnRefresh.disabled = false;
            }
        });
    }

    // --- Export Logic ---
    const handleExport = async (exportType) => {
        const fuels = getSelectedValues('fuel-select');
        const bmus = getSelectedValues('bmu-select');
        const attentionOnly = document.getElementById('attention-flag').checked;

        try {
            const response = await fetch('/api/export', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    export_type: exportType,
                    fuels: fuels,
                    bmus: bmus,
                    attention_only: attentionOnly
                })
            });

            if (!response.ok) {
                console.error("Export failed", response.status);
                alert("Failed to export data.");
                return;
            }

            // Extract filename from disposition header if available
            const disposition = response.headers.get('Content-Disposition');
            let filename = `${exportType}_export.csv`;
            if (disposition && disposition.indexOf('attachment') !== -1) {
                const filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                const matches = filenameRegex.exec(disposition);
                if (matches != null && matches[1]) { 
                    filename = matches[1].replace(/['"]/g, '');
                }
            }

            // Trigger download via blob
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

        } catch (e) {
            console.error("Failed to export:", e);
        }
    };

    const btnAnnual = document.getElementById('btn-export-annual');
    if (btnAnnual) btnAnnual.addEventListener('click', () => handleExport('annual'));
    
    const btnMonthly = document.getElementById('btn-export-monthly');
    if (btnMonthly) btnMonthly.addEventListener('click', () => handleExport('monthly'));
    
    const btnAttention = document.getElementById('btn-export-attention');
    if (btnAttention) btnAttention.addEventListener('click', () => handleExport('attention'));

});
