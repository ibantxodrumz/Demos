# PN Accuracy Dashboard 2025 (Azure App Service Edition)

This is the Azure-ready release of the PN Accuracy Dashboard. It is designed to be deployed to an Azure App Service (Linux Web App) running Python, and it reads its data directly from Azure Blob Storage rather than the local filesystem.

## Architecture

1. **Frontend**: HTML/JS/CSS served by Flask.
2. **Backend**: Python Flask application.
3. **Storage**: Azure Blob Storage (using the `azure-storage-blob` SDK).

## Deployment Instructions

### 1. Configure Application Settings in Azure
Before or after deploying the code to Azure App Service, navigate to your App Service in the Azure Portal. Go to **Settings > Configuration** and add the following **Application settings** (secrets):

- `AZURE_STORAGE_CONNECTION_STRING`: The connection string to your Azure Storage Account.
- `AZURE_CONTAINER_NAME`: The name of the Blob container (e.g., `data`).
- `ANNUAL_BLOB_NAME`: (Optional) The name of the annual CSV blob. Defaults to `annual_summary_2025.csv`.
- `MONTHLY_BLOB_NAME`: (Optional) The name of the monthly CSV blob. Defaults to `monthly_summary_2025.csv`.
- `SECRET_KEY`: A random string used by Flask to secure sessions.

### 2. Startup Command for Azure
Azure App Service (Linux) needs to know how to start the app. Since we included `gunicorn` in the `requirements.txt`, you should configure the following Startup Command in the Azure Portal (under Configuration > General Settings):

```bash
gunicorn --bind=0.0.0.0 --timeout 600 app:app
```

### 3. Deploying the Code
You can deploy this folder directly to your Azure App Service using your preferred method (e.g., VS Code Azure Extension, Azure CLI `az webapp up`, Github Actions, or Local Git). 

Azure will automatically detect the `requirements.txt` file and run `pip install` during the build process to install the Azure SDK, Pandas, and Flask.

## Local Testing
If you wish to test this code locally before deploying to Azure:
1. Copy `.env.example` to a new file named `.env`.
2. Fill in your real Azure Connection String in `.env`.
3. Create a virtual environment, install `requirements.txt`.
4. Run `python app.py`.
