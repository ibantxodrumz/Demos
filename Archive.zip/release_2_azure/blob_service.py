import io
from azure.storage.blob import BlobServiceClient
from config import Config

def get_blob_service_client():
    """
    Returns an authenticated BlobServiceClient.
    Using a Placeholder for local testing if the connection string isn't real.
    """
    conn_str = Config.AZURE_STORAGE_CONNECTION_STRING
    if not conn_str or "placeholder" in conn_str.lower():
        print("WARNING: Using placeholder or empty Azure Connection String.")
        return None
    return BlobServiceClient.from_connection_string(conn_str)

def download_blob_to_string(blob_name):
    """
    Connects to Azure Blob Storage, downloads the specified blob from the 
    configured container, and returns it as a StringIO object for Pandas to read.
    """
    client = get_blob_service_client()
    if not client:
        return None, "Azure Storage Connection String is missing or invalid."

    try:
        container_client = client.get_container_client(Config.AZURE_CONTAINER_NAME)
        blob_client = container_client.get_blob_client(blob_name)
        
        # Download the blob content as a string
        download_stream = blob_client.download_blob()
        content = download_stream.content_as_text()
        
        # Return as StringIO so pandas can read it like a file
        return io.StringIO(content), None
        
    except Exception as e:
        return None, f"Error downloading {blob_name} from Azure: {str(e)}"
