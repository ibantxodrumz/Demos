import os
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json
from flask import Flask, render_template, request, jsonify, Response
import io
from config import Config
from blob_service import download_blob_to_string

app = Flask(__name__)
app.config.from_object(Config)

_data_cache = {'annual': None, 'monthly': None, 'error': None}

def force_light_chart(fig):
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#000000"),
        xaxis=dict(gridcolor="#e5e7eb", linecolor="#000000", tickfont=dict(color="#000000"), title_font=dict(color="#000000")),
        yaxis=dict(gridcolor="#e5e7eb", linecolor="#000000", tickfont=dict(color="#000000"), title_font=dict(color="#000000")),
        title_font=dict(color="#000000"),
        margin=dict(l=40, r=40, t=40, b=40)
    )
    return fig

def add_size_category(df):
    def get_size_basis(row):
        cap = row.get("installedCapacity_mwh", 0)
        if pd.notnull(cap) and cap > 0: return cap
        return row.get("CapacityCalibrated", 0)

    df["SizeBasis"] = df.apply(get_size_basis, axis=1)
    
    def categorize(x):
        if x < 50: return "Small (<50MW)"
        elif x < 100: return "Medium (50-100MW)"
        else: return "Large (>100MW)"
        
    df["SizeCategory"] = df["SizeBasis"].apply(categorize)
    return df

def load_data():
    if _data_cache['annual'] is not None and _data_cache['monthly'] is not None:
        return _data_cache['annual'], _data_cache['monthly'], None

    # Download from Azure Blob Storage
    annual_stream, err_annual = download_blob_to_string(Config.ANNUAL_BLOB_NAME)
    if err_annual:
        return None, None, err_annual
        
    monthly_stream, err_monthly = download_blob_to_string(Config.MONTHLY_BLOB_NAME)
    if err_monthly:
        return None, None, err_monthly

    try:
        df_annual = pd.read_csv(annual_stream)
        df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
        df_annual["Fuel"] = df_annual["FUEL_I"].astype(str)
        df_annual["Year"] = 2025
        df_annual["Grain"] = "annual"
        
        numeric_cols_annual = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", 
            "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", 
            "max_M_ABS_NetError%", "installedCapacity_mwh", "A_NetError%", "A_ABS_NetError%"]
        for col in numeric_cols_annual:
            if col in df_annual.columns:
                df_annual[col] = pd.to_numeric(df_annual[col], errors='coerce').fillna(0)
        
        df_annual = add_size_category(df_annual)
    except Exception as e:
        return None, None, f"Error processing Annual file from Azure: {str(e)}"

    try:
        df_monthly = pd.read_csv(monthly_stream)
        
        def parse_date(x):
            try:
                parts = str(x).split('-')
                if len(parts) == 2: return datetime(int(parts[0]), int(parts[1]), 1)
                return pd.NaT
            except: return pd.NaT

        df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_date)
        df_monthly["Year"] = df_monthly["YearMonthObj"].dt.year
        df_monthly["Month"] = df_monthly["YearMonthObj"].dt.month
        df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
        
        df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
        df_monthly["Fuel"] = df_monthly["FUEL_I"].astype(str)
        df_monthly["Grain"] = "monthly"

        numeric_cols_monthly = ["PNLevel", "MELLevel", "MILLevel", "BidVolume", "OfferVolume", 
            "Metered", "ExpectOT", "CapacityCalibrated", "NetError", "ABSError", 
            "installedCapacity_mwh", "M_NetError%", "M_ABS_NetError%"]
        for col in numeric_cols_monthly:
            if col in df_monthly.columns:
                df_monthly[col] = pd.to_numeric(df_monthly[col], errors='coerce').fillna(0)
    except Exception as e:
        return None, None, f"Error processing Monthly file from Azure: {str(e)}"

    p90_series = df_monthly.groupby("BMU")["M_ABS_NetError%"].quantile(0.9)
    p90_df = p90_series.reset_index(name="P90_monthly_error")
    df_annual = pd.merge(df_annual, p90_df, on="BMU", how="left")
    df_annual["P90_monthly_error"] = df_annual["P90_monthly_error"].fillna(0)

    df_annual["NeedsAttention"] = (df_annual["A_ABS_NetError%"] >= 25) | (df_annual["P90_monthly_error"] >= 25)

    def categorize_error(x):
        if x <= 1: return "0-1%"
        elif x <= 2: return "1-2%"
        elif x <= 4: return "2-4%"
        elif x <= 10: return "4-10%"
        else: return ">10%"
    
    df_annual["ErrorBand"] = df_annual["A_ABS_NetError%"].apply(categorize_error)

    _data_cache['annual'] = df_annual
    _data_cache['monthly'] = df_monthly
    return df_annual, df_monthly, None

def apply_filters(df_a, df_m, fuels, bmus, attention_only):
    res_a = df_a
    if fuels: res_a = res_a[res_a["Fuel"].isin(fuels)]
    if bmus: res_a = res_a[res_a["BMU"].isin(bmus)]
    if attention_only: res_a = res_a[res_a["NeedsAttention"] == True]
        
    filtered_bmus = res_a["BMU"].unique()
    res_m = df_m[df_m["BMU"].isin(filtered_bmus)]
    if fuels: res_m = res_m[res_m["Fuel"].isin(fuels)]
    
    return res_a, res_m

@app.route('/')
def index():
    df_annual, df_monthly, error = load_data()
    if error: return f"<h1>Data Loading Error</h1><p>{error}</p>"
    all_fuels = sorted(df_annual["Fuel"].unique().tolist())
    all_bmus = sorted(df_annual["BMU"].unique().tolist())
    return render_template('index.html', fuels=all_fuels, all_bmus=all_bmus)

@app.route('/api/refresh', methods=['POST'])
def refresh_data():
    global _data_cache
    _data_cache = {'annual': None, 'monthly': None, 'error': None}
    df_annual, df_monthly, error = load_data()
    if error:
        return jsonify({'success': False, 'error': error}), 500
    
    all_fuels = sorted(df_annual["Fuel"].unique().tolist())
    all_bmus = sorted(df_annual["BMU"].unique().tolist())
    
    return jsonify({
        'success': True, 
        'fuels': all_fuels, 
        'all_bmus': all_bmus
    })

@app.route('/api/dashboard', methods=['POST'])
def dashboard_api():
    df_annual_raw, df_monthly_raw, error = load_data()
    if error: return jsonify({'error': error}), 500

    payload = request.json or {}
    fuels = payload.get('fuels', [])
    bmus = payload.get('bmus', [])
    attention_only = payload.get('attention_only', False)
    focus_fuel = payload.get('focus_fuel', None)
    bmu_pick = payload.get('bmu_pick', None)

    df_annual, df_monthly = apply_filters(df_annual_raw, df_monthly_raw, fuels, bmus, attention_only)
    if df_annual.empty:
        return jsonify({'error': 'No BMUs match the current filters.'})

    # --- TAB 1: Executive Summary KPIs ---
    fleet_median_error = df_annual["A_ABS_NetError%"].median()
    fleet_p90_error = df_annual["A_ABS_NetError%"].quantile(0.9)
    max_err_idx = df_annual["A_ABS_NetError%"].idxmax()
    max_err_row = df_annual.loc[max_err_idx]
    fleet_max_error = max_err_row["A_ABS_NetError%"]
    max_bmu_info = f"{max_err_row['BMU']} ({max_err_row['Fuel']})"
    bmu_count = df_annual["BMU"].nunique()
    fleet_abs_gwh = df_annual["ABSError"].sum() / 1000
    fleet_net_gwh = df_annual["NetError"].sum() / 1000

    # Fuel Summary Table
    fuel_summary = df_annual.groupby("Fuel").agg(
        Median_Error_Pct=("A_ABS_NetError%", "median"),
        P90_Error_Pct=("A_ABS_NetError%", lambda x: x.quantile(0.9)),
        Total_ABS_GWh=("ABSError", lambda x: x.sum() / 1000),
        Net_Bias_GWh=("NetError", lambda x: x.sum() / 1000),
        BMU_Count=("BMU", "nunique")
    ).reset_index().sort_values("Total_ABS_GWh", ascending=False)

    # Convert to HTML table for simple rendering in vanilla JS
    fuel_summary_html = fuel_summary.to_html(index=False, classes="data-table", float_format="%.2f")

    # --- Charts ---
    charts = {}

    def jsonify_fig(fig):
        return json.loads(force_light_chart(fig).to_json())

    # 1. Executive Summary Histogram
    fig_hist = px.histogram(df_annual, x="A_ABS_NetError%", title="Distribution of Annual Error % (0-100% Range)",
                            color_discrete_sequence=["#4A90E2"], template="plotly_white", range_x=[0, 100], text_auto=True)
    fig_hist.update_traces(textposition='outside')
    fig_hist.update_layout(xaxis=dict(title="Annual Error %"), yaxis=dict(title="Count of BMUs"), bargap=0.1)
    charts['fig_hist'] = jsonify_fig(fig_hist)

    # 2. Median Error
    fuel_median = df_annual.groupby("Fuel")["A_ABS_NetError%"].median().reset_index().sort_values("A_ABS_NetError%")
    fig_hm1 = px.bar(fuel_median, x="Fuel", y="A_ABS_NetError%", title="Median Error % by Fuel",
                     color="A_ABS_NetError%", color_continuous_scale="Reds", template="plotly_white", text_auto=".2f")
    charts['fig_hm1'] = jsonify_fig(fig_hm1)

    # 3. P90 Error
    fuel_p90 = df_annual.groupby("Fuel")["A_ABS_NetError%"].quantile(0.9).reset_index().sort_values("A_ABS_NetError%")
    fig_hm2 = px.bar(fuel_p90, x="Fuel", y="A_ABS_NetError%", title="P90 Annual Error % by Fuel",
                     color="A_ABS_NetError%", color_continuous_scale="Reds", template="plotly_white", text_auto=".2f")
    charts['fig_hm2'] = jsonify_fig(fig_hm2)

    # 4. Total GWh Error
    fuel_mwh = df_annual.groupby("Fuel")["ABSError"].sum().reset_index()
    fuel_mwh["ABSError_GWh"] = fuel_mwh["ABSError"] / 1000
    fuel_mwh = fuel_mwh.sort_values("ABSError_GWh", ascending=True)
    fig_mwh = px.bar(fuel_mwh, x="Fuel", y="ABSError_GWh", title="Total Absolute Error (GWh) by Fuel",
                     color="ABSError_GWh", color_continuous_scale="Reds", template="plotly_white", text_auto=".0f")
    charts['fig_mwh'] = jsonify_fig(fig_mwh)

    # 5. Fleet Error Distribution
    df_annual["ErrorBand_cat"] = pd.Categorical(df_annual["ErrorBand"], categories=["0-1%", "1-2%", "2-4%", "4-10%", ">10%"], ordered=True)
    band_counts = df_annual["ErrorBand_cat"].value_counts().sort_index().reset_index()
    band_counts.columns = ["ErrorBand", "Count"]
    fig_band = px.bar(band_counts, x="ErrorBand", y="Count", title="BMU Count by Error Band",
                      color="ErrorBand", color_discrete_sequence=px.colors.sequential.Bluyl, template="plotly_white", text="Count")
    fig_band.update_traces(textposition='outside')
    charts['fig_band'] = jsonify_fig(fig_band)

    # 6. Fleet Box Plot
    df_annual["SizeCategory_cat"] = pd.Categorical(df_annual["SizeCategory"], categories=["Small (<50MW)", "Medium (50-100MW)", "Large (>100MW)"], ordered=True)
    fig_box = px.box(df_annual, x="SizeCategory_cat", y="A_ABS_NetError%", color="SizeCategory",
                     title="Error % Distribution by Asset Size", template="plotly_white", points="outliers")
    charts['fig_box'] = jsonify_fig(fig_box)

    # 7. Fleet Capacity Bubble
    df_annual["SizeBasis_Abs"] = df_annual["SizeBasis"].abs()
    df_annual["ABSError_GWh"] = df_annual["ABSError"] / 1000
    fig_bub = px.scatter(df_annual, x="SizeBasis", y="A_ABS_NetError%", size="SizeBasis_Abs", color="Fuel",
                         hover_name="BMU", title="Installed Capacity (MWh) vs. Annual Absolute Net Error %",
                         template="plotly_white", size_max=50, log_x=True)
    charts['fig_bub'] = jsonify_fig(fig_bub)

    fleet_table_html = df_annual[["BMU", "Fuel", "SizeCategory", "A_ABS_NetError%", "ABSError_GWh"]].to_html(index=False, classes="data-table")

    # --- TAB 3: By Technology ---
    tech_data = {}
    if not focus_fuel:
        focus_fuel = sorted(df_annual_raw["Fuel"].unique().tolist())[0]

    tech_df = df_annual_raw[df_annual_raw["Fuel"] == focus_fuel].copy()
    tech_monthly = df_monthly_raw[df_monthly_raw["Fuel"] == focus_fuel].copy()

    if not tech_df.empty:
        tech_data['kpis'] = {
            't_median': tech_df["A_ABS_NetError%"].median(),
            't_p90': tech_df["A_ABS_NetError%"].quantile(0.9),
            't_count': int(tech_df["BMU"].nunique()),
            't_worst': tech_df.loc[tech_df["A_ABS_NetError%"].idxmax()]["BMU"],
            't_worst_val': float(tech_df["A_ABS_NetError%"].max()),
            't_attention': int(tech_df["NeedsAttention"].sum()),
            't_abs_gwh': float(tech_df["ABSError"].sum() / 1000),
            't_net_gwh': float(tech_df["NetError"].sum() / 1000),
            'focus_fuel': focus_fuel
        }
        
        fig_thist = px.histogram(tech_df, x="A_ABS_NetError%", title="Annual Absolute Error %",
                                 color_discrete_sequence=["#1f77b4"], template="plotly_white", range_x=[0, 100], text_auto=True)
        fig_thist.update_traces(xbins=dict(start=0, end=100, size=2.5), textposition='outside')
        charts['fig_thist'] = jsonify_fig(fig_thist)

        tech_df["NetError_GWh"] = tech_df["NetError"] / 1000
        fig_net_hist = px.histogram(tech_df, x="NetError_GWh", nbins=30, title="Net GWh Error Distribution",
                                    color_discrete_sequence=["#FF7F0E"], template="plotly_white", text_auto=True)
        fig_net_hist.update_traces(textposition='outside')
        charts['fig_net_hist'] = jsonify_fig(fig_net_hist)

        if not tech_monthly.empty:
            trend = tech_monthly.groupby(["Month", "MonthName"]).agg(
                Median_Error=("M_ABS_NetError%", "median"),
                P90_Error=("M_ABS_NetError%", lambda x: x.quantile(0.9))
            ).sort_index().reset_index()
            fig_trend = go.Figure()
            fig_trend.add_trace(go.Scatter(x=trend["MonthName"], y=trend["Median_Error"], mode='lines+markers', name='Median'))
            fig_trend.add_trace(go.Scatter(x=trend["MonthName"], y=trend["P90_Error"], mode='lines+markers', name='P90', line=dict(dash='dash')))
            fig_trend.update_layout(title="Monthly Error Trend", template="plotly_white")
            charts['fig_trend'] = jsonify_fig(fig_trend)
            
        tech_data['best_10'] = tech_df.nsmallest(10, "A_ABS_NetError%")[["BMU", "A_ABS_NetError%", "NeedsAttention"]].to_html(index=False, classes="data-table")
        tech_data['worst_10'] = tech_df.nlargest(10, "A_ABS_NetError%")[["BMU", "A_ABS_NetError%", "NeedsAttention"]].to_html(index=False, classes="data-table")

    # --- TAB 4: BMU Explorer ---
    bmu_data = {}
    if bmu_pick:
        bmu_annual = df_annual_raw[df_annual_raw["BMU"] == bmu_pick]
        if not bmu_annual.empty:
            bmu_annual = bmu_annual.iloc[0]
            bmu_data['annual'] = {
                'Fuel': bmu_annual['Fuel'],
                'SizeCategory': bmu_annual.get('SizeCategory', 'N/A'),
                'A_NetErrorPct': bmu_annual['A_NetError%'],
                'A_ABS_NetErrorPct': bmu_annual['A_ABS_NetError%'],
                'ABSError_GWh': bmu_annual['ABSError']/1000,
                'NetError_GWh': bmu_annual['NetError']/1000,
                'P90_monthly_error': bmu_annual['P90_monthly_error'],
                'NeedsAttention': bool(bmu_annual['NeedsAttention']),
                'bmu_pick': bmu_pick
            }
            
            bmu_monthly = df_monthly_raw[df_monthly_raw["BMU"] == bmu_pick].sort_values("Month")
            if not bmu_monthly.empty:
                fig_spark = px.line(bmu_monthly, x="MonthName", y="M_ABS_NetError%", markers=True, title="Monthly Absolute Error %", template="plotly_white")
                fig_spark.add_hline(y=25, line_dash="dash", line_color="red", annotation_text="25% Threshold")
                charts['fig_spark'] = jsonify_fig(fig_spark)
                bmu_data['monthly_html'] = bmu_monthly[["MonthName", "M_NetError%", "M_ABS_NetError%"]].to_html(index=False, classes="data-table")

    # --- TAB 5: Attention Needed ---
    attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()
    attention_html = ""
    if attention_df.empty:
        attention_html = "<div class='success-alert'>🎉 No BMUs require attention! All below thresholds.</div>"
    else:
        def get_reason(row):
            reasons = []
            if row["A_ABS_NetError%"] >= 25: reasons.append(f"Annual Error {row['A_ABS_NetError%']:.1f}% >= 25%")
            if row["P90_monthly_error"] >= 25: reasons.append(f"Monthly P90 {row['P90_monthly_error']:.1f}% >= 25%")
            return "; ".join(reasons)
        attention_df["Reason"] = attention_df.apply(get_reason, axis=1)
        attention_html += f"<p><strong>{len(attention_df)}</strong> BMUs triggered the threshold (Annual Error ≥ 25% OR Monthly P90 ≥ 25%).</p>"
        for fuel_grp in sorted(attention_df["Fuel"].unique()):
            attention_html += f"<h3>Fuel: {fuel_grp}</h3>"
            subset = attention_df[attention_df["Fuel"] == fuel_grp]
            attention_html += subset[["BMU", "Reason", "A_ABS_NetError%", "P90_monthly_error"]].to_html(index=False, classes="data-table")

    return jsonify({
        'kpis': {
            'fleet_median_error': float(fleet_median_error),
            'fleet_p90_error': float(fleet_p90_error),
            'fleet_max_error': float(fleet_max_error),
            'max_bmu_info': max_bmu_info,
            'bmu_count': int(bmu_count),
            'fleet_abs_gwh': float(fleet_abs_gwh),
            'fleet_net_gwh': float(fleet_net_gwh)
        },
        'fuel_summary_html': fuel_summary_html,
        'charts': charts,
        'fleet_table_html': fleet_table_html,
        'tech_data': tech_data,
        'bmu_data': bmu_data,
        'attention_html': attention_html
    })

@app.route('/api/export', methods=['POST'])
def export_csv():
    df_annual_raw, df_monthly_raw, error = load_data()
    if error: return "Data Load Error", 500

    payload = request.json or {}
    export_type = payload.get('export_type')
    fuels = payload.get('fuels', [])
    bmus = payload.get('bmus', [])
    attention_only = payload.get('attention_only', False)

    df_annual, df_monthly = apply_filters(df_annual_raw, df_monthly_raw, fuels, bmus, attention_only)
    
    csv_data = ""
    filename = "export.csv"

    if export_type == 'annual':
        csv_data = df_annual.to_csv(index=False)
        filename = "annual_summary_2025_filtered.csv"
    elif export_type == 'monthly':
        csv_data = df_monthly.to_csv(index=False)
        filename = "monthly_summary_2025_filtered.csv"
    elif export_type == 'attention':
        attention_df = df_annual_raw[df_annual_raw["NeedsAttention"] == True].copy()
        
        def get_reason(row):
            reasons = []
            if row["A_ABS_NetError%"] >= 25: reasons.append(f"Annual Error {row['A_ABS_NetError%']:.1f}% >= 25%")
            if row["P90_monthly_error"] >= 25: reasons.append(f"Monthly P90 {row['P90_monthly_error']:.1f}% >= 25%")
            return "; ".join(reasons)
            
        if not attention_df.empty:
            attention_df["Reason"] = attention_df.apply(get_reason, axis=1)
        csv_data = attention_df.to_csv(index=False)
        filename = "needs_attention_list.csv"
    
    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-disposition": f"attachment; filename={filename}"}
    )

if __name__ == '__main__':
    # When running locally, Flask uses this
    app.run(debug=True, port=8000)
