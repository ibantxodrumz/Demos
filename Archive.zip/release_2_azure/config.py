import os
from dotenv import load_vars

# Load variables from .env if it exists (useful for local testing)
try:
    load_vars()
except ImportError:
    pass # python-dotenv not installed, assuming vars are already in environment

class Config:
    """
    Configuration Variables for Azure App Service Deployment.
    These should not be hardcoded. They should be set in the Azure Portal
    under App Service -> Configuration -> Application settings.
    """
    
    # Storage Connection
    AZURE_STORAGE_CONNECTION_STRING = os.environ.get('AZURE_STORAGE_CONNECTION_STRING', '')
    AZURE_CONTAINER_NAME = os.environ.get('AZURE_CONTAINER_NAME', 'data')
    
    # Blob Names
    ANNUAL_BLOB_NAME = os.environ.get('ANNUAL_BLOB_NAME', 'annual_summary_2025.csv')
    MONTHLY_BLOB_NAME = os.environ.get('MONTHLY_BLOB_NAME', 'monthly_summary_2025.csv')
    
    # Secrets
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default-dev-secret-key')
