# Phase 2 Discovery Documentation Suite

> **Status**: **Phase 1 PASSED & APPROVED** | **Active Phase**: **Phase 2 Discovery**
> **Baseline Release**: `release_2_local_azure_sql_working_final` (Release 2 Final — Azure SQL)
> **Updated**: September 2026

---

## Overview

This directory (`docs/phase2_discovery/`) contains the complete, updated documentation suite for **Phase 2 Discovery**, reflecting all verified code structures from the authoritative `release_2_local_azure_sql_working_final` baseline and capturing all confirmed design decisions for Phase 2.

These documents replace and extend the initial technical documentation set found in `releases/release_2_local_azure_sql_working_final/documentation/`.

---

## Key Architectural Decisions (Phase 2)

1. **Workstream Abstraction & Separation of Concerns (`WorkstreamRegistry`)**:
   Import Constraints is explicitly structured as **one workstream within a generic platform shell**, not the hardcoded application itself. Core alert services and repositories bind dynamically via a central `WorkstreamRegistry`.
2. **Analyst Identity via Landing Page & Session Store**:
   Analyst identity is confirmed on a landing page (`/`) reading from the daily Rota schedule, replacing the `LOCAL_ANALYST_NAME` env var, and stored in `dcc.Store(storage_type='session')`.
3. **Database-Backed Rota & Admin Page**:
   Full CRUD management for analysts (`ANALYSTS`) and weekly/monthly duty shifts (`ROTA`) stored in Azure SQL with Excel import capabilities.
4. **Dynamic Date Range Bug Fix (P0)**:
   Replaces legacy hardcoded month arrays with a dynamic generator reading real date bounds from Azure SQL.

---

## Document Index

| Document | Description | Status & Scope |
|----------|-------------|----------------|
| 📄 [phase2_design_decisions.md](file:///Users/ivansanz/Desktop/PoC/docs/phase2_discovery/phase2_design_decisions.md) | Master Phase 2 architecture, design decisions, Workstream Abstraction pattern (`WorkstreamRegistry`), Risk Matrix, P0–P9 execution roadmap, and Workstream 2 migration strategy. Replaces `phase2_welcome_and_date_analysis.md`. | **Confirmed** |
| 📄 [functions_inventory.md](file:///Users/ivansanz/Desktop/PoC/docs/phase2_discovery/functions_inventory.md) | Complete inventory of all 6 classes and ~55 public functions across the codebase. Includes `user_guide.py`, `sp_analytics_service.py`, `sp_analytics_repository.py`, records `saved_reviews.py` removal, and details Phase 2 additions. | **100% Accurate Baseline** |
| 📄 [layer_connections.md](file:///Users/ivansanz/Desktop/PoC/docs/phase2_discovery/layer_connections.md) | Architectural map of imports, boundary contracts, data flow with `WorkstreamRegistry` from Browser → Page → Service → Repository → Connection → Database, and planned Phase 2 extensions. | **100% Accurate Baseline** |
| 📄 [alert_lifecycle_trace.md](file:///Users/ivansanz/Desktop/PoC/docs/phase2_discovery/alert_lifecycle_trace.md) | Step-by-step function execution trace for alert `ALT-CCGT-001` across load, select, and save phases. Annotated with Phase 2 analyst session store change. | **Verified against Azure SQL** |
| 📄 [alert_lifecycle_diagram.md](file:///Users/ivansanz/Desktop/PoC/docs/phase2_discovery/alert_lifecycle_diagram.md) | Sequence and flow diagrams for alert lifecycle, decision saving, and state transitions. Annotated with Phase 2 session identity updates. | **Verified against Azure SQL** |

---

## Technical Risk Analysis & Mitigation Matrix

| Category | Risk Description | Severity | Mitigation Strategy |
|----------|------------------|----------|---------------------|
| **Navigation & State** | Empty Session Store on Direct URL / Deep-Link Bookmark | **Medium** | Top-level client-side route guard (`dcc.Location`) redirecting to `/` landing page if session store is empty. |
| **Architecture** | Workstream Table Schema Drift & Hardcoded References | **High** | Implement `WorkstreamRegistry` in Part A before onboarding Workstream 2. |
| **Data Operations** | Rota Excel Upload Duplicate Entries / Key Conflicts | **Medium** | Idempotent `MERGE` / `UPSERT` logic in `rota_repository.py` matching on composite key `(ANALYST_ID, WEEK_START_DATE)`. |
| **Data Partitioning** | Multi-Workstream Review Cross-Contamination in `ACTIVITY_LOG` | **High** | Partition all `ACTIVITY_LOG` records and queries by `WORKSTREAM_ID`. |
| **Maintainability** | Legacy Date Generator Failure (Hardcoded Months) | **High (P0)** | Replace `get_available_time_options()` immediately with dynamic date generator. |

---

## Phase 2 Implementation Roadmap (Summary)

```
[P0] Dynamic Dates Fix (alert_service.py)
   ↓
[P1-P2] Azure SQL Tables (ANALYSTS, ROTA) & WorkstreamRegistry Abstraction Mapping
   ↓
[P3-P5] Rota Service/Repository & UI Pages (Admin CRUD & Landing Page with Session Store)
   ↓
[P6-P8] UI Polish: Remove per-page dropdowns, update callbacks to Session Store, Sidebar redesign (navbar.py)
   ↓
[P9] Cleanup: Remove saved_reviews.py stub
   ↓
[Phase 2 Part B] Workstream 2 Migration Exercise (Shared platform architecture)
```
