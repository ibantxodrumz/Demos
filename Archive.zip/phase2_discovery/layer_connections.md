# Layer Connections

> **Version**: Phase 2 Discovery — September 2026
> **Baseline**: `release_2_local_azure_sql_working_final`
> **Change from original**: Added `sp_analytics_service` and `sp_analytics_repository`. Included `WorkstreamRegistry` abstraction layer for Phase 2.

---

## Connection mechanism: Python `import`

```
app.py
  imports → navbar.py (components)
  imports → dash (framework)

alert_review.py (page)
  imports → alert_service, activity_log_service, analytics_service  (services)
  imports → alert_table (component)
  imports → bmrs_links (utils)
  imports → settings (config)

open_reviews.py (page)
  imports → alert_service, activity_log_service  (services)
  imports → alert_table (component)
  imports → settings (config)

closed_reviews.py (page)
  imports → alert_service  (service)
  imports → alert_table (component)
  imports → settings (config)

long_run_analytics.py (page)
  imports → long_run_service  (service)
  imports → settings (config)

import_constraints.py (page)
  imports → sp_analytics_service  (service)
  imports → settings (config)

user_guide.py (page)
  static layout only — no service or repository imports

alert_service.py (service)
  imports → alert_repository  (repository)
  imports → workstream_registry (Phase 2 abstraction)

activity_log_service.py (service)
  imports → activity_log_repository  (repository)
  imports → alert_repository         (repository — looks up alert before saving)
  imports → analytics_service        (service — generates INFO_FOR_ANALYST at save time)
  imports → SaveReviewRequest model  (models)
  imports → settings                 (config)

analytics_service.py (service)
  imports → analytics_repository  (repository)

sp_analytics_service.py (service)         ← analytical dashboard service
  imports → sp_analytics_repository  (repository)

long_run_service.py (service)
  imports → sp_analytics_repository  (repository)

alert_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants / registry  (table name strings & mappings)

activity_log_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

analytics_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

sp_analytics_repository.py (repository)  ← analytical dashboard repository
  imports → connection.get_db     (connection)
  imports → constants

connection.py
  imports → azure_connection      (Azure-specific driver)
  imports → settings              (reads DATABASE_MODE)
  imports → sqlite3               (Python stdlib)
```

---

## Contract at each boundary

| Boundary | What crosses it |
|---|---|
| Page → Service | function call, simple Python types (str, int, None) |
| Service → Repository | function call, simple Python types |
| Repository → Connection | calls `get_db()` context manager |
| Connection → Database | SQL string + params dict |
| Database → Connection | raw rows |
| Connection → Repository | connection object |
| Repository → Service | list of plain Python `dict` |
| Service → Page | dict or list of dicts |
| Page → Browser | Dash component tree (HTML) |

Nothing exotic crosses any boundary. No classes, no dataframes — plain Python dicts and lists throughout. Exception: `enrich_sp_data()` works internally with a pandas DataFrame but returns dicts to the page.

---

## Flow diagram (with Workstream Abstraction)

```mermaid
graph LR
    A[Page Layout] -->|"session.workstream_id"| B[Service Layer]
    B -->|"lookup tables & schema"| WR[WorkstreamRegistry]
    WR -->|"table names & config"| B
    B -->|"calls query f(workstream, dates)"| C[Repository]
    C -->|"get_db()"| D[Connection]
    D -->|SQL| E[(Azure SQL Database)]
    E -->|raw rows| D
    D -->|conn object| C
    C -->|list of dict| B
    B -->|dict| A

    style A fill:#0891b2,color:#fff
    style B fill:#2563eb,color:#fff
    style WR fill:#d97706,color:#fff
    style C fill:#6d1a57,color:#fff
    style D fill:#4e0038,color:#fff
    style E fill:#1e293b,color:#fff
```

---

## The one exception (core lifecycle)

`activity_log_service` calls both a repository **and** another service (`analytics_service`). Intentional — saving a review needs WHY evidence from analytics_service. Calling a service is cleaner than duplicating the logic in the repository.

---

## Why this matters

Because each layer only knows its immediate neighbour:

- Swap `connection.py` → different database, nothing else changes
- Swap a repository query → different SQL, service doesn't care
- Swap a page layout → different UI, service doesn't care
- Add a new workstream → register in `WorkstreamRegistry`, core platform shell handles it automatically

---

## Phase 2 Additions (planned)

New files following the established layer pattern:

| File | Layer | Purpose |
|------|-------|---------|
| `config/workstream_registry.py` | Config / Abstraction | Central mapping of workstream IDs → table names, routes, evidence providers |
| `pages/landing.py` | Page | Analyst identity confirmation + rota display |
| `pages/admin.py` | Page | Analyst and rota CRUD management |
| `services/rota_service.py` | Service | Rota retrieval, today's assignment, analyst list |
| `repositories/rota_repository.py` | Repository | CRUD against `ANALYSTS` and `ROTA` tables |

No new connection or database layer changes required — all new pages follow the existing Page → Service → Repository → Connection pattern.
