# Phase 2 — Confirmed Design Decisions

> **Version**: Phase 2 Discovery — September 2026
> **Replaces**: `phase2_welcome_and_date_analysis.md` from the release `documentation/` folder
> **Status**: All decisions confirmed. Ready for Phase 2 Part A engineering.

---

## Context

Phase 1 (Import Constraints full workflow on Azure SQL) is **PASSED & APPROVED**.
The authoritative baseline is `release_2_local_azure_sql_working_final`.

Phase 2 is split into two parts:
- **Part A**: Platform hardening — make Import Constraints production-ready and prepare architecture for Workstream 2
- **Part B**: Workstream 2 migration exercise

---

## Decision 1 — Dynamic Dates (P0 Active Bug)

### Problem
`get_available_time_options()` in `services/alert_service.py` returns a **hardcoded** list of months (Jan–Jun 2026 only) and 26 weeks. The date picker is already broken — it is September 2026 and no current week or month is selectable.

### Decision
Replace the hardcoded lists with a **dynamic generator**:

1. **Lower bound**: Call `sp_analytics_repository.get_database_date_bounds()` → returns MIN date in `IMPORT_ALERTS_DATA`. Fall back to a configured start year if query fails.
2. **Upper bound**: `datetime.today()` — always current.
3. **Months**: Programmatically generate every calendar month from lower bound to today.
4. **Weeks**: Programmatically generate ISO weeks (Monday–Sunday) for the same range using `datetime.isocalendar()`.

Self-maintaining — no code change required as time passes. This is **P0** and must be fixed before any analyst uses the application in production.

---

## Decision 2 — Landing Page + Analyst Identity

### Problem
Analyst identity currently comes from the `LOCAL_ANALYST_NAME` environment variable — a developer workaround. There is no production mechanism for identifying who is doing the review. The workstream dropdown sits redundantly on every operational page.

### Decision: Landing Page at `/`

The application entry point is a **landing page** (`pages/landing.py`, registered at `/`).

**Flow**:
1. Landing page queries `ROTA` table for today's on-duty analyst and workstream assignment.
2. The rota analyst is **suggested** (highlighted card) — not automatically selected.
3. Analyst must **actively click their name** to confirm — this is a deliberate, auditable act every session.
4. Override available: any active analyst from `ANALYSTS` table can be selected (for cover arrangements).
5. Confirmed analyst name + workstream are written to `dcc.Store(storage_type='session')`.
6. App navigates to `/alert-review` (or relevant workstream page).

**If session is empty** (e.g. direct URL bookmark): all pages redirect to `/` automatically.

### State mechanism: Session Store (confirmed)

URLs remain unchanged (`/alert-review`, `/open-cases`, etc.).

`LOCAL_ANALYST_NAME` env var is **removed** — identity always comes from the session store after confirmation on the landing page.

---

## Decision 3 — Admin Page + Analyst Rota

### New page: `pages/admin.py` at `/admin`

Provides full CRUD management of the analyst rota. Accessible from the sidebar.

### New Azure SQL Tables

```sql
-- Master list of analysts
CREATE TABLE ANALYSTS (
    ANALYST_ID    NVARCHAR(50)  PRIMARY KEY,
    NAME          NVARCHAR(100) NOT NULL,
    EMAIL         NVARCHAR(150),
    ACTIVE        BIT           NOT NULL DEFAULT 1
);

-- Weekly rota
CREATE TABLE ROTA (
    ROTA_ID          NVARCHAR(50)  PRIMARY KEY,
    ANALYST_ID       NVARCHAR(50)  NOT NULL REFERENCES ANALYSTS(ANALYST_ID),
    WEEK_START_DATE  DATE          NOT NULL,
    ON_DUTY_DAYS     NVARCHAR(50),   -- e.g. "Mon,Tue,Wed"
    WORKSTREAM       NVARCHAR(100),  -- e.g. "IMPORT_CONSTRAINTS"
    ROLE             NVARCHAR(50)    -- e.g. "Lead", "Support"
);
```

### Rota tracks two things (confirmed)
1. **General on-duty schedule** — who covers monitoring per day of the week
2. **Workstream assignment per week** — which analyst leads which workstream for the week

### Admin page capabilities
- **Analysts tab**: Add, Edit, Deactivate analysts (`ANALYSTS` table)
- **Rota tab**: Add, Edit, Remove rota entries (`ROTA` table)
- **Views**: Weekly calendar view + monthly overview
- **Excel import**: Upload and populate rota from existing team Excel rota (initial migration)
- **Ad-hoc**: Any entry editable at any time

---

## Decision 4 — Sidebar Redesign

### Current State
`navbar.py` has a static list of `dcc.Link` components. Each page also has a `dcc.Dropdown(id="select-workstream")` that allows switching workstream from within the page.

### Decision
**Remove** `dcc.Dropdown(id="select-workstream")` from all 5 operational page layouts:
- `alert_review.py`
- `open_reviews.py`
- `closed_reviews.py`
- `long_run_analytics.py`
- `import_constraints.py`

**Update `navbar.py` `create_sidebar()`**:
- Add **"Home"** link at the top → routes to `/` (landing page) for analyst/workstream re-selection
- Display **active analyst name** in sidebar header (read from session store)
- Display **active workstream** in sidebar header (read from session store)
- Add **"Admin"** link → routes to `/admin`
- Existing page links unchanged

All page callbacks that previously read from the workstream dropdown now read from the session store.

---

## Decision 5 — Workstream Abstraction & Separation of Concerns (KEY ARCHITECTURAL DECISION)

### Goal
Ensure **Import Constraints** is explicitly structured as **one workstream within a generic platform**, not **the** application code itself.

### Architecture Plan
1. **`WorkstreamRegistry` (Central Mapping)**:
   Define a central configuration mapping workstream identifiers to their respective database tables, analytical support views, and portal link generators.
   ```python
   # Example WorkstreamRegistry pattern
   WORKSTREAMS = {
       "IMPORT_CONSTRAINTS": {
           "name": "Import Constraints",
           "alerts_table": "IMPORT_ALERTS",
           "data_table": "IMPORT_ALERTS_DATA",
           "dashboard_page": "/import-constraints",
           "has_bmrs_links": True
       },
       "WORKSTREAM_2": {
           "name": "Workstream 2 Name",
           "alerts_table": "WS2_ALERTS",
           "data_table": "WS2_ALERTS_DATA",
           "dashboard_page": "/workstream-2",
           "has_bmrs_links": False
       }
   }
   ```
2. **Dynamic Repository Bindings**:
   `alert_repository.py` and `activity_log_repository.py` receive the active `workstream_id` from the service layer and dynamically bind to the correct underlying tables.
3. **Decoupled Analytical Extensions**:
   Workstream-specific analytics (e.g. C1/C2/C3 calculations in `sp_analytics_service.py`) are kept completely separate from core alert review state management.

---

## Decision 6 — Cleanup: `saved_reviews.py` Removed

`saved_reviews.py` (347 bytes) was a redirect stub from Release 1 routing `/saved-reviews` → `/closed-reviews`. It is dead code. **Remove** from `src/pages/`.

Note: `get_saved_reviews()` in `activity_log_service.py` and `get_all_saved_reviews()` in `activity_log_repository.py` are **real functions used elsewhere** and are NOT removed.

---

## Technical Risk Analysis & Mitigation Matrix

| Category | Risk Description | Risk Level | Mitigation Strategy |
|----------|------------------|------------|---------------------|
| **Authentication & Session** | Empty Session Store when bookmarking operational URLs directly | **Medium** | Implement top-level layout route guard checking session store state; auto-redirect (`dcc.Location`) to `/` if empty. |
| **Architecture & Coupling** | Hardcoded table names in `alert_service` / `alert_repository` breaking multi-workstream expansion | **High** | Implement `WorkstreamRegistry` abstraction in Part A before onboarding Workstream 2. |
| **Database Operations** | Concurrent Excel uploads creating duplicate entries or PK collisions in `ROTA` | **Medium** | Use SQL `MERGE` / `UPSERT` statements keyed on `(ANALYST_ID, WEEK_START_DATE)` during Rota Excel import. |
| **Data Integrity** | Review cross-contamination across workstreams in `ACTIVITY_LOG` | **High** | Enforce `WORKSTREAM_ID` partitioning on all `ACTIVITY_LOG` queries and writes. |
| **Operational Bug** | Hardcoded month list in `get_available_time_options()` preventing selection of current dates | **High (P0)** | Replace with dynamic date bound generator using DB bounds and `datetime.today()`. |

---

## Phase 2 Part A — Implementation Order

| Priority | Task | Files affected | Complexity |
|----------|------|---------------|-----------|
| P0 | Fix dynamic dates | `alert_service.py` | Low |
| P1 | Create `ANALYSTS` + `ROTA` tables in Azure SQL | SQL schema | Low |
| P2 | Build `WorkstreamRegistry` & abstract repo table mappings | New file / `constants.py` | Medium |
| P3 | Build `rota_repository.py` & `rota_service.py` | New files | Low |
| P4 | Build Admin page (`admin.py`) with CRUD + views | New file | Medium |
| P5 | Build landing page (`landing.py`) with rota + confirmation | New file | Medium |
| P6 | Remove workstream dropdown from all 5 operational pages | 5 page files | Medium |
| P7 | Update callbacks to read workstream & analyst from session store | 5 page files | Medium |
| P8 | Redesign sidebar (`navbar.py`) | `navbar.py` | Low |
| P9 | Remove `saved_reviews.py` | 1 page file | Trivial |

---

## Phase 2 Part B — Workstream 2 Migration (after Part A)

**Decision**: Workstream 2 is a **migration exercise**, not a new build from scratch.

Approach:
1. Identify all **shared platform components** (landing, session management, sidebar, open/closed review pages, long-run analytics, save pipeline)
2. Define the **scalable architecture** — how workstream-specific pages plug into the shared shell via `WorkstreamRegistry`
3. Define what is **workstream-specific** (alert data schema, analytical dashboards, evidence views, BMRS link parameters)
4. Migrate Workstream 2 following the established patterns — minimum new code

---

## Deferred (Not Phase 2)

| Item | Reason |
|------|--------|
| AAD / Entra ID authentication | Replaces landing page analyst selection in production. Deferred — landing page is the interim mechanism. |
| Historical NED data migration | Requires separate scoping discussion |
| Workstreams 3, 4, 5 | Follow after Workstream 2 pattern is proven |
| Full Power BI governance integration | Separate workstream |
