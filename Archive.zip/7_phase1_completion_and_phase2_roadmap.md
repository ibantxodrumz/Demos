# PoC Phase 1 Completion & Phase 2 Discovery Milestone

## Executive Summary

- **Phase 1 Status**: **PASSED & APPROVED**
- **Approval Date**: September 14, 2026
- **Authoritative Release Baseline**: `release_2_local_azure_sql_working_final` (Release 2 Final)
- **Current Operational Target**: Azure SQL Database (`DATABASE_MODE="azure"`)

---

## Key Achievements (Phase 1)

1. **Excel Replacement**: Proved complete operational replacement of legacy Excel monitoring for Import Constraints.
2. **State & Review Persistence**: Full lifecycle management of Unreviewed, Open, and Closed cases stored directly in Azure SQL (`ACTIVITY_LOG`).
3. **Audit Trail & Governance**: Seamless transition of closed investigations from Open Reviews to Closed Reviews with analyst metadata and timestamps.
4. **Analytical Support**: Integrated settlement period evidence, behavioral classification taxonomy, financial impact modeling, and external Elexon BMRS portal links.
5. **Long-Run Analytics**: Counterparty framing, threshold breach detection, and multi-week trend reporting.

---

## Phase 2 — Scope & Design Decisions

Phase 2 is divided into two parts:

### Part A — Platform Hardening (Import Constraints production-ready + architecture for WS2)

#### 1. Dynamic Dates (P0 — active bug)

`get_available_time_options()` in `alert_service.py` is hardcoded to Jan–Jun 2026.
The date picker is already broken (September 2026).

**Decision**: Replace with a dynamic generator reading real-world date (rolling ~3 years back from today). Uses `get_database_date_bounds()` as the lower bound.

---

#### 2. Landing Page — Analyst Identity

**Decision**: A landing page replaces the current workstream dropdown on each page.

The analyst selects their name on the landing page before entering the application. This feeds `PERSON_RAISING` (replacing the `LOCAL_ANALYST_NAME` env var) and is stored in a `dcc.Store(storage_type='session')`.

- All operational pages read analyst identity from the session store, not from an env var.
- If the session store is empty (e.g., direct URL bookmark), the app redirects to the landing page.
- The landing page will show which analyst is on the rota for today (see Admin/Rota below).

---

#### 3. Admin Page — Analyst Rota

**Decision**: A separate Admin page provides CRUD management of an analyst rota.

**Rota tracks two things** (confirmed):
- **General on-duty schedule**: who covers monitoring per day of the week
- **Workstream assignments per week**: who is assigned to each workstream for a given week (e.g. Ivan → Import Constraints W/C 14 Sep)

**New Azure SQL tables required**:

| Table | Purpose |
|-------|---------|
| `ANALYSTS` | Master list of analysts (ID, name, email, active flag) |
| `ROTA` | Weekly schedule (analyst, week start date, on-duty days, workstream assignment) |

**Admin page capabilities**:
- Add / Edit / Remove analysts from `ANALYSTS`
- Add / Edit / Remove rota entries
- View rota in **weekly** and **monthly** views
- **Import from Excel**: initial rota population via Excel upload (existing team rota migrated in)
- **Ad-hoc CRUD**: changes can be made at any time as the rota evolves

**Landing page integration**: The landing page reads today's rota from `ROTA` and **suggests** the analyst on duty. The analyst must always **actively confirm** by clicking their name before entering the app. Override is always available (e.g. for cover arrangements). Every session start is a deliberate, auditable act.

---

#### 4. Sidebar Redesign

**Decision**: The workstream dropdown is removed from all operational pages.

Sidebar changes:
- Add a **"Home"** link (returns to landing page for workstream/analyst reselection)
- Display the **active analyst name** and **active workstream** in the sidebar header
- Static page links remain (alert review, open reviews, closed reviews, long-run analytics, import constraints dashboard)

---

#### 5. Workstream Abstraction & Separation of Concerns (KEY ARCHITECTURAL DECISION)

**Decision**: Abstract all workstream references so **Import Constraints** is explicitly structured as **one workstream among many**, not THE hardcoded workstream.

- **Workstream Registry (`WorkstreamRegistry`)**: Introduce a generic workstream configuration mapping Workstream ID → Database Table names (`IMPORT_ALERTS` vs `WS2_ALERTS`), Analytical Dashboards, Evidence Providers, and Portal Generators (e.g. Elexon BMRS links vs alternative portal links).
- **Core Platform Shell**: The alert queue (`alert_review.py`), decision capture, open/closed review management (`open_reviews.py`, `closed_reviews.py`), and audit logging (`ACTIVITY_LOG`) interact with the registry abstractly rather than importing workstream-specific SQL queries directly.
- **Strict Separation of Concerns**: Workstream-specific analytics (such as `import_constraints.py` dashboard, C1/C2/C3 financial models, and ensemble logic) are encapsulated strictly within workstream modules, preventing core platform contamination.

---

#### 6. Cleanup — `saved_reviews.py`

`saved_reviews.py` is a 347-byte near-empty stub left from Release 1 (SQLite prototype). Its functionality was superseded by `open_reviews.py` and `closed_reviews.py`. Recommend removing in Phase 2 to avoid dead code.

---

### Part B — Workstream 2 Migration

Once Part A is complete and Import Constraints is running in production:

**Decision**: Workstream 2 is treated as a **migration exercise**, not a new build.

The migration approach:
1. Identify all **common functionality** that can be shared across workstreams (alert queue, decision capture, open/closed reviews, long-run analytics, sidebar, session management)
2. Define the **best architecture for scalability** — how workstream-specific pages/behaviour are plugged into the shared platform shell via `WorkstreamRegistry`
3. Add Workstream 2 following the established patterns

---

## Technical Risk Analysis & Mitigation Matrix

| Risk Category | Identified Risk | Severity | Mitigation Strategy |
|---------------|-----------------|----------|---------------------|
| **State & Navigation** | Empty Session Store on Direct URL / Deep-Link Bookmark | **Medium** | Implement global layout route guard. If session store is empty, automatically issue client-side redirect (`dcc.Location`) to `/` landing page. |
| **Architecture** | Workstream Schema Drift & Hardcoded Table Names | **High** | Implement `WorkstreamRegistry` in Phase 2 Part A. Abstract table names and evidence interfaces before onboarding Workstream 2. |
| **Data Integrity** | Rota Excel Upload Duplicate Entries / Key Conflicts | **Medium** | Implement idempotent `MERGE` / `UPSERT` logic in `rota_repository.py` matching on composite key `(ANALYST_ID, WEEK_START_DATE)`. |
| **Data Partitioning** | Multi-Workstream Review Cross-Contamination in `ACTIVITY_LOG` | **Medium** | Ensure all `ACTIVITY_LOG` records and queries explicitly partition by `WORKSTREAM_ID`. |
| **Maintainability** | Legacy Date Generator Failure (Hardcoded Months) | **High (P0)** | Replace `get_available_time_options()` immediately with dynamic generator bounded by DB min date and `datetime.today()`. |

---

## Open Questions (Resolved During Discovery)

1. ✅ **Rota granularity**: Dual — general on-duty schedule (per day) AND workstream assignments per week.
2. ✅ **Landing page selection**: Rota suggests today's analyst; analyst always confirms actively (auditable). Ad-hoc override always available. Initial rota populated from existing Excel rota.
3. ✅ **Workstream Abstraction**: Core platform decoupled from specific workstream tables via `WorkstreamRegistry`.
4. **Historical NED data migration**: To be raised and scoped separately.

---

## Deferred Decisions

- AAD / Entra ID integration (real authentication — deferred, not Phase 2)
- Historical data migration from NED (to be raised and scoped separately)
- Full governance Power BI integration
- Workstreams 3, 4, 5
