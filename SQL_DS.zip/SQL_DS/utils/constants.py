# utils/constants.py
# Define shared constants for SQL and Local Data Sources

# SQL Azure Configuration
SQL_SERVER = "sql-server-placeholder"
SQL_DATABASE = "sql-database-placeholder"
SQL_TABLE = "[dbo].[IMPORT_ALERTS_DATA]"
SQL_QUERY = f"SELECT * FROM {SQL_TABLE}"

# Local Data Configuration
LOCAL_INPUT_DIR = "inputs"
DEFAULT_ALERTS_FILENAME = "IMPORT_ALERTS_DATA.csv"
