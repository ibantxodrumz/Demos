# Import Constraints Dashboard (Release 5)

This repository contains a Streamlit dashboard used by the Market Monitoring team to analyse import constraint behaviour using local data and Azure SQL.

---

## Prerequisites (All Users)

- Windows laptop
- Anaconda installed
- ODBC Driver 18 for SQL Server installed
- Access to the NESO AAE Azure SQL database

No manual Azure CLI login is required.

---

## Supported Setup Scenarios

This README supports **both** of the following situations:

1. ✅ You already have a virtual environment from an earlier version of this dashboard  
2. ✅ You are setting the dashboard up for the first time  

Follow the section that applies to you.

---

## Option A — Existing Environment (Upgrade)

If you already have a virtual environment used for previous versions of this dashboard:

### 1. Activate your existing environment


conda activate (environment name - mm dashboard etc.)


### 2. Update dependencies

From the project root:

python -m pip install --upgrade pip
python -m pip install -r requirements.txt


This updates any new or changed dependencies introduced in this release.

---

### 3. Run the dashboard


python -m streamlit run app.py


---

## Option B — Fresh Environment (First‑time Setup)

If you do NOT already have a dashboard environment:

### 1. Create a new environment


conda create -n (environment name) python=3.11
conda activate (environment name)


---

### 2. Install dependencies

From the project root:


python -m pip install --upgrade pip
python -m pip install -r requirements.txt

---

### 3. Run the dashboard


python -m streamlit run app.py


---

## Azure SQL Authentication (What to Expect)

When the dashboard first connects to Azure SQL, a browser or Windows sign‑in window will open automatically.

- Sign in using your NG email account
- Close the browser window once authentication succeeds

This process is automatic.
No manual login commands are required.

---


## Using VS Code

VS Code is **fine to use for editing or browsing the code**.

If you use VS Code, please run the dashboard from a **Command Prompt terminal inside VS Code**, not via Run/Play buttons or Streamlit extensions.

Steps:

1. Open the project folder in VS Code
2. Open a **Command Prompt** terminal (Terminal → New Terminal → Command Prompt)
3. Run:


python -m streamlit run app.py


This ensures the dashboard runs under the correct Python environment.



## Important Note on Running the App

Always run the dashboard using:


python -m streamlit run app.py


Do **not** use:


streamlit run app.py


Using the `python -m` form ensures the dashboard runs under the correct Python environment and avoids issues with native dependencies such as `pyodbc`.

---

## Troubleshooting (Quick Checks)

Check which Python is being used:


python -c "import sys; print(sys.executable)"


Check that `pyodbc` is available:


python -c "import pyodbc; print(pyodbc.__file__)"


If SQL access fails:

- ensure you completed the browser sign‑in when prompted
- ensure you have access to the target database
- ensure ODBC Driver 18 is installed

---


## Summary

- Existing users: activate env → install requirements → run app

- New users: create env → install requirements → run app

- VS Code is fine, but use **Command Prompt** (including the one inside VS Code)

- Always run with:

   python -m streamlit run app.py

- Browser sign‑in for SQL is expected and automatic
