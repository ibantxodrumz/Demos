"""
Utilities for IC_ENCC Click 2.
Helpers for logging, PN ingest, trades ingest, awareness, deltas, matching, roll-ups, classification, and advisory.
"""

# =========================
# Standard/Third-Party Imps
# =========================
import os
import re
import json
import uuid
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
pd.set_option('future.no_silent_downcasting', True)

# .env for local dev; safe to ignore if not present
try:
    from dotenv import load_dotenv

    load_dotenv()
except Exception:
    pass

# ===========
# App Imports
# ===========
from constants import (
    OUTPUTS_DIR,
    LOGS_DIR,
    CP_CODES_FILE,
    IC_PATHS,
    TIMEZONE_LOCAL,
    FILENAME_TOKEN_REGEX,
    CAP_HOURS,
    TOLERANCE_MW,
    LOG_LEVEL,
    LOG_FILE_MAX_BYTES,
    LOG_FILE_BACKUP_COUNT,
)

# ============
# Public API
# ============
__all__ = [
    # Logging / summaries
    "setup_logger",
    "log_step",
    "write_run_summary_txt",
    "write_run_summary_json",
    # PN ingest / transform
    "list_pn_files",
    "read_and_melt_pn",
    "compute_delta_pn",
    # Trades ingest / awareness
    "fetch_trades",
    "load_cp_mapping",
    "map_bmu_to_cp",
    # Matching / rollups / classification
    "match_pn_to_trades",
    "rollup_company_hour",
    "classify_v2",
    # Receipts / window inference
    "parse_mcnn_token",
    "collect_receipts",
    "token_to_dt",
    "infer_latest_day_and_pair",
    "get_files_in_window",
    # Forward horizon helpers
    "compute_delivery_horizon",
    "filter_forward_horizon",
    "count_rows_by_delivery_hour",
    "extract_h_plus_1_view",
    "sample_changed_rows",
    "format_operator_banner",
    # Forward advisory
    "build_forward_advisory",
    "tidy_advisory_latest",
    "summarise_advisory",
    # Countertrade helpers
    "opposite_bmu_id",
    "detect_countertrade_on_same_ic",
    "apply_yes3_countertrade_override",
    # File writers
    "write_csv",
    "write_csv_bom",
]


# =================
# Logging & Summaries
# =================
def setup_logger(ic: str, ymd_chosen: str) -> tuple[logging.Logger, Path, str]:
    """Configure logging (file + console) and return (logger, log_path, run_id)."""
    run_id = str(uuid.uuid4())
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    log_path = LOGS_DIR / f"click2_{ic}_{ymd_chosen}_{ts}.log"

    # Root logger for this run
    logger = logging.getLogger(f"click2.{run_id}")
    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    logger.propagate = False

    # File handler (rotating)
    fh = RotatingFileHandler(
        str(log_path),
        maxBytes=LOG_FILE_MAX_BYTES,
        backupCount=LOG_FILE_BACKUP_COUNT,
        encoding="utf-8",
    )
    fh.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    fh.setFormatter(
        logging.Formatter(
            fmt="[{asctime}][{levelname}] {message}",
            datefmt="%Y-%m-%d %H:%M:%S",
            style="{",
        )
    )

    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))
    ch.setFormatter(logging.Formatter(fmt="[{levelname}] {message}", style="{"))

    logger.addHandler(fh)
    logger.addHandler(ch)

    # Header
    logger.info(
        f"RUN START | id={run_id} | ic={ic} | day={ymd_chosen} | log={log_path}"
    )
    return logger, log_path, run_id


def log_step(logger: logging.Logger, status: str, name: str, **kv) -> None:
    """Emit a structured step line: START/OK/FAIL with context."""
    msg = f"STEP {status.upper():<5} | {name}"
    if kv:
        parts = " | " + " | ".join(f"{k}={v}" for k, v in kv.items())
        msg += parts
    level = logging.ERROR if status.lower() == "fail" else logging.INFO
    logger.log(level, msg)


def write_run_summary_txt(ic: str, ymd_chosen: str, summary: dict) -> Path:
    """Write a human-readable run summary (TXT) and return its path."""
    path = OUTPUTS_DIR / f"Run_Summary_{ic}_{ymd_chosen}.txt"
    lines = [
        f"Interconnector Tool — Click 2 Run Summary",
        f"Run ID         : {summary.get('run_id')}",
        f"IC             : {ic}",
        f"Chosen Day     : {ymd_chosen}",
        f"Start UTC      : {summary.get('start_utc')}",
        f"End UTC        : {summary.get('end_utc')}",
        f"Duration (s)   : {summary.get('duration_s')}",
        f"Latest Receipt : {summary.get('latest_receipt_utc')}",
        f"H+1 Hour       : {summary.get('h_plus_1_utc')}",
        f"Delivery Scope : {summary.get('delivery_start_utc')} → {summary.get('day_end_utc')} (UTC)",
        f"--- Comparison 1 ---",
        f"Status         : {summary.get('c1_status')}",
        f"Message        : {summary.get('c1_message')}",
        f"--- Trades & Matching ---",
        f"Trades Rows    : {summary.get('trades_rows')}",
        f"On-IC Met      : {summary.get('on_ic_met_count')}",
        f"Across-IC Met  : {summary.get('across_ic_met_count')}",
        f"Countertrades  : {summary.get('countertrade_count')}",
        f"--- Classification ---",
        f"YES1/YES2/YES3/NO/INFO : {summary.get('class_tallies')}",
        f"--- Advisory ---",
        f"Advisory Hours : {summary.get('advisory_hours')}",
        f"Outputs        :",
        *(f" - {p}" for p in summary.get("output_paths", [])),
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def write_run_summary_json(ic: str, ymd_chosen: str, summary: dict) -> Path:
    """Write a machine-readable run summary (JSON) and return its path."""
    path = OUTPUTS_DIR / f"Run_Summary_{ic}_{ymd_chosen}.json"
    path.write_text(json.dumps(summary, default=str, indent=2), encoding="utf-8")
    return path


# ============================
# PN Ingest & Standardisation
# ============================
def list_pn_files(ic_name: str) -> List[Path]:
    """List all .xls/.xlsx PN files for a given interconnector."""
    base = IC_PATHS.get(ic_name)
    if base is None or not base.exists():
        return []
    # [Refactor] Support both extensions
    return sorted([p for p in base.glob("MCNN *") if p.suffix.lower() in (".xls", ".xlsx")])


def read_and_melt_pn(file_path: Path, ic_name: str) -> pd.DataFrame:
    """Read wide PN .xls/.xlsx and return tidy DF [BMU_ID, IC, DatetimeUTC, ReceiptUTC, PN_value]."""
    # [Refactor] Remove engine="xlrd" to allow pandas to choose (e.g., openpyxl for xlsx)
    df = pd.read_excel(file_path)
    # [Schema Guard] Verify UNIT column exists
    if "UNIT" not in df.columns:
        # Some files have headers on row 1
        df.columns = df.iloc[0]
        df = df.iloc[1:]
        if "UNIT" not in df.columns:
            # Try row 2
            df.columns = df.iloc[0]
            df = df.iloc[1:]
    
    if "UNIT" not in df.columns:
        raise ValueError(f"MALFORMED_INPUT: Excel file {file_path.name} is missing required 'UNIT' column.")
    
    df_melt = df.melt(id_vars=["UNIT"], var_name="DatetimeLocal", value_name="PN_value")
    df_melt["DatetimeLocal"] = pd.to_datetime(df_melt["DatetimeLocal"], errors="coerce")
    df_melt = df_melt.rename(columns={"UNIT": "BMU_ID"})
    df_melt["BMU_ID"] = df_melt["BMU_ID"].replace({"TOTAL PNS": "TOTAL_PNS_AT"})
    df_melt["IC"] = ic_name

    m = re.search(FILENAME_TOKEN_REGEX, file_path.name)
    if m:
        date_str = m.group("date")
        hour_str = m.group("hour") or "00"
        df_melt["ReceiptLocal"] = pd.to_datetime(
            f"{date_str} {hour_str}:00:00", format="%Y%m%d %H:%M:%S"
        )
    else:
        df_melt["ReceiptLocal"] = pd.to_datetime(file_path.stat().st_mtime, unit="s")

    df_melt = df_melt.dropna(subset=["DatetimeLocal", "BMU_ID"])
    df_melt["PN_value"] = pd.to_numeric(df_melt["PN_value"], errors="coerce")

    # DST-safe localisation then UTC-naive
    df_melt["DatetimeUTC"] = (
        df_melt["DatetimeLocal"]
        .dt.tz_localize(TIMEZONE_LOCAL, ambiguous="infer", nonexistent="shift_forward")
        .dt.tz_convert("UTC")
        .dt.tz_localize(None)
    )
    df_melt["ReceiptUTC"] = (
        df_melt["ReceiptLocal"]
        .dt.tz_localize(TIMEZONE_LOCAL, ambiguous="infer", nonexistent="shift_forward")
        .dt.tz_convert("UTC")
        .dt.tz_localize(None)
    )

    tidy = df_melt[["BMU_ID", "IC", "DatetimeUTC", "ReceiptUTC", "PN_value"]].copy()
    return tidy


def compute_delta_pn(pn_tidy: pd.DataFrame) -> pd.DataFrame:
    """Compute ΔPN per (BMU, DatetimeUTC) ordered by ReceiptUTC."""
    if pn_tidy is None or pn_tidy.empty:
        return pn_tidy.assign(DeltaPN=pd.Series(dtype="float64"))
    pn = pn_tidy.copy()
    pn = pn.sort_values(["BMU_ID", "DatetimeUTC", "ReceiptUTC"])
    pn["DeltaPN"] = pn.groupby(["BMU_ID", "DatetimeUTC"])["PN_value"].diff().fillna(0.0)
    return pn


# ==============================
# Trades Ingest (API-first) etc.
# ==============================
def _as_bool(val: Optional[str], default: bool = True) -> bool:
    """Parse common truthy strings to bool."""
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "y", "on")


def _build_url(base: str, endpoint: str, start_date: str, end_date: str) -> str:
    """Build OData URL with date filter query params."""
    base = base.rstrip("/")
    endpoint = endpoint.lstrip("/")
    return f"{base}/{endpoint}?$filter=Start_Time_UTC%20ge%20{start_date}%20and%20End_Time_UTC%20lt%20{end_date}"


def fetch_trades(
    window_start_utc: datetime,
    window_end_utc: datetime,
    mode: str = "api_first",  # "api_first" | "strict_api" | "replay"
    masterfile_dir: Optional[Path] = None,
    logger: Optional[logging.Logger] = None,
) -> pd.DataFrame:
    """Fetch trades using API-first with snapshot/masterfile write-through."""
    snap = OUTPUTS_DIR / f"trades_{window_start_utc.date()}_{window_end_utc.date()}.csv"

    def _normalise(df: pd.DataFrame) -> pd.DataFrame:
        """Normalise raw enTrader payload to expected column set."""
        if df is None or df.empty:
            return pd.DataFrame()
        for col in [
            "Start_Time_UTC",
            "End_Time_UTC",
            "Trade_Created",
            "Last_Updated",
            "Traded_Date",
            "DATETIME_FROM",
            "DATETIME_TO",
            "Awareness_Start",
        ]:
            if col in df.columns:
                df[col] = pd.to_datetime(
                    df[col], errors="coerce", utc=True
                ).dt.tz_convert(None)
        df = df.rename(
            columns={
                "Unit_Volume": "Unit_Volume_MW",
                "Price": "Price_£/MWh",
                "NGC_BM_Unit_Name": "BMU_ID",
                "Start_Time_UTC": "DATETIME_FROM",
                "End_Time_UTC": "DATETIME_TO",
            }
        )
        cols = [
            c
            for c in [
                "BMU_ID",
                "Agreement_Type",
                "DATETIME_FROM",
                "DATETIME_TO",
                "Traded_Date",
                "Trade_Created",
                "Unit_Volume_MW",
                "Total_Volume",
                "Price_£/MWh",
            ]
            if c in df.columns
        ]
        df = df[cols].copy()
        if {"Traded_Date", "Trade_Created"}.issubset(df.columns):
            lag_hours = (
                df["Traded_Date"] - df["Trade_Created"]
            ).dt.total_seconds() / 3600.0
            df["Awareness_Start"] = df["Traded_Date"] - pd.to_timedelta(
                np.minimum(lag_hours, CAP_HOURS), unit="h"
            )
        else:
            df["Awareness_Start"] = pd.NaT
        if {"DATETIME_FROM", "Traded_Date"}.issubset(df.columns):
            df["Trade_lag_hours"] = (
                df["DATETIME_FROM"] - df["Traded_Date"]
            ).dt.total_seconds() / 3600.0
        else:
            df["Trade_lag_hours"] = np.nan
        return df

    if mode == "replay":
        if not snap.exists():
            if logger:
                logger.error(f"Replay requested but snapshot missing: {snap}")
            return pd.DataFrame()
        if logger:
            logger.info(f"Loaded trades snapshot (replay): {snap}")
        return _normalise(pd.read_csv(snap))

    def _call_api_df() -> pd.DataFrame:
        """Call enTrader OData endpoint and return raw DataFrame."""
        API_BASE = os.environ.get(
            "ENTRADER_BASE", "https://prod.contigocloud.com/enTrader/NGC/OData/"
        )
        ENDPOINT = os.environ.get(
            "ENTRADER_EP", "extended/Trades_By_Agreement_Type_PostP399"
        )
        API_KEY = os.environ.get("ENTRADER_API_KEY", "").strip()
        if not API_KEY:
            raise RuntimeError("ENTRADER_API_KEY not set")
        https_proxy = os.environ.get("HTTPS_PROXY")
        proxies = {"https": https_proxy} if https_proxy else None
        verify_ssl_env = os.environ.get("VERIFY_SSL")
        verify_ssl = _as_bool(verify_ssl_env, default=True)
        verify_ssl_path = os.environ.get("VERIFY_SSL_PATH", "").strip()
        verify_arg = verify_ssl_path if verify_ssl_path else verify_ssl

        start_date = window_start_utc.date().strftime("%Y-%m-%d")
        end_date = window_end_utc.date().strftime("%Y-%m-%d")
        url = _build_url(API_BASE, ENDPOINT, start_date, end_date)
        if logger:
            logger.info(f"Requesting trades: {url}")
            logger.info(f"Proxy: {https_proxy or 'None'} | TLS verify: {verify_arg}")

        import requests

        session = requests.Session()
        session.headers.update(
            {"Authorization": API_KEY, "Content-Type": "application/json"}
        )
        if proxies:
            session.proxies.update(proxies)
        resp = session.get(url, verify=verify_arg, timeout=60)
        resp.raise_for_status()
        payload = resp.json()
        if "value" not in payload:
            raise RuntimeError("Unexpected response shape (no 'value')")
        
        df_raw = pd.DataFrame(payload["value"]) if payload["value"] else pd.DataFrame()
        
        # [Schema Guard] Verify Trade_Id exists in API response
        if not df_raw.empty and "Trade_Id" not in df_raw.columns:
            raise RuntimeError("MALFORMED_INPUT: API response missing required 'Trade_Id' column.")
            
        return df_raw

    def _append_to_masterfile(df_raw: pd.DataFrame, root: Path) -> None:
        """Append raw payload into CSV partition masterfile."""
        try:
            root.mkdir(parents=True, exist_ok=True)
            snap_date_str = datetime.utcnow().date().isoformat()
            part_dir = root / f"snapshot_date={snap_date_str}"
            part_dir.mkdir(parents=True, exist_ok=True)
            part_file = part_dir / "part.csv"
            write_header = not part_file.exists()
            df_to_write = df_raw.copy()
            df_to_write["ingested_at_utc"] = datetime.utcnow().isoformat(
                timespec="seconds"
            )
            df_to_write.to_csv(part_file, index=False, mode="a", header=write_header)
            if logger:
                logger.info(
                    f"Appended {len(df_raw)} rows to masterfile partition: {part_file}"
                )
        except Exception as e:
            if logger:
                logger.warning(f"Failed to append to masterfile: {e}")

    try:
        df_api_raw = _call_api_df()
        try:
            df_api_raw.to_csv(snap, index=False)
            if logger:
                logger.info(f"Saved trades snapshot: {snap}")
        except Exception as e:
            if logger:
                logger.warning(f"Failed to save trades snapshot: {e}")
        if masterfile_dir is not None:
            _append_to_masterfile(df_api_raw, masterfile_dir)
        return _normalise(df_api_raw)
    except Exception as e:
        if logger:
            logger.error(f"Trades API error: {e}")
        if mode == "api_first" and snap.exists():
            if logger:
                logger.warning(f"Falling back to existing snapshot: {snap}")
            return _normalise(pd.read_csv(snap))
        return pd.DataFrame()


# ===================================
# Mapping & Across-IC Roll-up Helpers
# ===================================
def load_cp_mapping() -> pd.DataFrame:
    """Load CP code ↔ BMU_ID mapping and return tidy melt."""
    if not CP_CODES_FILE.exists():
        return pd.DataFrame(columns=["CP Code", "Type", "BMU_ID"])
    cp = pd.read_csv(CP_CODES_FILE)
    cp.columns = [c.strip() for c in cp.columns]
    m = cp.melt(id_vars=["CP Code"], var_name="Type", value_name="BMU_ID")
    m["BMU_ID"] = m["BMU_ID"].astype(str).str.strip()
    m = m.dropna(subset=["BMU_ID"])
    return m


def map_bmu_to_cp(df: pd.DataFrame, cp_map: pd.DataFrame) -> pd.DataFrame:
    """Left-join CP Code onto a frame with BMU_ID."""
    if df.empty or cp_map.empty:
        df["CP Code"] = np.nan
        return df
    return df.merge(cp_map, how="left", on="BMU_ID")


# ==============================
# Matching & Rollups & Decisions
# ==============================
def match_pn_to_trades(
    pn_with_delta: pd.DataFrame, trades: pd.DataFrame
) -> pd.DataFrame:
    """Match ΔPN post-awareness to trades at (BMU_ID, HourUTC)."""
    # Schema baseline
    cols_to_return = [
        "BMU_ID", "HourUTC", "Agreement_Type", "DATETIME_FROM", 
        "DATETIME_TO", "Traded_Date", "Trade_Created", 
        "Awareness_Start", "Net_PN_Change_MW", "Total_Volume",
        "Trade_met_on_IC", "Countertrade_on_same_IC", 
        "Duplicate_Trade_Error"
    ]
    
    if pn_with_delta.empty:
        return pd.DataFrame(columns=cols_to_return)

    # 1. Joins
    pn = pn_with_delta.copy()
    if trades.empty:
        # Aggregate PN deltas and fill trade cols with nulls
        pn["HourUTC"] = pn["DatetimeUTC"].dt.floor("h")
        agg = pn.groupby(["BMU_ID", "HourUTC"]).agg(Net_PN_Change_MW=("DeltaPN", "sum")).reset_index()
        for c in ["Agreement_Type", "DATETIME_FROM", "DATETIME_TO", "Traded_Date", "Trade_Created", "Awareness_Start"]:
            agg[c] = np.nan
        agg["Total_Volume"] = 0.0
        agg["Trade_met_on_IC"] = False
        agg["Countertrade_on_same_IC"] = False
        agg["Duplicate_Trade_Error"] = False
        return agg[cols_to_return]

    # 2. Left Join
    tr = trades.copy()
    tr_cols = [
        c for c in [
            "BMU_ID", "HourUTC", "Awareness_Start", "Total_Volume",
            "Agreement_Type",            "DATETIME_FROM", "DATETIME_TO",
            "Traded_Date", "Trade_Created", "Unit_Volume_MW", "Price_£/MWh",
            "Duplicate_Trade_Error",
        ] if c in tr.columns
    ]
    # Ensure traders' HourUTC is naive
    tr["HourUTC"] = pd.to_datetime(tr["HourUTC"]).dt.tz_localize(None)
    
    merged = pn.merge(tr[tr_cols], how="left", on=["BMU_ID", "HourUTC"])
    
    # 3. Awareness Filter (keep if no trade or if aware)
    if not merged.empty:
        # Convert both to naive datetime series for robust comparison
        r_utc = pd.to_datetime(merged["ReceiptUTC"]).dt.tz_localize(None)
        a_utc = pd.to_datetime(merged["Awareness_Start"]).dt.tz_localize(None)

        # Keep Row if (No Trade found) OR (Trade exists and is aware)
        mask = a_utc.isna() | (r_utc >= a_utc)
        merged = merged[mask].copy()

    # Ensure column exists before groupby
    if "Duplicate_Trade_Error" not in merged.columns:
        merged["Duplicate_Trade_Error"] = False

    if merged.empty:
         return pd.DataFrame(columns=cols_to_return)

    # 4. Aggregation
    group_cols = [
        "BMU_ID", "HourUTC", "Agreement_Type", "DATETIME_FROM", 
        "DATETIME_TO", "Traded_Date", "Trade_Created", "Awareness_Start"
    ]
    # Replace nulls in group cols to avoid dropping them
    # But for trades, we might want one row per trade-hour group.
    # If no trade, the result of left join for these cols is NaN.
    # Groupby drops NaNs by default. 
    # Use dropna=False (available in recent pandas) or fillna.
    
    # Stage 1: Sum deltas per point in time (BMU, DatetimeUTC)
    # This sums shifts across evolution time (ReceiptUTC)
    stage1_keys = ["BMU_ID", "DatetimeUTC"] + [c for c in group_cols if c not in ["BMU_ID"]]
    merged_pt = (
        merged.groupby(stage1_keys, dropna=False, as_index=False)
        .agg(
            Point_Delta=("DeltaPN", "sum"), 
            Total_Volume=("Total_Volume", "first"),
            Duplicate_Trade_Error=("Duplicate_Trade_Error", "max")
        )
    )
    # Stage 2: Mean of point deltas across the hour
    agg = (
        merged_pt.groupby(group_cols, dropna=False, as_index=False)
        .agg(
            Net_PN_Change_MW=("Point_Delta", "mean"), 
            Total_Volume=("Total_Volume", "first"),
            Duplicate_Trade_Error=("Duplicate_Trade_Error", "max")
        )
    )
    
    agg["Total_Volume"] = agg["Total_Volume"].fillna(0.0)
    agg["Duplicate_Trade_Error"] = agg["Duplicate_Trade_Error"].fillna(False).astype(bool)
    # Check signs match AND volume covers delta
    same_sign = (np.sign(agg["Total_Volume"]) == np.sign(agg["Net_PN_Change_MW"]))
    # Trade is met IF PN move covers at least the traded volume (with tolerance)
    agg["Trade_met_on_IC"] = (
        same_sign & (agg["Net_PN_Change_MW"].abs() >= agg["Total_Volume"].abs() - TOLERANCE_MW)
    )
    
    # 5. Countertrade Logic
    agg = detect_countertrade(agg, pn_with_delta, trades)
    
    return agg[cols_to_return]

def detect_countertrade(agg_df, pn_df, trades_df):
    """Flag YES3 if opposite PN found on same IC."""
    if agg_df.empty:
        return agg_df

    # We need to check if for a given trade (HourUTC), there exists ANY PN Delta on the SAME IC
    # that is in the OPPOSITE direction to the Trade.
    # Trade Direction: Sign of Total_Volume.
    # PN Direction: Sign of DeltaPN.
    # Strategy:
    # 1. Get all PN Deltas on this IC (pn_df)
    # 2. Join with agg_df on HourUTC?
    # Actually, simpler: For each row in agg_df (Trade), check the PN pool.
    
    # Pre-aggregate PN pool by HourUTC, Direction?
    # Or just iterate (slow but fine for this scale).
    # Let's use vectorized approach.
    
    # Create a summary of PN Deltas by HourUTC: MinDelta, MaxDelta?
    # Or just list of (HourUTC, DeltaPN)
    
    # We want to know if there is a DeltaPN such that:
    # sign(DeltaPN) != sign(TradeRow.Total_Volume) && abs(DeltaPN) > TOLERANCE
    
    # Let's filter pn_df to significant deltas
    sig_pn = pn_df[pn_df["DeltaPN"].abs() > TOLERANCE_MW].copy()
    
    if sig_pn.empty:
        agg_df["Countertrade_on_same_IC"] = False
        return agg_df
        
    sig_pn["Sign"] = sig_pn["DeltaPN"].apply(lambda x: 1 if x > 0 else -1)
    
    # We need to map `sig_pn` to `agg_df` on `HourUTC`.
    # And check signals.
    
    # Create 'Has_Positive_Delta' and 'Has_Negative_Delta' per hour on IC
    hour_stats = sig_pn.groupby("HourUTC")["Sign"].unique()
    
    def check_ct(row):
        h = row["HourUTC"]
        vol = row["Total_Volume"]
        if vol == 0: return False
        trade_sign = 1 if vol > 0 else -1
        
        if h not in hour_stats:
            return False
            
        signs_present = hour_stats[h]
        target = -1 * trade_sign
        found = target in signs_present
        return found

    agg_df["Countertrade_on_same_IC"] = agg_df.apply(check_ct, axis=1)
    return agg_df

# [Fix] Alias for click_2.py compatibility
detect_countertrade_on_same_ic = detect_countertrade

def rollup_company_hour(
    pn_with_delta: pd.DataFrame, cp_map: pd.DataFrame
) -> pd.DataFrame:
    """Sum ΔPN across ICs at (CP Code, HourUTC)."""
    if pn_with_delta.empty:
        return pd.DataFrame()
    pn = pn_with_delta.copy()
    pn["HourUTC"] = pn["DatetimeUTC"].dt.floor("H")
    pn = map_bmu_to_cp(pn, cp_map)
    # Stage 1: Sum deltas per point
    # Evolution sum
    pn_pt = (
        pn.groupby(["CP Code", "BMU_ID", "DatetimeUTC", "HourUTC"], as_index=False)
        .agg(Point_Delta=("DeltaPN", "sum"))
    )
    # Stage 2: Sum across BMUs per point, then mean across hour
    # CP sum per point
    pn_pt_cp = (
        pn_pt.groupby(["CP Code", "DatetimeUTC", "HourUTC"], as_index=False)
        .agg(Cp_Point_Delta=("Point_Delta", "sum"))
    )
    # Step average across the hour
    grp = (
        pn_pt_cp.groupby(["CP Code", "HourUTC"], as_index=False)
        .agg(Total_PN_change_across_ICs=("Cp_Point_Delta", "mean"))
    )
    return grp


def classify_v2(row, now_utc):
    """Return (Decision, Action) per trade-hour using Option B semantics."""
    import pandas as _pd

    trade_met_on_ic = bool(row.get("Trade_met_on_IC", False))
    trade_met_across = bool(row.get("Trade_met_across_IC", False))
    hour_utc = _pd.to_datetime(row.get("HourUTC")).to_pydatetime()
    pn_on_ic = float(row.get("Net_PN_Change_MW", 0.0))
    # Note: Total_PN_change_across_ICs might be NaN if no match, handled by row.get default
    pn_across = float(row.get("Total_PN_change_across_ICs", 0.0))
    trade_vol = float(row.get("Total_Volume", 0.0))
    cp_code = row.get("CP Code")
    duplicate_flag = bool(row.get("Duplicate_Trade_Error", False))

    # 1. Ironclad Data Quality Checks
    if duplicate_flag:
        return "DATA_ERROR", "🚨 ERROR: Duplicate Trade ID detected in source data."
    
    if pd.isna(cp_code) or str(cp_code).strip() == "" or str(cp_code).lower() == "nan":
        return "DATA_ERROR", f"🚨 ERROR: BMU mapping missing for {row.get('BMU_ID')}."

    if abs(pn_on_ic) > 2000:
        return "DATA_ERROR", f"🚨 ERROR: Extreme PN Move ({pn_on_ic} MW) exceeds IC capacity."

    if abs(trade_vol) > 2000:
        return "DATA_ERROR", f"🚨 ERROR: Extreme Trade Volume ({trade_vol} MW) exceeds IC capacity."

    # 2. Operational Logic
    # Ensure now_utc is naive if comparing with naive hour_utc
    if now_utc.tzinfo is not None:
        now_utc = now_utc.replace(tzinfo=None)
        
    still_time_left = now_utc < hour_utc
    pn_signal = (abs(pn_on_ic) > TOLERANCE_MW) or (abs(pn_across) > TOLERANCE_MW)
    countertrade_flag = bool(row.get("Countertrade_on_same_IC", False))

    # [UAT Fix] If no trade exists (zero volume), ignore moves < 50MW.
    if abs(trade_vol) < 0.01:
        if abs(pn_on_ic) > 50:
            return "INFO", "⚠️ INFO: Significant un-traded move (>50MW). Check with Trades team."
        else:
            return "INFO", "✅ OK: Position Fully Balanced."

    if countertrade_flag:
        return "YES3", "Countertraded: opposite-direction PN on the same IC. Market move."

    if (not trade_met_on_ic) and trade_met_across:
        return "YES2", "♻️ OK (Across): Covered by other Interconnectors."
    
    if (not trade_met_on_ic) and (not trade_met_across) and still_time_left:
        return "YES1", "⏳ WAIT: Trade confirmed; window not yet reached."

    if (
        (not trade_met_on_ic)
        and (not trade_met_across)
        and (not still_time_left)
        and pn_signal
    ):
        return "YES3", "⚠️ ACTION: Market moved - insufficient PN. Find remaining MW elsewhere."
    
    if (
        (not trade_met_on_ic)
        and (not trade_met_across)
        and (not still_time_left)
        and (not pn_signal)
    ):
        return "NO", "🚨 URGENT: No movement. Chase Counterparty."
    
    if trade_met_on_ic:
        return "INFO", "✅ OK: Position Fully Balanced."
    return "INFO", "No decision – check inputs."


# =======================================
# Receipt Tokens & Window Inference (MCNN)
# =======================================

import re

# Accepts: "MCNN 20230402.xls" (DA) and "MCNN 20230402_14.xls" or "MCNN 20230402.14.xls"
# [Refactor] Add xlsx support
MCNN_REGEX = re.compile(r"^MCNN\s+(\d{8})(?:[_\.](\d{2}))?\.xlsx?$", flags=re.IGNORECASE)


def parse_mcnn_token(name: str):
    """Return (YYYYMMDD, 'DA'|HH) if MCNN filename matches, else None."""
    m = MCNN_REGEX.match(name)
    if not m:
        return None
    ymd = m.group(1)
    hh = m.group(2)
    return ymd, ("DA" if hh is None else hh)


def collect_receipts(folder: Path) -> dict:
    """Collect tokens per day from MCNN *.xls files in a folder."""
    buckets = {}
    # [Refactor] Glob generic or filter
    files = [p for p in Path(folder).glob("MCNN *") if p.suffix.lower() in (".xls", ".xlsx")]
    for f in files:
        tok = parse_mcnn_token(f.name)
        if not tok:
            continue
        ymd, htoken = tok
        buckets.setdefault(ymd, set()).add(htoken)

    def _sort_key(t):  # DA first, then numeric
        return -1 if t == "DA" else int(t)

    return {ymd: sorted(list(tokens), key=_sort_key) for ymd, tokens in buckets.items()}


def token_to_dt(ymd: str, token: str) -> datetime:
    """Convert (YYYYMMDD, token 'DA'|'00'..'23') to UTC datetime (assuming token is Local)."""
    hh = "00" if token == "DA" else token
    dt_local = datetime.strptime(f"{ymd}_{hh}", "%Y%m%d_%H")
    # Convert Local -> UTC using Series for robust 'ambiguous="infer"' support
    s = pd.Series(pd.to_datetime([dt_local]))
    s_utc = (
        s.dt.tz_localize(TIMEZONE_LOCAL, ambiguous="infer")
        .dt.tz_convert("UTC")
        .dt.tz_localize(None)
    )
    return s_utc[0].to_pydatetime()


def infer_latest_day_and_pair(folder: Path):
    """Infer [start,end) for latest day and return tokens + (baseline, update)."""
    buckets = collect_receipts(folder)
    if not buckets:
        return None
    target_ymd = max(buckets.keys())
    tokens = buckets[target_ymd]
    if len(tokens) < 2:
        start = token_to_dt(target_ymd, "DA")
        last = tokens[-1]
        end = token_to_dt(target_ymd, last) + (
            timedelta(hours=1) if last != "DA" else timedelta(hours=0)
        )
        return start, end, target_ymd, tokens, (None, None)
    baseline_tok, update_tok = tokens[-2], tokens[-1]
    start = token_to_dt(target_ymd, "DA")
    end = token_to_dt(target_ymd, update_tok) + timedelta(hours=1)
    return start, end, target_ymd, tokens, (baseline_tok, update_tok)


def get_files_in_window(folder: Path, start_dt: datetime, end_dt: datetime):
    """Return sorted list of (file_dt, path) for MCNN files within [start,end)."""
    # [Refactor] Support both extensions
    files = list(p for p in Path(folder).glob("MCNN *") if p.suffix.lower() in (".xls", ".xlsx"))
    selected = []
    for f in files:
        m = MCNN_REGEX.match(f.name)
        if m:
            ymd = m.group(1)
            hh = m.group(2) or "DA" # parse_mcnn_token logic
            # Use token_to_dt to ensure consistent UTC conversion
            hh_token = "DA" if hh is None else hh
            # Regex group 2 is None if missing (DA?) no, regex says (?:_...)
            # Regex: `..._(\d{2})?`
            # If group 2 is None, it's DA.
            # My token_to_dt handles 'DA' or 'HH'.
            token = hh if hh else "DA"
            file_dt = token_to_dt(ymd, token)
            if start_dt <= file_dt < end_dt:
                selected.append((file_dt, f))
    return sorted(selected, key=lambda x: x[0])


# =================================
# Forward Horizon & Operator Banner
# =================================
def compute_delivery_horizon(
    ymd_chosen: str,
    tokens_chosen: list,
    pair: Tuple[Optional[str], Optional[str]],
    forward_only: bool,
):
    """Return (delivery_start, day_end, latest_receipt_hour, h_plus_1_hour)."""
    latest_receipt_hour = (
        token_to_dt(ymd_chosen, pair[1])
        if pair and all(pair)
        else token_to_dt(ymd_chosen, tokens_chosen[-1])
    )
    day_start = datetime.strptime(ymd_chosen, "%Y%m%d")
    day_end = day_start + timedelta(days=1)
    delivery_start = (
        (latest_receipt_hour + timedelta(hours=1)) if forward_only else day_start
    )
    h_plus_1 = latest_receipt_hour + timedelta(hours=1)
    return delivery_start, day_end, latest_receipt_hour, h_plus_1


def filter_forward_horizon(
    pn_df: pd.DataFrame,
    delivery_start: datetime,
    day_end: datetime,
    pair: Tuple[Optional[str], Optional[str]] = (None, None),
    pairwise_only: bool = False,
    ymd_chosen: Optional[str] = None,
) -> pd.DataFrame:
    """Filter PN rows to delivery horizon; optionally keep last two receipts."""
    if pn_df.empty:
        return pn_df
    out = pn_df[
        (pn_df["DatetimeUTC"] >= delivery_start) & (pn_df["DatetimeUTC"] < day_end)
    ].copy()
    if pairwise_only and pair and all(pair) and ymd_chosen is not None:
        baseline_dt = token_to_dt(ymd_chosen, pair[0])
        update_dt = token_to_dt(ymd_chosen, pair[1])
        keep_hours = {baseline_dt, update_dt}
        out["ReceiptHourUTC"] = out["ReceiptUTC"].dt.floor("h")
        out = out[out["ReceiptHourUTC"].isin(keep_hours)].copy()
        out.drop(columns=["ReceiptHourUTC"], inplace=True, errors="ignore")
    return out


def count_rows_by_delivery_hour(pn_df: pd.DataFrame) -> pd.DataFrame:
    """Return PN row counts per hour for QA."""
    if pn_df.empty:
        return pd.DataFrame(columns=["HourUTC", "PN_rows"])
    return (
        pn_df.assign(HourUTC=pn_df["DatetimeUTC"].dt.floor("h"))
        .groupby("HourUTC", as_index=False)
        .size()
        .rename(columns={"size": "PN_rows"})
        .sort_values("HourUTC")
    )


def extract_h_plus_1_view(
    pn_with_delta: pd.DataFrame, h_plus_1: datetime
) -> pd.DataFrame:
    """Return ΔPN rows for H+1 hour."""
    if pn_with_delta.empty:
        return pn_with_delta
    fw = pn_with_delta.assign(HourUTC=pn_with_delta["DatetimeUTC"].dt.floor("h"))
    return fw[fw["HourUTC"] == h_plus_1].copy()


def sample_changed_rows(pn_with_delta: pd.DataFrame, n: int = 30) -> pd.DataFrame:
    """Return a deterministic sample of changed rows."""
    if pn_with_delta.empty:
        return pn_with_delta
    changed = pn_with_delta[pn_with_delta["DeltaPN"].abs() > 0]
    cols = ["BMU_ID", "DatetimeUTC", "ReceiptUTC", "PN_value", "DeltaPN"]
    return changed[cols].sort_values(["DatetimeUTC", "BMU_ID", "ReceiptUTC"]).head(n)


def format_operator_banner(
    chosen_date, pair, pn_with_delta: pd.DataFrame, h_plus_1
) -> str:
    """Return a concise operator banner string."""
    fw = pn_with_delta.assign(HourUTC=pn_with_delta["DatetimeUTC"].dt.floor("h"))
    h1_changed_rows = int((fw[fw["HourUTC"] == h_plus_1]["DeltaPN"].abs() > 0).sum())
    forward_hours = (
        fw[(fw["HourUTC"] > h_plus_1) & (fw["DeltaPN"].abs() > 0)]
        .groupby("HourUTC", as_index=False)
        .size()
        .rename(columns={"size": "changed_rows"})
        .sort_values("HourUTC")
    )
    parts = [
        f"Day: {chosen_date} | Pair: {pair[0]} → {pair[1]} | ΔPN rows: {len(pn_with_delta)}",
        f"H+1 ({h_plus_1} UTC): {'CHANGES DETECTED' if h1_changed_rows else 'no change'}",
    ]
    if forward_hours.empty:
        parts.append("No forward changes beyond H+1.")
    else:
        parts.append("Forward changes beyond H+1:")
        for _, row in forward_hours.iterrows():
            parts.append(f" - {row['HourUTC']}: {row['changed_rows']}")
    return "\n".join(parts)


# ==================
# Forward Advisory
# ==================
def build_forward_advisory(
    pn_with_delta: pd.DataFrame, trades: pd.DataFrame, h_plus_1_hour: datetime
) -> pd.DataFrame:
    """Build advisory of PN deltas without any trades in the hour."""
    fw = pn_with_delta.assign(HourUTC=pn_with_delta["DatetimeUTC"].dt.floor("h"))
    fw = fw[fw["HourUTC"] >= h_plus_1_hour]
    trades_by_hour = trades.copy()
    if "HourUTC" not in trades_by_hour.columns:
        # Emergency fallback if not already prepared
        trades_by_hour["HourUTC"] = pd.Series(dtype='datetime64[ns]')
    
    has_trade_hours = set(trades_by_hour["HourUTC"].dropna().unique())
    advisory = (
        fw[fw["DeltaPN"].abs() > 0]
        .assign(Has_Trade=lambda d: d["HourUTC"].isin(has_trade_hours))
        .loc[:, ["HourUTC", "BMU_ID", "PN_value", "DeltaPN", "Has_Trade", "ReceiptUTC"]]
        .sort_values(["HourUTC", "BMU_ID"])
    )
    if advisory.empty:
        return advisory
    advisory["Advisory"] = np.where(
        advisory["Has_Trade"],
        "PN delta exists and trades exist — handled by trade reconciliation.",
        "PN delta exists but no trades found — review / contact trading.",
    )
    return advisory


def tidy_advisory_latest(advisory: pd.DataFrame) -> pd.DataFrame:
    """Reduce to one row per (BMU_ID, HourUTC), keeping latest ReceiptUTC."""
    if advisory.empty:
        return advisory
    advisory_sorted = advisory.sort_values(["HourUTC", "BMU_ID", "ReceiptUTC"])
    return advisory_sorted.drop_duplicates(subset=["HourUTC", "BMU_ID"], keep="last")


def summarise_advisory(advisory_latest: pd.DataFrame) -> pd.DataFrame:
    """Return per-hour summary of affected BMUs and ΔPN sum."""
    if advisory_latest.empty:
        return pd.DataFrame(columns=["HourUTC", "BMUs_affected", "Total_DeltaPN_MW"])
    # If DatetimeUTC is missing, try to infer it from HourUTC or just sum
    if "DatetimeUTC" not in advisory_latest.columns:
        # Fallback to simple sum if no sub-hour granularity
        return (
            advisory_latest.groupby("HourUTC", as_index=False)
            .agg(BMUs_affected=("BMU_ID", "nunique"), Total_DeltaPN_MW=("DeltaPN", "sum"))
            .sort_values("HourUTC")
        )

    # Stage 1: Sum per point (BMU, Time)
    advisory_pt = (
        advisory_latest.groupby(["HourUTC", "BMU_ID", "DatetimeUTC"], as_index=False)
        .agg(Point_Delta=("DeltaPN", "sum"))
    )
    # Stage 2: Sum across BMUs per point, mean across hour
    adv_pt_sum = (
        advisory_pt.groupby(["HourUTC", "DatetimeUTC"], as_index=False)
        .agg(Hr_Pt_Sum=("Point_Delta", "sum"), BMUs_affected=("BMU_ID", "nunique"))
    )
    
    return (
        adv_pt_sum.groupby("HourUTC", as_index=False)
        .agg(BMUs_affected=("BMUs_affected", "max"), Total_DeltaPN_MW=("Hr_Pt_Sum", "mean"))
        .sort_values("HourUTC")
    )
    # Wait! Total_DeltaPN_MW for summary should probably be sum Across BMUs, mean Across Time?
    # Let's keep it consistent.


# =====================
# Countertrade Helpers
# =====================
def opposite_bmu_id(bmu: str) -> str:
    """Flip third character D<->G for interconnector BMU IDs."""
    if not isinstance(bmu, str) or len(bmu) < 3:
        return bmu
    prefix, rest = bmu[:3], bmu[3:]
    flipped = prefix[:2] + ("G" if prefix[2] == "D" else "D")
    return flipped + rest


# def detect_countertrade_on_same_ic (REMOVED - Aliased to match_pn_to_trades logic)


def apply_yes3_countertrade_override(classified: pd.DataFrame) -> pd.DataFrame:
    """Force YES3 decision and message where Countertrade_on_same_IC is True."""
    mask = classified["Countertrade_on_same_IC"].fillna(False)
    classified.loc[mask, ["Decision", "Action"]] = [
        "YES3",
        "Countertraded: opposite-direction PN on the same IC. Market move.",
    ]
    return classified


# =================
# File Writers (CSV)
# =================
def write_csv(df: pd.DataFrame, name: str) -> Path:
    """Write a CSV file into outputs/ and return path."""
    path = OUTPUTS_DIR / name
    df.to_csv(path, index=False)
    return path


def write_csv_bom(df: pd.DataFrame, name: str) -> Path:
    """Write CSV with UTF-8 BOM (Excel-friendly) and return path."""
    path = OUTPUTS_DIR / name
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return path
