# Release 3: Intelligence Layer & Portfolio Analytics Overhaul

## Overview
This release marks the finalization of the **Import Constraints Intelligence Dashboard**, evolving from a standard alert monitor into a structured participant-behavior analysis tool. It introduces granular impact quantification, episode-level grouping, and participant portfolio intelligence.

## Key Modules & Enhancements

### 1. System Intelligence (Tabs 1 & 2)
*   **Narrative context**: Introduced "Analyst Intelligence" sections that provide natural language definitions for complex detection logic.
*   **Extreme Price Focus**: Added high-visibility tables for pinpointing units that breached the Materiality (C3) threshold during constraint periods.
*   **Behavioral Classification**: Standardized all SP-level views using the three-class taxonomy: *Normal, Elevated, and Ensemble*.

### 2. Temporal Episode Intelligence (Tab 3)
*   **Persistence Analysis**: Alerts are now grouped into sequential "Constrained-Ensemble Windows," allowing analysts to view the duration and cumulative impact of behavior clusters.
*   **Priority Quadrant**: A dynamic scatter visualization to identify "high-impact, high-persistence" events that require immediate regulatory review.

### 3. Unit-Level Deep Dives (Tab 4)
*   **Condition Breakdown**: Detailed bar charts showing the specific mix of conditions (Historical, Fuel-Threshold, and Spread-Materiality) that triggered each alert for a selected BMU.
*   **Cost Sensitivity**: Introduced the "Estimated Impact (£)" metric at the SP and Window levels, benchmarking extra costs against condition-specific thresholds.

### 4. Market & Fuel Benchmarking (Tab 5)
*   **C3 Comparison Layer**: Replaced "Baseline D" with the **C3 (Materiality)** comparison, benchmarking constrained spreads against unconstrained historical medians.
*   **Two-Grain Analysis**:
    *   **Fuel Level (Aggregate)**: Trends and comparisons grouped by fuel type (e.g., CCGT, Wind, etc.).
    *   **BMU Level (Grain)**: Interactive portfolio drill-downs to see individual unit deviations within a specific fuel sector.

### 5. Participant & Portfolio Intelligence (Tab 6)
*   **Concentration Metrics**: Redesign of the "Counterparty Intelligence" tab to focus strictly on participant-level behavior.
*   **Portfolio Breakdown**: Dynamic selection tool to view a specific counterparty's unit portfolio, quantifying total ensemble event counts and extreme pricing incidents (£200+) across all their associated units.

## Technical Improvements
*   **UI Standardisation**: All bar chart visuals have been updated with taller aspect ratios, increased top margins, and disabled label clipping (`cliponaxis=False`) to ensure no numerical data is truncated.
*   **Consistent Filtering**: Temporal drill-downs (Date, Week, Month) are now uniform across all six tabs.
*   **Efficiency**: Optimized data grouping and caching for large datasets with localized sub-filters for complex unit comparisons.

---
**Released on: 2026-03-30**
**Version: 3.0.0 (Master Overhaul)**
