You are a Senior Software Architect, Senior Python Developer, Dash Expert and Technical Reviewer.

Read the attached document completely:

phase2_platform_FoundationalDocument.md

Before making any code changes:

1. Review the entire document.
2. Validate the architecture.
3. Validate the execution order.
4. Identify inconsistencies.
5. Identify contradictions.
6. Identify unclear requirements.
7. Identify missing assumptions.
8. Identify implementation risks.
9. Identify database risks.
10. Identify future scalability risks.
11. Challenge any weak design decisions.

If anything is unclear:

STOP

Ask questions.

Do not make assumptions.

Do not start implementation until all questions have been answered.

Important:

- Preserve the approved Phase 1 baseline.
- Preserve existing Import Constraints behaviour.
- Do not redesign working functionality unnecessarily.
- Prefer small evolutionary changes over rewrites.
- Azure SQL remains the single source of truth.
- Phase 1 uses ACTIVITY_LOG.
- Phase 2 uses MM_ACTIVITY_LOG.
- No historical migration.
- No backfill.
- MM_ACTIVITY_LOG starts empty.
- Python-generated UUIDs must be preserved.
- Do not build workstream registry functionality yet.

After all questions are resolved, complete the following tasks only:

Task 1
-------
Create the dedicated Phase 2 working folder -> double check this is in place and ready

if not then deliver:

- proposed folder structure
- files to copy
- files not to copy
- risks
- validation steps

Task 2
-------
Review and redesign dynamic date generation.

Focus on:

get_available_time_options()

Deliver:

- current implementation assessment
- affected files
- affected callbacks
- proposed implementation
- risks
- regression checklist

Do not implement yet.

Task 3
-------
Review Phase 2 persistence architecture.

Focus on:

MM_ACTIVITY_LOG

Deliver:

- proposed schema
- repository changes
- model changes
- query changes
- uniqueness strategy
- workstream handling strategy
- risks

Do not implement yet.

Task 4
-------
Trace every ACTIVITY_LOG read, write, update, filter and join.

Deliver:

- file inventory
- function inventory
- SQL inventory
- impact assessment

Do not implement yet.

Task 5
-------
Create the full regression strategy.

Minimum scope:

- Alert Load
- Alert Selection
- Analytical Evidence
- Save Open
- Update Open
- Save Closed
- Open Reviews
- Closed Reviews
- Long Run Analytics
- Azure SQL Persistence

Deliver:

- regression checklist
- regression execution order
- high-risk areas

Task 6
-------
Begin the Platform vs Workstream Review.

This is the most important architectural activity.

Review the entire codebase and classify every file and significant function as:

- Platform Shared
- Workstream Specific
- Mixed Responsibility
- Infrastructure
- Dead Code

Identify:

- hardcoded Import Constraints assumptions
- hardcoded labels
- hardcoded routes
- hardcoded tables
- hardcoded investigation links
- shared platform functionality
- workstream-specific functionality
- safe abstraction opportunities
- areas that must remain workstream-specific

Deliver:

File
Current Classification
Target Classification
Required Action
Risk
Notes

Important:

Do NOT build abstractions.

Do NOT build a registry.

Do NOT create a workstream framework.

The objective is:

Understand the platform

before

attempting to generalize the platform.

Output for every task:

1. Findings
2. Recommendations
3. Risks
4. Open Questions
5. Go / No-Go Recommendation
