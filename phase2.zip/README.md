# Market Monitoring Platform: Phase 2 Foundation

## 1. Status

Phase 1 is complete and approved.

Authoritative Phase 1 baseline:

`release_2_local_azure_sql_working_final`

The approved baseline is frozen and must remain available for:

- Demonstration
- Regression comparison
- Rollback
- Technical reference

All Phase 2 work must take place in a separate Phase 2 folder.

The Phase 1 baseline must not be modified.

## 2. North Star

Move from:

`Import Constraints application PoC`

to:

`Fully fledged Market Monitoring Platform`

The platform will support multiple Monitoring workstreams through a shared operational application.

Planned workstreams:

- Import Constraints
- IC
- TCLC
- IOLC
- UMM
- Other future workstreams

## 3. Phase 2 Objective

Phase 2 will establish the foundations required to:

- Preserve the approved Import Constraints workflow
- Remove known Phase 1 limitations
- Support multiple workstreams
- Reuse common platform functionality
- Isolate workstream-specific logic
- Store all operational records in Azure SQL
- Prevent records from different workstreams being mixed
- Introduce a platform landing page
- Introduce temporary analyst context
- Move the existing rota into the application
- Define what constitutes a workstream
- Prepare the architecture for a second workstream
- Avoid duplicating the application for every workstream

The key architectural objective is:

`Shared platform capabilities + isolated workstream-specific capabilities`

Each workstream may have its own:

- Azure SQL schema and tables
- Alert fields
- Business rules
- Analytical support
- Statistical support
- Investigation links
- Operational particularities

The platform must support these differences without duplicating all shared functionality.

## 4. Non-Negotiable Architecture Principles

### 4.1 Azure SQL

Azure SQL is the single operational source of truth.

Azure SQL will store:

- Alerts
- Supporting operational data
- Analyst reviews
- Review statuses
- Review comments
- Workstream identifiers
- Analyst reference data
- Rota data
- Future platform configuration
- BMU and counterparty reference data where required

Dash must not use SharePoint Excel workbooks as operational data sources.

The existing BMU and counterparty mapping workbook may later be used as an initial migration or reconciliation source.

Any reference data required during normal application operation should ultimately be available in Azure SQL.

#### Phase Separation

Phase 1 and Phase 2 review persistence must remain separated.

Phase 1:

```text
ACTIVITY_LOG
```

Phase 2:

```text
MM_ACTIVITY_LOG
```

The approved Phase 1 release must continue using ACTIVITY_LOG.

Phase 2 must use MM_ACTIVITY_LOG.

No Phase 2 implementation may modify or depend on changes to the approved Phase 1 ACTIVITY_LOG table.

The two releases must be capable of operating independently.

### 4.2 Dash

Dash is the operational Market Monitoring workspace.

Dash owns:

- Platform navigation
- Landing page
- Analyst context
- Alert review
- Open Reviews
- Closed Reviews
- Analytical support
- Workstream-specific analytical pages
- Weekly rota display
- Rota administration

### 4.3 External Investigation Destinations

External websites support investigations but are not operational sources of truth.

Potential destinations include:

- Elexon
- REMIT
- Enappsys

External investigation destinations will apply differently across workstreams.

The existing Elexon functionality used by Import Constraints may be reusable for other appropriate workstreams.

The active workstream and selected alert context will determine which investigation buttons are available.

A failure or change in an external destination must not prevent an analyst from:

- Reviewing an alert
- Saving a decision
- Updating a review
- Closing a review

External destinations are navigation aids, not persistence dependencies.

### 4.4 Streamlit

KPI and governance reporting will be handled separately in Streamlit by another colleague.

Streamlit development is outside this Phase 2 scope.

The Dash platform roadmap must not include Streamlit implementation tasks.

### 4.5 NED

Historical NED migration is a backlog item.

NED migration is not part of the immediate Phase 2 implementation.

However, current platform changes must not unnecessarily block a future controlled migration.

Future considerations may include:

- Historical export
- Retention requirements
- Record provenance
- Historical reconciliation
- Migration into Azure SQL
- Archival storage

These considerations remain backlog items until separately prioritised.

## 5. Approved Baseline Protection

Phase 2 development must take place separately from the approved Phase 1 release.

The following baseline must not be modified:

`release_2_local_azure_sql_working_final`

Phase 2 must preserve the existing Import Constraints behaviour, including:

- Alert loading
- Alert filtering
- Alert selection
- Analytical evidence
- Review validation
- Saving a review as Open
- Updating an Open review
- Saving a review as Closed
- Updating a review to Closed
- Open Reviews
- Closed Reviews
- Long-run analytics
- Azure SQL persistence

Regression checks must be completed after every material Phase 2 change.

A successful application start is not sufficient regression evidence.

The end-to-end operational workflow must be checked.

The approved Phase 1 release must continue using its existing ACTIVITY_LOG table.

Phase 2 must use the new MM_ACTIVITY_LOG table.

## 6. Existing Platform Architecture

The existing layer structure remains the preferred architecture:

`Dash Page -> Service -> Repository -> Azure SQL`

### 6.1 Pages

Pages own:

- Layout
- Components
- Callbacks
- User interaction
- Display formatting
- Navigation

Pages must not contain direct SQL queries.

### 6.2 Services

Services own:

- Business rules
- Validation
- Workflow logic
- Data preparation
- Workstream orchestration

### 6.3 Repositories

Repositories own:

- SQL queries
- Database reads
- Database writes
- Database-specific behaviour

### 6.4 Azure SQL

Azure SQL owns the authoritative operational records.

## 7. Definition of a Workstream

A workstream is an operational Monitoring area supported by the platform.

A workstream is not just:

- A navigation button
- A Dash page
- A SQL table
- A dashboard
- A workstream name

A complete workstream may consist of:

- Workstream identity
- Azure SQL schema and tables
- Alert output
- Shared review lifecycle integration
- Workstream-specific business rules
- Analytical support
- Statistical support
- Investigation links
- Routes and navigation
- Platform integration points

## 8. Phase 2 Delivery Plan

### P0: Dynamic Date Options

Replace all hardcoded date options.

Requirements:

- Support all data from August 2022 onwards
- Generate month options dynamically
- Generate ISO week options dynamically
- Support future years automatically
- Preserve the existing callback contracts

### P1: Create the Phase 2 MM_ACTIVITY_LOG

Create a new operational review table for the Market Monitoring Platform:

`MM_ACTIVITY_LOG`

The approved Phase 1 release continues to use:

`ACTIVITY_LOG`

The new Phase 2 platform uses:

`MM_ACTIVITY_LOG`

#### Verified Identifier Implementation

The current implementation generates `ACTIVITY_LOG_ID` in Python.

The repository uses:

```python
uuid.uuid4()
```

when no source value is available.

It uses:

```python
uuid.uuid5(uuid.NAMESPACE_DNS, value)
```

when a supplied value is not already a valid UUID.

The generated UUID value is supplied to Azure SQL by the Python application.

The live Azure SQL schema stores:

```sql
ACTIVITY_LOG_ID UNIQUEIDENTIFIER
```

The live SQLite schema stores:

```sql
ACTIVITY_LOG_ID TEXT
```

The historical DDL defining:

```sql
ACTIVITY_LOG_ID INT IDENTITY
```

is outdated and no longer reflects the working implementation.

MM_ACTIVITY_LOG must preserve this identifier strategy.

Python remains responsible for UUID generation.

Azure SQL remains responsible for storing the UUID using the UNIQUEIDENTIFIER datatype.

No UUID redesign is required during Phase 2A.

#### Initial Data Position

MM_ACTIVITY_LOG will start empty.

Existing ACTIVITY_LOG records will not be copied.

Existing ACTIVITY_LOG records will not be modified.

No historical migration or backfill is required during Phase 2A.

#### Workstream Field

MM_ACTIVITY_LOG must include:

`WORKSTREAM_NAME`

Initial supported values:

- IMPORT_CONSTRAINTS
- IC
- TCLC
- IOLC
- UMM

#### Identifier Strategy

Use:

`ACTIVITY_LOG_ID`

as the technical primary key.

Use:

`WORKSTREAM_NAME + ALERT_UNIQUE_ID`

as the logical identity of a review.

The platform table should therefore use:

```sql
UNIQUE (
    WORKSTREAM_NAME,
    ALERT_UNIQUE_ID
)
```

rather than:

```sql
UNIQUE (
    ALERT_UNIQUE_ID
)
```

to avoid collisions across future workstreams.

#### Acceptance Criteria

P1 is complete when:

- ACTIVITY_LOG remains unchanged
- MM_ACTIVITY_LOG exists
- MM_ACTIVITY_LOG starts empty
- MM_ACTIVITY_LOG includes WORKSTREAM_NAME
- Python UUID generation is preserved
- Import Constraints reviews persist to MM_ACTIVITY_LOG
- Open Reviews use MM_ACTIVITY_LOG
- Closed Reviews use MM_ACTIVITY_LOG
- Phase 1 and Phase 2 operate independently

### P2: Platform Versus Workstream Code Review

This is the most important architectural activity in Phase 2A.

No generic abstraction work should begin until this review is complete.

Classify every file and significant function as:

- Platform Shared
- Workstream Specific
- Mixed Responsibility
- Infrastructure
- Dead Code

Identify:

- Hardcoded Import Constraints assumptions
- Hardcoded routes
- Hardcoded labels
- Hardcoded database references
- Shared functionality
- Workstream-specific functionality

Deliver:

```text
File
Current Classification
Target Classification
Required Action
Risk
Notes
```

### P3: Platform Landing Page

Create a new landing page at:

`/`

It must contain:

- Market Monitoring Platform heading
- Analyst dropdown
- Workstream buttons
- Rota for This Week button
- Admin Page button

Initially:

- Import Constraints is operational
- Other workstreams are visible but disabled

### P4: Temporary Analyst Session

Use analyst selection from the landing page.

Example:

```python
{
    "analyst": "Analyst 1",
    "workstream": "IMPORT_CONSTRAINTS",
}
```

The analyst must be selected before entering a workstream.

### P5: Rota and Administration

Move the current Market Monitoring rota into Azure SQL.

Requirements:

- Weekly rota page
- Admin page
- SQL persistence
- Fast changes during stand-ups
- Preserve the existing rota process

### P6: Navigation Rules

Navigation rules:

- Analyst selected first
- Workstream selected second
- Session context stored
- Home returns to landing page
- Unsaved changes must be handled correctly

### P7: Sidebar and Navigation Review

Review:

- Home navigation
- Workstream navigation
- Analyst display
- Session behaviour
- Unsaved-change behaviour

### P8: Define the Shared Platform Contract

Define the minimum contract required for workstream integration.

Shared concepts include:

- Workstream
- Alert
- Investigation
- Decision
- Comments
- Analyst
- Investigation links

### P9: Workstream Definition or Registry

Implement only after:

- Platform review complete
- Platform contract complete
- Variation points understood

### P10: Investigation-Link Framework

Provide a shared mechanism for:

- Elexon
- REMIT
- Enappsys

based on workstream and alert context.

### P11: Second Workstream

Only after Phase 2B validation is complete.

Prerequisites:

- MM_ACTIVITY_LOG stable
- Shared platform contract complete
- Platform review complete
- Platform validation complete
- Phase 1 and Phase 2 operate independently

The second workstream must validate:

- Shared functionality reuse
- Workstream isolation
- Review partitioning by WORKSTREAM_NAME
- Investigation-link variation
- No regression in Import Constraints

## 9. Deferred and Backlog Scope

Not part of immediate Phase 2A:

- NED migration
- Historical Parquet archive
- Production authentication
- Streamlit KPI development
- Reference data migration
- Additional workstreams beyond the first migration candidate

## 10. Documentation Structure

### Authoritative Phase 2 Documents

- README.md
- phase2_platform_foundation.md
- DEVELOPMENT_LOG.md
- create_mm_activity_log.sql

### Authoritative Phase 1 Reference

- release_2_local_azure_sql_working_final

### Baseline Technical Reference Documents

- alert_lifecycle_trace.md
- alert_lifecycle_diagram.md
- functions_inventory.md
- layer_connections.md

### Historical Documents

- phase2_welcome_and_date_analysis.md
- previous phase2_design_decisions.md versions

## 11. Development Audit Rules

Record all Phase 2 work in:

`DEVELOPMENT_LOG.md`

Minimum evidence:

- Live ACTIVITY_LOG schema
- UUID generation behaviour
- MM_ACTIVITY_LOG schema
- Constraints and indexes
- Repository repointing
- Regression results
- Phase separation validation

## 12. Execution Plan

### Phase 2A - Build the Platform Foundations

Goal:

```text
Shared Platform Infrastructure
+
One Fully Functioning Import Constraints Workstream
```

Execution order:

1. Preserve Phase 1 baseline
2. Create Phase 2 working folder
3. Replace hardcoded date options
4. Create MM_ACTIVITY_LOG
5. Repoint Phase 2 persistence
6. Update tests
7. Run regression testing
8. Complete Platform vs Workstream Review
9. Build landing page
10. Add analyst session
11. Build rota
12. Build administration page
13. Define shared platform contract
14. Implement investigation-link framework

### Phase 2B - Platform Integration and Validation

Goal:

```text
Platform
+
Import Constraints
=
One coherent operational system
```

Validate:

- Landing page
- Analyst session
- MM_ACTIVITY_LOG
- Navigation
- Open Reviews
- Closed Reviews
- Rota
- Admin
- Investigation links
- Phase separation

No new workstream is introduced during Phase 2B.

### Phase 2C - Multi-Workstream Enablement

Goal:

Enable additional Monitoring workstreams.

Activities:

- Workstream definition
- Workstream registry
- Second workstream migration
- Validation
- Platform scaling

## Final Objective

```text
Fully operational Market Monitoring Platform

with

Shared Platform Functionality

+

Multiple Monitoring Workstreams

+

Azure SQL as the single operational source of truth

