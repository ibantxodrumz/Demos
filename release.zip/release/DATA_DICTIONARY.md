# Data Dictionary & Process Documentation

## Source Data Schema
The application expects CSV files in the `inputs/` folder with the following columns (headers are auto-detected):

| Column Name | Description | Type | Example |
| :--- | :--- | :--- | :--- |
| **HourStartLocal** | The local timestamp of the trading hour. | DateTime (ISO) | `2025-01-01 00:00:00+00:00` |
| **Interconnector** | Name of the interconnector asset. | String | `IFA1`, `BritNed` |
| **Trade_Abs_MW** | The absolute commercial flow in Megawatts (MW). | Float | `1471.0` |
| **Trade_Direction**| Direction of flow relative to the UK. | String | `Import` or `Export` |
| **IsPartialHour** | Flag indicating if the hour was incomplete (e.g., clock change). | Boolean | `False` |

## Calculated Metrics

### 1. Threshold Logic
-   **User Input**: `MW Threshold` (Default: 500 MW).
-   **Logic**: 
    -   The app filters for rows where `Trade_Abs_MW > Threshold`.
    -   **Active Hours**: Count of such rows.
    -   **Active Days**: Count of unique dates containing at least one Active Hour.

### 2. Energy Volume (GWh)
-   Sum of `Trade_Abs_MW` for all filtered hours.
-   Converted to Gigawatt-hours (GWh) by dividing by 1000.
    -   *Assumption*: Each row represents exactly 1 hour of flow.

### 3. Aggregations
-   **Global Network**: Sums activity across all loaded interconnectors.
-   **Daily/Monthly**: Groups by `Date` or `MonthName` derived from `HourStartLocal`.

## Processing Steps
1.  **Ingestion**: All CSVs in `inputs/` are read and concatenated.
2.  **Cleaning**: 
    -   Rows with missing dates or MW values are dropped.
    -   Partial hours (`IsPartialHour == True`) can be optionally excluded (default: Excluded).
3.  **Analysis**:
    -   Data is sliced based on the Sidebar Filters (Interconnector, Date Range).
    -   KPIs are recalculated dynamically.
4.  **Export**:
    -   Data is written to `outputs/` without index.
    -   Plots are saved as PNGs via Plotly Kaleido.
