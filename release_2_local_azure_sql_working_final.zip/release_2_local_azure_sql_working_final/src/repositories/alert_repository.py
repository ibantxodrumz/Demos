from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from src.config.constants import SQL_TABLE_ACTIVITY_LOG, SQL_TABLE_ALERTS
from src.repositories.connection import get_db


def get_alerts_by_date_range(
    start_date: str,
    end_date: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Retrieve alert records from SQL_TABLE_ALERTS LEFT JOIN SQL_TABLE_ACTIVITY_LOG.

    Uses a half-open interval: START_LOCAL >= start_date AND START_LOCAL < end_date_exclusive
    where end_date_exclusive is the calendar day after end_date.
    Preserves 1 row per IMPORT_ALERTS record (including repeated BMUs).
    """
    # Half-open upper bound: next calendar day after end_date
    end_date_str = str(end_date)[:10]
    end_exclusive = (datetime.strptime(end_date_str, "%Y-%m-%d") + timedelta(days=1)).strftime(
        "%Y-%m-%d"
    )

    query = f"""
    SELECT
        a.UNIQUE_ID AS UNIQUE_ID,
        a.BMU_ID AS BMU_ID,
        a.FUEL_TYPE AS FUEL_TYPE,
        a.COUNTERPARTY AS COUNTERPARTY,
        a.START_GMT AS START_GMT,
        a.END_GMT AS END_GMT,
        a.START_LOCAL AS START_LOCAL,
        a.END_LOCAL AS END_LOCAL,
        a.DURATION_MIN AS DURATION_MIN,
        a.COUNT_SP AS COUNT_SP,
        al.ACTIVITY_LOG_ID AS ACTIVITY_LOG_ID,
        al.PARAMETER_BREACHED AS PARAMETER_BREACHED,
        al.RAISE_DATE AS RAISE_DATE,
        al.PERSON_RAISING AS PERSON_RAISING,
        al.NOTIFICATION_SOURCE AS NOTIFICATION_SOURCE,
        al.ACTION_TAKEN AS ACTION_TAKEN,
        al.ANALYSIS_STATUS AS ANALYSIS_STATUS,
        al.INFO_FOR_ANALYST AS INFO_FOR_ANALYST,
        al.REVIEW_COMMENTS AS REVIEW_COMMENTS,
        al.CREATED_DATETIME AS CREATED_DATETIME,
        al.UPDATED_DATETIME AS UPDATED_DATETIME
    FROM {SQL_TABLE_ALERTS} a
    LEFT JOIN {SQL_TABLE_ACTIVITY_LOG} al ON a.UNIQUE_ID = al.ALERT_UNIQUE_ID
    WHERE a.START_LOCAL >= :start_date AND a.START_LOCAL < :end_exclusive
    ORDER BY a.START_LOCAL ASC, a.BMU_ID ASC, CASE WHEN al.ACTIVITY_LOG_ID IS NOT NULL THEN 0 ELSE 1 END ASC
    """
    with get_db(db_path) as conn:
        cursor = conn.execute(query, {"start_date": start_date, "end_exclusive": end_exclusive})
        rows = cursor.fetchall()

        seen_uids = set()
        event_map = {}
        deduped = []

        for r in rows:
            row_dict = dict(r)
            uid = row_dict.get("UNIQUE_ID")
            bmu = str(row_dict.get("BMU_ID") or "")
            start = str(row_dict.get("START_LOCAL") or row_dict.get("START_GMT") or "")
            end = str(row_dict.get("END_LOCAL") or row_dict.get("END_GMT") or "")

            event_key = (bmu, start, end) if (bmu and start) else uid
            has_activity = bool(row_dict.get("ACTIVITY_LOG_ID"))

            if event_key not in event_map:
                event_map[event_key] = row_dict
                deduped.append(row_dict)
                if uid:
                    seen_uids.add(uid)
            else:
                existing_row = event_map[event_key]
                existing_has_activity = bool(existing_row.get("ACTIVITY_LOG_ID"))

                if has_activity and not existing_has_activity:
                    event_map[event_key] = row_dict
                    idx = deduped.index(existing_row)
                    deduped[idx] = row_dict
                    if uid:
                        seen_uids.add(uid)
                elif has_activity and existing_has_activity:
                    cur_updated = str(row_dict.get("UPDATED_DATETIME") or "")
                    ex_updated = str(existing_row.get("UPDATED_DATETIME") or "")
                    if cur_updated > ex_updated:
                        event_map[event_key] = row_dict
                        idx = deduped.index(existing_row)
                        deduped[idx] = row_dict
                        if uid:
                            seen_uids.add(uid)

        return deduped


def get_alert_by_unique_id(
    unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    query = f"""
    SELECT 
        a.UNIQUE_ID AS UNIQUE_ID,
        a.BMU_ID AS BMU_ID,
        a.FUEL_TYPE AS FUEL_TYPE,
        a.COUNTERPARTY AS COUNTERPARTY,
        a.START_GMT AS START_GMT,
        a.END_GMT AS END_GMT,
        a.START_LOCAL AS START_LOCAL,
        a.END_LOCAL AS END_LOCAL,
        a.DURATION_MIN AS DURATION_MIN,
        a.COUNT_SP AS COUNT_SP,
        al.ACTIVITY_LOG_ID AS ACTIVITY_LOG_ID,
        al.PARAMETER_BREACHED AS PARAMETER_BREACHED,
        al.RAISE_DATE AS RAISE_DATE,
        al.PERSON_RAISING AS PERSON_RAISING,
        al.NOTIFICATION_SOURCE AS NOTIFICATION_SOURCE,
        al.ACTION_TAKEN AS ACTION_TAKEN,
        al.ANALYSIS_STATUS AS ANALYSIS_STATUS,
        al.INFO_FOR_ANALYST AS INFO_FOR_ANALYST,
        al.REVIEW_COMMENTS AS REVIEW_COMMENTS,
        al.CREATED_DATETIME AS CREATED_DATETIME,
        al.UPDATED_DATETIME AS UPDATED_DATETIME
    FROM {SQL_TABLE_ALERTS} a
    LEFT JOIN {SQL_TABLE_ACTIVITY_LOG} al ON a.UNIQUE_ID = al.ALERT_UNIQUE_ID
    WHERE a.UNIQUE_ID = :unique_id
    """
    with get_db(db_path) as conn:
        cursor = conn.execute(query, {"unique_id": unique_id})
        row = cursor.fetchone()
        return dict(row) if row else None
