from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.config.constants import SQL_TABLE_ACTIVITY_LOG, SQL_TABLE_ALERTS
from src.repositories.connection import get_db


def ensure_activity_log_table_exists(db_path: Optional[Union[Path, str]] = None) -> None:
    """Ensures the ACTIVITY_LOG table exists.

    Uses SQLite-compatible DDL when running against a SQLite connection (tests /
    local mode) and T-SQL DDL when running against Azure SQL.
    """
    import sqlite3 as _sqlite3

    sqlite_ddl = f"""
    CREATE TABLE IF NOT EXISTS {SQL_TABLE_ACTIVITY_LOG} (
        ACTIVITY_LOG_ID    TEXT NOT NULL PRIMARY KEY,
        ALERT_UNIQUE_ID    TEXT NOT NULL UNIQUE,
        BMU_ID             TEXT,
        PARTY_NAME         TEXT,
        PARAMETER_BREACHED TEXT,
        RAISE_DATE         TEXT,
        START_DATE         TEXT,
        END_DATE           TEXT,
        PERSON_RAISING     TEXT,
        NOTIFICATION_SOURCE TEXT,
        ACTION_TAKEN       TEXT,
        ANALYSIS_STATUS    TEXT,
        INFO_FOR_ANALYST   TEXT,
        REVIEW_COMMENTS    TEXT,
        CREATED_DATETIME   TEXT,
        UPDATED_DATETIME   TEXT
    )
    """

    azure_ddl = f"""
    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'{SQL_TABLE_ACTIVITY_LOG}') AND type in (N'U'))
    BEGIN
        CREATE TABLE {SQL_TABLE_ACTIVITY_LOG} (
            [ACTIVITY_LOG_ID]    VARCHAR(255) NOT NULL PRIMARY KEY,
            [ALERT_UNIQUE_ID]    VARCHAR(255) NOT NULL,
            [BMU_ID]             VARCHAR(100) NULL,
            [PARTY_NAME]         VARCHAR(255) NULL,
            [PARAMETER_BREACHED] VARCHAR(255) NULL,
            [RAISE_DATE]         VARCHAR(50) NULL,
            [START_DATE]         VARCHAR(50) NULL,
            [END_DATE]           VARCHAR(50) NULL,
            [PERSON_RAISING]     VARCHAR(255) NULL,
            [NOTIFICATION_SOURCE] VARCHAR(255) NULL,
            [ACTION_TAKEN]       VARCHAR(255) NULL,
            [ANALYSIS_STATUS]    VARCHAR(50) NULL,
            [INFO_FOR_ANALYST]   NVARCHAR(MAX) NULL,
            [REVIEW_COMMENTS]    NVARCHAR(MAX) NULL,
            [CREATED_DATETIME]   VARCHAR(50) NULL,
            [UPDATED_DATETIME]   VARCHAR(50) NULL,
            CONSTRAINT [UQ_ACTIVITY_LOG_ALERT_UNIQUE_ID] UNIQUE ([ALERT_UNIQUE_ID])
        );

        CREATE INDEX [IX_ACTIVITY_LOG_ANALYSIS_STATUS] ON {SQL_TABLE_ACTIVITY_LOG} ([ANALYSIS_STATUS]);
        CREATE INDEX [IX_ACTIVITY_LOG_PARTY_NAME] ON {SQL_TABLE_ACTIVITY_LOG} ([PARTY_NAME]);
    END
    """

    try:
        with get_db(db_path) as conn:
            if isinstance(conn, _sqlite3.Connection):
                conn.execute(sqlite_ddl)
            else:
                conn.execute(azure_ddl)
    except Exception:
        raise


def get_activity_log_by_alert_id(
    alert_unique_id: str,
    db_path: Optional[Union[Path, str]] = None,
) -> Optional[Dict[str, Any]]:
    query = f"SELECT * FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :alert_unique_id"
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query, {"alert_unique_id": alert_unique_id})
            row = cursor.fetchone()
            return dict(row) if row else None
    except Exception:
        return None


import uuid


def _ensure_valid_uuid(val: Any) -> str:
    """Ensures ACTIVITY_LOG_ID is a valid 36-character UUID string compatible with Azure SQL UNIQUEIDENTIFIER and SQLite TEXT."""
    if not val:
        return str(uuid.uuid4())
    val_str = str(val).strip()
    try:
        return str(uuid.UUID(val_str))
    except Exception:
        return str(uuid.uuid5(uuid.NAMESPACE_DNS, val_str))


def save_activity_log(
    record: Dict[str, Any],
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    """
    Inserts a new ACTIVITY_LOG record or updates an existing record linked to ALERT_UNIQUE_ID.
    Preserves CREATED_DATETIME on update, updates UPDATED_DATETIME.
    Uses transaction management via get_db context manager.
    """
    ensure_activity_log_table_exists(db_path)
    alert_unique_id = record["ALERT_UNIQUE_ID"]

    with get_db(db_path) as conn:
        cursor = conn.execute(
            f"SELECT ACTIVITY_LOG_ID, CREATED_DATETIME FROM {SQL_TABLE_ACTIVITY_LOG} WHERE ALERT_UNIQUE_ID = :id",
            {"id": alert_unique_id},
        )
        existing = cursor.fetchone()

        # Format dates for SQL DATE / DATETIME2 compatibility
        raise_date = str(record["RAISE_DATE"])[:10] if record.get("RAISE_DATE") else None
        start_date = str(record["START_DATE"])[:10] if record.get("START_DATE") else None
        end_date = str(record["END_DATE"])[:10] if record.get("END_DATE") else None
        created_dt = str(record.get("CREATED_DATETIME") or "").replace("T", " ")
        updated_dt = str(record.get("UPDATED_DATETIME") or "").replace("T", " ")

        if existing:
            # Update existing record
            activity_log_id = existing["ACTIVITY_LOG_ID"]
            update_query = f"""
            UPDATE {SQL_TABLE_ACTIVITY_LOG}
            SET PARTY_NAME = :PARTY_NAME,
                PARAMETER_BREACHED = :PARAMETER_BREACHED,
                RAISE_DATE = :RAISE_DATE,
                START_DATE = :START_DATE,
                END_DATE = :END_DATE,
                PERSON_RAISING = :PERSON_RAISING,
                NOTIFICATION_SOURCE = :NOTIFICATION_SOURCE,
                ACTION_TAKEN = :ACTION_TAKEN,
                ANALYSIS_STATUS = :ANALYSIS_STATUS,
                INFO_FOR_ANALYST = :INFO_FOR_ANALYST,
                REVIEW_COMMENTS = :REVIEW_COMMENTS,
                UPDATED_DATETIME = :UPDATED_DATETIME
            WHERE ALERT_UNIQUE_ID = :ALERT_UNIQUE_ID
            """
            params = {
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": raise_date,
                "START_DATE": start_date,
                "END_DATE": end_date,
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "UPDATED_DATETIME": updated_dt,
                "ALERT_UNIQUE_ID": alert_unique_id,
            }
            conn.execute(update_query, params)
            record["ACTIVITY_LOG_ID"] = activity_log_id
            record["CREATED_DATETIME"] = existing["CREATED_DATETIME"]
        else:
            # Insert new record using a valid UUID string for UNIQUEIDENTIFIER
            act_id = _ensure_valid_uuid(record.get("ACTIVITY_LOG_ID") or record["ALERT_UNIQUE_ID"])

            insert_query = f"""
            INSERT INTO {SQL_TABLE_ACTIVITY_LOG} (
                ACTIVITY_LOG_ID,
                ALERT_UNIQUE_ID,
                BMU_ID,
                PARTY_NAME,
                PARAMETER_BREACHED,
                RAISE_DATE,
                START_DATE,
                END_DATE,
                PERSON_RAISING,
                NOTIFICATION_SOURCE,
                ACTION_TAKEN,
                ANALYSIS_STATUS,
                INFO_FOR_ANALYST,
                REVIEW_COMMENTS,
                CREATED_DATETIME,
                UPDATED_DATETIME
            ) VALUES (
                :ACTIVITY_LOG_ID,
                :ALERT_UNIQUE_ID,
                :BMU_ID,
                :PARTY_NAME,
                :PARAMETER_BREACHED,
                :RAISE_DATE,
                :START_DATE,
                :END_DATE,
                :PERSON_RAISING,
                :NOTIFICATION_SOURCE,
                :ACTION_TAKEN,
                :ANALYSIS_STATUS,
                :INFO_FOR_ANALYST,
                :REVIEW_COMMENTS,
                :CREATED_DATETIME,
                :UPDATED_DATETIME
            )
            """

            params = {
                "ACTIVITY_LOG_ID": act_id,
                "ALERT_UNIQUE_ID": alert_unique_id,
                "BMU_ID": record["BMU_ID"],
                "PARTY_NAME": record.get("PARTY_NAME"),
                "PARAMETER_BREACHED": record["PARAMETER_BREACHED"],
                "RAISE_DATE": raise_date,
                "START_DATE": start_date,
                "END_DATE": end_date,
                "PERSON_RAISING": record.get("PERSON_RAISING"),
                "NOTIFICATION_SOURCE": record["NOTIFICATION_SOURCE"],
                "ACTION_TAKEN": record.get("ACTION_TAKEN"),
                "ANALYSIS_STATUS": record.get("ANALYSIS_STATUS"),
                "INFO_FOR_ANALYST": record.get("INFO_FOR_ANALYST"),
                "REVIEW_COMMENTS": record.get("REVIEW_COMMENTS"),
                "CREATED_DATETIME": created_dt,
                "UPDATED_DATETIME": updated_dt,
            }
            conn.execute(insert_query, params)
            record["ACTIVITY_LOG_ID"] = params["ACTIVITY_LOG_ID"]

    return record


def get_all_saved_reviews(
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    query = f"""
    SELECT *
    FROM {SQL_TABLE_ACTIVITY_LOG}
    ORDER BY START_DATE DESC, BMU_ID ASC
    """
    try:
        with get_db(db_path) as conn:
            cursor = conn.execute(query)
            rows = cursor.fetchall()
            return [dict(r) for r in rows]
    except Exception:
        return []


def get_closed_reviews(
    start_date: str,
    end_date: str,
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    """
    Returns persisted closed reviews from ACTIVITY_LOG.

    IMPORT_ALERTS is used to retrieve supplementary display fields via standard LEFT JOIN.
    """
    from datetime import datetime, timedelta

    end_date_str = str(end_date)[:10]
    end_exclusive = (datetime.strptime(end_date_str, "%Y-%m-%d") + timedelta(days=1)).strftime(
        "%Y-%m-%d"
    )

    query = f"""
    SELECT
        al.ALERT_UNIQUE_ID AS UNIQUE_ID,
        al.BMU_ID AS BMU_ID,
        al.PARTY_NAME AS COUNTERPARTY,
        al.ACTION_TAKEN AS ACTION_TAKEN,
        al.ANALYSIS_STATUS AS ANALYSIS_STATUS,
        al.PERSON_RAISING AS PERSON_RAISING,
        al.REVIEW_COMMENTS AS REVIEW_COMMENTS,
        al.CREATED_DATETIME AS CREATED_DATETIME,
        al.UPDATED_DATETIME AS UPDATED_DATETIME,
        a.FUEL_TYPE AS FUEL_TYPE,
        a.START_GMT AS START_GMT,
        a.END_GMT AS END_GMT,
        COALESCE(a.START_LOCAL, al.START_DATE) AS START_LOCAL,
        COALESCE(a.END_LOCAL, al.END_DATE) AS END_LOCAL,
        a.DURATION_MIN AS DURATION_MIN,
        a.COUNT_SP AS COUNT_SP
    FROM {SQL_TABLE_ACTIVITY_LOG} al
    LEFT JOIN {SQL_TABLE_ALERTS} a ON al.ALERT_UNIQUE_ID = a.UNIQUE_ID
    WHERE al.ANALYSIS_STATUS = 'Closed'
      AND COALESCE(a.START_LOCAL, al.START_DATE) >= :start_date
      AND COALESCE(a.START_LOCAL, al.START_DATE) < :end_exclusive
    ORDER BY COALESCE(a.START_LOCAL, al.START_DATE) DESC, al.BMU_ID ASC, al.UPDATED_DATETIME DESC
    """

    with get_db(db_path) as conn:
        cursor = conn.execute(
            query,
            {
                "start_date": start_date,
                "end_exclusive": end_exclusive,
            },
        )
        rows = cursor.fetchall()

        seen_uids = set()
        event_map = {}
        deduped = []

        for r in rows:
            row_dict = dict(r)
            uid = row_dict.get("UNIQUE_ID")
            bmu = str(row_dict.get("BMU_ID") or "")
            start = str(row_dict.get("START_LOCAL") or "")
            end = str(row_dict.get("END_LOCAL") or "")

            event_key = (bmu, start, end) if (bmu and start) else uid

            if event_key not in event_map:
                event_map[event_key] = row_dict
                deduped.append(row_dict)
                if uid:
                    seen_uids.add(uid)
            else:
                existing_row = event_map[event_key]
                cur_updated = str(row_dict.get("UPDATED_DATETIME") or "")
                ex_updated = str(existing_row.get("UPDATED_DATETIME") or "")
                if cur_updated > ex_updated:
                    event_map[event_key] = row_dict
                    idx = deduped.index(existing_row)
                    deduped[idx] = row_dict
                    if uid:
                        seen_uids.add(uid)

        return deduped

