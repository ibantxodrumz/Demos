from datetime import datetime
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Union
from src.config.settings import (
    DEFAULT_NOTIFICATION_SOURCE,
    DEFAULT_PARAMETER_BREACHED,
    LOCAL_ANALYST_NAME,
)
from src.models.activity_log import SaveReviewRequest
from src.repositories import activity_log_repository, alert_repository
from src.services import analytics_service


def save_analyst_review(
    alert_unique_id: str,
    action_taken: str,
    analysis_status: str,
    review_comments: Optional[str] = "",
    analyst_name: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> Dict[str, Any]:
    # 1. Validate inputs via Pydantic model
    validated_req = SaveReviewRequest(
        alert_unique_id=alert_unique_id,
        action_taken=action_taken,
        analysis_status=analysis_status,
        review_comments=review_comments or "",
    )

    # 2. Retrieve authoritative alert record by unique_id from DB
    alert = alert_repository.get_alert_by_unique_id(validated_req.alert_unique_id, db_path=db_path)
    if not alert:
        raise ValueError(f"Alert with UNIQUE_ID '{validated_req.alert_unique_id}' does not exist.")

    # 3. Derive system INFO_FOR_ANALYST
    info_for_analyst = analytics_service.get_aggregated_info_for_analyst(
        bmu_id=alert["BMU_ID"],
        start_gmt=alert["START_GMT"],
        end_gmt=alert["END_GMT"],
        db_path=db_path,
    )

    now_iso = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    today_str = datetime.now().strftime("%Y-%m-%d")
    person_raising = analyst_name if analyst_name else LOCAL_ANALYST_NAME

    # Valid UUID string for UNIQUEIDENTIFIER in Azure SQL and TEXT in SQLite
    valid_act_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, str(alert["UNIQUE_ID"])))

    record_payload = {
        "ACTIVITY_LOG_ID": valid_act_id,
        "ALERT_UNIQUE_ID": alert["UNIQUE_ID"],
        "BMU_ID": alert["BMU_ID"],
        "PARTY_NAME": alert.get("COUNTERPARTY", ""),
        "PARAMETER_BREACHED": alert.get("PARAMETER_BREACHED") or DEFAULT_PARAMETER_BREACHED,
        "RAISE_DATE": today_str,
        "START_DATE": alert.get("START_LOCAL", alert["START_GMT"]),
        "END_DATE": alert.get("END_LOCAL", alert["END_GMT"]),
        "PERSON_RAISING": person_raising,
        "NOTIFICATION_SOURCE": alert.get("NOTIFICATION_SOURCE") or DEFAULT_NOTIFICATION_SOURCE,
        "ACTION_TAKEN": validated_req.action_taken,
        "ANALYSIS_STATUS": validated_req.analysis_status,
        "INFO_FOR_ANALYST": info_for_analyst,
        "REVIEW_COMMENTS": validated_req.review_comments,
        "CREATED_DATETIME": now_iso,
        "UPDATED_DATETIME": now_iso,
    }

    saved_record = activity_log_repository.save_activity_log(record_payload, db_path=db_path)
    return saved_record


def bulk_save_analyst_reviews(
    reviews: List[Dict[str, Any]],
    analyst_name: Optional[str] = None,
    db_path: Optional[Union[Path, str]] = None,
) -> int:
    """
    Saves multiple analyst review decisions in batch.
    """
    saved_count = 0
    for rev in reviews:
        alert_id = rev.get("alert_unique_id") or rev.get("UNIQUE_ID")
        action = rev.get("action_taken") or rev.get("ACTION_TAKEN")
        status = rev.get("analysis_status") or rev.get("ANALYSIS_STATUS") or rev.get("DISPLAY_STATUS")
        comments = rev.get("review_comments") or rev.get("REVIEW_COMMENTS") or ""

        if alert_id and (action or (status and status != "Unreviewed") or comments):
            try:
                save_analyst_review(
                    alert_unique_id=alert_id,
                    action_taken=action or "Monitor Ongoing",
                    analysis_status=status if (status and status != "Unreviewed") else "Open",
                    review_comments=comments,
                    analyst_name=analyst_name,
                    db_path=db_path,
                )
                saved_count += 1
            except Exception:
                pass
    return saved_count


def get_saved_reviews(
    db_path: Optional[Union[Path, str]] = None,
) -> List[Dict[str, Any]]:
    return activity_log_repository.get_all_saved_reviews(db_path=db_path)
