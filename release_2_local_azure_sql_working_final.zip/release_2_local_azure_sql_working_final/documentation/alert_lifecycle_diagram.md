# Alert Lifecycle Diagram

## Full Flow — Read to Save

```mermaid
sequenceDiagram
    actor Analyst
    participant Page as alert_review.py
    participant AS as alert_service
    participant AR as alert_repository
    participant DB as Azure SQL
    participant ALS as analytics_service
    participant AnR as analytics_repository
    participant ALS2 as activity_log_service
    participant ALR as activity_log_repository

    Note over Analyst,DB: PHASE 1 — Load alerts

    Analyst->>Page: selects date range
    Page->>AS: get_alerts_for_period(start, end)
    AS->>AR: get_alerts_by_date_range(start, end)
    AR->>DB: LEFT JOIN IMPORT_ALERTS + ACTIVITY_LOG
    DB-->>AR: rows (ACTIVITY_LOG cols = NULL if unreviewed)
    AR-->>AS: list of dicts
    AS->>AS: derive_review_status() → "Unreviewed"
    AS-->>Page: alerts + summary + filter_options
    Page-->>Analyst: table rendered, row AMBER "Unreviewed"

    Note over Analyst,DB: PHASE 2 — Select alert

    Analyst->>Page: ticks checkbox on ALT-CCGT-001
    Page->>ALS: get_aggregated_info_for_analyst(bmu, start_gmt, end_gmt)
    ALS->>AnR: get_why_values_for_alert(bmu, start_gmt, end_gmt)
    AnR->>DB: SELECT WHY FROM IMPORT_ALERTS_DATA WHERE BMU_ID=...
    DB-->>AnR: ["High Spread", "Price above fuel threshold"]
    AnR-->>ALS: why list
    ALS-->>Page: "High Spread | Price above fuel threshold"
    Page-->>Analyst: details card + INFO_FOR_ANALYST + BMRS link shown

    Note over Analyst,DB: PHASE 3 — Save decision

    Analyst->>Page: fills form + clicks Save + confirms dialog

    alt Case A — OPEN
        Page->>ALS2: save_analyst_review(id, "Monitor Ongoing", "Open", comments)
    else Case B — CLOSED
        Page->>ALS2: save_analyst_review(id, "AutoClose", "Closed", comments)
    end

    ALS2->>ALS2: SaveReviewRequest validates action + status
    ALS2->>AR: get_alert_by_unique_id("ALT-CCGT-001")
    AR->>DB: SELECT ... LEFT JOIN WHERE UNIQUE_ID=...
    DB-->>AR: full alert row
    AR-->>ALS2: alert dict
    ALS2->>ALS: get_aggregated_info_for_analyst(bmu, start_gmt, end_gmt)
    ALS->>AnR: get_why_values_for_alert(...)
    AnR->>DB: SELECT WHY FROM IMPORT_ALERTS_DATA...
    DB-->>AnR: why list
    AnR-->>ALS: why list
    ALS-->>ALS2: "High Spread | Price above fuel threshold"
    ALS2->>ALS2: builds full record_payload with timestamps + analyst name

    ALS2->>ALR: save_activity_log(record_payload)
    ALR->>DB: SELECT FROM ACTIVITY_LOG WHERE ALERT_UNIQUE_ID=...

    alt No existing row → INSERT
        DB-->>ALR: no row found
        ALR->>DB: INSERT INTO ACTIVITY_LOG (...) OUTPUT INSERTED.ACTIVITY_LOG_ID
        DB-->>ALR: generated UUID
    else Existing row → UPDATE
        DB-->>ALR: existing row (CREATED_DATETIME preserved)
        ALR->>DB: UPDATE SET ANALYSIS_STATUS=..., UPDATED_DATETIME=now
        DB-->>ALR: ok
    end

    ALR-->>ALS2: saved record
    ALS2-->>Page: saved record
    Page->>Page: increments store-refresh-signal
    Page->>AS: get_alerts_for_period(...) [triggered by signal]
    AS->>AR: get_alerts_by_date_range(...)
    AR->>DB: LEFT JOIN (now ACTIVITY_LOG row exists)
    DB-->>AR: rows with ANALYSIS_STATUS = "Open" or "Closed"
    AR-->>AS: rows
    AS->>AS: derive_review_status() → "Open" or "Closed"
    AS-->>Page: updated alerts
    Page-->>Analyst: row now BLUE "Open" or GREEN "Closed"
```

---

## Layer Map

```mermaid
graph TD
    DB["🗄️ Azure SQL<br/>IMPORT_ALERTS<br/>IMPORT_ALERTS_DATA<br/>ACTIVITY_LOG (shared)"]
    CONN["connection.py<br/>SQLite or Azure SQL<br/>via DATABASE_MODE env var"]
    REPO["Repositories<br/>alert_repository<br/>analytics_repository<br/>activity_log_repository"]
    MODELS["Models (Pydantic)<br/>AlertModel<br/>ActivityLogModel<br/>SaveReviewRequest + validators"]
    SVC["Services<br/>alert_service<br/>analytics_service<br/>activity_log_service"]
    PAGES["Pages (Dash)<br/>alert_review / analytical_support<br/>open_reviews / closed_reviews<br/>long_run_analytics"]
    COMP["Components<br/>navbar · alert_table"]
    UTILS["Utils<br/>bmrs_links · formatting"]
    ANALYST["👤 Analyst"]

    DB <--> CONN
    CONN <--> REPO
    REPO <--> MODELS
    MODELS <--> SVC
    SVC <--> PAGES
    PAGES <--> COMP
    UTILS --> PAGES
    PAGES <--> ANALYST

    style DB fill:#1e293b,color:#fff
    style CONN fill:#4e0038,color:#fff
    style REPO fill:#6d1a57,color:#fff
    style MODELS fill:#7c3aed,color:#fff
    style SVC fill:#2563eb,color:#fff
    style PAGES fill:#0891b2,color:#fff
    style COMP fill:#0d9488,color:#fff
    style UTILS fill:#64748b,color:#fff
    style ANALYST fill:#16a34a,color:#fff
```

---

## Key Decision Points

```mermaid
flowchart TD
    A([Analyst selects dates]) --> B[update_alert_table callback]
    B --> C[get_alerts_for_period]
    C --> D{ACTIVITY_LOG row\nexists for this alert?}
    D -- No --> E[DISPLAY_STATUS = Unreviewed\nrow AMBER]
    D -- Yes --> F{ANALYSIS_STATUS\nvalue?}
    F -- Open --> G[DISPLAY_STATUS = Open\nrow BLUE]
    F -- Closed --> H[DISPLAY_STATUS = Closed\nrow GREEN]

    E --> I([Analyst ticks checkbox])
    G --> I
    H --> I

    I --> J[handle_alert_selection callback]
    J --> K[get_aggregated_info_for_analyst\nWHY flags from IMPORT_ALERTS_DATA]
    K --> L([Analyst fills form + saves])
    L --> M[save_review_callback]
    M --> N{Fields valid?}
    N -- No --> O[Red error message\nno DB write]
    N -- Yes --> P[save_analyst_review]
    P --> Q[SaveReviewRequest\nPydantic validation]
    Q --> R{action + status\nin controlled vocab?}
    R -- No --> S[ValueError\nno DB write]
    R -- Yes --> T[save_activity_log]
    T --> U{Row exists\nin ACTIVITY_LOG?}
    U -- No --> V[INSERT\nnew row]
    U -- Yes --> W[UPDATE\npreserve CREATED_DATETIME]
    V --> X[refresh-signal++\ntable reloads]
    W --> X
    X --> Y{What was\nANALYSIS_STATUS?}
    Y -- Open --> G
    Y -- Closed --> H
```
