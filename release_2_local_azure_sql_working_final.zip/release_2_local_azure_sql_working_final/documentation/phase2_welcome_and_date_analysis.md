# Analysis: Welcome Page, State Management & Date Freedom

This analysis explores the hidden complexities of the next phase. As you rightly pointed out, simply "adding a welcome page" has deep cascading effects on the sidebar, routing, and how pages maintain state. We also need to fix the hardcoded date constraints before scaling.

---

## Complexity 1: Removing the Workstream Dropdown

**The Current State:**
Right now, `alert_review`, `open_reviews`, `closed_reviews`, `long_run_analytics`, and `import_constraints` all have a `dcc.Dropdown` that allows the user to switch the "Active Workstream Domain". Because the dropdown exists *on the page*, the page's callbacks can easily read its value to know which data to query.

**The Target State:**
The user selects "Import Constraints" on the Welcome Page. They are then taken into the application, and the dropdown is gone from the individual pages. 

**The Challenge: How do the pages know which workstream is active?**
Once we remove the dropdown, we must pass the workstream context to every page. There are two ways to do this in Dash, and we need to choose carefully because it impacts the sidebar:

### Option A: URL Routing (The robust, standard way)
We change the URLs so they include the workstream.
- **Example URLs**: `/import-constraints/alert-review`, `/import-constraints/open-cases`.
- **Pros**: Users can bookmark pages. If a user refreshes the page, the app still knows they are in Import Constraints.
- **Cons**: High complexity for the Sidebar. The sidebar can no longer have static links. The `navbar.py` component must read the current URL, figure out the active workstream, and dynamically generate links for that specific workstream.

### Option B: Session Store (The Dash `dcc.Store` way)
We keep the URLs exactly as they are, but store the user's choice in their browser session.
- **Example URLs**: `/alert-review`, `/open-cases` (same as today).
- **How it works**: Clicking a workstream on the Welcome page writes "IMPORT_CONSTRAINTS" to a hidden `dcc.Store(storage_type='session')`. Every page's callbacks read from this store instead of a dropdown.
- **Pros**: Zero changes needed to the sidebar links. Very easy to implement.
- **Cons**: If a user bookmarks `/open-cases` and opens it in a brand new browser window, the session is empty, and the page won't know which workstream to load (we'd have to redirect them back to the Welcome page).

> **Recommendation**: **Option B (Session Store)** is significantly safer for making it work with what we have *now* without breaking the sidebar. We can implement a fallback: if a user lands on a page and the session store is empty, we automatically redirect them to `/` (Welcome Page).

---

## Complexity 2: The Sidebar

Currently, the sidebar in `navbar.py` has a static list of `dcc.Link` components. 

If we remove the workstream dropdown from the pages, the user needs a way to go back to the Welcome page to switch workstreams.

**Required Changes for the Sidebar:**
1. We need to add a "← Change Workstream" or "Home" link at the top of the sidebar that routes back to `/`.
2. (Optional but recommended): We should pass the active workstream name into the `create_sidebar()` function so the sidebar can display a title like: **"Active: Import Constraints"**. This reminds the user where they are since the dropdown is gone.

---

## Complexity 3: Freeing Up the Dates

**The Current State:**
In `services/alert_service.py`, the function `get_available_time_options()` returns a hardcoded list of Python dictionaries representing exactly 6 months (Jan-Jun 2026) and 26 weeks. This artificially restricts the date pickers.

**The Target State:**
As a daily operational tool, analysts must be able to go back to any historical date (e.g., 2023, 2024).

**The Solution:**
We need to replace the hardcoded lists in `get_available_time_options()` with a dynamic Python generator. 

The new logic should:
1. **Find the bounds**: Read the current real-world date (or query `sp_analytics_repository.get_database_date_bounds()` to find the oldest data we have).
2. **Generate Months**: Programmatically generate a list of dictionaries for every month from the start year up to the current month (e.g., `["Jan 2023", "Feb 2023", ... "Sep 2026"]`).
3. **Generate Weeks**: Programmatically generate ISO weeks (Monday to Sunday) for the same period. Python's `datetime` and `isocalendar()` make this reliable.

This ensures that tomorrow, next month, and next year, the dropdowns will automatically contain the correct weeks and months without any code changes.

---

## Summary of the "Make it work first" Plan

If we want to prove this structure safely with *only* Import Constraints first:

1. **Dates**: Rewrite `get_available_time_options()` to be dynamic (rolling 3 years) instead of hardcoded.
2. **Welcome Page**: Build `welcome.py` at `/` with 5 cards. Clicking "Import Constraints" writes to a `dcc.Store` and navigates to `/alert-review`.
3. **Dropdown Removal**: Delete the "Active Workstream Domain" dropdown from the layouts of all 5 pages.
4. **Callback Updates**: Update all callbacks across the 5 pages to read from the new `dcc.Store` instead of the deleted dropdown.
5. **Sidebar**: Add a "Home" link to `navbar.py` and display the active workstream name.

This approach isolates the complexity. We prove the navigation and state management works flawlessly for one workstream before we ever touch a second one.
