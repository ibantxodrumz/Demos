# Layer Connections

## Connection mechanism: Python `import`

```
app.py
  imports → navbar.py (components)
  imports → dash (framework)

alert_review.py (page)
  imports → alert_service, activity_log_service, analytics_service  (services)
  imports → alert_table (component)
  imports → bmrs_links (utils)
  imports → settings (config)

alert_service.py (service)
  imports → alert_repository  (repository)

activity_log_service.py (service)
  imports → activity_log_repository  (repository)
  imports → alert_repository         (repository — looks up alert before saving)
  imports → analytics_service        (service — generates INFO_FOR_ANALYST at save time)
  imports → SaveReviewRequest model  (models)
  imports → settings                 (config)

analytics_service.py (service)
  imports → analytics_repository  (repository)

alert_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants             (table name strings)

activity_log_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

analytics_repository.py (repository)
  imports → connection.get_db     (connection)
  imports → constants

connection.py
  imports → azure_connection      (Azure-specific driver)
  imports → settings              (reads DATABASE_MODE)
  imports → sqlite3               (Python stdlib)
```

---

## Contract at each boundary

| Boundary | What crosses it |
|---|---|
| Page → Service | function call, simple Python types (str, int, None) |
| Service → Repository | function call, simple Python types |
| Repository → Connection | calls `get_db()` context manager |
| Connection → Database | SQL string + params dict |
| Database → Connection | raw rows |
| Connection → Repository | connection object |
| Repository → Service | list of plain Python `dict` |
| Service → Page | dict or list of dicts |
| Page → Browser | Dash component tree (HTML) |

Nothing exotic crosses any boundary. No classes, no dataframes — plain Python dicts and lists throughout. Exception: `enrich_sp_data()` works internally with a pandas DataFrame but returns dicts to the page.

---

## Flow diagram

```mermaid
graph LR
    A[Page] -->|"calls f(str, str)"| B[Service]
    B -->|"calls f(str, str)"| C[Repository]
    C -->|"get_db()"| D[Connection]
    D -->|SQL| E[(Database)]
    E -->|raw rows| D
    D -->|conn object| C
    C -->|list of dict| B
    B -->|dict| A

    style A fill:#0891b2,color:#fff
    style B fill:#2563eb,color:#fff
    style C fill:#6d1a57,color:#fff
    style D fill:#4e0038,color:#fff
    style E fill:#1e293b,color:#fff
```

---

## The one exception

`activity_log_service` calls both a repository **and** another service (`analytics_service`). Intentional — saving a review needs WHY evidence from analytics_service. Calling a service is cleaner than duplicating the logic in the repository.

---

## Why this matters

Because each layer only knows its immediate neighbour:

- Swap `connection.py` → different database, nothing else changes
- Swap a repository query → different SQL, service doesn't care
- Swap a page layout → different UI, service doesn't care
- Add a new service function → page calls it, repository stays untouched
