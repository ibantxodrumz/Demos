# Classes & Functions Inventory

**6 classes · ~55 public functions** (plus ~10 inner helper functions)

---

## Classes

| Class | File | Docstring |
|---|---|---|
| `AzureRow` | `repositories/azure_connection.py` | Row object that supports both dict access and integer index access |
| `AzureCursorWrapper` | `repositories/azure_connection.py` | Cursor wrapper translating SQLite named params (`:name`) to pyodbc positional params (`?`) and wrapping rows in AzureRow dicts |
| `SqliteCompatibleAzureConnectionWrapper` | `repositories/azure_connection.py` | Connection wrapper providing a sqlite3-compatible interface for pyodbc |
| `AlertModel` | `models/alert.py` | Pydantic schema for an alert window record from IMPORT_ALERTS + ACTIVITY_LOG join |
| `ActivityLogModel` | `models/activity_log.py` | Pydantic schema for an ACTIVITY_LOG record |
| `SaveReviewRequest` | `models/activity_log.py` | Validated analyst review input — enforces controlled action and status vocabularies |

---

## Functions by File

### `repositories/connection.py`
| Function | Docstring |
|---|---|
| `get_connection(db_path)` | Returns a SQLite or Azure SQL connection based on DATABASE_MODE env var |
| `get_db(db_path)` | Context manager — auto-commit, auto-rollback, auto-close |

### `repositories/azure_connection.py`
| Function | Docstring |
|---|---|
| `get_access_token()` | Fetch an access token for Azure SQL with a 55-minute in-memory cache |
| `pick_odbc_driver()` | Prefer ODBC Driver 18, fallback to Driver 17 if installed |
| `get_azure_connection(server, database)` | Creates a pyodbc connection to Azure SQL wrapped for SQLite interface compatibility |

### `repositories/alert_repository.py`
| Function | Docstring |
|---|---|
| `get_alerts_by_date_range(start_date, end_date)` | LEFT JOIN IMPORT_ALERTS + ACTIVITY_LOG for a date range using half-open interval |
| `get_alert_by_unique_id(unique_id)` | Same LEFT JOIN for a single alert by UNIQUE_ID |

### `repositories/analytics_repository.py`
| Function | Docstring |
|---|---|
| `get_sp_evidence_for_alert(bmu_id, start_gmt, end_gmt)` | Retrieve settlement-period evidence rows from IMPORT_ALERTS_DATA for a specific alert window |
| `get_why_values_for_alert(bmu_id, start_gmt, end_gmt)` | Retrieve distinct, non-null WHY explanation strings for an alert window |

### `repositories/activity_log_repository.py`
| Function | Docstring |
|---|---|
| `ensure_activity_log_table_exists(db_path)` | Creates ACTIVITY_LOG table if missing — uses SQLite or Azure DDL based on connection type |
| `get_activity_log_by_alert_id(alert_unique_id)` | Fetch single ACTIVITY_LOG row by ALERT_UNIQUE_ID |
| `save_activity_log(record)` | Upsert — INSERT if no row exists, UPDATE preserving CREATED_DATETIME if row exists |
| `get_all_saved_reviews()` | Return all ACTIVITY_LOG rows ordered by date |
| `get_closed_reviews(start_date, end_date)` | Return Closed reviews in a date range (Azure SQL OUTER APPLY syntax) |

### `repositories/sp_analytics_repository.py`
| Function | Docstring |
|---|---|
| `get_sp_data_for_period(start_date, end_date)` | Retrieve all settlement period rows from IMPORT_ALERTS_DATA for a date range |
| `get_database_date_bounds()` | Retrieve MIN and MAX LOCAL_DATETIME present in IMPORT_ALERTS_DATA |

---

### `services/alert_service.py`
| Function | Docstring |
|---|---|
| `derive_review_status(row)` | NULL/empty ANALYSIS_STATUS → "Unreviewed"; otherwise pass through |
| `get_alerts_for_period(start, end, bmu_f, party_f, fuel_f, status_f)` | Orchestrates alert retrieval — calls repo, adds DISPLAY_STATUS, filters, counts, returns |
| `get_alert_by_id(unique_id)` | Retrieve single alert with DISPLAY_STATUS derived |
| `get_available_time_options()` | Static structured list of available weeks and months for date picker dropdowns |
| `get_reviews_by_status_for_period(target_status, ...)` | Alerts filtered by Open or Closed status, with optional action filter on top |

### `services/analytics_service.py`
| Function | Docstring |
|---|---|
| `parse_why(why_str)` | Splits pipe-delimited WHY string into (conditions, details) tuple |
| `get_behaviour_class(n_cond_true)` | Maps N_CONDITIONS_TRUE integer to behaviour class string |
| `enrich_sp_data(df)` | Normalises types, adds BEHAVIOUR_CLASS, parses WHY, calculates IMPACT_C1/C2/C3/SP |
| `get_aggregated_info_for_analyst(bmu_id, start_gmt, end_gmt)` | Joins WHY strings from all SPs in alert window into single pipe-delimited string |
| `get_alert_evidence_payload(bmu_id, start_gmt, end_gmt)` | Full evidence package: enriched SP records + summary metrics dict |
| *(inner)* `calc_c1(row)` | C1 impact: max(SPREAD − MED_SPREAD_UNCON, 0) × volume |
| *(inner)* `calc_c2(row)` | C2 impact: max(OFFER_PRICE − THR_FUEL, 0) × volume |
| *(inner)* `calc_c3(row)` | C3 impact: max(SPREAD − (MED_SPREAD_UNCON + 30), 0) × volume |

### `services/sp_analytics_service.py`
| Function | Docstring |
|---|---|
| `get_database_date_bounds()` | Retrieve minimum and maximum alert dates from database |
| `get_behaviour_class(row)` | Classifies a constrained SP based on the ensemble rule (row-level version) |
| `parse_why(why_str)` | Splits detect-reason string into summary conditions and expanded details |
| `preprocess_data(raw_df)` | Standardises data types, normalises Azure DECIMAL values, adds BEHAVIOUR_CLASS |
| `enrich_alerts_with_impact(alerts_df)` | Calculates per-SP financial impact per flag based on threshold deviations |
| `infer_alerts_windows(alerts_df)` | Groups individual ensemble SPs into continuous temporal alert windows/episodes |
| `get_sp_workspace_data(start_date, end_date)` | High-level: fetches SP data, preprocesses, enriches, infers windows, returns full workspace |
| *(inner)* `calc_c1(r)` | C1 impact calculation |
| *(inner)* `calc_c2(r)` | C2 impact calculation |
| *(inner)* `calc_c3(r)` | C3 impact calculation |

### `services/activity_log_service.py`
| Function | Docstring |
|---|---|
| `save_analyst_review(alert_id, action, status, comments)` | Full save pipeline: validate → lookup alert → generate INFO_FOR_ANALYST → stamp → write |
| `bulk_save_analyst_reviews(reviews)` | Saves multiple review decisions in batch, continues on individual failure |
| `get_saved_reviews()` | Returns all saved reviews from ACTIVITY_LOG |

### `services/long_run_service.py`
| Function | Docstring |
|---|---|
| `get_long_run_counterparty_stats(start, end, threshold_volume, threshold_impact_gbp, ...)` | Calculates long-run counterparty statistics using ensemble SPs for volume/impact and alert windows for duration metrics |

---

### `components/navbar.py`
| Function | Docstring |
|---|---|
| `create_header()` | Creates the NESO top header bar with logo and platform title |
| `create_sidebar()` | Creates the NESO plum navigation sidebar with page links |
| `create_navbar()` | Backward-compatible wrapper returning top header bar |

### `components/alert_table.py`
| Function | Docstring |
|---|---|
| `create_alert_table(alert_data)` | Builds the Dash DataTable with multi-select checkboxes, status colouring, and NESO brand styles |

---

### `pages/alert_review.py` — callbacks
| Function | Docstring |
|---|---|
| `handle_alert_review_dates(week_val, month_val, store_data)` | Syncs date pickers when a week or month preset is selected |
| `update_operational_date_store_from_alert_review(start_d, end_d)` | Persists selected dates to session store for cross-page sharing |
| `fetch_and_filter_alerts(start_date, end_date, ...)` | Main callback: loads and filters alert table + KPI cards on date/filter/refresh change |
| `handle_alert_selection(selected_rows, alerts_data)` | Handles checkbox selection — single row: details + links; multi: batch mode |
| `save_review_callback(...)` | Validates fields, calls save service, increments refresh signal |

### `pages/analytical_support.py` — callbacks
| Function | Docstring |
|---|---|
| `render_analytical_support_page(search_query)` | Loads and renders SP evidence table, metrics, and Plotly charts for a given alert |

### `pages/open_reviews.py` — callbacks
| Function | Docstring |
|---|---|
| `handle_open_review_dates(week_val, month_val, store_data)` | Syncs date pickers on preset selection |
| `update_operational_date_store_from_open(start_d, end_d)` | Persists dates to session store |
| `update_open_reviews(start_date, end_date, ...)` | Loads Open-status alerts for the period |
| `handle_open_alert_selection(selected_rows, alerts_data)` | Selection handler for open reviews table |
| `save_open_review_callback(...)` | Save pipeline for open reviews page |

### `pages/closed_reviews.py` — callbacks
| Function | Docstring |
|---|---|
| `handle_closed_review_dates(...)` | Syncs date pickers on preset selection |
| `update_closed_date_store(start_d, end_d)` | Persists dates to closed-reviews session store |
| `update_closed_reviews(start_date, end_date, ...)` | Loads Closed-status reviews for the period |

### `pages/long_run_analytics.py` — callbacks
| Function | Docstring |
|---|---|
| `handle_longrun_dates(...)` | Syncs date controls on preset selection |
| `update_longrun_analytics(...)` | Loads counterparty statistics and renders long-run dashboard |

### `pages/import_constraints.py` — callbacks (analytical dashboards)
| Function | Docstring |
|---|---|
| `toggle_ic_date_selection_visibility(tab_value)` | Shows/hides date controls based on active tab |
| `sync_ic_date_controls(...)` | Synchronises all date input variants (single day, range, week, month presets) |
| `render_ic_tab_content(tab_value, start_date, end_date)` | Routes to the correct tab renderer based on active tab |
| `render_bmu_deep_dive(selected_bmu, start_date, end_date)` | Renders BMU-level SP evidence and price charts |
| `render_t1_ex_bmu_table(...)` | Renders T1 extended BMU summary table |
| `render_t1_bmu_summary_table(...)` | Renders T1 BMU summary stats table |
| `render_t2_analyst_intelligence(...)` | Renders T2 analyst intelligence view with fuel and BMU filters |
| `update_t3_quadrant_graph(...)` | Renders T3 spread vs price quadrant scatter chart |
| `update_t5_fuel_spread_graph(...)` | Renders T5 fuel-level spread distribution chart |
| `update_t5_bmu_drilldown_graph(...)` | Renders T5 BMU drilldown spread chart |
| `update_t5_heatmap_graph(...)` | Renders T5 behaviour class heatmap |
| `update_t6_counterparty_intelligence(...)` | Renders T6 counterparty intelligence panel |

---

### `utils/bmrs_links.py`
| Function | Docstring |
|---|---|
| `get_bmrs_bmu_url(bmu_id, start_gmt)` | Generates Elexon BMRS link scoped to the UTC day of the alert |
| `get_bmrs_remit_url(bmu_id)` | Generates Elexon REMIT portal link for a BMU |

### `utils/formatting.py`
| Function | Docstring |
|---|---|
| `format_currency(value)` | Format float as £ GBP string |
| `format_number(value)` | Format number with thousand separators |

---

## Totals

| Type | Count |
|---|---|
| Classes | 6 |
| Public functions | ~55 |
| Inner helper functions | ~10 |
| Dash callbacks (are functions) | included in above |
| **Total** | **~65** |
