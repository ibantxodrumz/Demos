# Import Constraints Local Dash Prototype

A local **Dash & SQLite** operational monitoring workspace reproducing the Import Constraints Excel monitoring workflow.

---

## Purpose

This prototype proves that:
1. **Excel can be replaced** as the operational interface for Import Constraints monitoring.
2. Monitoring alerts can be retrieved from a local SQL database (`prototype.db`).
3. Analysts can review multiple alerts over weekly periods.
4. Multiple alerts for the same BMU remain distinct, selectable records.
5. Analytical support & investigation evidence can be delivered directly through Dash.
6. Analyst decisions, actions, and comments can be persisted to SQL (`ACTIVITY_LOG`).
7. Saved reviews remain available for historical review and statistics across application restarts.
8. The implementation cleanly separates Dash UI from database persistence for future transition to **Azure SQL** without altering Dash application logic.

---

## Architecture Overview

```
Dash Multi-Page Application (Analyst Workspace)
  │
  ├── Alert Review Queue (Queue, Filters, Decision Panel, Save Action)
  ├── Analytical Support (SP Evidence Table, Price/Spread Charts, BMRS Links)
  └── Saved Reviews (Historical ACTIVITY_LOG Audit Trail)
  ↓
Services Layer (alert_service, activity_log_service, analytics_service)
  ↓
Repositories Layer (alert_repository, activity_log_repository, analytics_repository)
  ↓
SQLite System of Record (import_constraints_local_prototype/data/prototype.db)
```

---

## Folder Structure

```
.
├── pyproject.toml                         # uv & project configuration
├── README.md                              # Application documentation & setup
├── src/                                   # Application source code
│   ├── app.py                             # Dash entry point & layout
│   ├── config/
│   │   └── settings.py                    # Environment settings & controlled values
│   ├── pages/
│   │   ├── alert_review.py                # Main alert queue & decision capture page
│   │   ├── analytical_support.py          # Settlement period evidence & Plotly charts
│   │   └── saved_reviews.py               # Historical ACTIVITY_LOG audit trail page
│   ├── components/
│   │   ├── navbar.py                      # Top navigation bar component
│   │   └── alert_table.py                 # Queue DataTable component
│   ├── services/
│   │   ├── alert_service.py               # Alert retrieval & filtering service
│   │   ├── analytics_service.py           # Evidence payload & impact calculator
│   │   └── activity_log_service.py        # Decision persistence & validation service
│   ├── repositories/
│   │   ├── connection.py                  # SQLite connection helper (foreign keys enabled)
│   │   ├── alert_repository.py            # Parameterised queries for IMPORT_ALERTS
│   │   ├── analytics_repository.py        # Parameterised queries for IMPORT_ALERTS_DATA
│   │   └── activity_log_repository.py    # Parameterised queries for ACTIVITY_LOG
│   ├── models/
│   │   ├── alert.py                       # Alert Pydantic schema
│   │   └── activity_log.py                # ActivityLog & validation schema
│   ├── charts/
│   │   └── analytics_charts.py            # Plotly price, spread, & condition figure builders
│   └── utils/
│       ├── formatting.py                  # Currency, number, and date formatters
│       └── bmrs_links.py                  # Elexon BMRS portal link generator
├── tests/                                 # Automated pytest suite
│   ├── test_database.py                   # DDL and check constraint tests
│   ├── test_alert_repository.py           # Demonstration week & repeated BMU tests
│   ├── test_analytics_repository.py       # Evidence query & payload tests
│   └── test_activity_log_repository.py    # Persistence & INSERT/UPDATE tests
└── import_constraints_local_prototype/
    ├── data/
    │   ├── IMPORT_ALERTS_DATA.csv         # 6 months SP analytical data
    │   ├── IMPORT_ALERTS.csv              # Alert windows
    │   ├── ACTIVITY_LOG.csv               # Empty template
    │   └── prototype.db                   # Local SQLite database
    ├── sql/
    │   ├── schema.sql                     # SQLite DDL
    │   └── queries.sql                    # Parity queries
    └── scripts/
        └── initialise_database.py         # DB reset script
```

---

## Local Setup & Run Commands

### Prerequisites
- Python >= 3.10 (Tested on Python 3.11 with [uv](https://github.com/astral-sh/uv))

### 1. Install Dependencies
```bash
uv sync
```

### 2. Initialise / Reset the SQLite Database
```bash
uv run python import_constraints_local_prototype/scripts/initialise_database.py
```

> ⚠️ **Warning**: Running the initialisation script resets `prototype.db` and deletes locally saved `ACTIVITY_LOG` reviews.

### 3. Start the Dash Application
```bash
uv run python -m src.app
```
Open your browser at: `http://127.0.0.1:8050`

### 4. Run Automated Test Suite
```bash
uv run pytest -v
```

### 5. Code Formatting Check
```bash
uv run black --check src tests import_constraints_local_prototype/scripts
```

---

## Demonstration Weeks

Use these periods to test alert retrieval and verify repeated BMU handling:

- **Demonstration Week 1**: `2026-02-02` to `2026-02-08`
  - Expected repeated BMU scenarios: `SYN-GAS-01`, `SYN-CCGT-01`, `SYN-IC-01`
- **Demonstration Week 2**: `2026-05-04` to `2026-05-10`
  - Expected repeated BMU scenarios: `SYN-GAS-01`, `SYN-CCGT-02`, `SYN-GAS-02`

---

## Database Explanation

- **`IMPORT_ALERTS_DATA`**: 6 months of static synthetic settlement-period records (includes `ENSEMBLE`, breach conditions, and `WHY` strings).
- **`IMPORT_ALERTS`**: Pre-collapsed alert windows created from consecutive `ENSEMBLE=1` settlement periods.
- **`ACTIVITY_LOG`**: Persistence table for analyst reviews. Initially empty after reset; written to when an analyst saves a review in Dash.

---

## System Info vs Human Comments Separation

- **`INFO_FOR_ANALYST`**: System-generated summary derived deterministically from SP-level `WHY` breach flags across the alert window.
- **`REVIEW_COMMENTS`**: Human-authored input entered by the analyst.
- The application guarantees that system-generated text is never stored in `REVIEW_COMMENTS` or labeled as analyst remarks.

---

## Assumptions and Known Limitations

1. **Local Identity**: Analyst identity defaults to environment variable `LOCAL_ANALYST_NAME` or `"Local Prototype Analyst"`. (No Entra ID / AAD local dependency).
2. **Comment History**: The prototype updates single `REVIEW_COMMENTS` per `ALERT_UNIQUE_ID` in place per the current schema contract. Full immutable comment audit history is deferred for future Azure SQL platform phases.
3. **Azure Migration**: Repositories isolate all SQLite queries. Transitioning to Azure SQL requires updating repository connection strings without changing Dash pages or services.
