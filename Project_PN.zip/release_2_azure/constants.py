# constants.py - Configuration for PN Accuracy Dashboard Release 2


ACCOUNT_URL = "https://datalake.blob.core.windows.net"
CONTAINER_NAME = "pn-accuracy-2025"

ANNUAL_BLOB = "internal/annual_summary_2025.csv"
MONTHLY_BLOB = "internal/monthly_summary_2025.csv"


# --- Local Configuration ---
LOCAL_INPUT_DIR = "inputs"

# --- App Settings ---
VERSION = "2.0 (Hybrid Cloud Architecture)"
DEFAULT_ANNUAL_PATTERN = "annual_summary"
DEFAULT_MONTHLY_PATTERN = "monthly_summary"
