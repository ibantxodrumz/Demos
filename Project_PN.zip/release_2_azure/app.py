import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

import constants
import azure_utils
import local_utils


# ------------------------------------------------------------------
# Page config
# ------------------------------------------------------------------
st.set_page_config(
    page_title=f"PN Accuracy Dashboard {constants.VERSION}",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ------------------------------------------------------------------
# Sidebar controls (IMPORTANT: clear both caches)
# ------------------------------------------------------------------
st.sidebar.title("Data source")

if st.sidebar.button("🔄 Refresh (clear cache)", key="clear_cache_all"):
    st.cache_data.clear()
    st.cache_resource.clear()
    st.rerun()


# ------------------------------------------------------------------
# Styling helper
# ------------------------------------------------------------------
def force_light_chart(fig):
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(color="#000000"),
        xaxis=dict(gridcolor="#e5e7eb", linecolor="#000000"),
        yaxis=dict(gridcolor="#e5e7eb", linecolor="#000000"),
    )
    return fig


# ------------------------------------------------------------------
# Data processing
# ------------------------------------------------------------------
def add_size_category(df):
    def get_size_basis(row):
        cap = row.get("installedCapacity_mwh", 0)
        return cap if pd.notnull(cap) and cap > 0 else row.get("CapacityCalibrated", 0)

    df["SizeBasis"] = df.apply(get_size_basis, axis=1)

    def categorize(x):
        if x < 50:
            return "Small (<50MW)"
        elif x < 100:
            return "Medium (50-100MW)"
        return "Large (>100MW)"

    df["SizeCategory"] = df["SizeBasis"].apply(categorize)
    return df


@st.cache_data
def process_raw_data(df_annual_raw, df_monthly_raw):
    # ---- Annual ----
    df_annual = df_annual_raw.copy()
    df_annual["BMU"] = df_annual["nationalGridBmUnit"].astype(str)
    df_annual["Fuel"] = df_annual["Fuel_type"].astype(str)

    num_cols_annual = [
        "PNLevel",
        "MELLevel",
        "MILLevel",
        "BidVolume",
        "OfferVolume",
        "Metered",
        "ExpectOT",
        "CapacityCalibrated",
        "NetError",
        "ABSError",
        "installedCapacity_mwh",
        "A_NetError%",
        "A_ABS_NetError%",
    ]

    for c in num_cols_annual:
        if c in df_annual.columns:
            df_annual[c] = pd.to_numeric(df_annual[c], errors="coerce").fillna(0)

    df_annual = add_size_category(df_annual)

    # ---- Monthly ----
    df_monthly = df_monthly_raw.copy()

    def parse_ym(x):
        try:
            y, m = str(x).split("-")
            return datetime(int(y), int(m), 1)
        except Exception:
            return pd.NaT

    df_monthly["YearMonthObj"] = df_monthly["year_month"].apply(parse_ym)
    df_monthly["MonthName"] = df_monthly["YearMonthObj"].dt.month_name()
    df_monthly["BMU"] = df_monthly["nationalGridBmUnit"].astype(str)
    df_monthly["Fuel"] = df_monthly["Fuel_type"].astype(str)

    num_cols_monthly = [
        "PNLevel",
        "MELLevel",
        "MILLevel",
        "BidVolume",
        "OfferVolume",
        "Metered",
        "ExpectOT",
        "CapacityCalibrated",
        "NetError",
        "ABSError",
        "installedCapacity_mwh",
        "M_NetError%",
        "M_ABS_NetError%",
    ]

    for c in num_cols_monthly:
        if c in df_monthly.columns:
            df_monthly[c] = pd.to_numeric(df_monthly[c], errors="coerce").fillna(0)

    # ---- P90 + attention ----
    p90 = (
        df_monthly.groupby("BMU")["M_ABS_NetError%"]
        .quantile(0.9)
        .reset_index(name="P90_monthly_error")
    )

    df_annual = df_annual.merge(p90, on="BMU", how="left").fillna(0)
    df_annual["NeedsAttention"] = (df_annual["A_ABS_NetError%"] >= 25) | (
        df_annual["P90_monthly_error"] >= 25
    )

    return df_annual, df_monthly


# ------------------------------------------------------------------
# DATA LOADING (Azure first, Local fallback)
# ------------------------------------------------------------------
with st.spinner("Loading data from Azure (will open browser sign-in if needed)..."):
    df_annual_raw, df_monthly_raw, err = azure_utils.load_annual_and_monthly()

if err:
    st.sidebar.warning(
        "Azure sign-in may have succeeded, but loading the Azure CSVs failed.\n\n"
        f"Reason:\n{err}\n\n"
        "Falling back to local files."
    )
    local_files = local_utils.list_local_csv_files()
    if not local_files:
        st.error("Azure failed and no local CSV files were found.")
        st.stop()

    annual_path = next(f for f in local_files if "annual" in f.lower())
    monthly_path = next(f for f in local_files if "monthly" in f.lower())

    df_annual_raw = local_utils.load_local_file_to_df(annual_path)
    df_monthly_raw = local_utils.load_local_file_to_df(monthly_path)

    st.sidebar.info("Data source: Local filesystem")
else:
    st.sidebar.success("Data source: Azure Blob Storage")


# ------------------------------------------------------------------
# PROCESS
# ------------------------------------------------------------------
df_annual_raw, df_monthly_raw = process_raw_data(df_annual_raw, df_monthly_raw)

# ------------------------------------------------------------------
# FILTERS
# ------------------------------------------------------------------
st.sidebar.markdown("---")
st.sidebar.subheader("Filters")

fuels = sorted(df_annual_raw["Fuel"].unique())
selected_fuels = st.sidebar.multiselect("Fuel", fuels, fuels, key="fuel_filter")

df_annual = df_annual_raw[df_annual_raw["Fuel"].isin(selected_fuels)]
df_monthly = df_monthly_raw[df_monthly_raw["Fuel"].isin(selected_fuels)]

# ------------------------------------------------------------------
# UI
# ------------------------------------------------------------------
tabs = st.tabs(["🚀 Executive Summary", "📉 Trends", "📥 Exports"])

with tabs[0]:
    st.title("Performance Executive Summary")
    k1, k2, k3 = st.columns(3)
    k1.metric("Median Error %", f"{df_annual['A_ABS_NetError%'].median():.2f}%")
    k2.metric("P90 Error %", f"{df_annual['A_ABS_NetError%'].quantile(0.9):.2f}%")
    k3.metric("BMU count", len(df_annual))

with tabs[1]:
    trend = df_monthly.groupby("MonthName")["M_ABS_NetError%"].median().reset_index()
    fig = px.line(trend, x="MonthName", y="M_ABS_NetError%", markers=True)
    # ✅ streamlit change: use width instead of use_container_width
    st.plotly_chart(force_light_chart(fig), width="stretch")

with tabs[2]:
    st.download_button(
        "Download annual CSV",
        df_annual.to_csv(index=False),
        "processed_annual.csv",
        "text/csv",
        key="dl_annual",
    )
    st.download_button(
        "Download monthly CSV",
        df_monthly.to_csv(index=False),
        "processed_monthly.csv",
        "text/csv",
        key="dl_monthly",
    )
