import io
import socket
import pandas as pd
import streamlit as st

from azure.identity import InteractiveBrowserCredential
from azure.storage.blob import BlobServiceClient

from constants import ACCOUNT_URL, CONTAINER_NAME, ANNUAL_BLOB, MONTHLY_BLOB


def _resolves(host: str) -> bool:
    try:
        socket.getaddrinfo(host, 443)
        return True
    except OSError:
        return False


def _pick_account_url() -> str:
    """
    Try public endpoint first. If it doesn't resolve on the VPN/DNS,
    try the common private endpoint hostname form:
      <account>.privatelink.blob.core.windows.net
    """
    public_host = ACCOUNT_URL.replace("https://", "").split("/")[0]
    if _resolves(public_host):
        return ACCOUNT_URL

    if public_host.endswith(".blob.core.windows.net"):
        priv_host = public_host.replace(
            ".blob.core.windows.net", ".privatelink.blob.core.windows.net"
        )
        if _resolves(priv_host):
            return f"https://{priv_host}"

    return ACCOUNT_URL


@st.cache_resource(ttl=3300)
def get_blob_service_client():
    # ✅ Always interactive web sign-in when needed
    credential = InteractiveBrowserCredential()

    account_url = _pick_account_url()

    return BlobServiceClient(
        account_url=account_url,
        credential=credential,
    )


def _load_blob_to_df(blob_name: str) -> pd.DataFrame:
    client = get_blob_service_client()
    container_client = client.get_container_client(CONTAINER_NAME)
    blob_client = container_client.get_blob_client(blob_name)

    stream = io.BytesIO()
    blob_client.download_blob().readinto(stream)
    stream.seek(0)

    return pd.read_csv(stream)


def load_annual_and_monthly():
    try:
        df_annual = _load_blob_to_df(ANNUAL_BLOB)
        df_monthly = _load_blob_to_df(MONTHLY_BLOB)
        return df_annual, df_monthly, None
    except Exception as e:
        return None, None, str(e)
